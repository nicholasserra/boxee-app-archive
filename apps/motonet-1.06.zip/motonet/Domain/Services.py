
class Session(object):
	def __init__(self, authenticationApi, customerStorage):
		self._authenticationApi = authenticationApi
		self._customerStorage = customerStorage
	
	def IsSignedIn(self):
		return self._customerStorage.HasCustomer()
	
	def SignIn(self, username, password):
		
		serviceReply = self._authenticationApi.SignIn(username, password)
		
		if serviceReply.Successful:
			self._customerStorage.Save(serviceReply.Customer)
		else:
			raise Exception("The email address or password you entered is incorrect.")

	def SignOut(self):
		
		self._customerStorage.Clear()
		
	def SignedInCustomer(self):
		return self._customerStorage.Get()

