import UI.Windows
import Domain.Factories
import mc
import time

def ApplicationStart():

	session = Domain.Factories.CreateSession()
	
	try:
		
		if session.IsSignedIn():
			UI.Windows.Home().SetSignedInState(True)
			LoadAllVideos()
		else:
			UI.Windows.Home().SetSignedInState(False)
			UI.Windows.Home().EmailAddress().SetFocus()
			
	except Exception, e:
		mc.ShowDialogOk("Unable to open session.", str(e))	

def SignIn():

	mc.ShowDialogWait()
	
	try:
		try:
			session = Domain.Factories.CreateSession()
				
			homeWindow = UI.Windows.Home()
			username = homeWindow.EmailAddress().GetText().strip()
			password = homeWindow.Password().GetText().strip()
			
			if len(username) == 0:
				mc.ShowDialogOk("Unable to login.", "Please enter an email address to login.")
				homeWindow.EmailAddress().SetFocus()	
				return
			
			if len(password) == 0:
				mc.ShowDialogOk("Unable to login.", "Please enter a password to login.")
				homeWindow.Password().SetFocus()	   
				return
			
			session.SignIn(username, password)
	
			UI.Windows.Home().SetSignedInState(True)
			ReLoadAllVideos()
			UI.Windows.Home().VideoList().SetFocus()
	
		except Exception, e:
			mc.ShowDialogOk("Unable to login.", str(e))	

	finally:
		mc.HideDialogWait()

def SignOut():

	mc.ShowDialogWait()
	session = Domain.Factories.CreateSession()
	
	try:

		session.SignOut()
		mc.ShowDialogNotification("Successfully logged out.")

		UI.Windows.Home().SetSignedInState(False)
		UI.Windows.Home().EmailAddress().SetFocus()

	except Exception, e:
		mc.ShowDialogOk("Unable to login.", str(e))	

	mc.HideDialogWait()

def ClearAllViewSelectedState():
	homeWindow = UI.Windows.Home()
	homeWindow.ViewAllSelectedImage().SetVisible(False)
	homeWindow.ViewFavouritesSelectedImage().SetVisible(False)
	homeWindow.ViewRecentlyWatchedSelectedImage().SetVisible(False)

def LoadAllVideos():
	
	time.sleep(1)
	
	if not UI.Windows.Home().HasVideosListed() and UI.Windows.Home().ViewAllSelectedImage().IsVisible():
		ReLoadAllVideos()
		UI.Windows.Home().VideoList().SetFocus()

def ReLoadAllVideos():
	LoadVideoList("rss://api.nodplatform.com/boxee/feed.xml?site=moto&customer=%s", UI.Windows.Home().ViewAllSelectedImage())

def LoadFavouriteVideos():
	LoadVideoList("rss://api.nodplatform.com/boxee/favorites.xml?site=moto&customer=%s", UI.Windows.Home().ViewFavouritesSelectedImage())

def LoadRecentlyWatchedVideos():
	LoadVideoList("rss://api.nodplatform.com/boxee/recent.xml?site=moto&customer=%s", UI.Windows.Home().ViewRecentlyWatchedSelectedImage())
	
def LoadVideoList(feedUri, selectedControl):
	
	try:
		mc.ShowDialogWait()
	
		try:
			ClearAllViewSelectedState()
			selectedControl.SetVisible(True)
			
			UI.Windows.Home().SaveState()
			
			session = Domain.Factories.CreateSession()
			feedId = session.SignedInCustomer().FeedId

			videoList = UI.Windows.Home().VideoList()
			videoList.SetContentURL(feedUri % feedId)
			
			#	give the list some time to load the feed
			time.sleep(1)
			#mc.ShowDialogOk("Debug.", "loaded")	
			#	TODO: set or clear state here? to prevent the video list disappearing after returning after the screensaver
			#videoList.SetFocus()
			
	
		except Exception, e:
			mc.ShowDialogOk("Unable to display videos.", str(e))	

	finally:
		mc.HideDialogWait()

def ShowVideoDetail():

	try:
		
		params = mc.Parameters()
		params['artwork'] = mc.GetInfoString('Container(200).ListItem.thumb')
		params['title'] = mc.GetInfoString('Container(200).ListItem.label')
		params['summary'] = mc.GetInfoString('Container(200).ListItem.plot')
		params['duration'] = mc.GetInfoString('Container(200).ListItem.duration')
		params['director'] = mc.GetInfoString('Container(200).ListItem.director')
		params['link'] = mc.GetInfoString('Container(200).ListItem.FileNameAndPath')
	
		#   TODO: pass preview link in
		#   also path doesn't look like it's used
		#   also see if we can get to props not via GetInfoString, it's messy
		videoList = UI.Windows.Home().VideoList()
		focusedItemIndex = videoList.GetFocusedItem()
		itemToPlay = videoList.GetItem(focusedItemIndex)
		params['path'] = itemToPlay.GetPath()
	
		#mc.ShowDialogOk("Debug", len(itemToPlay.GetProperty('contextmenuurl')))	
	
		UI.Windows.VideoDetail().ShowWithParameters(params)

	except Exception, e:
		mc.ShowDialogOk("Unable to display video.", str(e))	

def PlayVideo():

	try:
		
		params = mc.GetApp().GetLaunchedWindowParameters()
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_FEATURE_FILM)
		
		SetMetaDataItemFromParams(item, params)
	
		#item.SetDuration(params['duration'])
		item.SetPath(params['link'])
		#item.SetExternalItem(CreateTrailerItem(params))
	
		UI.Windows.Video().Play(item)

	except Exception, e:
		mc.ShowDialogOk("Unable to play video.", str(e))	
		
def ExitVideoDetails():
	mc.CloseWindow()
		
def PlayTrailer():

	try:
		params = mc.GetApp().GetLaunchedWindowParameters()
		trailerItem = CreateTrailerItem(params)
	
		UI.Windows.Video().Play(trailerItem)

	except Exception, e:
		mc.ShowDialogOk("Unable to play trailer.", str(e))	
		
def CreateTrailerItem(params):
	
	item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_TRAILER)
	
	SetMetaDataItemFromParams(item, params)

	#	TODO: set trailer link
	#item.SetPath(params['link'])
	
	return item

def SetMetaDataItemFromParams(item, params):

	item.SetLabel(params['title'])
	item.SetDescription(params['summary'])
	item.SetThumbnail(params['artwork'])
	item.SetContentType("application/x-shockwave-flash")
	item.SetProviderSource("TheMotoNetwork.com")
	
	return item	