import mc
import re
import urllib2
import urllib
import sys
import traceback

# The global player object
player = None 

# The current category
category = "" 

# Title of the current video
title = ""

# The index of the current video in the video list
current_video_index = 0

# The current list of videos
videolist = []

# Last state of the app
last_state = ""

# Gets the global player
def get_player():
  global player
  if (player is None):
    player = mc.Player(True)
    player.SetLastPlayerEvent(mc.Player.EVENT_NONE)
  return player

	
# Sets the current list of videos
def set_videolist(itemlist, selected):
  global category
  global videolist

  videolist = []
  for item in itemlist:
    videolist.append( item )

  set_current_video_index(selected)

# Sets the playlist index
def set_current_video_index(index):
  global current_video_index
  
  print "set_current_video_index:" +str(index)
  
  current_video_index = index

# Returns the playlist index
def get_current_video_index():
  print "get_current_video_index:" +str(current_video_index)
  return current_video_index
  
# Returns the current category
def get_category():
  global category
  if category == '':
    category = 'BEST OF THE WEB'
  return category

  # Sets the current category
def set_category(_category):
  global category
  category = _category
  
# Sets the category and updates the main container path
def list_set_category(_category, focus):
  print "list_set_category:" + str(focus)
  set_category(_category)
  categoryEncoded = _category.replace(' ', '+')
  url='rss://reddittv.appspot.com/categoryv1_1?name=' + categoryEncoded

  mc.GetActiveWindow().GetList(100).SetItems(mc.ListItems())
  mc.GetActiveWindow().GetList(100).SetContentURL(url)
  mc.GetActiveWindow().GetList(100).SetFocus()
  mc.GetActiveWindow().GetList(100).SetFocusedItem(focus)

  mc.GetActiveWindow().GetLabel(4000).SetLabel(_category)

def set_last_state(_last_state):
  global last_state
  last_state = _last_state
  
def get_last_state():
  return last_state
  
def get_current_video():
  return videolist[current_video_index]
  
def get_next_video():
  video = None
  if ((current_video_index < (len(videolist) -1)) and (current_video_index >= 0)):
    video = videolist[current_video_index+1]
  return video
  
def next_video():
  video = get_next_video()
  if video != None:
    set_current_video_index(current_video_index+1)
  return video

def get_previous_video():
  video = None
  if (current_video_index > 0):
    video = videolist[current_video_index-1]
  return video

def previous_video():
  video = get_previous_video()
  if video != None:
    set_current_video_index(current_video_index-1)
  return video

# Common method to play videos
# Special logic to handle youtube videos.
def play_video(video_item):
  player_name = video_item.GetProperty('playerName')
  print "** Player name:"+str(player_name)

  try:
    # Workaround to handle youtube videos.
    # Credit Ozalp - developer of Hot For Words - for this workaround
    if player_name == 'youtubePlayer':
      id = re.search('(?:youtube\.com/v/)([a-zA-Z0-9_\-]{11})', video_item.GetPath())
      video_id = id.group(1)

      YouTube = str( 'http://www.youtube.com/watch?v=' + video_id )
      socket = urllib2.urlopen( YouTube )
      data = socket.read()
      socket.close()

      #default to original url in case we dont find a valid video URL
      link = YouTube
      
      fmt_url_map = re.search('(?:"fmt_url_map": ")([^"]*)(?:")', data)
      if fmt_url_map != None:
        fmt_url_map = fmt_url_map.group(1)
        # fmt_url_map = urllib.unquote(fmt_url_map)
        fmt_url_map = fmt_url_map + ','
        print "fmt_url_map retrieved"
        fmt_url_list = re.findall('([0-9]*)(\|)(http://[a-z0-9A-Z_\-/\:\?\.\=\&%]*)(,)', fmt_url_map)

        # Boxee on windows does not support the higher format videos, so skip finding best format video for windows
        if (sys.platform != 'win32' and sys.platform != 'win64'):
          best_format = 0
          if fmt_url_list != None: 
            for fmt_url in fmt_url_list :
              fmt = int(fmt_url[0])
              if fmt > best_format:
                best_format = fmt
                best_format_url = fmt_url[2]

          print "best format:" + str(best_format)
          
          if best_format > 5: 
            link = best_format_url
            
      print "URL: #"+ link+"#"
      video_item.SetProperty('playerName', 'processedYoutubePlayer');
      video_item.SetPath( link )
      
    #item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
    #item.SetTitle( video_item.GetTitle() )
    #item.SetLabel( video_item.GetLabel() )
    #item.SetDescription( video_item.GetDescription() )
    #item.SetThumbnail( video_item.GetThumbnail() )
    #item.SetPath( video_item.GetPath() )
    #item.SetIcon( video_item.GetIcon() )
    #print "Thumb:" + video_item.GetThumbnail()
    try:
      #if mc.IsEmbedded():
      # video window is deprecated in boxee 1.5 and above
    	get_player().Play(video_item)
      #else:
      #get_player().PlayInBackground(video_item)
    except AttributeError:
      print "(utils)Attribute Error."
      get_player().PlayInBackground(video_item)
  except Exception, e:
    print "EXCEPTION: "
    print e
    traceback.print_exc()
    raise e

def update_player_controls():
  mc.GetActiveWindow().GetLabel(4000).SetLabel(get_current_video().GetDescription())
  mc.GetActiveWindow().GetLabel(4001).SetLabel("| "+get_category())
  if get_player().IsPaused():
    mc.GetActiveWindow().GetImage(4500).SetTexture("play2.png")
  else:
    mc.GetActiveWindow().GetImage(4500).SetTexture("pause2.png")
    
  video = get_previous_video()
  if video != None: 
    mc.GetActiveWindow().GetLabel(4401).SetLabel(video.GetDescription())
    mc.GetActiveWindow().GetImage(4501).SetTexture("left2.png")
  else:
    mc.GetActiveWindow().GetLabel(4401).SetLabel("")
    mc.GetActiveWindow().GetImage(4501).SetTexture("left2_gray.png")
    
  video = get_next_video()
  if video != None: 
    mc.GetActiveWindow().GetLabel(4402).SetLabel(video.GetDescription())
    mc.GetActiveWindow().GetImage(4502).SetTexture("right2.png")
  else:
    mc.GetActiveWindow().GetLabel(4402).SetLabel("")
    mc.GetActiveWindow().GetImage(4502).SetTexture("right2_gray.png")