import mc
import xml.dom.minidom
import urllib

#consts
cCHANNEL = "24109"
cDEVICE = "bxAdl"
cVERSION = "1_3"
cURL = "http://89.188.139.147/argoLogin-hook/services/user/"
cURL_register = "http://89.188.139.147/argoUser-portlet/services/user/"
LogIn_metod = "loginbyusername?"
LogOut_metod = "logout?"
Register_metod = "adduser?"

ChannelName = "Cherry Sauce TV"


def log(msg, alert=False, func=''):
   if func: func = '('+str(func).lower()+') '
   mc.LogError('@Cherry Adult INFO   -----!!!------ %s%s' % (func, str(msg).lower()))
   if alert:
      mc.ShowDialogOk(ChannelName, 'The following error has occurred: ' + str(msg).capitalize())
      mc.HideDialogWait()
      return False

def testURL():
    return ""
    
    

class userAccount:

   username = ''
   password = ''
   token = ''
   isLoggedIn = False
   category = ''
   credit = 0
   lista = ''
      
   def __init__(self):
      #on load we'll check for saved account details
      cf = mc.GetApp().GetLocalConfig()
      self.username = cf.GetValue('auth_user')
      self.password = cf.GetValue('auth_pwd')
      self.token = cf.GetValue('token')
      self.credit = cf.GetValue('credit')
      if self.username != "":
         self.commitLogin(self.username, self.password)


   def commitLogout(self):
     http = mc.Http()
     try:
          data = http.Get(cURL + LogOut_metod + "channel="+ cCHANNEL + "&token=" + str(self.token) +"&device="+cDEVICE)
          if data == "":
            mc.ShowDialogNotification('Service inaccessible!', 'LogoApp.png')
            self.isLoggedIn = False
            return False
             
          dom = xml.dom.minidom.parseString(data)
          
          nodo = dom.getElementsByTagName("result")[0]
          status = nodo.getAttribute("status")
          
          if str(status) == '1': 
            self.isLoggedIn = False
            self.username = ''
            self.password = ''
            self.token = ''
            self.credit = ''
            self.clearStoredCreds()
            http.Reset()
            return True
             
          elif  str(status) == '0':
             mc.ShowDialogNotification('Logout Invalid. Please try again.', 'LogoApp.png')
             self.isLoggedIn = False
             http.Reset()

             return False
             
          elif  str(status) == '-1':
             errormessage = nodo.getAttribute("error")
             log(str(errormessage), True, 'Logout') 
             self.isLoggedIn = False
             http.Reset()
             return  False
 
          else:  
             self.isLoggedIn = False
             http.Reset()
             return False

             return 
     except Exception, e:
          log(str(e), False, 'Logout') 
          
     
   def commitLogout_old(self):
     self.isLoggedIn = False
     self.username = ''
     self.password = ''
     self.token = ''
     self.credit = ''
     self.clearStoredCreds()
     return True
      
 

   def clearStoredCreds(self):
      cf = mc.GetApp().GetLocalConfig()
      cf.Reset('auth_user')
      cf.Reset('auth_pwd')
      cf.Reset('token')
      cf.Reset('credit')
    

   def checkToken(self):
      # qui assegno token nuovo
      log('checkToken')
      if self.token == '' or not self.token:
        result = False
      else:
        result = True
      
      self.isLoggedIn = result
          
   
   def commitLogin(self, user='', password=''):
       
      cf = mc.GetApp().GetLocalConfig()
      self.isLoggedIn = False
      test = cf.GetValue('test')
      http = mc.Http()
      try:
        
          data = http.Get(cURL + LogIn_metod + "channel="+ cCHANNEL+"&user="+user+"&password="+password+"&device="+cDEVICE)
          if data == "":
            mc.ShowDialogNotification('Service inaccessible!', 'LogoApp.png')
            self.isLoggedIn = False
            return
             
          dom = xml.dom.minidom.parseString(data)
          
          nodo = dom.getElementsByTagName("result")[0]
          status = nodo.getAttribute("status")
          
          
          if str(status) == '1': 
             self.token = nodo.getAttribute("token")
             cf.SetValue('token', str(self.token))
             self.credit = nodo.getAttribute("credit")
             cf.SetValue('credit', str(self.credit))                                                  
             cf.SetValue('auth_user', user)
             cf.SetValue('auth_pwd',  password)
             self.isLoggedIn = True
             http.Reset()

             return
             
          elif  str(status) == '0':
             mc.ShowDialogNotification('Login Invalid. Please try again.', 'LogoApp.png')
             self.isLoggedIn = False
             self.clearStoredCreds()
             http.Reset()

             return
             
          elif  str(status) == '-1':
             errormessage = nodo.getAttribute("error")
             if str(errormessage)!= "":
                log(str(errormessage), True, 'Login') 
             self.isLoggedIn = False
             self.clearStoredCreds()
             http.Reset()

             return
          else:  
             self.isLoggedIn = False
             mc.ShowDialogNotification('Login Invalid. Please try again.', 'LogoApp.png')
             self.clearStoredCreds()
             http.Reset()

             return    
             
      except Exception, e:
          log(str(e), False,'Login')
          
          
          
   def Register(self, user='', password='', email=''):
      
      cf = mc.GetApp().GetLocalConfig()
      self.isLoggedIn = False
      http = mc.Http()
      try:
      
        Codedurl =cURL_register + Register_metod + "channel="+ cCHANNEL+"&user="+user + "&password="+password+ "&email="+ urllib.quote(email) + "&device="+cDEVICE
        print "***********URL************** = "+ str(Codedurl)  
        data = http.Get(Codedurl)
        print str(data)
        if data == "":
          mc.ShowDialogNotification('Service inaccessible!', 'LogoApp.png')
          self.isLoggedIn = False
          return
           
        dom = xml.dom.minidom.parseString(data)
        
        nodo = dom.getElementsByTagName("result")[0]
        status = nodo.getAttribute("status")
       
        if str(status) == '1': 
           self.token = nodo.getAttribute("token")
           cf.SetValue('token', str(self.token))
           self.credit = nodo.getAttribute("credit")
           cf.SetValue('credit', str(self.credit))                                                  
           cf.SetValue('auth_user', user)
           cf.SetValue('auth_pwd',  password)
           self.isLoggedIn = True
           mc.ShowDialogOk(ChannelName, "Registration successful, buy credit on www.cherrysauce.tv")
           http.Reset()

           return
           
        elif  str(status) == '0':
           errormessage = nodo.getAttribute("error")
           if str(errormessage)!= "":
                log(str(errormessage), True, 'Register') 
          
           self.isLoggedIn = False
           http.Reset()

           return
           
        elif  str(status) == '-1':
           errormessage = nodo.getAttribute("error")
           if str(errormessage)!= "":
                log(str(errormessage), True, 'Register') 
           self.isLoggedIn = False
           http.Reset()

           return
        else:  
           self.isLoggedIn = False
           errormessage = nodo.getAttribute("error")
           if str(errormessage)!= "":
                log(str(errormessage), True, 'Register') 
           http.Reset()

           return    
           
      except Exception, e:
        log(str(e), False,'Register')          
          
          
          
           

#init global data
user = userAccount()
config = mc.GetApp().GetLocalConfig() 
