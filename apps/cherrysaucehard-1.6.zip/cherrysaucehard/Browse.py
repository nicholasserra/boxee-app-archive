import mc
import Account
import urllib
import xml.dom.minidom


Services_URL   =  "http://89.188.139.147/argoContent-portlet/services/content/"


Categories_URL =  "http://89.188.139.147/argoContent-portlet/services/category/getcategorylist?"


FocusedItem = -1

def getVideoList(ListType):
   items = mc.ListItems()
   if not Account.user.isLoggedIn:
      Account.user.token = "" 
   try:
     if ListType == 'MostViewed':
       function = "getcontentlistmost?" 
       
     elif ListType == 'Top':
       function = "getcontentlisttop?"

     elif ListType == 'Purchased':
       function = "getcontentlistmy?"
       
     elif ListType == 'New':
       function = "getcontentlistnew?"  
     
     elif ListType == 'Free':
       function = "getcontentlistfree?"  
     
       
     
     else:
       function = ""

     win = mc.GetWindow(14000)
     win.ClearStateStack()
     data = Services_URL + function +"channel="+ Account.cCHANNEL +"&token=" + str(Account.user.token) + "&checkToken=false"+ "&device="+ Account.cDEVICE + "&version="+Account.cVERSION
     mc.ShowDialogWait()
     items = mc.GetDirectory(data)
#     if len(items) == 0:
#       mc.ShowDialogNotification('Service inaccessible!', 'LogoApp.png')
     mc.HideDialogWait()
     return items 
        
   except Exception, e:
     mc.HideDialogWait()
     Account.log((e), False, str(ListType))
     return items   
   
#####################################################################
         
def search(text):
   if not Account.user.isLoggedIn:
      Account.user.token = ""    
   items = mc.ListItems()
   win = mc.GetWindow(14000)
   win.ClearStateStack()
   http = mc.Http()
   
   try:
      data = Services_URL + "getcontentlistsearch?channel="+ Account.cCHANNEL +"&token=" + str(Account.user.token) + "&checkToken=false"+"&categNames="+ str(Account.user.category)+"&tagNames="+""+"&searchText=" + text
     

      mc.ShowDialogWait()
      items = mc.GetDirectory(data)
#      if len(items) == 0:
#        mc.ShowDialogNotification('Service inaccessible!', 'LogoApp.png')
        #win.GetControl(7002).SetVisible(False)
      mc.HideDialogWait()
      return items 

        
   except Exception, e:
      
      Account.log((e), False, 'Search')
      return items   
   mc.HideDialogWait()
   
####################################################################
def getcontentinfo(id, button=True):
  try:
      mc.ShowDialogWait()
      if not Account.user.isLoggedIn:
         Account.user.token = "" 
      url = Services_URL + "getcontentinfo?channel=" + Account.cCHANNEL + "&token="+ str(Account.user.token) + "&contentid="+str(id) + "&checkToken=true"     
      try:
       
        http = mc.Http()
        data = http.Get(url)
        dom = xml.dom.minidom.parseString(data)
        nodo = dom.getElementsByTagName("result")[0]
        status = nodo.getAttribute("status") 
      except Exception, e:
        Account.log(str(e), True, 'getcontentinfo')
        status = '0'
      http.Reset()
      if str(status) == '1': 
         credit = str(dom.getElementsByTagName("credit")[0].childNodes[0].nodeValue) 
         purchased = dom.getElementsByTagName("ispurchased")[0].childNodes[0].nodeValue
         
         res =  True
         mc.HideDialogWait()   
         return res      
      elif  (str(status) == '-1') :
         Account.user.isLoggedIn = False
         
         if button==False :
           mc.HideDialogWait()
           mc.ShowDialogNotification("Session expired", 'LogoApp.png')
           return ''
         cf = mc.GetApp().GetLocalConfig()
         user = cf.GetValue('auth_user')
         password = cf.GetValue('auth_pwd')
         Account.user.commitLogin(user, password)
         
         if Account.user.isLoggedIn:
           return getcontentinfo(id, False)
           
###############    Error
      elif  (str(status) == '-130') :
           errorMessage = nodo.getAttribute("error") 
           mc.ShowDialogNotification(str(errorMessage), 'LogoApp.png')
           Account.log(str(errorMessage), False, 'getcontentinfo')
           return False
           
      elif  (str(status) == '0') :
           errorMessage = nodo.getAttribute("error")
           detail = nodo.getAttribute("detail") 
           mc.ShowDialogNotification('Failed to stream video!', 'LogoApp.png')
           Account.log(str(errorMessage), False, 'getcontentinfo')
           mc.HideDialogWait()
           return False   
      else:          
           mc.ShowDialogNotification('Failed to stream video!', 'LogoApp.png')
           mc.HideDialogWait()
           return False 
      
  except Exception, e:
      mc.HideDialogWait()
      Account.log(e, False, 'getcontentinfo')
      return False
  mc.HideDialogWait()

####################################################################
      
def getMovieUrl(id, button=True):
   try:
      mc.ShowDialogWait()
      try:
        if not Account.user.isLoggedIn:
          Account.user.token = "" 
        url = Services_URL + "getvideo?channel=" + Account.cCHANNEL + "&token="+ str(Account.user.token) + "&contentid="+str(id)
        http = mc.Http()
        data = http.Get(url)
        dom = xml.dom.minidom.parseString(data)
        nodo = dom.getElementsByTagName("result")[0]
        status = nodo.getAttribute("status")
        Account.user.credit = nodo.getAttribute("usercredit")
        cf = mc.GetApp().GetLocalConfig()
        cf.SetValue('credit', str(Account.user.credit))
#        Account.log(str(status), True, '' ) 
      except:
        print ''
        status = '-33'
      http.Reset()
      
      
#video purshased successfully, read url 
      if str(status) == '1': 
         path = nodo.getAttribute("url")
         return str(path)

#token expired, silent login 
      elif  (str(status) == '-1') :
         Account.user.isLoggedIn = False
         
         if button==False :
           mc.HideDialogWait()
           mc.ShowDialogNotification("Session expired", 'LogoApp.png')
           return ''
         cf = mc.GetApp().GetLocalConfig()
         user = cf.GetValue('auth_user')
         password = cf.GetValue('auth_pwd')
         Account.user.commitLogin(user, password)
         if Account.user.isLoggedIn:
           return getMovieUrl(id, False)
          
      elif  (str(status) == '-2') :
          mc.ShowDialogNotification('You haven''t had enought credits for purchase this video', 'LogoApp.png')
          mc.HideDialogWait()
          return ''
      else:
          mc.ShowDialogNotification(nodo.getAttribute("error"), 'LogoApp.png')
          mc.HideDialogWait()
          return ''
          
      mc.HideDialogWait()
      return ''
   except Exception, e:
      mc.HideDialogWait()
      Account.log((e), False, 'GetMovieUrl')
      return ''

#####################################################################
        
def get_categories(category_items ):
  http = mc.Http()
  try:
    try:
      category_names_string = http.Get(Categories_URL + "channel=" + Account.cCHANNEL)
    except:
       Account.log('Category list connection error', Flase, 'GetCategoryList') 
    category_names = category_names_string[2:-2].split("'"+","+"'")
    category_names.insert(0,'All Categories')

    for category_int in range(0, len(category_names)):
      	category_label = category_names[category_int]
      	category_item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
      	category_item.SetLabel(category_label)
      	mc.LogDebug(str(category_item))
      	category_items.append(category_item)         
      
    return category_items
	
  except Exception, e:
    Account.log((e), Flase, 'GetCategoryList')
    return ''
         