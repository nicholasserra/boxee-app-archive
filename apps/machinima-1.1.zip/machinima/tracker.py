# 
# Tracker Client - Google Analytics Integration
# A Python module for interacting with the Tracker web service on boxee.machinima.com.
#
# NOT FOR USE With any other service!
# 
# based on a tracker.py written by /rob, 29 July 2010
#



import mc
import urllib
import random

class Tracker:
    def __init__(self, uacode = False, debug = False):
        self.uacode = uacode
        self.version = "beta"
        self.path = "http://boxee.machinima.com/track.php"
        self.debug = 0
        #used to keep boxee from caching result
        self.rand = random.randint(100000000,999999999);         
    def trackView(self, window = False,title = 'none'):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Tracking view. %%%%%%%%%%%%%%%%%%%")
        if not window:
            window = "14000"
        
        mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Requesting tracker image path. %%%%%%%%%%%%%%%%%%%%%%%%%")
        tracker = self.request(self.path + "?type=page&title=" + urllib.quote(title) + "&url=" + urllib.quote(window)  + "&nocache=" + str(self.rand))    

        if self.debug:
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Path is " + str(tracker) + " %%%%%%%%%%%%%%%%%%%%%%%%%")
            tracker = self.request(str(tracker))
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% GA Debug: " + str(tracker) + " %%%%%%%%%%%%%%%%%%%%%%%%%")
        elif tracker:
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Path is " + str(tracker) + " %%%%%%%%%%%%%%%%%%%%%%%%%")
            return self.request(str(tracker))
        else:
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: tracking request failed. %%%%%%%%%%%%%%%%%%%")
            return False
    
    def trackEvent(self, category, action, label, value = False):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Tracking event. %%%%%%%%%%%%%%%%%%%")
        if value:
            eventPath = eventPath + "&value=" + value

        eventPath = self.path + "?type=event&category=" + urllib.quote(category) + "&action=" + urllib.quote(action) + "&label=" + urllib.quote(label) + "&nocache=" + str(self.rand)
        
        mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Requesting tracker image path. %%%%%%%%%%%%%%%%%%%%%%%%%")
        tracker = self.request(eventPath)
        
        if self.debug:
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Path is " + str(tracker) + " %%%%%%%%%%%%%%%%%%%%%%%%%")
            tracker = self.request(str(tracker))
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% GA Debug: " + str(tracker) + " %%%%%%%%%%%%%%%%%%%%%%%%%")
        elif tracker:
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: Path is " + str(tracker) + " %%%%%%%%%%%%%%%%%%%%%%%%%")
            return self.request(str(tracker))
        else:
            mc.LogDebug("%%%%%%%%%%%%%%%%%%% Tracker: tracking request failed. %%%%%%%%%%%%%%%%%%%")
            return False
        
    def request(self, path):
        # Instatiate HTTP object
        myHttp = mc.Http()
        
        # Set User Agent
        myHttp.SetUserAgent("Boxee App (boxee/beta " + self.version + " tracker)")
        
        # Get data
        data = myHttp.Get(path)
        
        # Make request
        return data