##
# Macinima Boxee Library
# written by Matt Antone matt.antone@gmail.com
# 
# Gets and displays youtube videos from parsing software at boxee.machinima.com
# 
##

import mc
import customplayer
import tracker
import urllib

class Machinima:
	def __init__(self): 
		#
		# Setup variables
		#
		self.debug = False
		self.curapp = mc.GetApp()
		self.curDir = self.curapp.GetAppDir()
		
		self.window = mc.GetActiveWindow()
		self.loading = self.window.GetControl(9003)
		
		self.posLabel = self.window.GetLabel(51)
		self.mainnav = self.window.GetList(52)
		self.contentlist = self.window.GetList(53)
		self.submenu = self.window.GetList(55)
		self.GA = "UA-26280717-1"
		self.Tracker = tracker.Tracker(self.GA)
		self.player = customplayer.CustomPlayer()
		self.mainItem = mc.ListItem()

	##
	# Start Function
	# sets up the initial state & content of the app.
	##
	
	def Start(self):
		self.LogHeader("Machinima Start()")
		
		# Display loading screen
		self.loading.SetVisible(1)
		
		# Empty Page Position Label
		self.posLabel.SetLabel('')
		
		# Get initial content from local file
		menulist = mc.GetDirectory("rss:///"+self.curDir+"/menu.xml")

		# Set the main menu
		self.mainnav.SetItems(menulist)
		self.mainnav.SetFocusedItem(0)
		self.mainnav.SetSelected(self.mainnav.GetFocusedItem(),True)
		self.mainnav.SetFocus()
		mainItem = self.mainnav.GetItem(0)
		mainItem.SetProperty("isSelected","true")

		# Display content for the first main menu item
		self.DisplayContentItems(52)
		self.LogFooter("End Start()")
		

	##
	# DisplayContentItems Function
	# @ listID = int - the list id of the menu that contains the selected item
	# @ Displaysubmenu = bol - if the menu is a submenu default = false
	##
	def DisplayContentItems(self,listID,Displaysubmenu = False):
		self.LogHeader("Machinima DisplayContentItems()")
		self.ClearBackButton()
		if listID is 52:
			self.window.ClearStateStack(True)

		# Display Loading Screen
		self.loading.SetVisible(1)
		
		# Get the list by id
		list = self.window.GetList(listID)
		# - Clear list selections
		list.UnselectAll()
		items = list.GetItems()

		# - Set the selected display flag
		# - displays the item as selected
		for curItem in items:
			curItem.SetProperty("isSelected","false")

		# - Get the Focused item (the item that was clicked)
		item = list.GetItem(list.GetFocusedItem())
		
		# - Set the focused item selected
		list.SetSelected(list.GetFocusedItem(),True)
		item.SetProperty("isSelected","true")
		label = item.GetLabel()
		list.SetSelected(list.GetFocusedItem(),True)

		# Get the content of the selected item from RSS Feed
		path = item.GetPath()+"&parent="+label
		tmpitems = mc.GetDirectory(path)
		newitems = self.TruncateList(tmpitems)
		targetitem = newitems[0]
		hasgroups = targetitem.GetProperty("hasgroups");
		if not hasgroups:
			hasgroups = "0"
		
		
		
		# Display the items as grouped content
		if int(hasgroups) > 0:
			self.LogMessage("Display Content as Grouped Content: "+hasgroups)
			self.submenu.SetItems(newitems)
			
			path = targetitem.GetPath()
			contentitems = mc.GetDirectory(path)
			
			firstitem = self.submenu.GetItem(0)
			firstitem.SetProperty("isSelected","true")
			self.SetPageLabel(contentitems[0])
			self.contentlist.SetItems(contentitems)
			self.submenu.SetFocusedItem(0)
			self.submenu.SetVisible(1)
			
		# Display the items as normal content
		else:
			self.LogMessage("Display content as content")
			newlabel = self.SetPageLabel(targetitem)
			if not Displaysubmenu:
				self.submenu.SetVisible(0)
			self.Tracker.trackEvent("Boxee App", "Playlist", newlabel)
			self.posLabel.SetVisible(1)
			self.contentlist.SetItems(newitems)		
		# Hide Loading screen
		self.loading.SetVisible(0)
		self.LogFooter("End DisplayContentItems()")

	##
	# DisplayContentItem() - Function
	# Gets the focused item in the content list and either plays a video or dipslays more content
	##
	def DisplayContentItem(self):
		self.LogHeader("Machinima DisplayContentItem()")
		self.window.PushState()
		# Get the focused item and analyze it
		item = self.contentlist.GetItem(self.contentlist.GetFocusedItem())
		newtext = item.GetLabel()
		path = item.GetPath()
		protocol = path.split('://')
		if protocol[0] == "rss":
			# Display RSS
			# - Display Loading
			self.loading.SetVisible(1)
			# - Clear state and push existing state
			
			# - Get & Display list items from RSS feed
			tmpitems = mc.GetDirectory(path)
			listitems = self.TruncateList(tmpitems)
			newitem = listitems[0]
			self.contentlist.SetItems(listitems)
			self.contentlist.SetFocus()
			curpage = newitem.GetProperty("curpage")
			pagecount = newitem.GetProperty("pagecount")
			newlabel = newtext+" : "+curpage+" of "+pagecount
			self.posLabel.SetLabel(newlabel)
			self.posLabel.SetVisible(1)
			self.SetBackToCategory()
			self.loading.SetVisible(0)
			self.Tracker.trackEvent("Boxee App", "Playlist", newtext+": "+curpage+" of "+pagecount)
		else:
			# Play Video
			self.player.Play(item)
			self.player.eventStart()
			self.posLabel.SetVisible(0)
			self.backbutton.SetLabel("")
			self.backbutton.SetVisible(0)	
			self.window.PushState()
		self.LogFooter("End DisplayContentItem()")
		
	##
	# DisplayPage() Function
	# Displays either the previous or next page of the content area
	# @linktype - string  "previous" or "next". Defaults to "next"
	##	
	def DisplayPage(self,linktype="next"):
		self.LogHeader("Machinima DisplayPage")
		# Display Loading
		self.loading.SetVisible(1)
		
		# Get the first item in the content list
		item = self.contentlist.GetItem(0)

		if linktype == "next":
			# Get "Next" link
			buttontype = "Next"
			path = item.GetProperty("nextlink")
		else:
			# Get "Previous" link
			buttontype = "Previous"
			path = item.GetProperty("prevlink")
		
		# Clear the current position label
		self.posLabel.SetLabel(' ')
		
		self.LogMessage("Path: "+path)
		
		
		# Get & Display new content items from RSS
		tmpitems = mc.GetDirectory(path)
		listitems = self.TruncateList(tmpitems)
		self.contentlist.SetItems(listitems)
		self.contentlist.SetFocusedItem(0)
		self.contentlist.SetFocus()
		
		# Get first new item to extract some display variables
		newitem = listitems[0]
		eventtext = self.SetPageLabel(newitem)
		
		# Tracking
		self.Tracker.trackEvent("Boxee App", buttontype, eventtext)
		
		# Reset Display
		self.posLabel.SetVisible(1)
		self.loading.SetVisible(0)
		self.LogFooter("End DisplayPage()")

	##
	# TruncateLabel Function
	# Returns a truncated string
	# @label - string
	##
	def TruncateLabel(self,label):
		self.LogHeader("Machinima TruncateLabel()")
		info = label[:26] + (label[26:] and '... ')
		self.LogFooter("End TruncateLabel")
		return info
		
	##
	# Truncate the labels in an entire list
	# Returns a Boxee ListItem object with truncated data and display variables
	# @dataitems = Boxee ListItems object
	##
	
	def TruncateList(self,dataitems):
		self.LogHeader("Machinima TruncateList")
		#Creat a new Boxee ListItems Object
		newitems = mc.ListItems()
		for dataitem in dataitems:
			newitem = mc.ListItem( mc.ListItem.MEDIA_VIDEO_EPISODE )
			newitem.SetTitle(dataitem.GetLabel())
			newitem.SetLabel(self.TruncateLabel(dataitem.GetLabel()))
			newitem.SetPath(dataitem.GetPath())
			newitem.SetThumbnail(dataitem.GetThumbnail())
			ytcount = dataitem.GetProperty("ytcount")
			if ytcount:
				newitem.SetProperty("ytcount",self.FormatNumber(int(ytcount))+" views")
			newitem.SetProperty("parent",dataitem.GetProperty("parent"))
			newitem.SetProperty("group",dataitem.GetProperty("group"))
			newitem.SetProperty("hasgroups",dataitem.GetProperty("hasgroups"))
			newitem.SetProperty("ytid",dataitem.GetProperty("ytid"))
			newitem.SetProperty("showdate",dataitem.GetProperty("showdate"))
			newitem.SetProperty("uploaded",dataitem.GetProperty("uploaded"))
			newitem.SetProperty("pagecount",dataitem.GetProperty("pagecount"))
			newitem.SetProperty("curpage",dataitem.GetProperty("curpage"))
			newitem.SetProperty("prevlink",dataitem.GetProperty("prevlink"))
			newitem.SetProperty("nextlink",dataitem.GetProperty("nextlink"))
			newitem.SetProperty("showprev",dataitem.GetProperty("showprev"))
			newitem.SetProperty("shownext",dataitem.GetProperty("shownext"))
			newitem.SetProperty("selected",dataitem.GetProperty("selected"))
			newitem.SetProperty("showlabel","true")
			newitem.SetProperty("showbackbutton","false`")
			newitems.append(newitem)
		self.LogFooter("End TruncateList()")
		return newitems
	
	
	##
	# FocusControl() Function
	# Displays focus on either the default control or an alternate control
	# @defaultcontrolID - int  Primary control to give focus to
	# @altcontrolID - in Secondary control to give focus too if primary is unavailable
	# RETURNS boolean
	##
	def FocusControl(self,defaultcontrolID,altcontrolID):
		self.LogHeader("Machinima FocusControl()")
		#Get the default control
		defaultcontrol = self.window.GetControl(defaultcontrolID)
		if defaultcontrol and defaultcontrol.IsVisible():
			# default control exists and can be seen
			defaultcontrol.SetFocus()
		else:
			# Get the alternate control
			altcontrol = self.window.GetControl(altcontrolID)
			if altcontrol and altcontrol.IsVisible():
				# alt control exists and can be seen
				altcontrol.SetFocus()
			else:
				mc.LogDebug("neither control can be seen. returning false")
				return False
		self.LogFooter("End FocusControl()")
		return True
	
	##
	# SetPageLabel() Function
	# Displays a string representation of the current location in the content's pagination
	#  using the display variables in the the argument "item"
	# @item - Boxee ListItem Object
	# RETURNS displayed string
	##
	def SetPageLabel(self,item):
		self.LogHeader("Machinima SetPageLabel()")
		group = item.GetProperty("group")
		if not group:
			group = " "
		else:
			group = " "+group+" "
		
		newlabel = item.GetProperty("parent")+group+" "+item.GetProperty("curpage")+" of "+item.GetProperty("pagecount")
		self.posLabel.SetLabel(newlabel)
		self.LogFooter("End SetPageLabel()")
		return newlabel
		
	
	
	##
	# SetBackToCategory()
	# Get the current top level nav point and displays a back button to that screen
	#
	# RETURNS nil
	#
	##
	def SetBackToCategory(self):
		self.LogHeader("Machinima SetBackToCategory()")
		listitems = mc.ListItems()
		
		self.submenu.SetItems(listitems)
		self.submenu.Refresh()
		selected = self.mainnav.GetSelected()
		self.mainItem = selected[0]
		listitems.append(self.mainItem)
		listitems[0].SetProperty("showlabel","false")
		listitems[0].SetProperty("showbackbutton","true")
		listitems[0].SetProperty("backtext","< Back To "+self.mainItem.GetLabel())
		self.submenu.SetItems(listitems)
		testitem  = self.submenu.GetItem(0)
		self.submenu.Refresh()
		self.submenu.SetVisible(1)
		self.LogFooter("End SetBackToCategory()")
		
	##
	# ClearBackButton()
	# Removes Back Button from screen
	#
	# RETURNS nil
	#
	##
	def ClearBackButton(self):
		listitems = mc.ListItems()
		self.submenu.SetItems(listitems)	


	##
	# FormatNumber(number - int, sperator= string)
	# RETURNS a number formated with the seperator string
	#
	##
	def FormatNumber(self,n,sep=','):
		s = str(n)
		out = ''
		while len(s) > 3:
			out = sep + s[-3:] + out
			s = s[:-3]
		return s + out

	##
	# Pretty logging
	##
	def LogHeader(self, message):
		if self.debug:
			mc.LogError("/************************* Machinima *************************/")
			mc.LogError("/ "+message)
			mc.LogError("/")

	def LogFooter(self,message):
		if self.debug:
			mc.LogError("/")
			mc.LogError("/ "+message)
			mc.LogError("/*************************************************************/")

	def LogMessage(self, message):
		if self.debug:
			mc.LogError("/")
			mc.LogError("/ "+message)
			mc.LogError("/")
