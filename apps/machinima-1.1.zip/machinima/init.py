###
# Machinima Boxee Init
#
# Sets up the initial state of the app.
# Launched on app startup
#
###


import mc
import machinima


#
# Setup any global parameter for the app and activate the Window
#
targetwindow = 14000
curapp = mc.GetApp()
params = mc.Parameters()
curapp.ActivateWindow(targetwindow, params)

#
# Start up the machinima library
#
mach = machinima.Machinima()
mach.Start()
