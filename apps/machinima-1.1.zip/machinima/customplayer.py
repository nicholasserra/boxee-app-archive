# 
# CustomPlayer - A player that allows for callbacks with boxee players events AND tracking on all events
#

import mc
import tracker
import urllib

class CustomPlayer(mc.Player):
	def __init__(self):
		mc.Player.__init__(self, True)
		self.last = self.GetLastPlayerEvent()
		self.call = {
			self.EVENT_NEXT_ITEM	:	self.callbackNextItem,
			self.EVENT_STOPPED		:	self.callbackStopped,
			self.EVENT_ENDED		:	self.callbackEnded,
			self.EVENT_STARTED		:	self.callbackStarted,
			self.EVENT_NONE			:	self.callbackNone }
		self.Tracker = tracker.Tracker("UA-26280717-1")

	#
	# eventStart - Starts the event tracking of the player
	# 
	def eventStart(self):
		import xbmc

		while True:
			event = self.GetLastPlayerEvent()
			if event != self.last:
				if event in self.call.keys():
					self.last = event
					self.call[event]()
					if event in [self.EVENT_ENDED, self.EVENT_STOPPED]:
						break
			xbmc.sleep(1000)

	#
	# callbackNextItem()
	# fires on EVENT_NEXT_ITEM
	#
	def callbackNextItem(self):
		self.trackView()
		self.Tracker.trackEvent("Boxee Player", "Next Item in Playlist", item.GetTitle())

	#
	# callbackEnded()
	# fires on EVENT_ENDED
	#
	def callbackEnded(self):
		item = mc.GetPlayer().GetPlayingItem()
		self.Tracker.trackEvent("Boxee Player", "Video Ended", item.GetTitle())
		targetwindow = 14000
		curapp = mc.GetApp()
		params = mc.Parameters()
		params["playback"] = "0"
		curapp.ActivateWindow(targetwindow, params)

	#
	# callbackStarted()
	# fires on EVENT_STARTED
	#
	def callbackStarted(self):
		item = mc.GetPlayer().GetPlayingItem()
		self.trackView()
		self.Tracker.trackEvent("Boxee Player", "Video Start", item.GetTitle())

	#
	# callbackStarted()
	# fires on EVENT_STARTED
	#
	def callbackStopped(self):
		item = mc.GetPlayer().GetPlayingItem()
		self.Tracker.trackEvent("Boxee Player", "Video Stop", item.GetTitle())

	#
	# callbackStarted()
	# fires on EVENT_STARTED
	#
	def callbackNone(self):
		pass

	#
	# callbackStarted()
	# fires on EVENT_STARTED
	#
	def trackView(self):
		item = mc.GetPlayer().GetPlayingItem()
		item.Dump()
		videoid = item.GetProperty("ytid")
		self.Tracker.trackView("/video?"+videoid+"&tab="+item.GetProperty("parent"),item.GetTitle())
		