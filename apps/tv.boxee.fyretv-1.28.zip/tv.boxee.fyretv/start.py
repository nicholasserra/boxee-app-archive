import mc
mc.ShowDialogWait()
import fyre
import fyre.helpers.loading
import space # space must be imported first -- it requests sha_salt as the first request

import fyre.hash
import ConfigParser
import lib.cache
import fyre.helpers.distribution_window
import fyre.helpers.keyboard
import fyre.helpers.options
import fyre.helpers.pin
import fyre.helpers.rating
import fyre.helpers.scroll
import fyre.helpers.grocery
import fyre.view
import fyre.helpers.mode
import simplejson
import time
import lib.player_thread
from lib.request import call_method

import fyre.controllers.scenes_panel
import fyre.controllers.signup_code_activation
import fyre.controllers.store_minutes
import fyre.controllers.signin
import fyre.controllers.stdp
import fyre.controllers.sdp
import fyre.controllers.menu
import fyre.controllers.my_library
import fyre.controllers.movies
import fyre.controllers.categories
import fyre.controllers.coverflow
import fyre.controllers.stars
import fyre.controllers.tdp
import fyre.controllers.pdp
import fyre.controllers.packages
import fyre.controllers.player
import fyre.controllers.store_packages
import fyre.controllers.studios
import fyre.controllers.signup
import fyre.controllers.signup_activation
import fyre.controllers.signup_association_finished
import fyre.controllers.simple_signup
import fyre.controllers.terms_and_conditions
import fyre.controllers.about


params = mc.Parameters()
params["title"] = "FyreTV"

pin = {}

#some test info
print(mc.GetInfoString('System.ScreenResolution'))
import xbmc
print xbmc.getLanguage()

if space.application_mode == 'F':
  mc.GetApp().ActivateWindow(fyre.hash.windows['signin'], params)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['signin']['main']).SetVisible(True)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['signin']['main']).SetFocus()
else:
  mc.GetApp().ActivateWindow(fyre.hash.windows['age_verification'], params)
#  mc.GetApp().ActivateWindow(fyre.hash.windows['switcher'], params)
#  mc.ShowDialogOk("Welcome", "You are in anonymous mode.")

space.init = True
mc.HideDialogWait()
