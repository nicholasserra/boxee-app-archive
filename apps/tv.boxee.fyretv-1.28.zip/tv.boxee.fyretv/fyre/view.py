import space
import mc
import fyre
import xbmc

# These methods does not belong into a class, but are scoped into $filename module

def show(view, *params):
  fyre.helpers.loading.show()
  space.unload = False
  cache = space.cache
  cache.push_level(view, *params)
  print("ReplaceWindow(%s)" % cache.current().scope())
  print('cache: %s' % str(space.cache.data))
  xbmc.executebuiltin("ReplaceWindow(%s)" % fyre.hash.windows[cache.current().scope()])

  cache.current().related_group().SetVisible(True)
  print('focusing new view')
  cache.current().related_group().SetFocus()
  fyre.helpers.loading.hide()

