config = {
    'server_prefix': {
      'mw': "https://boxee.fyretv.com:8281/services/boxee",
      'wowza': "https://boxee.fyretv.com:8281/services/new_wowza",
      'thumbnails': 'http://img.fyretv.com:8182/thumbnails',
      'vod': '' # we need trailing slash here to work
    },
    'version': '1.28',
}
