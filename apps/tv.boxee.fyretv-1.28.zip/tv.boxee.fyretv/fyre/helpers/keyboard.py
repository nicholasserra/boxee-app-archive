import mc
import fyre
import fyre.hash
from string import letters
import space

#def show():
#  mc.GetApp().GetLocalConfig().SetValue('keyboard_uppercase', 'true')
##  mc.GetActiveWindow().GetControl(fyre.hash.ids['keyboard']['key_a']).SetFocus()
#  print('show keyboard')
#  mc.GetApp().ActivateWindow(fyre.hash.windows['keyboard'], mc.Parameters())
#
##  mc.GetActiveWindow().GetEdit(fyre.hash.ids['keyboard']['edit_field']).SetText('')

def set_focus(scope):
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['keyboard_main']).SetVisible(True)
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['key_a']).SetFocus()


def deductAction():
  print('deduct action')
  scope = space.cache.current().scope()
  #TODO i don't know how to get module by name
  helper = False
  if scope == 'stars':
    helper = fyre.controllers.stars
  elif scope == 'packages':
    helper = fyre.controllers.packages
  elif scope == 'studios':
    helper = fyre.controllers.studios
  elif scope == 'movies':
    helper = fyre.controllers.movies

  if helper:
     if scope == 'movies':
       mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['show_on_coverflow']).SetFocus()
     else:
       mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['list']).SetFocus()
     mc.GetActiveWindow().GetControl(fyre.hash.ids[space.cache.current().scope()]['keyboard_main']).SetVisible(False)
     edit = mc.GetActiveWindow().GetEdit(int(mc.GetApp().GetLocalConfig().GetValue(scope + '_keyboard_reciever')))
     helper.search_by_pattern(edit.GetText())
  elif scope == 'signup' or scope == 'simple_signup':
    config = mc.GetApp().GetLocalConfig()
    return_id = int(config.GetValue(scope + '_keyboard_return'))
    border_id = int(config.GetValue(scope + '_keyboard_border'))
    mc.GetActiveWindow().GetControl(border_id).SetVisible(False)
    mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['keyboard']).SetVisible(False)
    mc.GetActiveWindow().GetControl(return_id).SetFocus()


def keyPressed(letter):
  print('pressed %s' % letter)
  scope = space.cache.current().scope()
  config = mc.GetApp().GetLocalConfig()
  use_uppercase = config.GetValue(scope + '_keyboard_uppercase')
  edit_field = int(config.GetValue(scope + '_keyboard_reciever'))
  search_string = mc.GetActiveWindow().GetEdit(edit_field).GetText()

  if use_uppercase == 'true':
    search_string += letter.upper()
  else:
    search_string += letter

  mc.GetActiveWindow().GetEdit(edit_field).SetText(search_string)


def showAlphabet():
  scope = space.cache.current().scope()
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['alphabet']).SetVisible(True)
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['numbers']).SetVisible(False)
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['key_num']).SetFocus()


def showNumbers():
  scope = space.cache.current().scope()
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['alphabet']).SetVisible(False)
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['numbers']).SetVisible(True)
  mc.GetActiveWindow().GetControl(fyre.hash.ids[scope]['key_alpha']).SetFocus()


def toggleShift():
  scope = space.cache.current().scope()
  config = mc.GetApp().GetLocalConfig()
  use_uppercase = config.GetValue(scope + '_keyboard_uppercase')
  window = mc.GetActiveWindow()

  if use_uppercase == 'true':
    config.SetValue(scope + '_keyboard_uppercase', 'false')
    for letter in letters[:26]:
      window.GetButton(fyre.hash.ids[scope]['key_' + letter.lower()]).SetLabel(letter)
  else:
    config.SetValue(scope + '_keyboard_uppercase', 'true')
    for letter in letters[26:]:
      window.GetButton(fyre.hash.ids[scope]['key_' + letter.lower()]).SetLabel(letter)


def setUppercase():
  scope = space.cache.current().scope()
  config = mc.GetApp().GetLocalConfig()
  uppercase = config.GetValue(scope + '_keyboard_uppercase')

  if uppercase != 'true':
    toggleShift()


def setLowercase():
  scope = space.cache.current().scope()
  config = mc.GetApp().GetLocalConfig()
  uppercase = config.GetValue(scope + '_keyboard_uppercase')

  if uppercase == 'true':
    toggleShift()


def delChar():
  scope = space.cache.current().scope()
  config = mc.GetApp().GetLocalConfig()
  receiver_id = int(config.GetValue(scope + '_keyboard_reciever'))
  string = mc.GetActiveWindow().GetEdit(receiver_id).GetText()
  string = string[:-1]
  mc.GetActiveWindow().GetEdit(receiver_id).SetText(string)

