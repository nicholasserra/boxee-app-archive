import mc;import fyre; import space; import fyre.view; import fyre.helpers.mode

def available(item):
  if item.GetProperty('contentID') == "None":
    mc.ShowDialogOk("Video not avaiable", "Comming soon on this platform.")
    return False
  else:
    return True