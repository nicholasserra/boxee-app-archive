import mc
import xbmc
import fyre
import fyre.hash


def show():
  mc.ShowDialogWait()
  #mc.HideDialogWait()
  #mc.ActivateWindow(fyre.hash.windows['loading'])


def hide():
  mc.HideDialogWait()
  #xbmc.executebuiltin("Dialog.Close(" + str(fyre.hash.windows['loading']) + ")")

