import mc
import fyre
import fyre.hash
import simplejson
import space

def increase(pinId, pinButtonId, digtNumber):
    pin = pinValue(pinId)
    new_value = pin[digtNumber] + 1
    if new_value > 9:
        new_value = 0

    mc.GetActiveWindow().GetButton(pinButtonId).SetLabel(str(new_value))
    pin[digtNumber] = new_value
    savePinValue(pinId, pin)

def decrease(pinId, pinButtonId, digtNumber):
    pin = pinValue(pinId)
    new_value = pin[digtNumber] - 1
    if new_value < 0:
        new_value = 9
    mc.GetActiveWindow().GetButton(pinButtonId).SetLabel(str(new_value))
    pin[digtNumber] = new_value
    savePinValue(pinId, pin)

def exit_fyre():
  mc.GetActiveWindow().ClearStateStack(False)
  mc.CloseWindow()

def loadDigt(pinId, digtNumber, scope):
    win = mc.GetActiveWindow()
    for i in range(6):
      buttonId = fyre.hash.ids[scope][pinId + '_digt' + str(i)]
      button = win.GetButton(buttonId)
      if i == digtNumber:
        digtValue = pinValue(fyre.hash.ids[scope][pinId + '_pin'])[digtNumber]
        button.SetLabel(str(digtValue))
      else:
        button.SetLabel('')

def pinValue(labelId):
  label = mc.GetActiveWindow().GetLabel(labelId)
  return simplejson.loads(label.GetLabel())

def savePinValue(labelId, pinValue):
  label = mc.GetActiveWindow().GetLabel(labelId)
  label.SetLabel(simplejson.dumps(pinValue))
