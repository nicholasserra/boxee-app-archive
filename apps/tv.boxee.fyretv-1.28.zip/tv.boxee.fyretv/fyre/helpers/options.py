import mc
import fyre
import fyre.hash

def select_scenes():
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['view_scenes']).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['view_titles']).SetSelected(False)
  fyre.controllers.coverflow.change_view_by('scene')
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['scenes']).SetVisible(True)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['titles']).SetVisible(False)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['redframe_row1']).SetFocus()

def select_movies():
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['view_scenes']).SetSelected(False)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['view_titles']).SetSelected(True)
  fyre.controllers.coverflow.change_view_by('movie')
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['scenes']).SetVisible(False)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['titles']).SetVisible(True)

