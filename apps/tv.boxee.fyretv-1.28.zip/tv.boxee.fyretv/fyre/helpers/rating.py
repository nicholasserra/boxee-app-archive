import mc
import fyre
import fyre.hash

def setRating(rating, ratingId):
  if rating <= 0.25:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('emptystar_cell.png')
  elif rating <= 0.75:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('halfstar_cell.png')
  elif rating <= 1.25:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('onestar_cell.png')
  elif rating <= 1.75:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('halfstar1_cell.png')
  elif rating <= 2.25:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('twostar_cell.png')
  elif rating <= 2.75:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('halfstar2_cell.png')
  elif rating <= 3.25:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('threestar_cell.png')
  elif rating <= 3.75:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('halfstar3_cell.png')
  elif rating <= 4.25:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('fourstar_cell.png')
  elif rating <= 4.75:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('halfstar4_cell.png')
  elif rating <= 5.0:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('fivestar_cell.png')
  else:
    mc.GetActiveWindow().GetImage(ratingId).SetTexture('emptystar_cell.png')
