import mc
import fyre
import fyre.hash

def set_distribution(distribution, scope):
  if int(distribution) == 1:
    texture = 'yellowprem_capsule.png'
    label = 'NEW RELEASE'
  else:
    texture = 'bluecatalog_capsule.png'
    label = 'CATALOG'

  mc.GetActiveWindow().GetImage(scope['distribution_image']).SetTexture(texture)
  mc.GetActiveWindow().GetLabel(scope['distribution_label']).SetLabel(label)
