import space; import mc; import fyre.view; import xbmc;import urllib

from lib.request import call_method

AVAILABLE_MODES = {'anonymous': 'A', 'full': 'F'}

def check_permission():
  if space.application_mode == 'F':
    return True
  elif space.application_mode == 'A':
    show_signup()

def get():
  application_mode = AVAILABLE_MODES[call_method('mode')['mode']]
  # mc.GetApp().GetLocalConfig().SetValue("mode_" + application_mode, application_mode)
  #setting value in localconfig didn't works with conditional visibility
  for mode in AVAILABLE_MODES.values():
    xbmc.executebuiltin("App.Reset(%s)" % ("mode_" + mode.lower()))
  xbmc.executebuiltin("App.SetString(%s, %s)" % (("mode_" + application_mode.lower()), application_mode))
  return application_mode

def get_currency():
  return urllib.unquote(call_method('currency')['symbol'])


def update():
  space.application_mode = get()
  space.currency = get_currency()

def show_signup():
  fyre.view.show('signup_reminder')


