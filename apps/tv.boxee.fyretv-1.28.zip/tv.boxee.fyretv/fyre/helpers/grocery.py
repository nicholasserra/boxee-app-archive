import mc;import fyre; import space; import fyre.view; import fyre.helpers.mode

def buy(confirmation_message, buying_method):
  if fyre.helpers.mode.check_permission():
    confirmation_header = "Confirm"
    response = mc.ShowDialogConfirm(confirmation_header, confirmation_message,
      "Cancel", "Buy")
    if response:
      fyre.helpers.loading.show()
      message = buying_method()
      fyre.helpers.loading.hide()
      #mc.ShowDialogNotification(message)
    else:
      print('he not buy')

def number_to_currency(price):
  return "%s%s" % (space.currency, price)
