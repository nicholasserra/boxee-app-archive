import mc;import fyre; import space;


def left(list_id):
  print('scrollLeft')
  list = mc.GetActiveWindow().GetList(list_id)
  current_position = list.GetFocusedItem()

  if current_position > 1:
    new_position = current_position - 1
  else:
    new_position = 0

  space.cache.current().focus(new_position)
  list.SetFocusedItem(new_position)

def right(list_id, elements):
  print('scrollRight')
  list = mc.GetActiveWindow().GetList(list_id)
  current_position = list.GetFocusedItem()

  if current_position < (len(elements) -1):
    new_position = current_position + 1
  elif current_position < len(elements): #when we are on last element we don't want to move any more
    new_position = current_position
  else:
    new_position = len(elements) - 1

  space.cache.current().focus(new_position)
  list.SetFocusedItem(new_position)

def scenes_left(scope, content):
  print('scroll scenes Left')
  current_position = content.focused_element
  if current_position > 2:
    new_position = current_position - 2
  else:
    if (current_position % 2) == 1:
      new_position = 1
    else:
      new_position = 0


  space.cache.current().focus(new_position)
  mc.GetActiveWindow().GetList(scope['scene_list_row1']).SetFocusedItem(new_position/2)
  mc.GetActiveWindow().GetList(scope['scene_list_row2']).SetFocusedItem(new_position/2)

def scenes_rowup(scope, content):
  new_position = content.focused_element - 1
  space.cache.current().focus(new_position)
  mc.GetActiveWindow().GetControl(scope['redframe_row1']).SetFocus()

def scenes_rowdown(scope, content):
  print("Debug focused_element: %s" % content.focused_element)
  #special case for such situation(when on 1 row is more element than on 2 row)
  #
  # ****
  # ***
  #
  if content.focused_element + 1 >= len(content.playlist_scenes()) and (len(content.playlist_scenes()) % 2) == 1:
    new_position = content.focused_element - 1
  else:
    new_position = content.focused_element + 1
  print("Debug new pos: %s" % new_position)
  print("Debug total: %s" % len(content.playlist_scenes()))
  space.cache.current().focus(new_position)
  mc.GetActiveWindow().GetControl(scope['redframe_row2']).SetFocus()
  mc.GetActiveWindow().GetList(scope['scene_list_row1']).SetFocusedItem(new_position/2)
  mc.GetActiveWindow().GetList(scope['scene_list_row2']).SetFocusedItem(new_position/2)

def scenes_right(scope, content):
  current_position = content.focused_element
  if current_position < len(content.playlist_scenes()) - 2:
    new_position = current_position + 2
  else:
    new_position = current_position

  content.focus(new_position)
  mc.GetActiveWindow().GetList(scope['scene_list_row1']).SetFocusedItem(new_position/2)
  mc.GetActiveWindow().GetList(scope['scene_list_row2']).SetFocusedItem(new_position/2)



