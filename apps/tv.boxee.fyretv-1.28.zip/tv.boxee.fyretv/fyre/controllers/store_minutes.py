import mc;import fyre;import fyre.hash;import space; import fyre.helpers.grocery


def load(content):
  items = mc.ListItems()
  first = True
  for minutes, offer in content.offers.items():
    item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    item.SetLabel('%s minutes for %s' % (offer['credits'], fyre.helpers.grocery.number_to_currency(offer['price'])))
    if first:
      first = False
      content.set_selected_offer(offer['credits'])
      choosen = '1'
    else:
      choosen = '0'
    item.SetProperty('choosen', choosen)
    item.SetProperty('minutes', str(offer['credits']))
    items.append(item)

  list = mc.GetActiveWindow().GetList(fyre.hash.ids['store_minutes']['minutes_list'])
  list.SetItems(items)

  mc.GetActiveWindow().GetLabel(fyre.hash.ids['store_minutes']['current_balance']).SetLabel(str(content.current_balance))


def check_element():
  list = mc.GetActiveWindow().GetList(fyre.hash.ids['store_minutes']['minutes_list'])
  items = list.GetItems()
  new_items = mc.ListItems()
  focused_item_index = list.GetFocusedItem()
  focused_item = list.GetItem(focused_item_index)
  for item in items:
    if item.GetLabel() == focused_item.GetLabel():
      item.SetProperty('choosen', '1')
    else:
      item.SetProperty('choosen', '0')
    new_items.append(item)
  list.SetItems(new_items)
  list.SetFocusedItem(focused_item_index)
  space.cache.current().set_selected_offer(focused_item.GetProperty('minutes'))

def onclick_buy():
  offer = space.cache.current().selected_offer()
  fyre.helpers.grocery.buy("[B]Purchase credits for %s[/B][CR] *This will add some minutes" % fyre.helpers.grocery.number_to_currency(offer['price']), _buy_minutes)

def _buy_minutes():
  if space.cache.current().buy_minutes():
    load(space.cache.current())
    message = 'Thank you.'
  else:
    message = 'Something went wrong'
  return message
