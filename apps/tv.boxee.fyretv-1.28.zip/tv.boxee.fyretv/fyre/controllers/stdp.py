import mc
import fyre
import fyre.hash

def load(stdp_content):
  star = stdp_content.star
  mc.GetActiveWindow().GetImage(fyre.hash.ids['stdp']['headshot']).SetTexture(fyre.config['server_prefix']['thumbnails'] + str(star['headshot']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['stdp']['star_name']).SetLabel(str(star['name']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['stdp']['attributes']).SetLabel(str(star['categories']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['stdp']['date_of_birth']).SetLabel(str(star['date_of_birth']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['stdp']['place_of_birth']).SetLabel(str(star['place_of_birth']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['stdp']['measurements']).SetLabel(str(star['measurements']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['stdp']['total_scenes']).SetLabel(str(star["nbr_scenes"]))
