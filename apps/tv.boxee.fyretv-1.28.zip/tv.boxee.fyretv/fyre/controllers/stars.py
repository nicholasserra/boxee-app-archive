import mc;import fyre;import fyre.hash;import space;

def load(content):
  mc.GetApp().GetLocalConfig().SetValue("stars_keyboard_reciever", str(fyre.hash.ids['stars']['edit_field']))
  mc.GetActiveWindow().GetEdit(fyre.hash.ids['stars']['edit_field']).SetText(content.opts['pattern'])
  print 'load stars '
  starItems = mc.ListItems()
  for (i, (star_id, star)) in zip(range(1, len(content.response['stars'])+1), content.response['stars'].items()):
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel(str(star['name']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(star['headshot']))
    item.SetProperty('index', str(i))
    item.SetProperty('categories', str(star['categories']))
    item.SetProperty('date_of_birth', str(star['date_of_birth']))
    item.SetProperty('place_of_birth', str(star['place_of_birth']))
    item.SetProperty('measurements', str(star['measurements']))
    item.SetProperty('nbr_scenes', str(star['nbr_scenes']))
    item.SetProperty('star_id', str(star_id))
    starItems.append(item)

  star_list = mc.GetActiveWindow().GetList(fyre.hash.ids['stars']['list'])
  star_list.SetItems(starItems)
  star_list.SetFocusedItem(content.focused_element)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['stars']['empty_list']).SetVisible(int(content.response['count']) == 0)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['stars']['list_content']).SetVisible(not int(content.response['count']) == 0)
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['stars']['number_of_items']).SetLabel(str(content.response['count']))


def on_click(list):
  space.cache.current().focused_element = list.GetFocusedItem()
  star_item = list.GetItem(list.GetFocusedItem())
  star_id = star_item.GetProperty('star_id')
  fyre.view.show('coverflow', 'star_scenes/' + star_id, {'media_type': 'scene', 'label': star_item.GetLabel()})

#TODO refactor it, this method is the same in movies/stars/studios
#exclude this method to other file
def search_by_pattern(pattern):
  fyre.helpers.loading.show()
  space.cache.current().search_by_name(pattern)
  load(space.cache.current())
  fyre.helpers.loading.hide()


def next_page():
  space.cache.current().next_page()
