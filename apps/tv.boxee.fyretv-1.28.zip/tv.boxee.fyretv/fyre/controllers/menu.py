import mc; import fyre; import space;import fyre.hash; import fyre.helpers.scroll

def load(content):
  mc.GetActiveWindow().GetList(1001).SetFocusedItem(space.cache.current().entered_menu)
  fill_list(content)

def fill_list(content):
  print('fill view menu')
  fyre.controllers.coverflow.fill_scenes_generic(content, fyre.hash.ids['menu'], content.first_time_render)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['menu']['scenes']).SetVisible(True)
  if content.first_time_render:
    content.first_time_render = False
    mc.GetActiveWindow().GetControl(fyre.hash.ids['menu']['recomendation']).SetFocus()

def scroll_left_scenes():
  fyre.helpers.scroll.scenes_left(fyre.hash.ids['menu'], space.cache.current())

def scroll_right_scenes():
  fyre.helpers.scroll.scenes_right(fyre.hash.ids['menu'], space.cache.current())

def scroll_up_scenes():
  fyre.helpers.scroll.scenes_rowup(fyre.hash.ids['menu'], space.cache.current())

def scroll_down_scenes():
  fyre.helpers.scroll.scenes_rowdown(fyre.hash.ids['menu'], space.cache.current())


def set_focus_to_submenu():
  window = mc.GetActiveWindow()
  movies = window.GetControl(fyre.hash.ids['menu']['menu_movies'])
  #live_tv = window.GetControl(fyre.hash.ids['menu']['menu_live_tv'])
  account = window.GetControl(fyre.hash.ids['menu']['menu_account'])
  store = window.GetControl(fyre.hash.ids['menu']['menu_store'])
  quit = window.GetControl(fyre.hash.ids['menu']['menu_quit'])

  #for group in [movies, live_tv, account, store, quit]:
  for group in [movies, account, store, quit]:
    if group.IsVisible():
      group.SetFocus()
      break

def remember_entered_menu():
  window = mc.GetActiveWindow()
  movies = window.GetControl(fyre.hash.ids['menu']['menu_movies'])
  #live_tv = window.GetControl(fyre.hash.ids['menu']['menu_live_tv'])
  account = window.GetControl(fyre.hash.ids['menu']['menu_account'])
  store = window.GetControl(fyre.hash.ids['menu']['menu_store'])
  quit = window.GetControl(fyre.hash.ids['menu']['menu_quit'])

  i=0
  #for group in [movies, live_tv, account, store, quit]:
  for group in [movies, account, store, quit]:
    if group.IsVisible():
      space.cache.current().entered_menu = i
      break
    else:
      i += 1

