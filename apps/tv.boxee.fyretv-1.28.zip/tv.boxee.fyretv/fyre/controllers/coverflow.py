import mc; import fyre; import space; import fyre.hash; import fyre.content; import fyre.helpers.loading; import fyre.helpers.scroll

def load(coverflow_content):
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['coverflow']['title']).SetLabel(coverflow_content.opts['label'])
  mc.GetActiveWindow().GetList(fyre.hash.ids['coverflow']['selected_categories']).SetItems(mc.ListItems()) # clear selected categories


  if coverflow_content.method == 'new_releases':
    mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_new_releases']).SetEnabled(False)
  else:
    mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_new_releases']).SetEnabled(True)

  show_options_for(coverflow_content.opts['label'])
  fill_list(coverflow_content)
  initialize_view(coverflow_content)

def change_view_by(view_by):
  fyre.helpers.loading.show()
  space.cache.current().update_options({'media_type': view_by})
  fyre.helpers.loading.hide()

def change_sort(sort):
  fyre.helpers.loading.show()
  space.cache.current().update_options({'sort': sort})
  fyre.helpers.loading.hide()

def change_quality(hd, sd):
  fyre.helpers.loading.show()
  params = {}
  if sd and not hd:
    params['only_this_quality'] = 'sd'
  elif hd and not sd:
    params['only_this_quality'] = 'hd'
  elif hd and sd:
    params['only_this_quality'] = False
  space.cache.current().update_options(params)
  fyre.helpers.loading.hide()

def change_category_filter(category_list_items):
  included = []
  excluded = []
  for item in category_list_items:
    if item.GetProperty('category-include') == 'True':
      included.append(item.GetProperty('category_id'))
    elif item.GetProperty('category-exclude') == 'True':
      excluded.append(item.GetProperty('category_id'))
  space.cache.current().update_options({'categories_excluded': excluded, 'categories_included': included})

def change_show_new_releases():
  fyre.helpers.loading.show()
  include = mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_new_releases']).IsSelected()
  space.cache.current().update_options({'exclude_new_releases': not include})
  fyre.helpers.loading.hide()

def change_show_watched():
  fyre.helpers.loading.show()
  include =   mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_watched']).IsSelected()
  space.cache.current().update_options({'exclude_watched': not include})
  fyre.helpers.loading.hide()

def clear():
  fyre.helpers.loading.show()
  space.cache.current().clear()
  fyre.helpers.loading.hide()

def fill_list(content, reset_data = False):
  if content.opts['media_type'] == 'movie':
    fill_movie_list(content)
  else:
    fill_scene_list(content, reset_data)
#    self.focused_element = 0

  if content.method == 'playlist':
    count = str(len(content.playlist_scenes()))
    no_results = (int(count) == 0)
  else:
    count = str(content.response['count'])
    no_results = (
                   int(count) == 0 or
                   (
                     ((not content.response.has_key('scenes')) or len(content.response['scenes']) == 0) and
                     ((not content.response.has_key('movie_titles')) or len(content.response['movie_titles']) == 0)
                   )
                 )

  mc.GetActiveWindow().GetLabel(fyre.hash.ids['coverflow']['number_of_items']).SetLabel(count)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['empty_list']).SetVisible(no_results)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['lists_content']).SetVisible(not no_results)
  if hasattr(content, 'response') and content.response.has_key('categories'):
    load_category_filter(space.all_categories, content.response['categories'])


def fill_movie_list(content):
  list_element = mc.GetActiveWindow().GetList(fyre.hash.ids['coverflow']['movie_list'])
  items = mc.ListItems()

  for (i, (title_id, movie)) in (zip(range(1, len(content.response['movie_titles'])+1), content.response['movie_titles'].items())):
    item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
    item.SetLabel(str(movie['title']))
    item.SetPath(fyre.config['server_prefix']['thumbnails'] + str(movie['front_cover']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(movie['front_cover']))
    item.SetProperty('index', str(i))
    item.SetProperty('movie-title-id', str(title_id))
    item.SetProperty('new_release', str(str(movie['distribution_window']) == '1'))
    item.SetProperty('is_hd', str(movie['is_hd']))
    items.append(item)

  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)) # two blank movies, hack for not working fixedlist
  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))

  list_element.SetItems(items)
  list_element.SetFocusedItem(content.focused_element)

def fill_scene_list(content, reset_data = False):
  fill_scenes_generic(content, fyre.hash.ids['coverflow'], not reset_data)

def fill_scenes_generic(content,scope, set_focus = True):
  list1 = mc.GetActiveWindow().GetList(scope['scene_list_row1'])
  list2 = mc.GetActiveWindow().GetList(scope['scene_list_row2'])
  row1 = mc.ListItems()
  row2 = mc.ListItems()

  for (i, scene_item) in zip(range(1, len(content.playlist_scenes()) + 1), content.playlist_scenes()):
    item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
    item.SetLabel(str(scene_item['name']))
    item.SetPath(fyre.config['server_prefix']['thumbnails'] + str(scene_item['thumbnails'][3]))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(scene_item['thumbnails'][3]))
    item.SetProperty('index', str(i))
    item.SetProperty('scene_id', str(scene_item['scene_id']))
    item.SetProperty('new_release', str(str(scene_item['distribution_window']) == '1'))
    item.SetProperty('is_hd', str(scene_item['is_hd']))
    if i % 2 == 0:
      row2.append(item)
    else:
      row1.append(item)

  row1.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  row1.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  row1.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  row1.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  row2.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  row2.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  row2.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  row2.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))

  mc.GetActiveWindow().GetList(scope['scene_list_row1']).SetItems(row1)
  mc.GetActiveWindow().GetList(scope['scene_list_row2']).SetItems(row2)


  focused = content.focused_element
  if focused % 2 ==0:
    list2.SetFocusedItem(focused/2)
    list1.SetFocusedItem(focused/2)
    if set_focus: mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['redframe_row1']).SetFocus()
  else:
    list2.SetFocusedItem((focused+1)/2)
    list1.SetFocusedItem((focused+1)/2)
    if set_focus: mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['redframe_row2']).SetFocus()

def scrollLeft():
  fyre.helpers.scroll.left(fyre.hash.ids['coverflow']['movie_list'])

def scrollRight():
  fyre.helpers.scroll.right(fyre.hash.ids['coverflow']['movie_list'], space.cache.current().response['movie_titles'])

def movie_click():
  fyre.view.show('tdp', mc.GetActiveWindow().GetList(fyre.hash.ids['coverflow']['movie_list']).GetItem(mc.GetActiveWindow().GetList(fyre.hash.ids['coverflow']['movie_list']).GetFocusedItem()).GetProperty('movie-title-id'))

def scroll_up_scenes():
  fyre.helpers.scroll.scenes_rowup(fyre.hash.ids['coverflow'], space.cache.current())

def scroll_down_scenes():
  fyre.helpers.scroll.scenes_rowdown(fyre.hash.ids['coverflow'], space.cache.current())

def scroll_left_scenes():
  fyre.helpers.scroll.scenes_left(fyre.hash.ids['coverflow'], space.cache.current())

def scroll_right_scenes():
  fyre.helpers.scroll.scenes_right(fyre.hash.ids['coverflow'], space.cache.current())


def toggle_sort_buttons(new_sort):
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['sort_addition_date']).SetSelected(False)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['sort_name']).SetSelected(False)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['sort_rating']).SetSelected(False)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['sort_views_count']).SetSelected(False)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['sort_' + new_sort]).SetSelected(True)
  change_sort(new_sort)

def toggle_quality(quality):
  button = {}
  is_enabled = {}
  button['hd'] = mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_hd'])
  button['sd'] = mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_sd'])
  is_enabled['hd'] = button['hd'].IsSelected()
  is_enabled['sd'] = button['sd'].IsSelected()
  print(is_enabled)
  if not is_enabled['hd'] and not is_enabled['sd']:
    #one button must be checked
    button[quality].SetSelected(True)
  else:
    change_quality(is_enabled['hd'], is_enabled['sd'])



def load_category_filter(all_categories, active_categories):
  content = space.cache.current()

  available_categories = mc.GetWindow(fyre.hash.windows['coverflow']).GetList(fyre.hash.ids['coverflow']['available_categories'])
  selected_categories = mc.GetActiveWindow().GetList(fyre.hash.ids['coverflow']['selected_categories'])

  items = mc.ListItems()
  selected_items = mc.ListItems()
  for categoryId, category in all_categories.items():
    item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    item.SetLabel(str(category['name']))
    item.SetProperty('category_id', str(categoryId))
    if active_categories.has_key(categoryId):
      item.SetProperty('enabled', 'True')

    if content.selected_categories.has_key(categoryId):
      if content.selected_categories[categoryId]:
        item.SetProperty('category-exclude', 'True')
        item.SetProperty('category-include', 'False')
      else:
        item.SetProperty('category-include', 'True')
        item.SetProperty('category-exclude', 'False')

      selected_items.append(item)

    items.append(item)

  selected_categories.SetItems(selected_items)
  previous_position = available_categories.GetFocusedItem()
  previous_items = available_categories.GetItems()
  available_categories.SetItems(items)
  if len(previous_items) > 0:
    available_categories.SetFocusedItem(previous_position)
  else:
    available_categories.SetFocusedItem(11)

def checkCategoryOnFilter():
  content = space.cache.current()
  def find_item_in_list(list, field, value):
    for item in list:
      if item.GetProperty(field) == value:
        return item
    return False

  def remove_from_list(glist, gitem):
    for item, idx in zip(glist, range(150)):
      if item.GetLabel() == gitem.GetLabel():
        return glist.__delitem__(idx)

  available_categories = mc.GetActiveWindow().GetList(fyre.hash.ids['coverflow']['available_categories'])
  selected_categories = mc.GetActiveWindow().GetList(fyre.hash.ids['coverflow']['selected_categories'])
  selected_items = selected_categories.GetItems()
  focused_item = available_categories.GetItem(available_categories.GetFocusedItem())
  if not focused_item.GetProperty('enabled') == 'True' and focused_item.GetProperty('category-exclude') != 'True':
    return False
  if focused_item.GetProperty('category-include') == 'True':
    focused_item.SetProperty('category-include', 'False')
    focused_item.SetProperty('category-exclude', 'True')
    item_to_change_in_selected = find_item_in_list(selected_items, 'category_id', focused_item.GetProperty('category_id'))
    item_to_change_in_selected.SetProperty('category-include', 'False')
    item_to_change_in_selected.SetProperty('category-exclude', 'True')
    content.selected_categories[focused_item.GetProperty('category_id')] = True
  elif focused_item.GetProperty('category-exclude') == 'True':
    focused_item.SetProperty('category-exclude', 'False')
    item_to_change_in_selected = find_item_in_list(selected_items, 'category_id', focused_item.GetProperty('category_id'))
    remove_from_list(selected_items, focused_item)
    selected_categories.SetItems(selected_items)
    del content.selected_categories[focused_item.GetProperty('category_id')]
  else:
    focused_item.SetProperty('category-include', 'True')
    selected_items.append(focused_item) # here we can use item from diffrent list
    selected_categories.SetItems(selected_items)
    content.selected_categories[focused_item.GetProperty('category_id')] = False

  fyre.helpers.loading.show()
  change_category_filter(selected_items)
  fyre.helpers.loading.hide()

def initialize_view(content):
  if content.opts['media_type'] == 'movie':
    view_type_id = 'view_titles'
    red_frame = 'frame_button'
    mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['titles']).SetVisible(True)
    mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['scenes']).SetVisible(False)
  else:
    view_type_id = 'view_scenes'
    list = 'scenes'
    red_frame = 'redframe_row1'
    mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['titles']).SetVisible(False)
    mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['scenes']).SetVisible(True)

  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow'][view_type_id]).SetSelected(True)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow'][red_frame]).SetFocus()

  if not content.method == 'playlist': mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['sort_' + content.opts['sort']]).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_watched']).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_new_releases']).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_hd']).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['coverflow']['show_sd']).SetSelected(True)

def show_options_for(label):
  visible = not label in ['NAKED NEWS', 'STORE: MOVIES', 'STORE: SCENES', 'WATCHED SCENES', 'FAVORITE SCENES', 'CURRENT PLAYLIST']
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['categories_hint']).SetVisible(visible)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['categories']).SetVisible(visible)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['options']).SetVisible(visible)
  show_clear = label in ['WATCHED SCENES', 'CURRENT PLAYLIST', 'FAVORITE SCENES']
  mc.GetActiveWindow().GetControl(fyre.hash.ids['coverflow']['clear']).SetVisible(show_clear)
