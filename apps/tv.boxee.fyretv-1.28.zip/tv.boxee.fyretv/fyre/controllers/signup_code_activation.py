import fyre
import mc
import time
import space
import xbmc
from lib.request import call_method

def load(content):
  fyre.helpers.loading.show()
  result = call_method('registration_code')
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['signup_code_activation']['activation_code']).SetLabel(result['code'])
  fyre.helpers.loading.hide()

def is_associated():
  response = call_method('associated')

  if response['result'] == 'OK':
    fyre.controllers.signup.close_after_signup()
    #mc.GetApp().ActivateWindow(fyre.hash.windows['menu'], mc.Parameters())
    #xbmc.executebuiltin("ReplaceWindow(%s)" % fyre.hash.windows['switcher'])
    #fyre.view.show('signup_association_finished')
  else:
    mc.ShowDialogOk("Error occured", "Please visit www.fyretv.com/MyDevices and enter the code in the Activate field.")

def is_associated_onunload():
  if call_method('associated')['result']  == 'OK':
    fyre.controllers.signup.close_after_signup(False)


