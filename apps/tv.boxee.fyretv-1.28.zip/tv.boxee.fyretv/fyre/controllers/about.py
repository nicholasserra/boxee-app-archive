import mc; import fyre; import space;import fyre.hash; import fyre.helpers.scroll

def load(content):
  print('load about info')
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['about']['fyretv_version']).SetLabel(fyre.config['version'])
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['about']['serial_num']).SetLabel(space.serial_num)

