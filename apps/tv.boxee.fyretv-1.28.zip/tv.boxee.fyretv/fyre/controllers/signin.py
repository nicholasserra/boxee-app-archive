import mc
import xbmc
import fyre
import fyre.hash
import space
from lib.request import call_method

def load(content):
  pass

def verifyPin(pinArray):
    pin = ''.join([str(e) for e in pinArray])
    results = call_method('verify_pin', {'pin': pin})
    if results:
      if space.after_screensaver:
        space.after_screensaver_after_signin = True
        space.after_screensaver = False
      xbmc.executebuiltin("ReplaceWindow(%s)" % fyre.hash.windows['switcher'])
    else:
      mc.ShowDialogNotification('Invalid pin')

