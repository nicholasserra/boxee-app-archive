import mc; import fyre; import fyre.hash; import space

def load(content):
  pass
