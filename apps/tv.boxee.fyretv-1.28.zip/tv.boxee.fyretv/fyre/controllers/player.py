import mc
import fyre.hash
import space

from lib.player_thread import start_playback

def pause():
  mc.GetPlayer().Pause()
  space.pt.touch()

def fast_forward():
  mc.GetPlayer().SeekTime(mc.GetPlayer().GetTime() + 30)
  space.pt.touch()

def rewind():
  mc.GetPlayer().SeekTime(mc.GetPlayer().GetTime() - 30)
  space.pt.touch()

def show_scenes():
  mc.GetActiveWindow().GetButton(fyre.hash.ids['player']['scenes_focus']).SetFocus()
  if not mc.GetPlayer().IsPaused():
    mc.GetPlayer().Pause()
  space.pt.touch()

def hide_scenes():
  mc.GetActiveWindow().GetButton(fyre.hash.ids['player']['action']).SetFocus()
  space.pt.touch()

def scroll_left():
  lst = mc.GetActiveWindow().GetList(fyre.hash.ids['player']['scenes_list'])
  idx = lst.GetFocusedItem()

  if idx > 0:
    idx -= 1
    lst.SetFocusedItem(idx)

def scroll_right():
  lst = mc.GetActiveWindow().GetList(fyre.hash.ids['player']['scenes_list'])
  idx = lst.GetFocusedItem()

  if idx < len(lst.GetItems()) - 5:
    idx += 1
    lst.SetFocusedItem(idx)

def scene_click():
  lst = mc.GetActiveWindow().GetList(fyre.hash.ids['player']['scenes_list'])
  idx = lst.GetFocusedItem()

  scene = lst.GetItem(idx)
  cid = scene.GetProperty('cid')

  space.pt.switch_played_content(cid)
