import mc; import fyre; import space;import fyre.hash; import fyre.helpers.scroll; import fyre.helpers.media_content;
from fyre.controllers.coverflow import change_sort

def load(content):
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['my_library']['title']).SetLabel('My Library')
  initialize_toggle_option_buttons(content.opts['sort'])
  fill_list(content)
  list = mc.GetActiveWindow().GetList(fyre.hash.ids['my_library']['media_list'])
  if list.GetItem(list.GetFocusedItem()+2).GetProperty('scene') == 'True':
    mc.GetActiveWindow().GetControl(fyre.hash.ids['my_library']['redframe_scene1']).SetFocus()
  else:
    mc.GetActiveWindow().GetControl(fyre.hash.ids['my_library']['redframe_big']).SetFocus()

def fill_list(content):
  covers = mc.GetActiveWindow().GetList(fyre.hash.ids['my_library']['media_list'])
  print('fill_list')
  items = mc.ListItems()
  for (i, (object_id, object)) in (zip(range(1, len(content.response['subscribed_media'])+1), content.response['subscribed_media'].items())):
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel(str(object['name']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(object['thumbnail']))
    item.SetProperty('index', str(i))
    item.SetProperty('object_id', str(object_id))
    item.SetProperty('type', str(object['type']))
    item.SetProperty('contentID', str(object['contentID']))
    if object['type'] == 'scene':
      item.SetProperty('scene', 'True')
    else:
      item.SetProperty('scene', 'False')
    items.append(item)

  covers.SetItems(items)
  covers.SetFocusedItem(content.focused_element)

  mc.GetActiveWindow().GetLabel(fyre.hash.ids['my_library']['number_of_items']).SetLabel(str(content.response['count']))
  mc.GetActiveWindow().GetControl(fyre.hash.ids['my_library']['empty_list']).SetVisible(int(content.response['count']) == 0)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['my_library']['lists_content']).SetVisible(not int(content.response['count']) == 0)

def toggle_sort_button(new_sort):
  change_sort(new_sort)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['sort_name']).SetSelected(False)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['sort_purchase_date']).SetSelected(False)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['sort_' + new_sort]).SetSelected(True)

def toggle_view_type(new_type):
  something_selected = False
  types = []
  for type in ['scene', 'movie', 'package']:
    if mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['view_%s' % type]).IsSelected():
      types.append(type)
      something_selected = True
  if not something_selected:
    mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['view_%s' % new_type]).SetSelected(True)
    types.append(new_type)
  space.cache.current().update_options({'types': ','.join(types)})

def initialize_toggle_option_buttons(sort_by):
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['sort_' + sort_by]).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['view_scene']).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['view_movie']).SetSelected(True)
  mc.GetActiveWindow().GetToggleButton(fyre.hash.ids['my_library']['view_package']).SetSelected(True)

def enter_to_detail_page():
  list = mc.GetActiveWindow().GetList(fyre.hash.ids['my_library']['media_list'])
  mediaItem = list.GetItem(list.GetFocusedItem())
  if mediaItem.GetProperty('type') == 'scene':
     print(mediaItem)
     print(mediaItem.GetProperty('contentID'))
     if fyre.helpers.media_content.available(mediaItem):
       print('iam in')
       fyre.view.show('sdp', mediaItem.GetProperty('object_id'))
  elif mediaItem.GetProperty('type') == 'movie':
    if fyre.helpers.media_content.available(mediaItem):
      fyre.view.show('tdp', mediaItem.GetProperty('object_id'))
  elif mediaItem.GetProperty('type') == 'package':
    fyre.view.show('pdp', mediaItem.GetProperty('object_id'))

def scroll_left():
  fyre.helpers.scroll.left(fyre.hash.ids['my_library']['media_list'])

def scroll_right():
  fyre.helpers.scroll.right(fyre.hash.ids['my_library']['media_list'], space.cache.current().response['subscribed_media'])
