import mc; import fyre; import space;import fyre.hash; import fyre.helpers.scroll
from lib.player_thread import start_playback

def scene_click(scene_id):
  fyre.view.show('sdp', scene_id)
