import mc; import fyre; import space;import fyre.hash; import fyre.helpers.scroll

def load(content):
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['store_packages']['title']).SetLabel('Store Packages')
  fill_list(content)

def fill_list(content):
  covers = mc.GetActiveWindow().GetList(fyre.hash.ids['store_packages']['package_list'])
  print('fill_list')
  items = mc.ListItems()
  for (i, (package_id, package)) in (zip(range(1, len(content.response['packages'])+1), content.response['packages'].items())):
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel(str(package['name']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(package['thumbnail_library']))
    item.SetProperty('index', str(i))
    item.SetProperty('nbr_movies', package['nbr_movies'])
    item.SetProperty('package_id', str(package_id))
    items.append(item)
    i += 1

  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)) # two blank movies, hack for not working fixedlist
  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  items.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))

  covers.SetItems(items)
  covers.SetFocusedItem(content.focused_element)

  mc.GetActiveWindow().GetLabel(fyre.hash.ids['store_packages']['number_of_items']).SetLabel(str(content.response['count']))


def scroll_left():
  fyre.helpers.scroll.left(fyre.hash.ids['store_packages']['package_list'])

def scroll_right():
  fyre.helpers.scroll.right(fyre.hash.ids['store_packages']['package_list'], space.cache.current().response['packages'])

def click():
  fyre.view.show('pdp', mc.GetActiveWindow().GetList(fyre.hash.ids['store_packages']['package_list']).GetItem(mc.GetActiveWindow().GetList(fyre.hash.ids['store_packages']['package_list']).GetFocusedItem()).GetProperty('package_id'))
