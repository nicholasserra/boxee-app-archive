import mc; import fyre; import fyre.hash; import space

def load(content):
  mc.GetApp().GetLocalConfig().SetValue("studios_keyboard_reciever", str(fyre.hash.ids['studios']['edit_field']))
  mc.GetActiveWindow().GetEdit(fyre.hash.ids['studios']['edit_field']).SetText(content.pattern)
  studioItems = mc.ListItems()
  i = 0
  for studio_id, studio in content.studios.items():
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel(str(studio['name']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(studio['thumbnail_large']))
    i += 1
    item.SetProperty('index', str(i))
    item.SetProperty('nbr_movies', str(studio['nbr_movies']))
    item.SetProperty('studio_id', str(studio_id))
    studioItems.append(item)

  list = mc.GetActiveWindow().GetList(fyre.hash.ids['studios']['list'])
  list.SetItems(studioItems)
  list.SetFocusedItem(content.focused_element)
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['studios']['number_of_items']).SetLabel(str(content.count))
  mc.GetActiveWindow().GetControl(fyre.hash.ids['studios']['empty_list']).SetVisible(int(content.count) == 0)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['studios']['list_content']).SetVisible(not int(content.count) == 0)

def on_click(list):
  space.cache.current().focused_element = list.GetFocusedItem()
  studio_item = list.GetItem(list.GetFocusedItem())
  studio_id = studio_item.GetProperty('studio_id')
  fyre.view.show('coverflow', 'studio/' + studio_id, {'media_type': 'movie', 'label': studio_item.GetLabel()})

#TODO refactor it, this method is the same in movies/stars/studios
#exclude this method to other file
def search_by_pattern(pattern):
  fyre.helpers.loading.show()
  space.cache.current().search_by_name(pattern)
  load(space.cache.current())
  fyre.helpers.loading.hide()

def next_page():
  pass
