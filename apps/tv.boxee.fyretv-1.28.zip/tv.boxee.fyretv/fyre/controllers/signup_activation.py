import mc;import xbmc;import fyre;import fyre.hash; import space
from lib.request import call_method

def connect():
  fyre.helpers.loading.show()
  window = mc.GetActiveWindow()
  email = window.GetEdit(fyre.hash.ids['signup_activation']['email']).GetText()
  password = window.GetEdit(fyre.hash.ids['signup_activation']['password']).GetText()

  if email == '':
    mc.ShowDialogOk("Error", "E-mail field can't be blank.")
  elif password == '':
    mc.ShowDialogOk("Error", "Password field can't be blank.")
  else:
    print('email: %s, pass: %s' % (email, password))
    response = call_method('connect_with_account', {'email': email, 'password': password})

    if response['result'] == 'OK':
      fyre.controllers.signup.close_after_signup()
    else:
      mc.ShowDialogOk("Error occured", response['notice'].replace('<br/>', '\n'))

  fyre.helpers.loading.hide()
