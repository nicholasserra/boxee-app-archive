import mc;import xbmc;import fyre;import fyre.hash; import space;

def finish():
  space.cache.clear_signup()