import mc;import fyre;import fyre.hash;import space; import player;import fyre.helpers.grocery
from lib.player_thread import start_playback

def load(tdp_content):
  movie = tdp_content.movie
  tdp = fyre.hash.ids['tdp']
  mc.GetActiveWindow().GetLabel(tdp['title']).SetLabel(movie['title'].encode())
  mc.GetActiveWindow().GetControl(tdp['is_hd']).SetVisible(movie['is_hd'])
  coverList = mc.ListItems()
  for path in [movie['large_cover'], movie['back_cover']]:
    coverItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    coverItem.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(path))
    coverList.append(coverItem)

  mc.GetActiveWindow().GetList(tdp['cover_back']).SetItems(coverList)

  # Scenes list
  scenesItems = mc.ListItems()

  for scene_id, scene in tdp_content.scenes_details.items():
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel('Scene %s:' % str(scene['scene_nbr']))
    item.SetPath(fyre.config['server_prefix']['vod'] + str(scene['content_id']) + ".ts?id=" + scene['scene_nbr'].encode())
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(scene['thumbnails'][3]))
    item.SetProperty('scene_id', str(scene['scene_id']))
    item.SetProperty('cid', str(scene['content_id']))
    item.SetProperty('starsInfo', ', '.join([str(tdp_content.stars[str(e)]['name']) for e in scene['stars']]))
    item.SetProperty('categoriesInfo', ', '.join([str(tdp_content.categories[str(e)]['name']) for e in scene['categories']]))
    scenesItems.append(item)

  scenesItems.append(mc.ListItem(mc.ListItem.MEDIA_UNKNOWN))
  scenesItems.append(mc.ListItem(mc.ListItem.MEDIA_UNKNOWN))
  scenesItems.append(mc.ListItem(mc.ListItem.MEDIA_UNKNOWN))
  scenesItems.append(mc.ListItem(mc.ListItem.MEDIA_UNKNOWN))

  mc.GetActiveWindow().GetList(tdp['scenes_list']).SetItems(scenesItems)

  # Stars list
  starsItems = mc.ListItems()
  star_items = tdp_content.stars.items()
  if star_items:
    for star_id, star in star_items:
      item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
      item.SetLabel(str(star['name']))
      item.SetPath('star_' + str(star_id))
      item.SetProperty('star_id', str(star_id))
      starsItems.append(item)
  else:
    mc.GetActiveWindow().GetControl(fyre.hash.ids['tdp']['stars_label']).SetVisible(False)

  mc.GetActiveWindow().GetList(fyre.hash.ids['tdp']['stars_list']).SetItems(starsItems)

  load_package_studio_image(tdp, tdp_content)

  fyre.helpers.rating.setRating(float(movie['rating']), fyre.hash.ids['tdp']['rating'])
  fyre.helpers.distribution_window.set_distribution(movie['distribution_window'], fyre.hash.ids['tdp'])
  load_buttons(tdp_content)

def load_package_studio_image(scope, content):
  # Studio logo
  #jeśli film ma pakiet to wyświetlamy logo pakietu plus button który umożliwa przejście do pdp
  #jeśli nie ma pakietu to wyświetlamy logo studia
  if content.package:
    mc.GetActiveWindow().GetControl(scope['package']).SetVisible(True)
    studio_or_package_img = fyre.config['server_prefix']['thumbnails'] + str(content.package['thumbnail_mini'])
  else:
    studio_or_package_img = fyre.config['server_prefix']['thumbnails'] + str(content.studio['thumbnail'])
    mc.GetActiveWindow().GetControl(scope['package']).SetVisible(False)
    mc.GetActiveWindow().GetControl(scope['package']).SetEnabled(False)
  mc.GetActiveWindow().GetImage(scope['package_img']).SetTexture(studio_or_package_img)

def load_buttons(content):
  button1 = mc.GetActiveWindow().GetButton(fyre.hash.ids['tdp']['button1'])
  button3 = mc.GetActiveWindow().GetButton(fyre.hash.ids['tdp']['button3'])
  button4 = mc.GetActiveWindow().GetButton(fyre.hash.ids['tdp']['button4'])
  button3.SetVisible(content.offers.has_key('ppm'))
  button1.SetVisible(content.offers.has_key('ppm'))
  if content.offers.has_key('vod'):
    button4.SetLabel('buy movie')
    button3.SetLabel('play with min.')
    button4.SetFocus()
  else:
    button4.SetLabel('go to library')
    button3.SetLabel('play')
    button3.SetFocus()

  if space.playlist.issuperset(content.scenes_details.values()):
    button1.SetLabel('go to playlist')
  else:
    button1.SetLabel('add to playlist')

def onclick_button4():
  offers = space.cache.current().offers
  if offers.has_key('vod'):
    fyre.helpers.grocery.buy(space.cache.current().purchase_confirm_message(), _buy_vod)
  else:
    fyre.view.show('my_library')

#simple account could play movie from my-library
def onclick_button3():
  if not space.cache.current().offers.has_key('vod') or fyre.helpers.mode.check_permission():
    space.unload = 'player'
    items = mc.GetActiveWindow().GetList(fyre.hash.ids['tdp']['scenes_list']).GetItems()
    start_playback(items, space.cache.current().scenes_details)

def onclick_button2():
  fyre.view.show('coverflow', 'similar_for_movie/' + space.cache.current().movie['movie_title_id'], {'media_type': 'movie', 'label': 'Similar to: %s' % space.cache.current().movie['title']})

def onclick_button1():
  if space.playlist.issuperset(space.cache.current().scenes_details.values()):
    fyre.view.show('coverflow', 'playlist', {'media_type': 'scene'})
  else:
    space.playlist.extend(space.cache.current().scenes_details.values())
    load_buttons(space.cache.current())

def scroll_left():
  lst = mc.GetActiveWindow().GetList(fyre.hash.ids['tdp']['scenes_list'])
  idx = lst.GetFocusedItem()

  if idx > 0:
    idx -= 1
    lst.SetFocusedItem(idx)

def scroll_right():
  lst = mc.GetActiveWindow().GetList(fyre.hash.ids['tdp']['scenes_list'])
  idx = lst.GetFocusedItem()

  if idx < len(lst.GetItems()) - 5:
    idx += 1
    lst.SetFocusedItem(idx)

def focus_stars_list(from_where):
  if space.cache.current().stars:
    mc.GetActiveWindow().GetControl(fyre.hash.ids['tdp']['stars_list']).SetFocus()
  else:
    if from_where == 'down':
      mc.GetActiveWindow().GetControl(fyre.hash.ids['tdp']['package']).SetFocus()
    elif from_where == 'up':
      mc.GetActiveWindow().GetControl(fyre.hash.ids['tdp']['button1']).SetFocus()

def _buy_vod():
  if space.cache.current().buy_vod():
    load(space.cache.current())
    message = 'Thank you.'
  else:
    message = 'Something went wrong'
  return message

