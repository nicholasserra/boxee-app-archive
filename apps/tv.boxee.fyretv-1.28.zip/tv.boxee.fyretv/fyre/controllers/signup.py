import mc
import xbmc
import fyre
import fyre.hash
import space
import re
from lib.request import call_method


def load(content):
  loadCountries()


def showSignup():
  mc.GetApp().ActivateWindow(fyre.hash.windows['signup'], mc.Parameters())
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['first_name_btn']).SetFocus()


def hideSignup():
  pass


def showStepOne():
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['email']).SetFocus()
  window.GetControl(fyre.hash.ids['signup']['step1']).SetVisible(True)
  window.GetControl(fyre.hash.ids['signup']['step1_5']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step2']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step3']).SetVisible(False)

def showStep1_5():
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['first_name']).SetFocus()
  window.GetControl(fyre.hash.ids['signup']['step1']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step1_5']).SetVisible(True)
  window.GetControl(fyre.hash.ids['signup']['step2']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step3']).SetVisible(False)

def showStepTwo():
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['street_address']).SetFocus()
  window.GetControl(fyre.hash.ids['signup']['step1']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step1_5']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step2']).SetVisible(True)
  window.GetControl(fyre.hash.ids['signup']['step3']).SetVisible(False)


def showStepThree():
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['cc_type_master']).SetFocus()
  window.GetControl(fyre.hash.ids['signup']['step1']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step1_5']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step2']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['step3']).SetVisible(True)


def showCountries():
  window = mc.GetActiveWindow()
  window.GetButton(fyre.hash.ids['signup']['state_btn']).SetLabel('select ...')
  window.GetControl(fyre.hash.ids['signup']['countries']).SetVisible(True)
  window.GetControl(fyre.hash.ids['signup']['countries_list']).SetFocus()


def hideCountries():
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['countries']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['country_btn']).SetFocus()


def showStates():
  window = mc.GetActiveWindow()
  country = window.GetButton(fyre.hash.ids['signup']['country_btn']).GetLabel()
  window.GetButton(fyre.hash.ids['signup']['state_btn']).SetLabel('select ...')

  if country == "select...":
    mc.ShowDialogNotification("Select country first.")
  else:
    window.GetControl(fyre.hash.ids['signup']['states']).SetVisible(True)
    window.GetControl(fyre.hash.ids['signup']['states_list']).SetFocus()


def hideStates():
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['states']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['state_btn']).SetFocus()


def showStatesCtrl():
  window = mc.GetActiveWindow()
  window.GetButton(fyre.hash.ids['signup']['state_btn']).SetLabel('select ...')
  window.GetControl(fyre.hash.ids['signup']['state_label']).SetVisible(True)
  window.GetControl(fyre.hash.ids['signup']['state_btn']).SetVisible(True)


def hideStatesCtrl():
  window = mc.GetActiveWindow()
  window.GetControl(fyre.hash.ids['signup']['state_label']).SetVisible(False)
  window.GetControl(fyre.hash.ids['signup']['state_btn']).SetVisible(False)


def selectCard(card_type):
  window = mc.GetActiveWindow()
  master = window.GetToggleButton(fyre.hash.ids['signup']['cc_type_master'])
  visa = window.GetToggleButton(fyre.hash.ids['signup']['cc_type_visa'])
  discovery = window.GetToggleButton(fyre.hash.ids['signup']['cc_type_discovery'])
  aexpress = window.GetToggleButton(fyre.hash.ids['signup']['cc_type_aexpress'])
  if card_type == 'master':
    visa.SetSelected(False)
    discovery.SetSelected(False)
    aexpress.SetSelected(False)
  if card_type == 'visa':
    master.SetSelected(False)
    discovery.SetSelected(False)
    aexpress.SetSelected(False)
  if card_type == 'discovery':
    master.SetSelected(False)
    visa.SetSelected(False)
    aexpress.SetSelected(False)
  if card_type == 'aexpress':
    master.SetSelected(False)
    visa.SetSelected(False)
    discovery.SetSelected(False)


def validateStepOne():
  window = mc.GetActiveWindow()

  email = window.GetEdit(fyre.hash.ids['signup']['email']).GetText()
  email_confirm = window.GetEdit(fyre.hash.ids['signup']['email_confirm']).GetText()
  password = window.GetEdit(fyre.hash.ids['signup']['password']).GetText()
  password_confirm = window.GetEdit(fyre.hash.ids['signup']['password_confirm']).GetText()

  if email == '':
    mc.ShowDialogNotification("Email can't be blank!")
  elif email != email_confirm:
    mc.ShowDialogNotification("Error in email (%s != %s)!" % (email, email_confirm))
  elif password == '':
    mc.ShowDialogNotification("Password can't be blank!")
  elif password != password_confirm:
    mc.ShowDialogNotification("Password and confirmation doesn't match!")
  elif len(password) < 6:
    mc.ShowDialogNotification("Password must be at least 6 characters")
  else:
    showStep1_5()

def validateStep1_5():
  window = mc.GetActiveWindow()

  first_name = window.GetEdit(fyre.hash.ids['signup']['first_name']).GetText()
  family_name = window.GetEdit(fyre.hash.ids['signup']['family_name']).GetText()
  pin = window.GetEdit(fyre.hash.ids['signup']['pin']).GetText()

  if first_name == '':
    mc.ShowDialogNotification("First name can't be blank!")
  elif family_name == '':
    mc.ShowDialogNotification("Family name can't be blank!")
  elif pin == '':
    mc.ShowDialogNotification("PIN can't be blank!")
  elif not re.match("\d{6}", pin):
    mc.ShowDialogNotification("PIN should contain 6 digits!")
  else:
    showStepTwo()

def validateStepTwo():
  window = mc.GetActiveWindow()
  street_address = window.GetEdit(fyre.hash.ids['signup']['street_address'])
  city = window.GetEdit(fyre.hash.ids['signup']['city'])
  state = window.GetButton(fyre.hash.ids['signup']['state_btn'])
  country = window.GetButton(fyre.hash.ids['signup']['country_btn'])
  zip_code = window.GetEdit(fyre.hash.ids['signup']['zip_code'])
  if street_address.GetText() == '':
    mc.ShowDialogNotification("Street Address can't be blank.")
  elif city.GetText() == '':
    mc.ShowDialogNotification("City can't be blank.")
  elif state.GetLabel() == '':
    mc.ShowDialogNotification("State can't be blank.")
  elif country.GetLabel() == '':
    mc.ShowDialogNotification("Country can't be blank.")
  elif zip_code.GetText() == '':
    mc.ShowDialogNotification("Zip Code can't be blank.")
  else:
    showStepThree()

#TODO parameters to sign_up/validate
# field_name	first_name
# field_value	ala
# model_name	Account



def validateStepThree():
  window = mc.GetActiveWindow()
  cc_type = ''
  cc_number = window.GetEdit(fyre.hash.ids['signup']['cc_number'])
  name_on_cc = window.GetEdit(fyre.hash.ids['signup']['name_on_cc'])
  cc_expiration_month = window.GetEdit(fyre.hash.ids['signup']['cc_expiration_month'])
  cc_expiration_year = window.GetEdit(fyre.hash.ids['signup']['cc_expiration_year'])
  cc_verification_number = window.GetEdit(fyre.hash.ids['signup']['cc_verification_number'])
  valid = True
  for field in [[cc_number, 'Credit Card Number'], [name_on_cc, 'Name'],[cc_expiration_month, "Expiration Month"],[cc_expiration_year, "Expiration Year"],[cc_verification_number, "Verifiaction Number"]]:
    if field[0].GetText() == '':
      valid = False
      mc.ShowDialogNotification("%s can't be blank." % field[1])
      break

  if not re.match('\w+ \w+', name_on_cc.GetText()):
    valid = False
    mc.ShowDialogNotification("Cc owner should contain last name")

  if valid:
    if try_register():
      fyre.controllers.signup.close_after_signup()
    else:
      mc.ShowDialogOk("ERROR!", space.cache.current().results['errors'])


def try_register():
  fyre.helpers.loading.show()
  window = mc.GetActiveWindow()
  content = space.cache.current()
  for field in ['email', 'password', 'first_name', 'family_name', 'pin', 'street_address', 'city', 'zip_code', 'cc_number', 'name_on_cc', 'cc_expiration_month', 'cc_expiration_year', 'cc_verification_number', 'phone']:
    content.params[field] = window.GetEdit(fyre.hash.ids['signup'][field]).GetText()

  for field in ['state', 'country']:
    content.params[field] = window.GetButton(fyre.hash.ids['signup'][field + '_btn']).GetLabel()
  fyre.helpers.loading.hide()
  return content.do_signup()


def countriesOnClick():
  window = mc.GetActiveWindow()
  focused_id = window.GetList(fyre.hash.ids['signup']['countries_list']).GetFocusedItem()
  focused_item = window.GetList(fyre.hash.ids['signup']['countries_list']).GetItem(focused_id)
  country_name = focused_item.GetProperty('country_name')
  country_id = focused_item.GetProperty('country_id')

  window.GetButton(fyre.hash.ids['signup']['country_btn']).SetLabel(country_name)
  loadStates(country_id)

  hideCountries()


def statesOnClick():
  window = mc.GetActiveWindow()
  focused_id = window.GetList(fyre.hash.ids['signup']['states_list']).GetFocusedItem()
  focused_item = window.GetList(fyre.hash.ids['signup']['states_list']).GetItem(focused_id)
  state_name = focused_item.GetProperty('state_name')
  state_id = focused_item.GetProperty('state_id')
  window.GetButton(fyre.hash.ids['signup']['state_btn']).SetLabel(state_name)
  hideStates()


def loadCountries():
  countries_data = call_method('countries')
  countries_list = mc.GetActiveWindow().GetList(fyre.hash.ids['signup']['countries_list'])
  countries_items = mc.ListItems()

  for country in countries_data:
    item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    item.SetLabel(str(country['english_name']))
    item.SetProperty('country_id', str(country['country_id']))
    item.SetProperty('country_name', str(country['english_name']))
    countries_items.append(item)

  countries_list.SetItems(countries_items)


def loadStates(country_id):
  states_data = call_method('states', {'country_id': country_id})
  states_list = mc.GetActiveWindow().GetList(fyre.hash.ids['signup']['states_list'])
  states_items = mc.ListItems()

  if not states_data:
    hideStatesCtrl()
  else:
    showStatesCtrl()
    for state in states_data:
      item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
      item.SetLabel(str(state['english_name']))
      item.SetProperty('state_id', str(state['state_id']))
      item.SetProperty('state_name', str(state['english_name']))
      states_items.append(item)

  states_list.SetItems(states_items)

#it should be used on all signup paths
def close_after_signup(close_current_window = True):
  fyre.helpers.mode.update()
  print('cache: %s' % str(space.cache.data))
  space.cache.clear_signup()
  space.init = True
  if close_current_window:
    mc.CloseWindow()
  mc.ShowDialogNotification("Welcome - Enjoy FyreTV !!!")

