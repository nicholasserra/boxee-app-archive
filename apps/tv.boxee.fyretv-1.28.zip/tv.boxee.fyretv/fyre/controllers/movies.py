import mc;import fyre;import fyre.hash;import space;

def load(content):
  mc.GetApp().GetLocalConfig().SetValue("movies_keyboard_reciever", str(fyre.hash.ids['movies']['edit_field']))
  mc.GetActiveWindow().GetEdit(fyre.hash.ids['movies']['edit_field']).SetText(content.opts['pattern'])
  movieItems = mc.ListItems()
  i = 0
  for (i, (movie_id, movie)) in zip(range(1, len(content.response['movie_titles'])+1), content.response['movie_titles'].items()):
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel(str(movie['title']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(movie['front_cover']))
    item.SetImage(0, fyre.config['server_prefix']['thumbnails'] + str(movie['back_cover']))
    item.SetProperty('index', str(i))
    item.SetProperty('movie_title_id', str(movie_id))
    movieItems.append(item)

  list = mc.GetActiveWindow().GetList(fyre.hash.ids['movies']['list'])
  list.SetItems(movieItems)
  list.SetFocusedItem(content.focused_element)
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['movies']['number_of_items']).SetLabel(str(content.response['count']))
  mc.GetActiveWindow().GetControl(fyre.hash.ids['movies']['list_content']).SetVisible(not int(content.response['count']) == 0)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['movies']['empty_list']).SetVisible(int(content.response['count']) == 0)

def on_click(list):
  space.cache.current().focused_element = list.GetFocusedItem()
  movie_title_id = list.GetItem(list.GetFocusedItem()).GetProperty('movie_title_id')
  fyre.view.show('tdp', movie_title_id)

#TODO refactor it, this method is the same in movies/stars/studios
#exclude this method to other file
def search_by_pattern(pattern):
  fyre.helpers.loading.show()
  space.cache.current().search_by_name(pattern)
  load(space.cache.current())
  fyre.helpers.loading.hide()


def next_page():
  space.cache.current().next_page()
