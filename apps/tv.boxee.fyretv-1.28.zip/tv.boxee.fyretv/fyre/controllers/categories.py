import mc;import fyre;import fyre.hash;import space;

def load(content):
  categoryItems = mc.ListItems()
  i = 0
  for categoryId, category in content.categories.items():
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel(str(category['name']))
    item.SetProperty('description', str(category['description']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(category['thumbnail']))
    i += 1
    item.SetProperty('index', str(i))
    item.SetProperty('category_id', str(categoryId))
    categoryItems.append(item)

  list = mc.GetActiveWindow().GetList(fyre.hash.ids['categories']['list'])
  list.SetItems(categoryItems)
  list.SetFocusedItem(content.focused_element)

def on_click():
  space.cache.current().focused_element = mc.GetActiveWindow().GetList(fyre.hash.ids['categories']['list']).GetFocusedItem()
  category_list = mc.GetActiveWindow().GetList(fyre.hash.ids['categories']['list'])
  category_item = category_list.GetItem(category_list.GetFocusedItem())
  category_id = category_item.GetProperty('category_id')
  opts = { 'media_type': 'scene',
           'label': category_item.GetLabel(),
           'with_categories': True,
           'categories_included': category_id
         }
  fyre.view.show('coverflow', 'category/' + category_id, opts)

def next_page():
  pass
