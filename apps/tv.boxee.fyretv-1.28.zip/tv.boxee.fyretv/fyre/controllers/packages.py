import mc;import fyre;import fyre.hash;import space;

def load(content):
  mc.GetApp().GetLocalConfig().SetValue("packages_keyboard_reciever", str(fyre.hash.ids['packages']['edit_field']))
  mc.GetActiveWindow().GetEdit(fyre.hash.ids['packages']['edit_field']).SetText(content.pattern)
  package_items = mc.ListItems()
  i = 0
  for package_id, package in content.packages.items():
    item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
    item.SetLabel(str(package['name']))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(package['thumbnail']))
    i += 1
    item.SetProperty('index', str(i))
    item.SetProperty('nbr_movies', str(package['nbr_movies']))
    item.SetProperty('package_id', str(package_id))
    package_items.append(item)

  list = mc.GetActiveWindow().GetList(fyre.hash.ids['packages']['list'])
  list.SetItems(package_items)
  list.SetFocusedItem(content.focused_element)
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['packages']['number_of_items']).SetLabel(str(content.count))
  mc.GetActiveWindow().GetControl(fyre.hash.ids['packages']['empty_list']).SetVisible(int(content.count) == 0)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['packages']['list_content']).SetVisible(not int(content.count) == 0)


#TODO refactor it, this method is the same in movies/stars/studios
#exclude this method to other file
def search_by_pattern(pattern):
  fyre.helpers.loading.show()
  space.cache.current().search_by_name(pattern)
  load(space.cache.current())
  fyre.helpers.loading.hide()


def on_click(list):
  space.cache.current().focused_element = list.GetFocusedItem()
  package_id = list.GetItem(list.GetFocusedItem()).GetProperty('package_id')
  fyre.view.show('pdp', package_id)

def next_page():
  pass
