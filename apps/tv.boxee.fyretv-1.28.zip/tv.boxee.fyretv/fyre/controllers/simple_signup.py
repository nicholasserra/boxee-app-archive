import mc
import fyre
import fyre.hash
import space

def activate_account():
  mc.ShowDialogNotification("activate account with code %s " % mc.GetActiveWindow().GetEdit(fyre.hash.ids['simple_signup']['activation_code']).GetText())

def signin():
  email = mc.GetActiveWindow().GetEdit(fyre.hash.ids['simple_signup']['email']).GetText()
  password = mc.GetActiveWindow().GetEdit(fyre.hash.ids['simple_signup']['password']).GetText()
  valid = True
  for field in [[email, 'Email'], [password, 'Password']]:
    if len(field[0]) < 1:
      valid = False
      mc.ShowDialogNotification("%s can't be blank." % field[1])
      break

  if valid: space.cache.current().connect_with_account(email, password)

def show_email_password_form():
  mc.GetActiveWindow().GetControl(fyre.hash.ids['simple_signup']['choose']).SetVisible(False)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['simple_signup']['email_password_form']).SetVisible(True)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['simple_signup']['email']).SetFocus()

