from lib.player_thread import start_playback
import mc;import fyre; import space

def load(sdp_content):
  scene = sdp_content.scene
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['sdp']['title']).SetLabel(str(scene['name']))
  mc.GetActiveWindow().GetControl(fyre.hash.ids['sdp']['is_hd']).SetVisible(scene['is_hd'])

  listItems = mc.ListItems()
  for thumbnail in scene['thumbnails']:
    item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
    item.SetLabel(str(scene['content_id']))
    item.SetPath(fyre.config['server_prefix']['thumbnails'] + str(thumbnail))
    item.SetThumbnail(fyre.config['server_prefix']['thumbnails'] + str(thumbnail))
    item.SetProperty('title', str(scene['name']))
    item.SetProperty('cid', str(scene['content_id']))
    item.SetProperty('scene_id', space.cache.current().scene['scene_id'])
    listItems.append(item)

  listItems.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  listItems.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))
  listItems.append(mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER))

  mc.GetActiveWindow().GetList(fyre.hash.ids['sdp']['scenes_list']).SetItems(listItems)

  starItems = mc.ListItems()
  for star_id in scene['stars']:
    star = sdp_content.stars[str(star_id)]
    item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    item.SetLabel(str(star['name']))
    item.SetProperty('star_id',str(star_id))
    starItems.append(item)

  mc.GetActiveWindow().GetList(fyre.hash.ids['sdp']['stars_list']).SetItems(starItems)

  categoryItems = mc.ListItems()
  for category_id in scene['categories']:
    category = sdp_content.categories[str(category_id)]
    item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    item.SetLabel(str(category['name']))
    item.SetProperty('category_id', str(category_id))
    categoryItems.append(item)

  mc.GetActiveWindow().GetList(fyre.hash.ids['sdp']['categories_list']).SetItems(categoryItems)
  fyre.helpers.rating.setRating(float(scene['rating']), fyre.hash.ids['sdp']['rating'])
  fyre.helpers.distribution_window.set_distribution(scene['distribution_window'], fyre.hash.ids['sdp'])

  load_buttons(sdp_content)
  set_focus_on_buttons()
  fyre.controllers.tdp.load_package_studio_image(fyre.hash.ids['sdp'], sdp_content)

  #mc.GetActiveWindow().GetLabel(scene_title_id).SetLabel(str(movie['title']) + " " + str(scene['scene_nbr']))

def load_buttons(content):
  button1 = mc.GetActiveWindow().GetButton(fyre.hash.ids['sdp']['button1'])
  button2 = mc.GetActiveWindow().GetButton(fyre.hash.ids['sdp']['button2'])
  button3 = mc.GetActiveWindow().GetButton(fyre.hash.ids['sdp']['button3'])
  if content.offers.has_key('sod'):
    button2.SetLabel('buy scene')
    button1.SetLabel('play with min.')
  else:
    button2.SetLabel('go to library')
    button1.SetLabel('play')

  if space.playlist.contains(space.cache.current().scene):
    button3.SetLabel('go to playlist')
  else:
    button3.SetLabel('add to playlist')

  button1.SetVisible(content.offers.has_key('ppm'))
  button3.SetVisible(content.offers.has_key('ppm'))

def set_focus_on_buttons():
  button1 = mc.GetActiveWindow().GetButton(fyre.hash.ids['sdp']['button1'])
  button2 = mc.GetActiveWindow().GetButton(fyre.hash.ids['sdp']['button2'])
  if space.cache.current().offers.has_key('sod'):
    button2.SetFocus()
  else:
    button1.SetFocus()


#simple account could play movie from my-library
def onclick_button1():
  if not space.cache.current().offers.has_key('sod') or fyre.helpers.mode.check_permission():
    space.unload = 'player'
    scene_item = mc.GetActiveWindow().GetList(fyre.hash.ids['sdp']['scenes_list']).GetItem(mc.GetActiveWindow().GetList(fyre.hash.ids['sdp']['scenes_list']).GetFocusedItem())
    start_playback(scene_item, movie_title_id = space.cache.current().scene['movie_title_id'])


def onclick_button2():
  offers = space.cache.current().offers
  if offers.has_key('sod'):
    fyre.helpers.grocery.buy(space.cache.current().purchase_confirm_message(),_buy_sod)
  else:
    fyre.view.show('my_library')

def onclick_button4():
  fyre.view.show('coverflow', 'similar_for_scene/' + space.cache.current().scene['scene_id'], {'media_type': 'scene', 'label': 'Similar to: %s' % space.cache.current().scene['name']})

def onclick_button3():
  if space.playlist.contains(space.cache.current().scene):
    fyre.view.show('coverflow', 'playlist', {'media_type': 'scene'})
  else:
    space.playlist.append(space.cache.current().scene) # TODO: should playlist be uniquified?
    load_buttons(space.cache.current())

def scroll_left():
  list = mc.GetActiveWindow().GetList(fyre.hash.ids['sdp']['scenes_list'])
  i = list.GetFocusedItem()
  list.SetFocusedItem(i - 1)

def scroll_right():
  list = mc.GetActiveWindow().GetList(fyre.hash.ids['sdp']['scenes_list'])
  i = list.GetFocusedItem()
  if (i + 4) < len(list.GetItems()):
    list.SetFocusedItem(i + 1)

def _buy_sod():
  response = space.cache.current().buy_sod()
  if response['success']:
    load(space.cache.current())
    message = "Thank you."
    if response['upgraded_movie']: message += "\nWe have granted a free title upgrade with your purchased scene."
  else:
    message = 'Something went wrong'
  return message
