import mc;import fyre;import fyre.hash;import space;import fyre.helpers.grocery

def load(pdp_content):
  package = pdp_content.package
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['pdp']['name']).SetLabel(str(package['name']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['pdp']['big_name']).SetLabel(str(package['name']))
  mc.GetActiveWindow().GetImage(fyre.hash.ids['pdp']['thumbnail_large']).SetTexture(fyre.config['server_prefix']['thumbnails'] + str(package['thumbnail_large']))
  mc.GetActiveWindow().GetLabel(fyre.hash.ids['pdp']['nbr_movies']).SetLabel("Unlimited viewing of %s movie titles" % str(package['nbr_movies']))
  package_already_bought = not pdp_content.offers.has_key('package')
  mc.GetActiveWindow().GetControl(fyre.hash.ids['pdp']['buy_package']).SetVisible(not package_already_bought)
  if not package_already_bought:
    mc.GetActiveWindow().GetButton(fyre.hash.ids['pdp']['buy_package']).SetLabel("Buy Package: %s" % fyre.helpers.grocery.number_to_currency((pdp_content.offers['package']['price'])))
  mc.GetActiveWindow().GetControl(fyre.hash.ids['pdp']['big_name']).SetVisible(not package_already_bought)
  mc.GetActiveWindow().GetControl(fyre.hash.ids['pdp']['bought_package_info']).SetVisible(package_already_bought)


def onclick_buy_package():
  offers = space.cache.current().offers
  if offers.has_key('package'):
    if offers['package'].has_key('price'):
      price = offers['package']['price']
    else:
      price = None
    fyre.helpers.grocery.buy("[B]Purchase this unlimited package for %s?[/B][CR]*This will be a monthly recurring charge\n**Additional taxes may apply" % fyre.helpers.grocery.number_to_currency(price),
                     _buy_package)

def _buy_package():
  if space.cache.current().buy_package():
    load(space.cache.current())
    message = 'Thank you.'
    print('he buy')
  else:
    message = 'Something went wrong'
  return message
