import fyre;from lib.request import call_method
from fyre.content import Content

class Settings(Content):
  def __init__(self):
    pass
    
  def scope(self):
    return 'settings'