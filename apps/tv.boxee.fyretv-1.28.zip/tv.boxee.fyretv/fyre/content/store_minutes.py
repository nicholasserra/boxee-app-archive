import fyre; from lib.request import call_method, call_method_async; import space
from fyre.content import Content

class StoreMinutes(Content):
  def __init__(self):
    self.offers = call_method('credit_offers')['offers']
    self.current_balance = 0
    if space.application_mode == 'F':
      self.current_balance = call_method('current_balance')
    self.selected_minutes = 1000

  def scope(self):
    return 'store_minutes'

  def buy_minutes(self):
    results = False
    if self.selected_offer():
      results = call_method('buy_credits/' + str(self.selected_offer()['credit_offer_id']))
      #TODO here is ugly invalidation, maybe later will be something better
      self.current_balance = call_method('current_balance')
    return results

  def selected_offer(self):
    return self.offers[self.selected_minutes]

  def set_selected_offer(self, minutes):
    self.selected_minutes = str(minutes)
