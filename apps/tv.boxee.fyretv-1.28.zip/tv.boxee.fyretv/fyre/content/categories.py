import fyre;import categories;
from lib.request import call_method, call_method_async

from fyre.content import Content

class Categories(Content):
  def __init__(self):
    self.focused_element = 0
    self.categories = call_method('categories')['categories']

  def scope(self):
    return 'categories'
