import fyre.content; import fyre;
from lib.request import call_method, call_method_async
from fyre.content import PaginatedContent

class Movies(PaginatedContent):
  def __init__(self):
    self.opts = {}
    self.keys_paginated = ['movie_titles']
    PaginatedContent.__init__(self, 'movies')
    self.opts['pattern'] = ''

  def search_by_name(self, pattern = ''):
    if not self.opts.has_key('pattern') or not pattern == self.opts['pattern']:
      self.opts.update({'pattern': pattern})
      self.pull_page(0, reset_data = True)

  def next_page(self):
    self.focus((self.pages + 1) * 20)

  def fill_view(self, reset_data = False):
    fyre.controllers.movies.load(self)

  def scope(self):
    return 'movies'

  def set_default_sort_for_method(self, method):
    pass
