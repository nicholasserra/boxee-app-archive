import fyre;
from fyre.content.paginated_content import PaginatedContent

class MyLibrary(PaginatedContent):
  keys_paginated = ['subscribed_media']

  def __init__(self, opts = {}):
    opts['types'] = 'scene,movie,package'
    PaginatedContent.__init__(self,'my_library', opts)

  def scope(self):
    return 'my_library'

  def fill_view(self, reset_data = False):
     fyre.controllers.my_library.fill_list(self)

  def set_default_sort_for_method(self, method):
    self.opts['sort'] = 'purchase_date'
