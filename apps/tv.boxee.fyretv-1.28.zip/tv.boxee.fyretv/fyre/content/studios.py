import fyre.content; import fyre;
from lib.request import call_method
from fyre.content import Content

class Studios(Content):
  #pagination here is obsolete
  def __init__(self):
    self.focused_element = 0
    self.pattern = None
    self.search_by_name('')

  def search_by_name(self, pattern = ''):
    if not self.pattern == pattern:
      params = {}
      self.pattern = pattern
      if len(pattern) > 0:
        params['pattern'] = pattern
      response = call_method('studios', params)
      self.studios = response['studios']
      self.count = response['count']
  def scope(self):
    return 'studios'
