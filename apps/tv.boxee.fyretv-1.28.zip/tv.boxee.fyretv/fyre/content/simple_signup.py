import fyre; from lib.request import call_method, call_method_async
from fyre.content import Content

class SimpleSignup(Content):
  def __init__(self):
    pass

  def scope(self):
    return 'simple_signup'

  def connect_with_account(self, email, password):
    #TODO send also a mac address
    params = {'email': email, 'password': password}
    results = call_method('connect_with_account', params)

