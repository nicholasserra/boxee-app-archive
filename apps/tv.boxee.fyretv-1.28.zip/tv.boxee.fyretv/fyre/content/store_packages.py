import fyre;
from fyre.content.packages import Packages

class StorePackages(Packages):
  def __init__(self):
    Packages.__init__(self)
    self.focused_element = 0

  def scope(self):
    return 'store_packages'

  def focus(self, element):
    print('focused element %d' % element)
    self.focused_element = element

