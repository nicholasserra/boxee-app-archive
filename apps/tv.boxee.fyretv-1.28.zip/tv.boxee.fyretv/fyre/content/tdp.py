import fyre.content; import fyre;import tdp; import space
from lib.request import call_method, call_method_async
from fyre.content import Content
from fyre.helpers.grocery import number_to_currency

class Tdp(Content):
  def __init__(self, movie_title_id):
    results = call_method('title_details/' + movie_title_id)
    self.stars = results['stars']
    self.categories = results['categories']
    self.scenes_details = results['scenes_details']
    self.movie = results['movie']
    self.studio = results['studio']
    self.package = results['package']
    self.offers = results['offers']

    for scene in self.scenes_details.values():
      scene['distribution_window'] = self.movie['distribution_window']

  def scope(self):
    return 'tdp'


  def buy_vod(self):
    results = False
    if self.offers.has_key('vod'):
      results = call_method('buy_vod/' + str(self.offers['vod']['movie_profile_id']))
      if results:
        del(self.offers['vod'])
        self.offers['ppm'] = {}
        space.cache.invalidate_by_movie_id(space.cache.current().movie['movie_title_id'])
    return results

  def invalidate(self):
    if self.need_invalidate:
      self.offers = call_method('movie_offers/' + self.movie['movie_title_id'])

  def purchase_confirm_message(self):
    if self.offers['vod'].has_key('price'):
      message = ''
      if self.offers['vod'].has_key('original_price'):
        message = '[B]Purchase this title for [COLOR F3999999]%s[/COLOR] %s[/B] [CR][COLOR F3999999](Prior scene purchase discount)[/COLOR]' % (number_to_currency(self.offers['vod']['original_price']), number_to_currency(self.offers['vod']['price']))
      else:
        message = '[B]Purchase this title for %s[/B]' % number_to_currency(self.offers['vod']['price'])
      message = message + '[CR]*Purchased title includes all scenes[CR]**Additional taxes may apply'
      return message
    else:
      return self.offers['vod']['confirm_text']