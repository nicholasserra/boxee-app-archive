import fyre; import mc
from lib.request import call_method, call_method_async
from fyre.content import PaginatedContent
import space

class Coverflow(PaginatedContent):
  def __init__(self, method, opts = {}):
    self.keys_paginated = ['movie_titles', 'scenes']
    self.method = method
    self.selected_categories = {}
    self.opts = {}
    self.focused_element = 0

    if not opts.has_key('media_type'): opts['media_type'] = 'movie'
    if not opts.has_key('label'): self.__generate_label(method)

    if method == 'playlist':
      self.opts['media_type'] = 'scenes'
    else:
      PaginatedContent.__init__(self, method, opts)

  def focus(self, element):
    if not self.method == 'playlist':
      return PaginatedContent.focus(self, element)
    else:
      self.focused_element = element

  def playlist_scenes(self):
    if self.method == 'playlist':
      return space.playlist.items()
    else:
      return self.response['scenes'].values()

  def manipulate_options(self, local_opts):
    def stringify(x):
      if local_opts.has_key(x):
        if local_opts[x] == []:
          del local_opts[x]
        elif type([]) == type(local_opts[x]):
          local_opts[x] = ','.join(local_opts[x])

    stringify('categories_included')
    stringify('categories_excluded')
    self.add_categories_filter(local_opts)

  def scope(self):
    return 'coverflow'

  def fill_view(self, reset_data = False):
    fyre.controllers.coverflow.fill_list(self, reset_data)

  def clear(self):
    if self.method == 'playlist':
      space.playlist.clear()
      self.fill_view()
    elif self.method == 'watched':
      call_method('clear_watched')
      self.update_options({})
    elif self.method == 'favorites':
      call_method('clear_favorites')
      self.update_options({})
    else:
      print('support this')

  def __generate_label(self, method):
    # When you change label remember to change it also
    # in fyre/controllers/coverflow.rb in show_options_for()
    self.opts['label'] = {
      'naked_news': 'NAKED NEWS',
      'new_releases': 'NEW RELEASES',
      'new_catalog': 'NEW CATALOG',
      'just_added': 'JUST ADDED',
      'most_watched': 'MOST WATCHED',
      'best_rated': 'BEST RATED',
      'watched': 'WATCHED SCENES',
      'favorites': 'FAVORITE SCENES',
      'playlist': 'CURRENT PLAYLIST'
    }.get(method, 'Error!')

  def update_options(self, opts):
    if self.response.has_key('categories'): del self.response['categories']
    PaginatedContent.update_options(self, opts)

  def set_default_sort_for_method(self, method):
    self.opts['sort'] = {'naked_news': 'addition_date',
      'new_releases': 'addition_date',
      'new_catalog': 'addition_date',
      'just_added': 'addition_date',
      'most_watched': 'views_count',
      'best_rated': 'rating'}.get(method, 'name')

  def add_categories_filter(self, local_opts):
    if self.pages == 0:
      local_opts.update({'with_categories': True})
    #we need categories to filter only on first page
    #on next pages it will not change
    elif local_opts.has_key('with_categories'):
      del(local_opts['with_categories'])

