import fyre.controllers.packages
import fyre.content
from lib.request import call_method, call_method_async
from fyre.content import Content

class Packages(Content):
  def __init__(self):
    self.focused_element = 0
    self.pattern = None
    self.search_by_name('')

  def search_by_name(self, pattern = ''):
    if not self.pattern == pattern:
      params = {}
      self.pattern = pattern
      if len(pattern) > 0:
        params['pattern'] = pattern
      self.response = call_method('packages', params)
      self.packages = self.response['packages']
      self.count = self.response['count']

  def scope(self):
    return 'packages'
