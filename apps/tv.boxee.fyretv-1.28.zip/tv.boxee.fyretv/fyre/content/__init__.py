import mc; import fyre;
from lib.request import call_method, call_method_async

class Content:
  need_invalidate = False
  def related_group(self):
    return mc.GetActiveWindow().GetControl(fyre.hash.ids[self.scope()]['main'])
  def scope(self):
#    raise NotImplementedError, "Please set the scope"
    return ''
  def invalidate(self):
    pass

class Generic:
  def __init__(self, scope):
    self.name = scope
  def scope(self):
    return self.name
  def invalidate(self):
    return True
  def related_group(self):
    return mc.GetActiveWindow().GetControl(fyre.hash.ids[self.scope()]['main'])

class Player(Content):
  def scope(self):
    return 'player'

from fyre.content.paginated_content import PaginatedContent
from fyre.content.menu import Menu
from fyre.content.about import About
from fyre.content.categories import Categories
from fyre.content.coverflow import Coverflow
from fyre.content.movies import Movies
from fyre.content.my_library import MyLibrary
from fyre.content.packages import Packages
from fyre.content.store_packages import StorePackages
from fyre.content.sdp import Sdp
from fyre.content.stars import Stars
from fyre.content.stdp import Stdp
from fyre.content.studios import Studios
from fyre.content.store_minutes import StoreMinutes
from fyre.content.tdp import Tdp
from fyre.content.pdp import Pdp
from fyre.content.signup import Signup
from fyre.content.settings import Settings
from fyre.content.simple_signup import SimpleSignup
from fyre.content.signup_activation import SignupActivation
from fyre.content.signup_code_activation import SignupCodeActivation
from fyre.content.signup_reminder import SignupReminder
