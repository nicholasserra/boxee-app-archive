import fyre;
from lib.request import call_method, call_method_async
from lib.odict import OrderedDict

from fyre.content import Content

class PaginatedContent(Content):
  def __init__(self, method, opts = {}):
    self.method = method
    self.pages = 0
    self.focused_element = 0
    self.response = OrderedDict()
    self.updated = {}

    if not hasattr(self, 'opts'):
      self.opts = opts
    else:
      self.opts.update(opts)

    self.set_default_sort_for_method(method)
    self.__pull_initial_page()

  def update_options(self, opts):
    print('Update options:')
    self.opts.update(opts)
    self.pull_page(0, reset_data = True)

  def focus(self, element):
    print('focused element %d, page: %d, elements: %d' % (element, self.pages, ((self.pages + 1) * 20 - element)))
    self.focused_element = element
    if ((self.pages + 1) * 20 - element) < 5:
      self.pages += 1
      self.pull_page(self.pages)

  def pull_page(self, page, reset_data = False):
    print('pull_page')
    local_opts = self.opts.copy()
    local_opts.update({'page': page})
    self.manipulate_options(local_opts)

    if local_opts.has_key('async'):
      async = local_opts['async']
      del local_opts['async']
    else:
      async = False

    if async:
      call_method_async(self.method, local_opts, lambda data:self.__update_and_fill(data, page, reset_data))
    else:
      data = call_method(self.method, local_opts)
      self.__update_and_fill(data, page, reset_data)

  def manipulate_options(self, local_opts):
    pass

  def __pull_initial_page(self):
    local_opts = self.opts
    local_opts.update({'page': self.pages})
    self.manipulate_options(local_opts)
    response = call_method(self.method, self.opts)
    self.__update_content(response, 0, False)

  def __update_content(self, new_objects, page, reset_data = False):
    print('update_list:')
    if reset_data:
      for key in self.keys_paginated:
        if self.response.has_key(key):
          del self.response[key]
      self.focused_element = 0
      self.pages = 0
    for key in new_objects.keys():
      if self.response.has_key(key) and type(self.response[key]) == OrderedDict:
        self.response[key].update(new_objects[key])
        self.updated[key] = True
      else:
        self.response[key] = new_objects[key]
        self.updated[key] = True

  def __update_and_fill(self, new_content, page, reset_data):
    self.__update_content(new_content, page, reset_data)
    self.fill_view(reset_data)

