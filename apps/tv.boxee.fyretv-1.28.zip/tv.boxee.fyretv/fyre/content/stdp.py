import fyre.content; import fyre;import stdp;
from lib.request import call_method, call_method_async

from fyre.content import Content

class Stdp(Content):
  def __init__(self, star_id):
    results = call_method('star_details/' + star_id)
    self.star = results['star']

  def scope(self):
    return 'stdp'
