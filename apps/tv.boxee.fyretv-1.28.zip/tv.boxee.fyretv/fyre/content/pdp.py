import fyre; from lib.request import call_method, call_method_async; import space
from fyre.content import Content

class Pdp(Content):
  def __init__(self, package_id):
    results = call_method('package_details/' + package_id)
    self.package = results['package']
    self.offers = results['offers']

  def scope(self):
    return 'pdp'

  def buy_package(self):
    results = False
    if self.offers.has_key('package'):
      results = call_method('buy_package/' + str(self.package['package_id']))
      if results:
        del(self.offers['package'])
        space.cache.invalidate_by_package_id(space.cache.current().package['package_id'])
    return results
