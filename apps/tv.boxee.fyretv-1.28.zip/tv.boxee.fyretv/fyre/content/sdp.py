import fyre.content; import fyre;import sdp; import space
from lib.request import call_method, call_method_async
from fyre.content import Content
from fyre.helpers.grocery import number_to_currency

class Sdp(Content):
  def __init__(self, scene_id):
    results = call_method('scene_details/' + scene_id)
    self.stars = results['stars']
    self.categories = results['categories']
    self.scene = results['scene']
    self.offers = results['offers']
    self.package = results['package']
    self.studio = results['studio']

  def scope(self):
    return 'sdp'

  def buy_sod(self):
    results = False
    if self.offers.has_key('sod'):
      results = call_method('buy_sod/' + str(self.offers['sod']['scene_profile_id']))
      print('aaa' + str(results))
      if results['success']:
        del(self.offers['sod'])
        self.offers['ppm'] = {}
        space.cache.invalidate_by_movie_id(space.cache.current().scene['movie_title_id'])
    return results

  def invalidate(self):
    if self.need_invalidate:
      self.offers = call_method('scene_offers/' + self.scene['scene_id'])

  def purchase_confirm_message(self):
    if self.offers['sod'].has_key('price'):
      return '[B]Purchase this title for %s[/B] [CR]*Additional taxes may apply' % number_to_currency(self.offers['sod']['price'])
    else:
      return self.offers['sod']['confirm_text']



