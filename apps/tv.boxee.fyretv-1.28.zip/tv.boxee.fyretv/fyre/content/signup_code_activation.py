import fyre; from lib.request import call_method, call_method_async
from fyre.content import Content

class SignupCodeActivation(Content):
  def __init__(self):
    pass

  def scope(self):
    return 'signup_code_activation'

