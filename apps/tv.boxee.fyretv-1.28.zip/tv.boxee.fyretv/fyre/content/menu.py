import fyre;from lib.request import call_method
from fyre.content import Content

class Menu(Content):
  def __init__(self):
    self.focused_element = 0
    self.method = 'recommended_scenes'
    self.response = call_method('recomended_scenes')
    self.first_time_render = True
    self.entered_menu = 0

  def scope(self):
    return 'menu'

  def playlist_scenes(self):
    return self.response['scenes'].values()

  def focus(self, position):
    self.focused_element = position
