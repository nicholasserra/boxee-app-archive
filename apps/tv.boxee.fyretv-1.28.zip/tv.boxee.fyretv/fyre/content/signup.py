import fyre
from lib.request import call_method, call_method_async
from fyre.content import Content

class Signup(Content):
  def __init__(self):
    self.params = {}
    self.results = {}
    pass

  def scope(self):
    return 'signup'

  def do_signup(self):
    self.results = call_method('sign_up', self.params)
    return self.results['result'] == 'success'
