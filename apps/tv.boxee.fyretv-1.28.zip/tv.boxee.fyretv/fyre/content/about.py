import fyre;from lib.request import call_method
from fyre.content import Content

class About(Content):
  def __init__(self):
    pass
    
  def scope(self):
    return 'about'