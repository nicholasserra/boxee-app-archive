import fyre;import lib.cache;import fyre.helpers.mode
import base64
import mc
import re
from lib.request import call_method
from sets import Set
from lib.playlist import Playlist
from lib.security import secure_wrap

try:
  import bxappsec
  secure = True
  def decrypt(cypher):
    def inner_decrypt(ctx):
      decrypted = ''
      decrypted += '\0' * (16-(len(decrypted)%16))

      decryption_status = bxappsec.Decrypt(ctx, cypher, decrypted, len(cypher))
      return decrypted[:decrypted.index('\0')]
    return secure_wrap(inner_decrypt)
except:
  secure = False

unload = False
after_screensaver = False
after_screensaver_after_signin = False

if secure:
  serial_num = mc.GetDeviceId()
else:
  serial_num = 'N/A'

if secure:
  encrypted_base64_salt = call_method('get_session_id', use_salt=False)['session_id']
  encrypted_salt = base64.decodestring(encrypted_base64_salt)
  sha_salt = decrypt(encrypted_salt)
else:
  sha_salt = call_method('get_session_id', {'test':'true'}, use_salt=False)['session_id']

cache = lib.cache.Cache()
cache.push_level('menu')

#TODO consider storing it in config
#here we will storing scenes and movies, but only ids,
#after on playlist page we will get data by these ids
playlist = Playlist()
all_categories = call_method('categories')['categories']

pt = 0

application_mode = None 
currency = None
fyre.helpers.mode.update()


