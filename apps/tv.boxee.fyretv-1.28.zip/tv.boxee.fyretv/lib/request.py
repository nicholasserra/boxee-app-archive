import mc
import space
import fyre
import fyre.helpers.loading
import simplejson
from threading import Thread
from lib.odict import OrderedDict
from simplejson.scanner import make_scanner
from simplejson.decoder import scanstring
import re
import sys, errno, os
import sha
from lib.security import secure_wrap

try:
  import bxappsec
except:
  space.secure = False

def encrypt(text):
  def inner_encrypt(ctx):
    plain = text
    plain += '\0' * (16-(len(plain)%16))

    cypher = ''
    cypher += '\0' * (16-(len(cypher)%16))

    encryption_status = bxappsec.Encrypt(ctx, plain, cypher, len(plain))
    return cypher
  return secure_wrap(inner_encrypt)

def decrypt(cypher):
  def inner_decrypt(ctx):
    decrypted = ''
    decrypted += '\0' * (16-(len(decrypted)%16))

    decryption_status = bxappsec.Decrypt(ctx, cypher, decrypted, len(cypher))
    return decrypted
  return secure_wrap(inner_decrypt)

FLAGS = re.VERBOSE | re.MULTILINE | re.DOTALL
WHITESPACE = re.compile(r'[ \t\n\r]*', FLAGS)
WHITESPACE_STR = ' \t\n\r'
STRINGCHUNK = re.compile(r'(.*?)(["\\\x00-\x1f])', FLAGS)
BACKSLASH = {
    '"': u'"', '\\': u'\\', '/': u'/',
    'b': u'\b', 'f': u'\f', 'n': u'\n', 'r': u'\r', 't': u'\t',
}

def JSONObject((s, end), encoding, strict, scan_once, object_hook, _w=WHITESPACE.match, _ws=WHITESPACE_STR):
  pairs = OrderedDict()
  # Use a slice to prevent IndexError from being raised, the following
  # check will raise a more specific ValueError if the string is empty
  nextchar = s[end:end + 1]
  # Normally we expect nextchar == '"'
  if nextchar != '"':
    if nextchar in _ws:
      end = _w(s, end).end()
      nextchar = s[end:end + 1]
    # Trivial empty object
    if nextchar == '}':
      return pairs, end + 1
    elif nextchar != '"':
      raise ValueError(errmsg("Expecting property name", s, end))
  end += 1
  while True:
    key, end = scanstring(s, end, encoding, strict)

    # To skip some function call overhead we optimize the fast paths where
    # the JSON key separator is ": " or just ":".
    if s[end:end + 1] != ':':
      end = _w(s, end).end()
      if s[end:end + 1] != ':':
        raise ValueError(errmsg("Expecting : delimiter", s, end))

    end += 1

    try:
      if s[end] in _ws:
        end += 1
        if s[end] in _ws:
          end = _w(s, end + 1).end()
    except IndexError:
      pass

    try:
      value, end = scan_once(s, end)
    except StopIteration:
      raise ValueError(errmsg("Expecting object", s, end))
    pairs[key] = value

    try:
      nextchar = s[end]
      if nextchar in _ws:
        end = _w(s, end + 1).end()
        nextchar = s[end]
    except IndexError:
      nextchar = ''
    end += 1

    if nextchar == '}':
      break
    elif nextchar != ',':
      raise ValueError(errmsg("Expecting , delimiter", s, end - 1))

    try:
      nextchar = s[end]
      if nextchar in _ws:
        end += 1
        nextchar = s[end]
        if nextchar in _ws:
          end = _w(s, end + 1).end()
          nextchar = s[end]
    except IndexError:
      nextchar = ''

    end += 1
    if nextchar != '"':
      raise ValueError(errmsg("Expecting property name", s, end - 1))
  return pairs, end

def call_method(method, data = {}, use_salt = True):
  print '##### fyre(call_method): %s %s' % (method, data)
  def deunicode(ent):
    if type(ent) == OrderedDict:
      return OrderedDict([(deunicode(k), deunicode(v)) for k,v in ent.items()])
    elif type(ent) == list:
      return [deunicode(el) for el in ent]
    elif type(ent) == unicode:
#      return str(ent.replace(u'\x85', ''))
      return ent.encode('ascii', 'ignore') # we're dropping all non-ascii characters. Boxee seems to be unable to print them
    else:
      return ent

  data['serial_num'] = space.serial_num
  params = mc.Parameters()
  for key, value in data.items():
    params[key] = str(value)

  querystring = params.toQueryString()
  if use_salt:
    checksum = sha.new(querystring + space.sha_salt)
    querystring += '&checksum=' + checksum.hexdigest()

  try:
    http = mc.Http()
    if method == 'use_product' or method == 'end_product_usage':
      response = http.Get(fyre.config['server_prefix']['wowza'] + '/' + method + '?' + querystring)

      if http.GetHttpResponseCode() == 200 or http.GetHttpResponseCode() == 304:
        deserializer = simplejson.JSONDecoder(encoding=None, object_hook=None)
        deserializer.parse_object = JSONObject
        deserializer.scan_once = make_scanner(deserializer)
        pom = deunicode(deserializer.decode(response))
        return pom

      else:
        mc.ShowDialogOk("Error", "There was an error communicating with FyreTv servers.\n %s" % str(response))
        mc.HideDialogWait()
        fyre.helpers.loading.hide()
        return False

    else:
      response = http.Get(fyre.config['server_prefix']['mw'] + '/' + method + '?' + querystring)

      if http.GetHttpResponseCode() == 200 or http.GetHttpResponseCode() == 304:
        deserializer = simplejson.JSONDecoder(encoding=None, object_hook=None)
        deserializer.parse_object = JSONObject
        deserializer.scan_once = make_scanner(deserializer)
        pom = deunicode(deserializer.decode(response))
        #print('response parsed (%s %s)' % (method, pom))
        return pom

      else:
        mc.ShowDialogOk("Error", "There was an error communicating with FyreTv servers.\n %s" % str(response))
        mc.HideDialogWait()
        fyre.helpers.loading.hide()
        return False

  except Exception, error:
    mc.ShowDialogOk("Error", "There was an error communicating with FyreTv servers.")
    print(str(error))
    mc.HideDialogWait()
    fyre.helpers.loading.hide()
    return False

def call_method_async(method, params, callback):
  thread = _async_call_thread(method, params, callback)
  thread.start()

class _async_call_thread(Thread):
  def __init__(self, method, params, callback):
    Thread.__init__(self)
    self.method = method
    self.params = params
    self.callback = callback

  def run(self):
    data = call_method(self.method, self.params)
    print('data pulled, invoking callback')
    self.callback(data)
    print('callback finished')
