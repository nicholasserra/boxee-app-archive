import space
import mc
import os
import os.path

try:
  import bxappsec
except:
  space.secure = False

def secure_wrap(code):
  if not space.secure:
    return False

  prod_key_path = mc.GetApp().GetAppDir() + '/fyretv_production_wrapped.key'
  dev_key_path = mc.GetApp().GetAppDir() + '/fyretv_developer_wrapped.key'

  if os.path.exists(prod_key_path):
    key_path = prod_key_path
  else:
    key_path = dev_key_path

  f = open(key_path, 'r')
  key = f.read()
  f.close()
  ctx = bxappsec.Init(key)
  if ctx:
    res = code(ctx)
    bxappsec.Close(ctx)
    return res
  else:
    return False
