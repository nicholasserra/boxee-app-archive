import fyre
import fyre.hash
import space
from lib.async_request import async_get
from threading import Thread
import mc, time
from lib.request import call_method
import re
from urllib import quote_plus, urlencode

# Play item with either Boxee's action menu, our MF's. #
#def play_content(cid):
#  """Function meant to be used from within views. It will switch to player osd view and start playback."""

print "MYDEBUG :: loading player module"
from threading import Thread
import mc, time

def start_playback(scene_items, playlist = None, movie_title_id = None):
  """Internal player view function, starts playback and thread that will control communication with BO."""
  space.pt = _play_in_thread(scene_items, playlist, movie_title_id)
  space.pt.start()

class _play_in_thread(Thread):

  #this codes were rewrited from Back office
  CODES = {
    # SUCCESSES:
    'TOKEN_FOUND' : 200,
    'USE_PRODUCT' : 210,
    'TOKEN_INVALIDATED' : 211,
    'EXCEPTION_SAVED' : 212,

    # FAILURES:
    'GENERAL_FAILURE' : 100,
    'NO_TOKEN_FOUND' : 110,
    'LIMIT_EXCEEDED' : 111,
    'TOKEN_ALREADY_CONSUMED' : 112,
    'TOKEN_ALREADY_USED' : 113,
    'TOKEN_EXPIRED' : 114,
    'BOX_SERVICE_ERROR' :120,
    'WRONG_PARAMS' : 101,
    'TOKEN_INVALIDATION_FAILURE' : 102
  }
  CONTENT_STATUS = {
    'ok' : 1,
    'skip': 2,
    'try_again': 3,
    'cancel': 4
  }

  # Define class vars. #
  def __init__ (self, content, playlist, movie_title_id):
    Thread.__init__(self)

    self.player = mc.GetPlayer()
    self.playtime = 0
    self.playtime_all = 0
    self.no_playtime = 0
    self.scene_number = 0
    self.abort_play = False
    self.first_error = False 
    self.token = ''
    self.touch()

    if type(content).__name__ == 'ListItems':
      self.items = content
    else:
      self.items = []
      self.items.append(content)

  def playHlsStream(self, stream):
     #set playlist stream bandwith, 0, 1, A (low, high, adaptive)
     params = { 'quality': stream['quality'] }

     #build stream url
     playlist_url = "playlist://%s?%s" % (quote_plus(stream['url']), urlencode(params))

     print playlist_url

     #build Boxee listitem and set properties"
     item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_EPISODE)
     item.SetPath(playlist_url)
     item.SetLabel(stream['title'])
     item.SetContentType('application/vnd.apple.mpegurl')

     #initialize the Boxee player and pass our listitem"
     mc.GetPlayer().Play(item)

  def touch(self):
    self.timeout_counter = 0

  def switch_played_content(self, content):
    self.end_product_usage()
    self.prepare_player(self.create_content_object(content))

  def end_product_usage(self):
    params = {}
    params['token'] = self.token + self.time_to_magic_string(self.playtime_all)
    call_method('end_product_usage', params)
    self.playtime = 0
    self.playtime_all = 0

  def time_to_magic_string(self, time):
    some_string = str(time)
    return some_string + str(len(some_string))


  def use_product(self):
    params = {}
    params['token'] = self.token
    params['ft'] = '0'
    result = call_method('use_product', params)
    return result


  def create_content_object(self, content):
    use_ppm = '1'

    response = call_method('get_token', {'id': content.GetProperty('scene_id'), 'ppm': use_ppm, 'content_id': content.GetProperty('cid')})
    if response.has_key('error'):
      if response['error'] == 'InsufficientBalance':
        mc.ShowDialogOk("Error", "Unable to play video, not enough founds.")
      else:
        mc.ShowDialogOk("Error", "There was an error, please contact with support")
      mc.HideDialogWait()
      fyre.helpers.loading.hide()
      return False
    else:
      token = response['token']
      video_url = response['url']
      self.token = token

      my_stream = {
        'url':      video_url,
        'quality': 'A',
        'title': content.GetProperty('title')
      }

      return my_stream

  def prepare_player(self, content):
    self.preparing_content = True
    while self.player.IsPlaying():
      self.player.Stop()
      time.sleep(1)
    print('some play stuff')
    self.playHlsStream(content)
    print('some play stuff2')
    fyre.helpers.loading.show()
    while not self.player.IsPlaying():
      time.sleep(1)
      self.no_playtime += 1
      print("no playback: %s" % self.no_playtime)
      if self.no_playtime > 30:
        if mc.IsConnectedToInternet():
          error_action = self.handle_play_error()
          if error_action == self.CONTENT_STATUS['try_again']:
            pass
          else:
            fyre.helpers.loading.hide()
            return error_action
        else: #we want to handle lack of internet in different way
          pass
    self.preparing_content = False
    return self.CONTENT_STATUS['ok'] 

  # Run() method required for Thread. #
  def run(self):
    for item in self.items:
      self.scene_number += 1
      if not self.abort_play and item.GetLabel() != "":
        self.content = self.create_content_object(item)
        if self.content:
          content_status = self.prepare_player(self.content)
          if content_status == self.CONTENT_STATUS['ok']:
            try:
              while self.player.IsPlaying() and not self.preparing_content:
                time.sleep(1)
                if not (self.player.IsPaused() or self.player.IsCaching()):
                  self.playtime += 1
                  self.playtime_all += 1
                  self.no_playtime = 0
                  self.first_error = False
                  if self.playtime > 60:
                    response = self.use_product()
                    self.playtime = 0
                    if response['code'] == self.CODES['USE_PRODUCT']:
                      pass
                    elif response['code'] == self.CODES['LIMIT_EXCEEDED']:
                      mc.ShowDialogOk("Error", "Unable to play video. Not enough funds.")
                      fyre.helpers.loading.hide()
                      break
                    else:
                      print("Use product error: %s" % str(response))
                      self.stop_play()
                      mc.ShowDialogOk("Error", "Unknown error. Please contact customer support.")
                      break
                else:
                  self.no_playtime += 1
                  print("no playback: %s" % self.no_playtime)
                  if self.no_playtime > 30:
                    error_action = self.handle_play_error()
                    if error_action == self.CONTENT_STATUS['try_again']:
                      pass
                    else:
                      break

            finally:
              self.end_product_usage()
              if self.player.GetLastPlayerEvent() == self.player.EVENT_STOPPED:
                break
              print "########## Stopping playback thread"
          elif content_status == self.CONTENT_STATUS['skip'] or content_status == self.CONTENT_STATUS['cancel']:
            break

  def handle_play_error(self):
    if self.first_error:
      mc.ShowDialogOk("Error 609", "Unable to play video.")
      fyre.helpers.loading.hide()
      self.stop_play()
      return self.CONTENT_STATUS['cancel']
    else:
      if not self.is_last_scene(): 
        response = mc.ShowDialogConfirm("Error", "Unable to play video", "Try again", "Skip scene")
      else:  
        response = mc.ShowDialogConfirm("Error", "Unable to play video", "Try again", "Close")
      if not response:
        self.first_error = True
        self.no_playtime = 0
        return self.CONTENT_STATUS['try_again']
      else:
        if self.is_last_scene():
          self.player.Stop()
        return self.CONTENT_STATUS['skip']
  
  def is_last_scene(self):
    return len(self.items) == 1 or self.scene_number >= len(self.items)

  def stop_play(self):
    self.abort_play = True
    self.player.Stop()
