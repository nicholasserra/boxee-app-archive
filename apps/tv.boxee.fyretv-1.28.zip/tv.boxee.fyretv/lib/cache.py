import fyre; import fyre.content

class Cache:
  def __init__(self):
    self.data = []

  def current(self):
    if len(self.data) > 0:
      return self.data[-1]
    else:
      return None

  def previous(self):
    if len(self.data) > 1:
      return self.data[-2].scope()
    else:
      return ''

  def push_level(self, page_type, *params):
    klass = getattr(fyre.content, page_type.title().replace('_', ''), lambda:fyre.content.Generic(page_type))

    self.data.append(klass(*params))
    return self.current()

  def pop_level(self):
    print 'pop level ' + str(self.current())
    return self.data.pop()

  def clear(self):
    #we don't want to remove menu content which is first in stack
    del(self.data[1:len(self.data)])

  def clear_signup(self):
    #we don't want to remove menu content which is first in stack
    del(self.data[0:len(self.data)])
    self.push_level('menu')
    #while self.current().scope() in ('signup_activation.rb', 'signup_activation_type.rb', 'signup_association_finished.rb', 'signup_code_activation.rb', 'signup.rb', 'signup_reminder.rb'):
    #  print "XXXXX: %s" % self.current().scope()
    #  self.pop_level(self)

  def size(self):
    return len(self.data)

  def invalidate_by_movie_id(self, movie_id):
    for content in self.data:
      if content.scope() == 'tdp' and content.movie['movie_title_id'] == movie_id:
        content.need_invalidate = True
      elif content.scope() == 'sdp' and content.scene['movie_title_id'] == movie_id:
        content.need_invalidate = True

  def invalidate_by_package_id(self, package_id):
    for content in self.data:
      if content.scope() in ['tdp', 'sdp'] and content.package['package_id'] == package_id:
        content.need_invalidate = True

