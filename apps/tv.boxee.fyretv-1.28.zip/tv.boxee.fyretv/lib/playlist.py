from sets import Set

class Playlist:
  def __init__(self):
    self.uniq = Set()
    self.scene_data = {}
    
  def clear(self):
    self.uniq = Set()
    self.scene_data = {}    

  def extend(self, others):
    sceneset = Set(scene_item['scene_id'] for scene_item in others)
    new = sceneset - self.uniq
    self.uniq.update(sceneset)
    for scene_item in others:
      if scene_item['scene_id'] in new:
        self.scene_data[scene_item['scene_id']] = scene_item

  def append(self, other):
    self.extend([other])

  def items(self):
    return self.scene_data.values()

  def issuperset(self, others):
    return Set(scene_item['scene_id'] for scene_item in others).issubset(self.uniq)

  def contains(self, other):
    return self.issuperset([other])

  def __len__(self):
    return len(self.scene_data)

