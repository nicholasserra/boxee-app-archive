from threading import Thread
from httplib import HTTPConnection

class _async_get_thread(Thread):
  def __init__(self, url, callback):
    Thread.__init__(self)
    self.backoffice = 'localhost:80'
    self.url = url
    self.callback = callback

  def run(self):
    o = HTTPConnection(self.backoffice)
    o.connect()
    o.request('GET', self.url)
    response = o.getresponse()
    self.callback(response.read())

def async_get(url, callback):
  thread = _async_get_thread(url, callback)
  thread.start()

