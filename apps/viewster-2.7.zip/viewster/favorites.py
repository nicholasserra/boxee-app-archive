import mc

# VIEWSTER Librarys
import utilities
import options
import wscalls


#
# LOAD FAVORITES CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def loadFavoritesContent():
    config = mc.GetApp().GetLocalConfig()
    
    authenticatedUser = config.GetValue("authenticatedUser")
    if(authenticatedUser == "True"):
        # hide login mask
        mc.GetActiveWindow().GetControl(1300).SetVisible(False)
        # hide register mask
        mc.GetActiveWindow().GetControl(1900).SetVisible(False)
        
        loadMovieGrid("fav", "0", "9")
    else:
        options.loadLoginContent("Favorites")
    
    return True


#
# Load GRID Content
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadMovieGrid(criteria, offsetRow, maxRow):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    if(offsetRow == "0"):
        totalList = mc.ListItems()
        for index in range(1):
            totalItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            totalList.append(totalItem)
        mc.GetActiveWindow().GetList(602).SetItems(totalList)
    
    moviesJsonObject = wscalls.WSGetUserMovieList("fav", offsetRow, maxRow)
    
    if(moviesJsonObject != False):
        config.SetValue("currentMovieListContent", "Favorites")
        
        movieList = mc.ListItems()
        
        if(moviesJsonObject["data"]["its"] == None):
            # set focus on Favorites menu button
            if(utilities.isViewster()):
                nextlist = mc.GetActiveWindow().GetList(200)
                nextlist.SetFocus()
                nextlist.SetFocusedItem(3)
            
            # display no items msg
            txt_no_items_in_category = utilities.getGuiTagContent(widgetGuiXML, "txt_no_items_in_category")
            noList = mc.ListItems()
            for index in range(1):
                noItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                noItem.SetLabel(txt_no_items_in_category)
                noList.append(noItem)
            mc.GetActiveWindow().GetList(801).SetItems(noList)
            mc.GetActiveWindow().GetControl(800).SetVisible(True)
        else:
            movies = moviesJsonObject["data"]["its"]["it"]
            
            if offsetRow != "0":
                for index in range(len(mc.GetActiveWindow().GetList(601).GetItems())):
                    movieItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                    movieItem = mc.GetActiveWindow().GetList(601).GetItem(index)
                    movieList.append(movieItem)
            else:
                # display fake right arrow
                #totalItems = int(mc.GetActiveWindow().GetLabel(602).GetLabel())
                totalItems = int(mc.GetActiveWindow().GetList(602).GetItem(0).GetLabel())
                
                if(totalItems > 9):
                    mc.GetActiveWindow().GetControl(607).SetVisible(True)
                else:
                    mc.GetActiveWindow().GetControl(607).SetVisible(False)
            
            txt_min = utilities.getGuiTagContent(widgetGuiXML, "txt_min")
            language = config.GetValue("language")
            if(language != "en" and language != "de" and language != "fr"):
                language = "en"
            
            for index in range(len(movies)):
                movieItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                
                artworkURL = str(moviesJsonObject["data"]["ar"]).replace("[ab]", moviesJsonObject["data"]["ab"]).replace("[mid]", movies[index]["i"]).replace("[LANG]", language.upper())
                movieItem.SetProperty("breadCrumb", utilities.cleanString(movies[index]["t"]) + " | " + utilities.cleanString(movies[index]["g"]) + " | " + utilities.cleanString(movies[index]["c"]) + " | " + utilities.cleanString(movies[index]["rd"]) + " | " + utilities.cleanString(movies[index]["r"]) + txt_min)
                movieItem.SetProperty("userRating", utilities.cleanString(movies[index]["ur"]))
                movieItem.SetProperty("currentIndex", str(int(offsetRow) + index + 1))
                movieItem.SetProperty("contentType", "item")
                
                movieItem.SetImage(0, str(artworkURL))
                movieItem.SetLabel(utilities.cleanString(movies[index]["t"]))
                movieItem.SetProperty("id", utilities.cleanString(movies[index]["i"]))
                
                movieList.append(movieItem)
                
            mc.GetActiveWindow().GetList(601).SetItems(movieList)
            
            if(offsetRow != "0"):
                #totalItems = int(mc.GetActiveWindow().GetLabel(602).GetLabel())
                totalItems = int(mc.GetActiveWindow().GetList(602).GetItem(0).GetLabel())
                # hide fake right arrow ( if list contains all movies )
                if(len(movieList) == totalItems):
                    mc.GetActiveWindow().GetControl(607).SetVisible(False)
            
            if(config.GetValue("previousScreenContent") == "grid"):
                mc.GetActiveWindow().GetList(601).SetFocus()
                mc.GetActiveWindow().GetList(601).SetFocusedItem(int(offsetRow))
            
            # set grid content visible
            mc.GetActiveWindow().GetControl(600).SetVisible(True)
    
    return True


#
# GRID ITEM - ON RIGHT -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def gridItemOnRight():
    #totalNoOfMovies = mc.GetActiveWindow().GetLabel(602).GetLabel()
    totalNoOfMovies = mc.GetActiveWindow().GetList(602).GetItem(0).GetLabel()
    currentNoOfMovies = str(len(mc.GetActiveWindow().GetList(601).GetItems()))
    
    endReached = (totalNoOfMovies == currentNoOfMovies)
    criteria = "fav"
    
    if(not endReached):
        loadMovieGrid(criteria, str(len(mc.GetActiveWindow().GetList(601).GetItems())), "11")
    
    return True


#
# Favorites     - ON UP -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def favorites_OnUp(control_ID):
    
    # movie button
    if(control_ID == 601):
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    return True