import mc

# VIEWSTER Librarys
import utilities
import grid
from menu import setSelectedMenuButton
import search
from options import loadHelpContent
import wscalls
import movieDetails


#
# Load FrontPage 
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadFrontPage(json_object):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # hide disclaimer popup
    mc.GetActiveWindow().GetControl(1600).SetVisible(False)
    
    # display breadcrumb line
    mc.GetActiveWindow().GetControl(105).SetVisible(True)
    
    artworkRule = str(json_object["data"]["ar"])
    artworkBase = str(json_object["data"]["ab"])
    artwork = []
    artworkURL = []
    
    for index in range(len(json_object["data"]["ls"]["l"])):
        artwork.append(json_object["data"]["ls"]["l"][index])
    
    for index in range(len(artwork)):
        artworkURL.append(str(artworkRule.replace("[ab]", artworkBase).replace("[a]",str(artwork[index]["a"])).replace("[resx]", "1280").replace("[resy]", "720")))
    
    frontPageList = mc.ListItems()
    for index in range(len(artworkURL)):
        command = str(artwork[index]["c"])
        parameter = str(artwork[index]["p"])
        
        startPageItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        startPageItem.SetImage(0, str(artworkURL[index]))
        startPageItem.SetProperty("command", command)
        startPageItem.SetProperty("parameter", parameter)
        
        if(command == "h"):
            startPageItem.SetLabel(utilities.getGuiTagContent(widgetGuiXML, "txt_highlights"))
        elif(command == "p"):
            startPageItem.SetLabel(utilities.getGuiTagContent(widgetGuiXML, "txt_specials"))
        if(command == "g"):
            startPageItem.SetLabel(utilities.getGuiTagContent(widgetGuiXML, "txt_genre"))
        elif(command == "free"):
            startPageItem.SetLabel(utilities.getGuiTagContent(widgetGuiXML, "txt_free"))
        elif(command == "s"):
            startPageItem.SetLabel(utilities.getGuiTagContent(widgetGuiXML, "txt_search"))
        elif(command == "help"):
            startPageItem.SetLabel(utilities.getGuiTagContent(widgetGuiXML, "txt_help"))
        elif(command == "m"):
            md_json_object = wscalls.WSGetMovieDetail(parameter)
            title = utilities.cleanString(md_json_object["data"]["md"]["t"])
            startPageItem.SetLabel(title)
        
        frontPageList.append(startPageItem)
    
    mc.GetActiveWindow().GetList(301).SetItems(frontPageList)
    
    mc.GetActiveWindow().GetControl(300).SetVisible(True)
    
    nextlist = mc.GetActiveWindow().GetList(301)
    nextlist.SetFocus()
    nextlist.SetFocusedItem(0)
    
    config.SetValue("frontPageLoaded", "already")
    
    return True


#
# FrontPage Box Button - On Click -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def frontPageBoxButtonOnClick():
    config = mc.GetApp().GetLocalConfig()
    widgetGuiXML = utilities.loadGuiXML()
    
    frontpageList = mc.GetActiveWindow().GetList(301)
    frontpageListItem = frontpageList.GetItem(frontpageList.GetFocusedItem())
    
    utilities.hideAllContent()
    
    config.SetValue("previousScreenContent", "grid")
    
    command = frontpageListItem.GetProperty("command")
    parameter = frontpageListItem.GetProperty("parameter")
    
    # Highlights
    if(command == "h"):
        mc.GetActiveWindow().GetList(200).SetFocusedItem(0)
        config.SetValue("currentMovieListContent", "Highlights")
        grid.loadMovieGrid("h", "0", "18")
    
    # Specials
    elif(command == "p"):
        mc.GetActiveWindow().GetList(200).SetFocusedItem(1)
        # load Specials
        if(parameter == ""):
            config.SetValue("currentMovieListContent", "Specials")
            criteria = command
        # load Special category
        else:
            config.SetValue("currentMovieListContent", "Special")
            criteria = command + ":" + parameter
        grid.loadMovieGrid(criteria, "0", "18")
    
    # Genre
    elif(command == "g"):
        mc.GetActiveWindow().GetList(200).SetFocusedItem(2)
        # load Genres
        if(parameter == ""):
            config.SetValue("currentMovieListContent", "Genres")
            criteria = command
        # load Genre category
        else:
            config.SetValue("currentMovieListContent", "Genre")
            criteria = command + ":" + parameter
        grid.loadMovieGrid(criteria, "0", "18")
    
    # Free
    elif(command == "free"):
        mc.GetActiveWindow().GetList(200).SetFocusedItem(4)
        config.SetValue("currentMovieListContent", "Free")
        grid.loadMovieGrid("free", "0", "18")
    
    # Search
    elif(command == "s"):
        mc.GetActiveWindow().GetList(200).SetFocusedItem(5)
        search.loadSearchContent()
        # load Search
        if(parameter == ""):
            # set focus on search button
            mc.GetActiveWindow().GetControl(702).SetFocus()
        # load Search result
        else:
            mc.GetActiveWindow().GetEdit(701).SetText(parameter)
            config.SetValue("currentMovieListContent", "Search")
            criteria = command + ":" + parameter
            search.loadMovieGrid(criteria, "0", "9")
            # set focus on first movie
            mc.GetActiveWindow().GetList(704).SetFocus()
            mc.GetActiveWindow().GetList(704).SetFocusedItem(0)
    
    # Help
    elif(command == "help"):
        loadHelpContent()
    
    # Movie Details
    elif(command == "m"):
        movieDetails.loadMovieDetails(parameter)
    
    setSelectedMenuButton()
    
    return True