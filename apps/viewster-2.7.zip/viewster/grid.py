import mc

# Viewster Librarys
import wscalls
import utilities
import movieDetails
import options


#
# Load GRID Content
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadMovieGrid(criteria, offsetRow, maxRow):
    row = ""
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    specialCategoryId = ""
    genreCategoryId = ""
    
    if(offsetRow == "0"):
        totalList = mc.ListItems()
        for index in range(1):
            totalItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            totalList.append(totalItem)
        mc.GetActiveWindow().GetList(404).SetItems(totalList)
    else:
        position = int(mc.GetInfoString("Container(401).Position"))
        if(position % 2 == 0):
            row = "upper"
        else:
            row = "lower"
    
    if(str(criteria.find("p:")) != "-1"):
        specialCategoryId = criteria.split(":")[1]
        config.SetValue("specialID", utilities.cleanString(specialCategoryId))
    elif(str(criteria.find("g:")) != "-1"):
        genreCategoryId = criteria.split(":")[1]
        config.SetValue("genreID", utilities.cleanString(genreCategoryId))
    
    if((criteria == "h") or (criteria == "free") or (criteria == "p:" + specialCategoryId) or (criteria == "g:" + genreCategoryId) or (criteria[:2] == "e:")):
        moviesJsonObject = wscalls.WSGetMovieList(criteria, offsetRow, maxRow)
    elif((criteria == "p") or (criteria == "g")):
        moviesJsonObject = wscalls.WSGetItemList(criteria, offsetRow, maxRow)
    elif(criteria == "my"):
        moviesJsonObject = wscalls.WSGetUserMovieList("my", offsetRow, maxRow)
    elif(criteria == "Options"):
        moviesJsonObject = utilities.createOptionsDictionary()
        mc.GetActiveWindow().GetList(404).GetItem(0).SetLabel(str(moviesJsonObject["data"]["t"]))
    
    #mc.ShowDialogWait()
    
    if(moviesJsonObject != False):
        movieList = mc.ListItems()
        
        # no movies available
        if(moviesJsonObject["data"]["its"] == None):
             # test for back
            if(utilities.isCleanScreen()):
                # set focus
                nextlist = mc.GetActiveWindow().GetList(200)
                focusedItem = nextlist.GetFocusedItem()
                nextlist.SetFocus()
                nextlist.SetFocusedItem(focusedItem)
                
                ## My Movies
                #if(criteria == "my"):
                #    # set focus on options menu button
                #    if(utilities.isViewster()):
                #        nextlist.SetFocusedItem(6)
                #    elif(utilities.isHustler()):
                #        nextlist.SetFocusedItem(4)
                ## Specials
                #elif(criteria == "p"):
                #    nextlist.SetFocusedItem(1)
                ## Genre
                #elif(criteria == "g"):
                #    nextlist.SetFocusedItem(2)
                
                # display no items msg
                txt_no_items_in_category = utilities.getGuiTagContent(widgetGuiXML, "txt_no_items_in_category")
                noList = mc.ListItems()
                for index in range(1):
                    noItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                    noItem.SetLabel(txt_no_items_in_category)
                    noList.append(noItem)
                mc.GetActiveWindow().GetList(801).SetItems(noList)
                mc.GetActiveWindow().GetControl(800).SetVisible(True)
        
        else:
            movies = moviesJsonObject["data"]["its"]["it"]
            
            if offsetRow != "0":
                for index in range(len(mc.GetActiveWindow().GetList(401).GetItems())):
                    movieItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                    movieItem = mc.GetActiveWindow().GetList(401).GetItem(index)
                    movieList.append(movieItem)
            else:
                # display fake right arrow
                totalItems = int(mc.GetActiveWindow().GetList(404).GetItem(0).GetLabel())
                
                if(totalItems > 18):
                    mc.GetActiveWindow().GetControl(408).SetVisible(True)
                else:
                    mc.GetActiveWindow().GetControl(408).SetVisible(False)
            
            txt_min = utilities.getGuiTagContent(widgetGuiXML, "txt_min")
            
            language = config.GetValue("language")
            # Viewster APP
            if(utilities.isViewster()):
                if(language != "en" and language != "de" and language != "fr"):
                    language = "en"
                separator = " | "
            # Hustler APP
            elif(utilities.isHustler()):
                language = "en"
                separator = ""
            
            for index in range(len(movies)):
                movieItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                
                if((criteria == "h") or (criteria == "free") or (criteria == "p:" + specialCategoryId) or (criteria == "g:" + genreCategoryId)):
                    artworkURL = str(moviesJsonObject["data"]["ar"]).replace("[ab]", moviesJsonObject["data"]["ab"]).replace("[mid]", movies[index]["i"]).replace("[LANG]", language.upper())
                    movieItem.SetProperty("breadCrumb", utilities.cleanString(movies[index]["t"]) + " | " + utilities.cleanString(movies[index]["g"]) + " | " + utilities.cleanString(movies[index]["c"]) + " | " + utilities.cleanString(movies[index]["rd"]) + " | " + utilities.cleanString(movies[index]["r"]) + txt_min)
                    movieItem.SetProperty("userRating", utilities.cleanString(movies[index]["ur"]))
                    movieItem.SetProperty("contentType", "item")
                elif(criteria == "p"):
                    artworkURL = str(moviesJsonObject["data"]["ar"]).replace("[ab]", moviesJsonObject["data"]["ab"]).replace("[pid]", movies[index]["i"]).replace("[resx]","1280").replace("[resy]", "720")#.replace("[LANG]", language.upper())
                    movieItem.SetProperty("breadCrumb", utilities.cleanString(movies[index]["t"]))
                    movieItem.SetProperty("contentType", "list")
                elif(criteria == "g"):
                    artworkURL = str(moviesJsonObject["data"]["ar"]).replace("[ab]", moviesJsonObject["data"]["ab"]).replace("[gid]", movies[index]["i"]).replace("[resx]","1280").replace("[resy]", "720")
                    movieItem.SetProperty("breadCrumb", utilities.cleanString(movies[index]["t"]))
                    movieItem.SetProperty("contentType", "list")
                elif(criteria == "my"):
                    artworkURL = str(moviesJsonObject["data"]["ar"]).replace("[ab]", moviesJsonObject["data"]["ab"]).replace("[mid]", movies[index]["i"]).replace("[LANG]", language.upper())
                    movieItem.SetProperty("breadCrumb", utilities.cleanString(movies[index]["t"]) + " | " + utilities.cleanString(movies[index]["g"]) + " | " + utilities.cleanString(movies[index]["c"]) + " | " + utilities.cleanString(movies[index]["rd"]) + " | " + utilities.cleanString(movies[index]["r"]) + txt_min)
                    movieItem.SetProperty("userRating", utilities.cleanString(movies[index]["ur"]))
                    movieItem.SetProperty("contentType", "item")
                elif(criteria == "Options"):
                    artworkURL = str(moviesJsonObject["data"]["ar"]).replace("[id]", movies[index]["i"])
                    movieItem.SetProperty("breadCrumb", movies[index]["t"])
                    if((utilities.isViewster() and index == 4) or (utilities.isHustler() and index == 3)):
                        movieItem.SetProperty("contentType", "list")
                    else:
                        movieItem.SetProperty("contentType", "optionsItem")
                    
                movieItem.SetProperty("movieArtwork", str(artworkURL))
                movieItem.SetProperty("currentIndex", str(int(offsetRow) + index + 1))
                
                # for options dict cleanString not needed 
                if(criteria == "Options"):
                    movieItem.SetLabel(str(movies[index]["t"]))
                    movieItem.SetProperty("id", str(movies[index]["i"]))
                else:
                    movieItem.SetLabel(utilities.cleanString(movies[index]["t"]))
                    movieItem.SetProperty("id", utilities.cleanString(movies[index]["i"]))
                
                movieList.append(movieItem)
            
            mc.GetActiveWindow().GetList(401).SetItems(movieList)
            
            if(offsetRow != "0"):
                totalItems = int(mc.GetActiveWindow().GetList(404).GetItem(0).GetLabel())
                # hide fake right arrow ( if list contains all movies )
                if(len(movieList) == totalItems):
                    mc.GetActiveWindow().GetControl(408).SetVisible(False)
            
            # set grid content visible
            mc.GetActiveWindow().GetList(401).SetVisible(True)
            mc.GetActiveWindow().GetControl(400).SetVisible(True)
            
            if((offsetRow != "0") or (config.GetValue("previousScreenContent") == "grid")):
                mc.GetActiveWindow().GetList(401).SetFocus()
                if(row == "upper"):
                    mc.GetActiveWindow().GetList(401).SetFocusedItem(int(offsetRow))
                elif(row == "lower"):
                    if(int(offsetRow) + 2 <= totalItems):
                        mc.GetActiveWindow().GetList(401).SetFocusedItem(int(offsetRow) + 1)
                    else:
                        mc.GetActiveWindow().GetList(401).SetFocusedItem(int(offsetRow))
        
        #mc.HideDialogWait()
    else:
        if(criteria == "my"):
            # set focus on option menu button
            nextlist = mc.GetActiveWindow().GetList(200)
            nextlist.SetFocus()
            if(utilities.isViewster()):
                nextlist.SetFocusedItem(6)
            elif(utilities.isHustler()):
                nextlist.SetFocusedItem(4)
    
    return True


#
# GRID ITEM - ON RIGHT -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def gridItemOnRight():
    config = mc.GetApp().GetLocalConfig()
    
    criteria = utilities.GetCriteria()
    
    totalNoOfMovies = mc.GetActiveWindow().GetList(404).GetItem(0).GetLabel()
    currentNoOfMovies = str(len(mc.GetActiveWindow().GetList(401).GetItems()))
    
    endReached = (totalNoOfMovies == currentNoOfMovies)
    
    if((criteria != "Options") and (not endReached)):
        loadMovieGrid(criteria, str(len(mc.GetActiveWindow().GetList(401).GetItems())), "22")
    else:
        config.SetValue("callBackRecieved", "True")
    
    return True


#
# GRID ITEM - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def gridItemOnClick():
    config = mc.GetApp().GetLocalConfig()
    
    config.SetValue("previousScreenContent", "grid")
    currentGrid = config.GetValue("currentMovieListContent")
    
    if(currentGrid == "Favorites"):
        list_ID = 601
    elif(currentGrid == "Search"):
        list_ID = 704
    else:
        list_ID = 401
    
    # load Special category
    if(currentGrid == "Specials"):
        utilities.hideAllContent()
        
        config.SetValue("currentMovieListContent", "Special")
        criteria = utilities.GetCriteria()
        loadMovieGrid(criteria, "0", "18")
    # load Genre category
    elif(currentGrid == "Genres"):
        utilities.hideAllContent()
        
        config.SetValue("currentMovieListContent", "Genre")
        criteria = utilities.GetCriteria()
        loadMovieGrid(criteria, "0", "18")
    # load proper Options content
    elif(currentGrid == "Options"):
        optionsList = mc.GetActiveWindow().GetList(list_ID)
        optionsFocussedItemIndex = optionsList.GetFocusedItem()
        options.optionsItemOnClick(optionsFocussedItemIndex)
    else:
        utilities.hideAllContent()
        
        movieGridList = mc.GetActiveWindow().GetList(401)
        movieGridItem = movieGridList.GetItem(movieGridList.GetFocusedItem())
        contentType = movieGridItem.GetProperty("contentType")
        
        if(((currentGrid == "Special") and (contentType == "list")) or ((currentGrid == "Genre") and (contentType == "list")) or ((currentGrid == "MyMovies") and (contentType == "list"))):
            criteria = utilities.GetCriteria()
            loadMovieGrid(criteria, "0", "18")
        elif((currentGrid == "MyMovies") and (contentType == "optionsItem")):
            config.SetValue("currentMovieListContent", "Options")
            optionsList = mc.GetActiveWindow().GetList(list_ID)
            optionsFocussedItemIndex = optionsList.GetFocusedItem()
            options.optionsItemOnClick(optionsFocussedItemIndex)
        # load movie details
        else:
            movieList = mc.GetActiveWindow().GetList(list_ID)
            movieListItem = movieList.GetItem(movieList.GetFocusedItem())
            movieDetails.loadMovieDetails(movieListItem.GetProperty("id"))
    
    return True