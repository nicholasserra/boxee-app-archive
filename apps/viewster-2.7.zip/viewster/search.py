import mc

# VIEWSTER Librarys
import utilities
import wscalls


#
# LOAD SEARCH CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def loadSearchContent():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # initialize search filter
    edit = mc.GetActiveWindow().GetEdit(701)
    edit.SetText("")
    
    txt_search = utilities.getGuiTagContent(widgetGuiXML, "txt_search")
    
    searchButtonsList = mc.ListItems()
    for index in range(1):
        searchButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        searchButtonItem.SetLabel(txt_search)
        searchButtonsList.append(searchButtonItem)
    mc.GetActiveWindow().GetList(702).SetItems(searchButtonsList)
    
    txt_search_info = utilities.getGuiTagContent(widgetGuiXML, "txt_search_info")
    searchDescriptionList = mc.ListItems()
    for index in range(1):
        searchDescriptionItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        searchDescriptionItem.SetLabel(txt_search_info)
        searchDescriptionList.append(searchDescriptionItem)
    mc.GetActiveWindow().GetList(703).SetItems(searchDescriptionList)
    
    # Bread Crumb for Search input and Search button
    mc.GetActiveWindow().GetLabel(710).SetLabel(txt_search)
    
    # hide search results
    mc.GetActiveWindow().GetControl(704).SetVisible(False)
    
    # display Search content
    mc.GetActiveWindow().GetControl(700).SetVisible(True)
    
    config.SetValue("returnToSearchContent", "701")
    
    return True


#
# Load GRID Content
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadMovieGrid(criteria, offsetRow, maxRow):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    appName = config.GetValue("appName")
    
    # initialize list for saving total items no
    if(offsetRow == "0"):
        totalList = mc.ListItems()
        for index in range(1):
            totalItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            totalList.append(totalItem)
        mc.GetActiveWindow().GetList(404).SetItems(totalList)
    
    moviesJsonObject = wscalls.WSGetMovieList(criteria, offsetRow, maxRow)
    
    if(moviesJsonObject != False):
        # NO MOVIES available
        if(moviesJsonObject["data"]["its"] == None):
            txt_no_search_results = utilities.getGuiTagContent(widgetGuiXML, "txt_no_search_results")
            mc.ShowDialogOk(appName, txt_no_search_results)
        
        else :
            movieList = mc.ListItems()
            movies = moviesJsonObject["data"]["its"]["it"]
            
            # display fake right arrow
            if offsetRow == "0":
                totalItems = int(mc.GetActiveWindow().GetList(404).GetItem(0).GetLabel())
                if(totalItems > 9):
                    mc.GetActiveWindow().GetControl(709).SetVisible(True)
                else:
                    mc.GetActiveWindow().GetControl(709).SetVisible(False)
            
            else:
                for index in range(len(mc.GetActiveWindow().GetList(704).GetItems())):
                    movieItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                    movieItem = mc.GetActiveWindow().GetList(704).GetItem(index)
                    movieList.append(movieItem)
            
            txt_min = utilities.getGuiTagContent(widgetGuiXML, "txt_min")
            
            language = config.GetValue("language")
            
            if(utilities.isViewster()):         # VIEWSTER APP
                if(language != "en" and language != "de" and language != "fr"):
                    language = "en"
                separator = " | "
            elif(utilities.isHustler()):        # HUSTLER APP
                language = "en"
                separator = ""
            
            for index in range(len(movies)):
                movieItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                
                artworkURL = str(moviesJsonObject["data"]["ar"]).replace("[ab]", moviesJsonObject["data"]["ab"]).replace("[mid]", movies[index]["i"]).replace("[LANG]", language.upper())
                movieItem.SetProperty("breadCrumb", utilities.cleanString(movies[index]["t"]) + " | " + utilities.cleanString(movies[index]["g"]) + " | " + utilities.cleanString(movies[index]["c"]) + " | " + utilities.cleanString(movies[index]["rd"]) + " | " + utilities.cleanString(movies[index]["r"]) + txt_min)
                movieItem.SetProperty("userRating", utilities.cleanString(movies[index]["ur"]))
                movieItem.SetProperty("currentIndex", str(int(offsetRow) + index + 1))
                movieItem.SetProperty("contentType", "item")
                
                movieItem.SetImage(0, str(artworkURL))
                movieItem.SetLabel(utilities.cleanString(movies[index]["t"]))
                movieItem.SetProperty("id", utilities.cleanString(movies[index]["i"]))
                
                movieList.append(movieItem)
            
            mc.GetActiveWindow().GetList(704).SetItems(movieList)
            
            if(offsetRow != "0"):
                totalItems = int(mc.GetActiveWindow().GetList(404).GetItem(0).GetLabel())
                # hide fake right arrow ( if list contains all movies )
                if(len(movieList) == totalItems):
                    mc.GetActiveWindow().GetControl(709).SetVisible(False)
                
                mc.GetActiveWindow().GetList(704).SetFocus()
                mc.GetActiveWindow().GetList(704).SetFocusedItem(int(offsetRow))
            
            # set grid content visible
            mc.GetActiveWindow().GetList(704).SetVisible(True)
    
    return True


#
# SEARCH     - ON UP -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def search_OnUp(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    # search input
    # search button
    if((control_ID == 701) or (control_ID == 702)):
        config.SetValue("returnToSearchContent", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    # movie button
    elif(control_ID == 704):
        #mc.GetActiveWindow().GetList(704).Refresh()
        control_ID = config.GetValue("returnToSearchContent")
        mc.GetActiveWindow().GetControl(int(control_ID)).SetFocus()
    
    return True


#
# SEARCH     - ON DOWN -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def search_OnDown(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    # search input
    # search button
    if((control_ID == 701) or (control_ID == 702)):
        if mc.GetActiveWindow().GetControl(704).IsVisible():
            config.SetValue("returnToSearchContent", str(control_ID))
            nextlist = mc.GetActiveWindow().GetList(704)
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(int(focusedItem))
    
    return True


#
# SEARCH     - ON RIGHT -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def search_OnRight(control_ID):
    # grid
    if(control_ID == 704):
        config = mc.GetApp().GetLocalConfig()
        
        criteria = utilities.GetCriteria()
        
        totalNoOfMovies = mc.GetActiveWindow().GetList(404).GetItem(0).GetLabel()
        currentNoOfMovies = str(len(mc.GetActiveWindow().GetList(704).GetItems()))
        
        endReached = (totalNoOfMovies == currentNoOfMovies)
        
        if(not endReached):
            #loadMovieGrid(criteria, currentNoOfMovies, "22")
            loadMovieGrid(criteria, currentNoOfMovies, "11")
    
    return True


#
# SEARCH     - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def search_OnClick(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    appName = config.GetValue("appName")
    
    # search button
    if(control_ID == 702):
        edit = mc.GetActiveWindow().GetEdit(701)
        editText = edit.GetText()
        if(editText != ""):
            config.SetValue("searchFilter", editText)
            config.SetValue("currentMovieListContent", "Search")
            criteria = utilities.GetCriteria()
            
            loadMovieGrid(criteria, "0", "9")
        else:
            txt_no_search_results = utilities.getGuiTagContent(widgetGuiXML, "txt_no_search_results")
            mc.ShowDialogOk(appName, txt_no_search_results)
    return True