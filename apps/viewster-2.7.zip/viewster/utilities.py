from xml.dom import minidom
import mc
import simplejson as json

# HUSTLER Librarys
import wscalls
import menu


#
# Init App Variables (at app start)
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def initAppVariables():
    config = mc.GetApp().GetLocalConfig()
    
    config.SetValue("appName", "Viewster")# 
    
    config.SetValue("firstOnload", "True")
    config.SetValue("frontPageLoaded", "")
    
    if(config.GetValue("rememberMe") == ""):
        config.SetValue("rememberMe", "False")
    
    if(config.GetValue("rememberMe") == "False"):
        config.SetValue("authenticatedUser", "False")
        config.SetValue("emailAddress", "")
        config.SetValue("password", "")
    
    if(config.GetValue("activePC") == ""):
        config.SetValue("activePC", "False")
    
    if(config.GetValue("activePC") == "False"):
        config.SetValue("pc_filter", "")
        config.SetValue("pc_pin", "")
    
    config.SetValue("confirmed_pc_pin", "False")
    
    config.SetValue("countryCode", "")
    config.SetValue("operationMode", "")
    
    config.SetValue("previousScreenContent", "")
    config.SetValue("lastFocusedMenuButtonIndex", "")
    
    config.SetValue("callBackRecieved", "True")
    
    config.SetValue("currentMovieListContent", "")
    config.SetValue("genreID", "")
    config.SetValue("specialID", "")
    config.SetValue("videoLanguage", "")
    config.SetValue("subtitleLanguage", "")
    config.SetValue("videoType", "")
    
    config.SetValue("returnToChooseLangPopupContent", "")
    config.SetValue("returnToLoginPopupContent", "")
    config.SetValue("returnToMdRightContent", "")
    config.SetValue("returnToSearchContent", "")
    config.SetValue("returnToLoginContent", "")
    config.SetValue("returnToRegisterPopupContent", "")
    config.SetValue("returnToInput", "")
    
    config.SetValue("searchFilter", "")
    
    config.SetValue("subscription_currency", "")
    config.SetValue("subscription_price", "")
    config.SetValue("subscription_status", "")
    
    config.SetValue("stopMovie", "")
    
    config.SetValue("voucherValidity", "")
    config.SetValue("availableVoucherCredits", "")
    config.SetValue("remainingVoucherCredits", "")
    config.SetValue("voucherValidityDate", "")
    
    return True


#
# Clean read string from xml/json ( encode special characters)
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def cleanString(unicodeString):
    unicodeString = str(unicodeString.encode("utf-8", "replace"))
    
    return unicodeString


#
# Load Gui widget XML
# # # # # # # # # # # # # ## # # # # # # # # # # # # #
def loadGuiXML():
    tempDir = mc.GetTempDir()
    
    if(isViewster()):
        widgetGuiXML = minidom.parse(str(tempDir + "viewster_v2_widget_gui.xml"))
    elif(isHustler()):
        widgetGuiXML = minidom.parse(str(tempDir + "hustler_v2_widget_gui.xml"))
    
    return widgetGuiXML


#
# get tag content from json (widgetGuiXML's data node)
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def getGuiTagContent(widgetGuiXML, tagName):
    GuiJsonLength = int(widgetGuiXML.getElementsByTagName("data")[0].firstChild.length)
    GuiJsonContent = cleanString(widgetGuiXML.getElementsByTagName("data")[0].firstChild.substringData(0, GuiJsonLength))
    GuiJsonObject = json.loads(GuiJsonContent)
    
    try:
        GuiTagContent = cleanString(GuiJsonObject["gui"][tagName])
    except:
        GuiTagContent = ""

    return GuiTagContent


#
# CREATE OPTIONS DICTIONARY
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def createOptionsDictionary():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = loadGuiXML()
    
    txt_help = getGuiTagContent(widgetGuiXML, "txt_help")
    txt_language = getGuiTagContent(widgetGuiXML, "txt_language")
    txt_login = getGuiTagContent(widgetGuiXML, "txt_login")
    txt_my_movies = getGuiTagContent(widgetGuiXML, "txt_my_movies")
    txt_subscribe = getGuiTagContent(widgetGuiXML, "txt_subscribe")
    txt_info = getGuiTagContent(widgetGuiXML, "txt_info")
    txt_my_voucher = getGuiTagContent(widgetGuiXML, "txt_my_voucher")
    
    # VIEWSTER APP
    if(isViewster()):
        txt_parental_control = getGuiTagContent(widgetGuiXML, "txt_parental_control")
        if(config.GetValue("init_svod") == "t"):
            optionsDict = {"data":{"ar":"options_[id].png", "its":{"it":[{"i":"help", "t":txt_help}, {"i":"language", "t":txt_language}, {"i":"login", "t":txt_login}, {"i":"pc", "t":txt_parental_control}, {"i":"myMovies", "t":txt_my_movies}, {"i":"subscribe", "t":txt_subscribe}, {"i":"info", "t":txt_info}, {"i":"myVoucher", "t":txt_my_voucher}]}, "t":"8"}}
        else:
            optionsDict = {"data":{"ar":"options_[id].png", "its":{"it":[{"i":"help", "t":txt_help}, {"i":"language", "t":txt_language}, {"i":"login", "t":txt_login}, {"i":"pc", "t":txt_parental_control}, {"i":"myMovies", "t":txt_my_movies}, {"i":"info", "t":txt_info}, {"i":"myVoucher", "t":txt_my_voucher}]}, "t":"7"}}
    # HUSTLER APP
    elif(isHustler()):
        if(config.GetValue("init_svod") == "t"):
            optionsDict = {"data":{"ar":"h_options_[id].png", "its":{"it":[{"i":"help", "t":txt_help}, {"i":"language", "t":txt_language}, {"i":"login", "t":txt_login}, {"i":"myMovies", "t":txt_my_movies}, {"i":"subscribe", "t":txt_subscribe}, {"i":"info", "t":txt_info}, {"i":"myVoucher", "t":txt_my_voucher}]}, "t":"7"}}
        else:
            optionsDict = {"data":{"ar":"h_options_[id].png", "its":{"it":[{"i":"help", "t":txt_help}, {"i":"language", "t":txt_language}, {"i":"login", "t":txt_login}, {"i":"myMovies", "t":txt_my_movies}, {"i":"info", "t":txt_info}, {"i":"myVoucher", "t":txt_my_voucher}]}, "t":"6"}}
    
    
    return optionsDict


#
# get movie criteria
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def GetCriteria():
    config = mc.GetApp().GetLocalConfig()
    
    longCriteria = str(config.GetValue("currentMovieListContent"))
    
    if(longCriteria == "Highlights"):
        shortCriteria = "h"
    elif(longCriteria == "Specials"):
        shortCriteria = "p"
    elif(longCriteria == "Genres"):
        shortCriteria = "g"
    elif(longCriteria == "Free"):
        shortCriteria = "free"
    elif(longCriteria == "MyMovies"):
        shortCriteria = "my"
    
    elif(longCriteria == "Special"):
        specialsList = mc.GetActiveWindow().GetList(401)
        specialsListItem = specialsList.GetItem(specialsList.GetFocusedItem())
        if(specialsListItem.GetProperty("contentType") == "list"):
            specialCategoryId = str(specialsListItem.GetProperty("id"))
        elif(specialsListItem.GetProperty("contentType") == "item"):
            specialCategoryId = str(config.GetValue("specialID"))
        shortCriteria = "p:" + specialCategoryId
        
    elif(longCriteria == "Genre"):
        genresList = mc.GetActiveWindow().GetList(401)
        genresListItem = genresList.GetItem(genresList.GetFocusedItem())
        if(genresListItem.GetProperty("contentType") == "list"):
            genreCategoryId = str(genresListItem.GetProperty("id"))
        elif(genresListItem.GetProperty("contentType") == "item"):
            genreCategoryId = str(config.GetValue("genreID"))
        shortCriteria = "g:" + genreCategoryId
    
    elif(longCriteria == "Search"):
        searchFilter = str(config.GetValue("searchFilter"))
        shortCriteria = "s:" + searchFilter
        
    elif(longCriteria == "Options"):
        shortCriteria = "Options"
    
    return shortCriteria


#
# Hide ALL Content
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def hideAllContent():
    window = mc.GetActiveWindow()
    
    window.GetControl(300).SetVisible(False)      # Front Page
    window.GetControl(400).SetVisible(False)      # Grid Content
    window.GetControl(500).SetVisible(False)      # Movie Details Content
    window.GetControl(600).SetVisible(False)      # Favorites grid Content
    window.GetControl(700).SetVisible(False)      # Search Content
    window.GetControl(800).SetVisible(False)      # "No items msg" Content
    window.GetControl(1100).SetVisible(False)     # Help(Options) Content
    window.GetControl(1200).SetVisible(False)     # Language(Options) Content
    window.GetControl(1300).SetVisible(False)     # Login Content
    window.GetControl(1400).SetVisible(False)     # Parental Control(Options) Content
    window.GetControl(1500).SetVisible(False)     # Info(Options) Content
    window.GetControl(2000).SetVisible(False)     # My Voucher(Options) Content
    window.GetControl(1600).SetVisible(False)     # Disclaimer popup Content
    window.GetControl(1700).SetVisible(False)     # Enter Parental Pin Popup
    window.GetControl(1800).SetVisible(False)     # Payment Confirmation(big) Content
    window.GetControl(1900).SetVisible(False)     # Create Account(big) Content
    
    return True


#
# Check if  ALL Content Is Hidden
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def isCleanScreen():
    window = mc.GetActiveWindow()
    
    if window.GetControl(300).IsVisible() or window.GetControl(400).IsVisible() or window.GetControl(500).IsVisible() or window.GetControl(600).IsVisible() or window.GetControl(700).IsVisible() or window.GetControl(800).IsVisible() or window.GetControl(1100).IsVisible() or window.GetControl(1200).IsVisible() or window.GetControl(1300).IsVisible() or window.GetControl(1400).IsVisible() or window.GetControl(1500).IsVisible() or window.GetControl(1600).IsVisible() or window.GetControl(1700).IsVisible():
        clean = False
    else:
        clean = True
    
    return clean


#
# Check if current APP is Viewster
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def isViewster():
    config = mc.GetApp().GetLocalConfig()
    
    if(config.GetValue("appName") == "Viewster"):
        return True
    else:
        return False


#
# Check if current APP is Hustler
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def isHustler():
    config = mc.GetApp().GetLocalConfig()
    
    if(config.GetValue("appName") == "Hustler"):
        return True
    else:
        return False


#
# Check if current window  id is 14000
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def getCurrentWindowId():
    params = mc.GetApp().GetLaunchedWindowParameters()
    try:
        if(params["windowId"] == "14000"):
            currentWindowId = params["windowId"]
    except:
        currentWindowId = "native_window"
    
    return currentWindowId


#
# Reset video languages
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def resetVideoLanguages():
    config = mc.GetApp().GetLocalConfig()
    
    config.SetValue("videoLanguage", "")
    config.SetValue("subtitleLanguage", "")
    
    return True


#
# Load Disclaimer Popup
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def loadDisclaimerPopup():
    widgetGuiXML = loadGuiXML()
    
    # set Disclaimer title
    txt_disclaimer_title = getGuiTagContent(widgetGuiXML, "txt_disclaimer_title")
    disclaimerTitleList = mc.ListItems()
    for index in range(1):
        disclaimerTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        disclaimerTitleItem.SetLabel(txt_disclaimer_title)
        disclaimerTitleList.append(disclaimerTitleItem)
    mc.GetActiveWindow().GetList(1604).SetItems(disclaimerTitleList)
    
    # set Disclaimer text
    txt_disclaimer_text = getGuiTagContent(widgetGuiXML, "txt_disclaimer_text")
    disclaimerTextList = mc.ListItems()
    for index in range(1):
        disclaimerTextItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        disclaimerTextItem.SetLabel(txt_disclaimer_text)
        disclaimerTextList.append(disclaimerTextItem)
    mc.GetActiveWindow().GetList(1605).SetItems(disclaimerTextList)
    
    # Exit & Enter buttons
    txt_exit = getGuiTagContent(widgetGuiXML, "txt_exit")
    txt_enter = getGuiTagContent(widgetGuiXML, "txt_enter")
    disclaimerButtonsList = mc.ListItems()
    for index in range(2):
        disclaimerButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        if index == 0:
            disclaimerButtonItem.SetLabel(txt_exit)
        elif index == 1:
            disclaimerButtonItem.SetLabel(txt_enter)
        disclaimerButtonsList.append(disclaimerButtonItem)
    mc.GetActiveWindow().GetList(1606).SetItems(disclaimerButtonsList)
    
    # set Disclaimer footer
    txt_disclaimer_footer = getGuiTagContent(widgetGuiXML, "txt_disclaimer_footer")
    disclaimerFooterList = mc.ListItems()
    for index in range(1):
        disclaimerFooterItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        disclaimerFooterItem.SetLabel(txt_disclaimer_footer)
        disclaimerFooterList.append(disclaimerFooterItem)
    mc.GetActiveWindow().GetList(1607).SetItems(disclaimerFooterList)
    
    # set Focus on exit button
    disclaimerButtonsList = mc.GetActiveWindow().GetList(1606)
    disclaimerButtonsList.SetFocus()
    disclaimerButtonsList.SetFocusedItem(0)
    
    mc.GetActiveWindow().GetControl(1600).SetVisible(True)
    
    return True


#
# Disclaimer Button - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def disclaimerButtonOnClick():
    disclaimerButtonList = mc.GetActiveWindow().GetList(1606)
    focusedDisclaimerButtonIndex = disclaimerButtonList.GetFocusedItem()
    
    # Exit button
    if(focusedDisclaimerButtonIndex == 0):
        mc.GetActiveWindow().ClearStateStack(False)
        mc.CloseWindow()
    
    # Enter button
    elif(focusedDisclaimerButtonIndex == 1):
        config = mc.GetApp().GetLocalConfig()
        
        if(config.GetValue("frontPageLoaded") != "already"):
            wscalls.WSGetFrontPage()
        
        menu.loadMenu()
        
        #if(config.GetValue("authenticatedUser") != "True"):
        #    widgetGuiXML = loadGuiXML()
        #    
        #    txt_start_popup = getGuiTagContent(widgetGuiXML, "txt_start_popup").replace("|br|","").replace("http://hustler.viewster.tv", "[COLOR FFE13993]http://hustler.viewster.tv[/COLOR]")
        #    appName = config.GetValue("appName")
        #    mc.ShowDialogOk(appName, txt_start_popup)
    
    return True