project = "yuitheater"
director = "yuitheater"
publisher = "Yahoo!"
channel = "boxee"