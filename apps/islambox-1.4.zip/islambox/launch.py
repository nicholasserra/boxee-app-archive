import sys
import mc
import utils
def launch():
    params = mc.Parameters()
    app = mc.GetApp()
    app.RunScript('utils', params)
	#app.RunScript('service', params)
	
launch()
