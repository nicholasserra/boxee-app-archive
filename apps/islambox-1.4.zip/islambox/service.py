import httplib
import urllib
import xml.dom.minidom
import mc

#-------SETTINGS-------
HOST = 'www.islambox.com'
URL = '/services/IBPIService.asmx'	
httplib.HTTPConnection.debuglevel = 0
#----------------------

def _SOAP_post(SOAPAction,xml):
	"""Handles making the SOAP request"""
	h = httplib.HTTPConnection(HOST)
	headers={
		'Host':HOST,
		'Content-Type':'text/xml; charset=utf-8',
		'Content-Length':len(xml),
		'SOAPAction': SOAPAction,
		'User-agent': 'Boxee'
	}
	h.request ('POST',URL,xml,headers)
	r = h.getresponse()	
	d = r.read()	
	#h.close()
	return d
def Call_Service_Method(methodName,param):
	methodParams = ""
	for key,value in param.items():
		methodParams += "<%s>%s</%s>" % (key,value,key)
	in_xml="""\
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
<soap:Body>
<%s xmlns="http://services.islambox.com/services/">
%s
</%s>
</soap:Body>
</soap:Envelope>""" % (methodName,methodParams,methodName)
	soapAction = "http://services.islambox.com/services/%s" % methodName
	result = _SOAP_post(soapAction,in_xml)
	
	return result	