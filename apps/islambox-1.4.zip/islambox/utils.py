import sys
import mc
import service
from xml.dom import minidom
from urllib import quote_plus, urlencode


device = 'Boxee'
config = mc.GetApp().GetLocalConfig()
version = 'v1.4'
ChannelsList = mc.ListItems()
VodProgramsList = mc.ListItems()
ContentTypes = {
"112":"video/x-ms-asf",
"107":"video/x-flv",
"106":"video/x-msvideo",
"110":"video/quicktime",
"111":"video/mp4",
"live-wmv":"video/x-ms-asf",
"live-hls":"application/vnd.apple.mpegurl"
}
#wmv,flv,avi,mov,mp4

EpisodeList = mc.ListItems()
Index = 0
PackageId = 0
ProgramId = 0
EpisodeCount = 0


def LoadMainScreen():
	mc.ShowDialogWait()
	mc.GetActiveWindow().GetControl(6006).SetVisible(False)
	SetLogin()
	GetBanner()
	packagesListUI = mc.ListItems()
	packagesListUI = GetPackages()
	if len(packagesListUI) > 0:
		mc.GetActiveWindow().GetList(120).SetItems(packagesListUI)
		mc.GetActiveWindow().GetControl(120).SetFocus()
		mc.GetActiveWindow().GetLabel(500).SetLabel(version)
		mc.GetActiveWindow().GetList(120).SetFocusedItem(0)
		if len(packagesListUI) > 4:
			mc.GetActiveWindow().GetControl(6006).SetVisible(True)
		else:
			mc.GetActiveWindow().GetControl(6006).SetVisible(False)
	else:
		mc.ShowDialogOk("Error", "Failed to retrieve Packages, please try later!")
	mc.HideDialogWait()
	
def GetBanner():
	params = {"device":device}
	try:
		dom = minidom.parseString(service.Call_Service_Method("GetPlayerBanners",params))
		if dom:
			bannerList = mc.ListItems()
			for node in dom.getElementsByTagName('Banner'):				
				try:
					item = mc.ListItem()
					image = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('ImagePath')
					if image:				
						item.SetThumbnail(str(image[0].childNodes[0].data))
					url = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('NavigateUrl')
					if url[0].childNodes:					
						item.SetProperty('NavigateUrl', str(url[0].childNodes[0].data))
					else:
						item.SetProperty('NavigateUrl', '')
					item.SetLabel("Navi-X Browser")
					item.SetAddToHistory(False)
					item.SetReportToServer(False)
					bannerList.append(item)
				except:
					mc.LogInfo("Banner Error: %s" % sys.exc_info()[1])				
				break
			if len(bannerList) > 0:
				mc.GetActiveWindow().GetList(300).SetItems(bannerList)
				mc.GetActiveWindow().GetList(300).SetVisible(True)
			else:
				mc.GetActiveWindow().GetList(300).SetVisible(False)
	except:
		mc.LogInfo("Banner Error: %s" % sys.exc_info()[1])

def OnBannerClick():
	index = mc.GetActiveWindow().GetList(300).GetFocusedItem()
	item =  mc.GetActiveWindow().GetList(300).GetItem(index)
	navigateUrl = item.GetProperty("NavigateUrl")	
	if navigateUrl != '':		
		item.SetPath(navigateUrl)
		item.SetContentType("text/html")	
		mc.GetPlayer().Play(item)
			
def OnPackageClick():
	mc.ShowDialogWait()
	selectedItem = mc.GetActiveWindow().GetList(120).GetFocusedItem()
	item = mc.GetActiveWindow().GetList(120).GetItem(selectedItem)
	pid = item.GetProperty("Pakid")
	name = item.GetLabel()	
	mc.HideDialogWait()
	LaunchSelectionScreen(pid,name)
	
def LoadSelectionScreen():
	mc.ShowDialogWait()
	SetLogin()
	categoryListUI = mc.ListItems()
	params = mc.GetApp().GetLaunchedWindowParameters()
	pid = params["id"]
	name = params["name"]
	mc.GetActiveWindow().GetLabel(500).SetLabel(version)
	categoryListUI = GetCategories(pid)
	mc.GetActiveWindow().GetList(121).SetItems(categoryListUI)
	mc.GetActiveWindow().GetControl(121).SetFocus()
	mc.GetActiveWindow().GetList(121).SetFocusedItem(0)
	mc.GetActiveWindow().GetLabel(123).SetLabel(name)
	mc.HideDialogWait()

def OnCategoryClick():
	mc.ShowDialogWait()
	selectedItem = mc.GetActiveWindow().GetList(121).GetFocusedItem()
	item = mc.GetActiveWindow().GetList(121).GetItem(selectedItem)
	pid = item.GetProperty("Pakid")
	type = selectedItem
	mc.HideDialogWait()
	
	LaunchMediaListing(pid,type)

def LoadChannelsScreen():
	mc.ShowDialogWait()
	SetLogin()
	mc.GetActiveWindow().GetLabel(500).SetLabel(version)
	params = mc.GetApp().GetLaunchedWindowParameters()
	pid = params["pid"]
	type = params["type"]
	name = params["name"]
	mc.GetActiveWindow().GetList(110).SetItems(GetMediaCategories(pid, type))
	channelListUI = mc.ListItems()
	catId = ''
	if mc.GetApp().GetLocalConfig().GetValue("CatId") != '':
		catId = mc.GetApp().GetLocalConfig().GetValue("CatId")
	else:
		catId = mc.GetActiveWindow().GetList(110).GetItem(0).GetProperty("catId")
	channelListUI = GetList(pid, catId, type)
	if len(channelListUI) > 0:
		mc.GetActiveWindow().GetList(122).SetItems(channelListUI)
		mc.GetActiveWindow().GetControl(122).SetFocus()
		mc.GetActiveWindow().GetList(122).SetFocusedItem(0)
		mc.GetActiveWindow().GetLabel(123).SetLabel(name)
	else:		
		mc.ShowDialogOk("Oops", "Sorry, Currently no item is available in this package!")		
		mc.ActivateWindow(15000)
	mc.HideDialogWait()
	
def OnMediaCategoryClick():
	mc.ShowDialogWait()
	selectedCategory =  mc.GetActiveWindow().GetList(110).GetFocusedItem()
	item = mc.GetActiveWindow().GetList(110).GetItem(selectedCategory)
	itemList = GetList(item.GetProperty("PackId"), item.GetProperty("catId"), item.GetProperty("type"))
	if len(itemList) > 0:
		mc.GetActiveWindow().GetList(122).SetItems(itemList)
		mc.GetActiveWindow().GetControl(122).SetFocus()
		mc.GetActiveWindow().GetList(122).SetFocusedItem(0)
	else:
		mc.ShowDialogOk("Oops", "Sorry, Currently no item is available in this category!")
	mc.HideDialogWait()
	
def OnMediaClick():
	selectedItem = mc.GetActiveWindow().GetList(122).GetFocusedItem()
	item = mc.GetActiveWindow().GetList(122).GetItem(selectedItem)
	type = item.GetProperty("type")
	if type == '0':
		Play(122)
	else:
		mc.ShowDialogWait()		
		name = item.GetLabel()
		id = item.GetProperty("Id")
		catId = item.GetProperty("CatId")
		packId = item.GetProperty("PackId")
		episodeCount = item.GetProperty("EpisodeCount")
		mc.HideDialogWait()		
		LaunchEpisodeScreen(id,name,catId,packId,episodeCount)
		
def LoadEpisodeScreen():
	mc.ShowDialogWait()	
	mc.GetActiveWindow().GetControl(555).SetVisible(False)
	SetLogin()
	mc.GetActiveWindow().GetLabel(500).SetLabel(version)
	episodeListUI = mc.ListItems()
	params = mc.GetApp().GetLaunchedWindowParameters()
	id = params["id"]
	name = params["name"]
	cid = params["CatId"]
	packId = params["packId"]
	episodeCount = params["episodeCount"]
	mc.GetActiveWindow().GetList(110).SetItems(GetProgramsList(cid))
	GetEpisodes(id,packId,episodeCount,'False')
	#mc.GetActiveWindow().GetControl(125).SetFocus()
	#mc.GetActiveWindow().GetList(125).SetFocusedItem(0)
	mc.GetActiveWindow().GetLabel(123).SetLabel(name)
	mc.HideDialogWait()
	
def OnEpisodeProgramClick():
	mc.ShowDialogWait()
	selectedCategory =  mc.GetActiveWindow().GetList(110).GetFocusedItem()
	item = mc.GetActiveWindow().GetList(110).GetItem(selectedCategory)
	GetEpisodes(item.GetProperty("Id"), item.GetProperty("PackId"), item.GetProperty("EpisodeCount"), 'False')
	#mc.GetActiveWindow().GetControl(125).SetFocus()
	#mc.GetActiveWindow().GetList(125).SetFocusedItem(0)
	
	mc.HideDialogWait()
	
def GetContentType(mediaFormat):
	return ContentTypes.get(str(mediaFormat))
	
def SetLogin():
	if CheckUserLogin():
		mc.GetActiveWindow().GetToggleButton(132).SetSelected(True)
	else:
		mc.GetActiveWindow().GetToggleButton(132).SetSelected(False)

def GetUserEmail():
	if config.GetValue("islambox_username"):
		return config.GetValue("islambox_username")
	return False

def GetUserPass():
	if config.GetValue("islambox_password"):
		return config.GetValue("islambox_password")
	return False
	
def CheckUserLogin():	
	if GetUserEmail() and GetUserPass():
		if((GetUserEmail() != "") and (GetUserPass != "")):
			return True
	return False
	
def LoginUser():
	params = GetCredentials()
	if params:	
		dom = minidom.parseString(service.Call_Service_Method("ValidateUser",params))
		res = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('HasError')[0]
		try:
			if res.childNodes[0].data == 'True':
				err = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('Message')
				if err:
					mc.ShowDialogOk("Error", str(err[0].childNodes[0].data))
					mc.GetActiveWindow().GetToggleButton(132).SetSelected(False)
			else:			
				user = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('UserID')
				if user and user[0].childNodes[0].data != '':
					SaveCredentials(params['email'], params['password'])				
				else:
					mc.GetActiveWindow().GetToggleButton(132).SetSelected(False)
		except:
			mc.LogInfo("LoginUser Error: %s" % sys.exc_info()[1])
	else:
		mc.GetActiveWindow().GetToggleButton(132).SetSelected(False)
		mc.ShowDialogOk("Login Failed!", "Credentials are not correct!")
		
def ClearCredentials():
	config.SetValue("islambox_username", '')
	config.SetValue("islambox_password", '')
	mc.GetActiveWindow().GetToggleButton(132).SetSelected(False)
	
def SaveCredentials(userName, password):
	config.SetValue("islambox_username", userName)
	config.SetValue("islambox_password", password)
	mc.GetActiveWindow().GetToggleButton(132).SetSelected(True)
	
def GetCredentials():
	userName = ''
	password = ''
	if CheckUserLogin():
		userName = GetUserEmail()
		password = GetUserPass()
	else:
		userName = mc.ShowDialogKeyboard("Please enter your IslamBox Email ID:", "", False)
		password = mc.ShowDialogKeyboard("Please enter your IslamBox Password:", "", True)
	if((userName != "") and (password != "")):		
		params = {}
		params['device'] = device
		params['deviceID'] = GetUniqueId()
		params['email'] = str(userName)
		params['password'] = str(password)
		return params
	return False
	
def GetPackages():	
	params = {}
	params['device'] = device
	params['deviceID'] = GetUniqueId()
	dom = minidom.parseString(service.Call_Service_Method("GetPackages",params))
	PackageList = mc.ListItems()
	if dom:	
		for node in dom.getElementsByTagName('Package'):			
			try:
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				item.SetThumbnail(str(node.getAttribute('Image')))
				item.SetLabel(str(node.getAttribute('Title')))					
				item.SetProperty('PakId', str(node.getAttribute('PackageID')))
				PackageList.append(item)
			except:
				mc.LogInfo("Packages Error: %s" % sys.exc_info()[1])			
		mc.GetApp().GetLocalConfig().SetValue("CatId", '')		
	return PackageList
	
def GetCategories(packageId):	
	params = {}
	params['device'] = device
	params['deviceID'] = GetUniqueId()	
	dom = minidom.parseString(service.Call_Service_Method("GetCategories",params))
	CategoryList = mc.ListItems()
	if dom:
		for node in dom.getElementsByTagName('Category'):					
			try:
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				item.SetThumbnail(str(node.getAttribute('SDImage')))
				item.SetLabel(str(node.getAttribute('Title')))					
				item.SetProperty('CatId', str(node.getAttribute('CategoryID')))
				item.SetProperty('PakId', packageId)
				CategoryList.append(item)
			except:
				mc.LogInfo("Categories Error: %s" % sys.exc_info()[1])			
		mc.GetApp().GetLocalConfig().SetValue("CatId", '')
	return CategoryList


def GetAllChannels(packageId):
	params = {}
	params['device'] = device
	params['deviceID'] = GetUniqueId()
	params['packageID'] = packageId
	dom = minidom.parseString(service.Call_Service_Method("GetChannels",params))
	del ChannelsList[:]
	for node in dom.getElementsByTagName('Channel'):
		subNodes = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('Category')
		for n in subNodes:						
			try:
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				image = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('SDImage')
				item.SetThumbnail(str(image[0].childNodes[0].data))
				title = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('Title')
				item.SetLabel(str(title[0].childNodes[0].data))
				channelId = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('ContentID')
				item.SetProperty('Id', str(channelId[0].childNodes[0].data))
				url = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('StreamUrl')
				if url:
					item.SetProperty('Url', str(url[0].childNodes[0].data))
				item.SetProperty('CatId', str(n.getAttribute('ID')))
				item.SetProperty('PackId', packageId)
				item.SetProperty('MediaFormat' , 'live-wmv')
				ChannelsList.append(item)
			except:
				mc.LogInfo("Get All Channels Error: %s" % sys.exc_info()[1])			

def GetList(packageId, catId, type):	
	if type == '0':
		if len(ChannelsList) == 0 or (len(ChannelsList) > 0 and packageId != ChannelsList[0].GetProperty("PackId")):
			GetAllChannels(packageId)
	elif type == '1':
		if len(VodProgramsList) == 0 or (len(VodProgramsList) > 0 and packageId != VodProgramsList[0].GetProperty("PackId")):
			GetAllVodPrograms(packageId)
	myList = mc.ListItems()
	if type == '0':
		myList = ChannelsList
	elif type =='1':
		myList = VodProgramsList
	NewList = mc.ListItems()
	for item in myList:
		if item.GetProperty("CatId") == catId:
			newItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
			h = mc.Http()
			if h.Get(item.GetThumbnail()):
				newItem.SetThumbnail(item.GetThumbnail())
			else:
				newItem.SetThumbnail('no-image.png')
			newItem.SetLabel(item.GetLabel())
			newItem.SetProperty('Id', item.GetProperty("Id"))
			newItem.SetProperty('PackId', packageId)
			newItem.SetProperty('type', type)
			newItem.SetProperty('CatId', item.GetProperty("CatId"))
			newItem.SetProperty('Url', item.GetProperty("Url"))
			newItem.SetProperty('MediaFormat', item.GetProperty("MediaFormat"))
			if type == '1':
				newItem.SetProperty('EpisodeCount', str(item.GetProperty('EpisodeCount')))
			NewList.append(newItem)
	mc.GetApp().GetLocalConfig().SetValue("CatId", catId)
	return NewList

def GetAllVodPrograms(packageId):
	params = {}
	params['device'] = device
	params['deviceID'] = GetUniqueId()
	params['packageID'] = packageId
	params['categoryID'] = ''	
	dom = minidom.parseString(service.Call_Service_Method("GetVODs",params))
	del VodProgramsList[:]
	for node in dom.getElementsByTagName('VOD'):
		subNodes = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('Category')
		for n in subNodes:				
			try:			
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				image = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('SDImage')				
				item.SetThumbnail(str(image[0].childNodes[0].data))
				title = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('Title')
				item.SetLabel(str(title[0].childNodes[0].data))
				PId = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('ContentID')
				item.SetProperty('Id', str(PId[0].childNodes[0].data))
				item.SetProperty('CatId', str(n.getAttribute('ID')))
				item.SetProperty('PackId', packageId)
				item.SetProperty('type', '1')
				count = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('EpisodeCount')
				if count[0]:
					item.SetProperty('EpisodeCount', str(count[0].childNodes[0].data))
				else:
					item.SetProperty('EpisodeCount', '0')
				VodProgramsList.append(item)
			except:
				mc.LogInfo("Vod Program Error: %s" % sys.exc_info()[1])
			
			
def GetProgramsList(catId):
	NewList = mc.ListItems()
	for item in VodProgramsList:
		if item.GetProperty("CatId") == catId:
			newItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
			newItem.SetThumbnail(item.GetThumbnail())
			title = item.GetLabel()
			if len(title) > 15:								
				newItem.SetLabel(title[:13] + '..')
			else:
				newItem.SetLabel(title)
			newItem.SetProperty('Id', item.GetProperty("Id"))
			newItem.SetProperty('EpisodeCount', str(item.GetProperty('EpisodeCount')))
			NewList.append(newItem)
	mc.GetApp().GetLocalConfig().SetValue("CatId", catId)
	return NewList


def GetMediaCategories(packageId, type):
	params = {}
	params['device'] = device
	params['deviceID'] = GetUniqueId()
	params['packageID'] = packageId
	mediaType = ''
	if type == '1':
		mediaType = 'VOD'
	else:
		mediaType = 'TVChannel'
	try:
		dom = minidom.parseString(service.Call_Service_Method("GetCategories",params))
		CategoryList = mc.ListItems()
		for node in dom.getElementsByTagName('Category'):
			try:
				if str(node.getAttribute('Code')) == mediaType :
					subNodes = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('SubCategory')
					for n in subNodes:
						try:
							item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
							title = str(n.getAttribute('Title'))
							if len(title) > 15:
								item.SetLabel(title[:13] + '..')
							else:
								item.SetLabel(title)
							item.SetProperty('catId', str(n.getAttribute('CategoryID')))
							item.SetProperty('PackId', packageId)
							item.SetProperty('type', type)
							CategoryList.append(item)
						except:
							mc.LogInfo("Media Category Error: %s" % sys.exc_info()[1])
			except:
				mc.LogInfo("Media Category Error: %s" % sys.exc_info()[1])
	except:
		mc.LogInfo("Media Category Error: %s" % sys.exc_info()[1])
	return CategoryList


def GetEpisodes(programId, packageId, episodeCount, showMore):
	params = {}
	params['device'] = device
	params['deviceID'] = GetUniqueId()
	params['programID'] = programId	
	global EpisodeList
	global Index
	global PackageId
	global ProgramId
	global EpisodeCount
	
	if showMore == 'False':
		Index = 0
		EpisodeCount = episodeCount
		PackageId = packageId
		ProgramId = programId
		del EpisodeList[:]
		
	totalEpisodes = int(episodeCount)	
	if totalEpisodes > 0:
		if totalEpisodes > 4 and  (Index + 4 < totalEpisodes):
			mc.GetActiveWindow().GetControl(555).SetVisible(True)
		else:
			mc.GetActiveWindow().GetControl(555).SetVisible(False)
		
		params['startIndex'] = Index 
		params['pageSize'] = 4
		Index = Index + 4
		dom = minidom.parseString(service.Call_Service_Method("GetVODEpisodesForBoxee",params))	
		for node in dom.getElementsByTagName('VODEpisode'):		
			try:					
				if not mc.GetActiveWindow().GetList(125):					
					break
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				title = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('Title')
				title = title[0].childNodes[0].data.encode('utf-8')
				item.SetLabel(str(title))
				description = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('Description')
				desc = description[0].childNodes[0].data.encode('utf-8')
				item.SetThumbnail(str(desc))		
				PId = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('ContentId')
				item.SetProperty('Id', str(PId[0].childNodes[0].data))
				item.SetProperty('PackId', packageId)
				item.SetProperty('type', '1')
				mediaFormat = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('MediaFormat')
				if mediaFormat:
					item.SetProperty('MediaFormat', str(mediaFormat[0].childNodes[0].data))
				url = minidom.parseString(str(node.toxml().encode('utf-8'))).getElementsByTagName('StreamUrl')
				if url[0] and url[0].childNodes:
					item.SetProperty('Url', str(url[0].childNodes[0].data))
				EpisodeList.append(item)										
			except:
					mc.LogInfo("Vod Episode Error: %s" % sys.exc_info()[1])		
		mc.GetActiveWindow().GetList(125).SetItems(EpisodeList)
		mc.GetActiveWindow().GetList(125).SetFocus()
			
	else:
		mc.ShowDialogOk("Oops", "Sorry, Currently no episode is available for this program!")
		mc.ActivateWindow(16000)

def ShowMoreEpisodes():
	mc.ShowDialogWait()
	GetEpisodes(ProgramId,PackageId,EpisodeCount,'True')
	mc.HideDialogWait()
	


def LaunchSelectionScreen(z,x):
    params = {
            "id": z,
			"name": x
    }
    p = mc.Parameters()
    if (params != False):
        for i in params:
            p[i] = params[i]
    mc.GetApp().ActivateWindow(15000,p)
	
def LaunchMediaListing(x,z):
	params = {"pid":x,"type":str(z)}
	if z == 0:
		params['name'] = "Live TV Channels"
	elif z == 1:
		params['name'] = "Video On Demand"
	p = mc.Parameters()
	if (params != False):
		for i in params:
			p[i] = params[i]
	mc.GetApp().ActivateWindow(16000,p)

def LaunchEpisodeScreen(x,z,y,p,e):
    params = {
            "id": x,
			"name": z,
			"CatId": y,
			"packId": p,
			"episodeCount": e
			}
    p = mc.Parameters()
    if (params != False):
        for i in params:
            p[i] = params[i]		
	mc.GetApp().ActivateWindow(17000,p)
	
def ValidateBoxee(url, packageId, type):
	params = GetCredentials()
	if params:
		params['packageId'] = packageId
		params['url'] = url
		submitRequest = 'True'
		if type == '1':
			submitRequest = 'False'
		params['submitRequest'] = submitRequest
		dom = minidom.parseString(service.Call_Service_Method("ValidateBoxee",params))
		res = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('HasError')[0]
		if res.childNodes[0].data == 'True':
			err = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('Code')
			if err:
				msg = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('Message')
				if str(err[0].childNodes[0].data) == '18':
					if msg:
						response = mc.ShowDialogConfirm("Confirmation", str(msg[0].childNodes[0].data), "No", "Yes")
						if response:
							subId = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('SubId')
							if subId:
								del params["packageId"]
								del params["url"]
								del params["submitRequest"]
								params['subscriptionId'] = str(subId[0].childNodes[0].data)
								dom2 = minidom.parseString(service.Call_Service_Method("LinkPlayerWithSubscription",params))
								error = minidom.parseString(str(dom2.toxml().encode('utf-8'))).getElementsByTagName('HasError')[0]								
								if error:
									msg2 = minidom.parseString(str(dom2.toxml().encode('utf-8'))).getElementsByTagName('Message')
									if error.childNodes[0].data == 'True':										
										mc.ShowDialogOk("Error", str(msg2[0].childNodes[0].data))
									else:
										SaveCredentials(params['email'], params['password'])
										mc.ShowDialogOk("Congratulations", str(msg2[0].childNodes[0].data))
									
				else:
					mc.ShowDialogOk("Error", str(msg[0].childNodes[0].data))
		else:
			SaveCredentials(params['email'], params['password'])
			url = minidom.parseString(str(dom.toxml().encode('utf-8'))).getElementsByTagName('StreamUrl')
			return url[0].childNodes[0].data
	else:
		mc.ShowDialogOk("Login Failed!", "Credentials are not correct!")


def Play(itemNo):
	mc.ShowDialogWait()
	selectedItem = mc.GetActiveWindow().GetList(itemNo).GetFocusedItem()
	item2 = mc.GetActiveWindow().GetList(itemNo).GetItem(selectedItem)
	type = item2.GetProperty("type")
	res = ValidateBoxee(str(item2.GetProperty("Url")), item2.GetProperty("PackId"), type)	
	mc.HideDialogWait()
	if res:				
		title = item2.GetLabel()
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
		if res.find('playlist.m3u8') > 0:
			params = { 'quality': '1' }
			res = "playlist://%s?%s" % (quote_plus(res), urlencode(params))
			item.SetContentType('application/vnd.apple.mpegurl')
		else:			
			if title == 'Press TV':
				item.SetContentType('video/x-ms-wmv')
			else:
				item.SetContentType(GetContentType(item2.GetProperty("MediaFormat")))
		item.SetLabel(title)
		item.SetPath(str(res))				
		mc.GetPlayer().Play(item)
		mc.ShowDialogNotification(title)
		item.Dump()	

def GetUniqueId():	
	return mc.GetDeviceId()
	
mc.ActivateWindow(14000)

