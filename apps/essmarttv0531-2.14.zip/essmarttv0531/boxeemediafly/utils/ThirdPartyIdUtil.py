from mediafly import HttpPost
from boxeemediafly.utils import StringUtils
import mc

def getThirdPartyId():
	"""
	Gets the thrid party id
	"""
	
	# check if there is a value in the config
	config = mc.GetApp().GetLocalConfig()
	if config.GetValue("thirdpartyid"): return config.GetValue("thirdpartyid")

	#TODO figure look into using some sort of unique id from boxee
	# currently we can't just use GetUniqueId as it is per box and multiple
	# boxee users could be on one box.
	#if hasattr(mc, "GetUniqueId"): rturn mc.GetUniqueId() + "::" + mc.GetInfoString("System.ProfileName").replace(" ", "")

	# fallback use mf to generate and store id
	thirdPartyId = StringUtils.CleanString(HttpPost.createDeviceId())
	config.SetValue("thirdpartyid", thirdPartyId)
	return thirdPartyId