ON_DEMAND = "OnDemand"
BROADCAST = "Broadcast"