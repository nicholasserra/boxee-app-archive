__author__ = "Mike McMullin"
__version__ = "2.0"
version = __version__