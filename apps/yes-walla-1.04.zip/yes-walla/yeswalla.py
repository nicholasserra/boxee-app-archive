import urllib
import re
import mc


class WebSiteScrapper(object):    
    HOME_URL = 'http://yes.walla.co.il/?w=1/7000'
    BASE_URL = 'http://yes.walla.co.il'
    AJAX_ITEMS = 'http://yes.walla.co.il/%s/%s/10/@ajaxItems'

    def __init__(self):
        pass
        
    def getSeriesList(self, categoryId):
        # read source
        data = mc.Http().Get(self.HOME_URL)

        # make it single line
        data = data.replace("\n","").replace("\r","")

        # get the results
        itemsBody = re.findall('<table.*?class="buxaBg_2".*?>(.*?)</table><img', data)
        items = []
        
        for item in itemsBody:
            x = re.findall('<tr.*?<td.*?<table.*?class="wtable wbgpos" background="(.*?)"><tr><Td.*?<a href="(.*?)".*?<img.*?></a></td></tr>.*?<a href=.*?>(.*?)</a><br>(.*?)</div></td></tr>', item)
            newitem = {"title":x[0][2].decode("windows-1255").encode("utf-8"),"url":x[0][1],"thumb":x[0][0],"descr":x[0][3].decode("windows-1255").encode("utf-8"),"type":"folder"}
            items.append(newitem)
            
        return items
        
    def getItems(self, url):                
        # read source
        data = mc.Http().Get(url)

        # find "all-chapters" link
        allChapters = re.findall('<a href="(.*?)">��� ������</a>',  data)
        
        items = []
        pagenum = 0
        if len(allChapters)>0:
            while True :
                # read all-chapters page
                data = mc.Http().Get(self.AJAX_ITEMS % (allChapters[0], pagenum))
                           
                # make it single line
                data = data.replace("\n","").replace("\r","")
                     
                # get the results
                itemsBody = re.findall('<div class="buxaBg_2.*?>.*?background="(.*?)".*?href="(.*?)".*?class="w2b">(.*?)</a><br>(.*?)</div>',data)
                for item in itemsBody:
                    newitem = {"title": item[2].decode("windows-1255").encode("utf-8"),"url":"%s%s" % (self.BASE_URL, item[1]),"thumb":item[0],"descr":item[3].decode("windows-1255").encode("utf-8"),"type":"video"}
                    items.append(newitem)
                
                if (len(itemsBody)==0):
                    break
                
                pagenum = pagenum + 1
            
        return items


