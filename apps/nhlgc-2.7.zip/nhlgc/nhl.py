import mc
import time
import xbmc
import tracker
import urllib
import urllib2
import calendar
import cookielib
import unicodedata
import simplejson as json
from xml.dom.minidom import parse, parseString
from urllib import quote, quote_plus, urlencode
from datetime import date,datetime,timedelta

myTracker = tracker.Tracker(False, True)

teams = {
   "ana":	{"full": "Anaheim Ducks", "code": "ducks", "short": "Ducks"},
   "atl":	{"full": "Atlanta Thrashers", "code": "thrashers", "short": "Thrashers"},
   "bos":	{"full": "Boston Bruins", "code": "bruins", "short": "Bruins"},
   "buf":	{"full": "Buffalo Sabres", "code": "sabres", "short": "Sabres"},
   "cgy":	{"full": "Calgary Flames", "code": "flames", "short": "Flames"},
   "car":	{"full": "Carolina Hurricanes", "code": "hurricanes", "short": "Hurricanes"},
   "chi":	{"full": "Chicago Blackhawks", "code": "blackhawks", "short": "Blackhawks"},
   "col":	{"full": "Colorado Avalanche", "code": "avalanche", "short": "Avalanche"},
   "clb":	{"full": "Columbus Blue Jackets", "code": "bluejackets", "short": "Blue Jackets"},
   "cbj":	{"full": "Columbus Blue Jackets", "code": "bluejackets", "short": "Blue Jackets"},
   "dal":	{"full": "Dallas Stars", "code": "stars", "short": "Stars"},
   "det":	{"full": "Detroit Red Wings", "code": "redwings", "short": "Red Wings"},
   "edm":	{"full": "Edmonton Oilers", "code": "oilers", "short": "Oilers"},
   "fla":	{"full": "Florida Panthers", "code": "panthers", "short": "Panthers"},
   "los":	{"full": "Los Angeles Kings", "code": "kings", "short": "Kings"},
   "lak":	{"full": "Los Angeles Kings", "code": "kings", "short": "Kings"},
   "min":	{"full": "Minnesota Wild", "code": "wild", "short": "Wild"},
   "mtl":	{"full": "Montreal Canadiens", "code": "canadiens", "short": "Canadiens"},
   "nsh":	{"full": "Nashville Predators", "code": "predators", "short": "Predators"},
   "njd":	{"full": "New Jersey Devils", "code": "devils", "short": "Devils"},
   "nyi":	{"full": "New York Islanders", "code": "islanders", "short": "Islanders"},
   "nyr":	{"full": "New York Rangers", "code": "rangers", "short": "Rangers"},
   "ott":	{"full": "Ottawa Senators", "code": "senators", "short": "Senators"},
   "phi":	{"full": "Philadelphia Flyers", "code": "flyers", "short": "Flyers"},
   "phx":	{"full": "Phoenix Coyotes", "code": "coyotes", "short": "Coyotes"},
   "pit":	{"full": "Pittsburgh Penguins", "code": "penguins", "short": "Penguins"},
   "sjs":	{"full": "San Jose Sharks", "code": "sharks", "short": "Sharks"},
   "stl":	{"full": "St. Louis Blues", "code": "blues", "short": "Blues"},
   "tbl":	{"full": "Tampa Bay Lightning", "code": "lightning", "short": "Lightning"},
   "tor":	{"full": "Toronto Maple Leafs", "code": "mapleleafs", "short": "Maple Leafs"},
   "van":	{"full": "Vancouver Canucks", "code": "canucks", "short": "Canucks"},
   "wsh":	{"full": "Washington Capitals", "code": "capitals", "short": "Capitals"},
   "wpg":	{"full": "Winnipeg Jets", "code": "jets", "short": "Jets"}
   }

def log(msg, alert=False, func=''):
   if func: func = '('+str(func).lower()+') '
   print '@nhlgcl %s%s' % (func, str(msg).lower())
   if alert:
      mc.ShowDialogOk("NHL GameCenter", 'The following error has occurred: ' + str(msg).capitalize())
      mc.HideDialogWait()
      return False

def play(item):
    user.commitLogin()
    gameFilter = mc.GetApp().GetLocalConfig().GetValue('GameFilterByType')

    if gameFilter == 'live' and user.vaultOnly:
        mc.ShowDialogOk('NHL GameCenter Live', 'Your Boxee box is currently linked to an NHL account with an NHL GameCenter VAULT subscription however an NHL GameCenter LIVE subscription is required to watch live games.')
        return False

    if user.isLoggedIn:
        if gameFilter == 'live':
         #current_time = datetime(*(time.strptime('20111013 20:00', '%Y%m%d %H:%M')[0:6]))
         sync_time = item.GetProperty('syncTime')
         current_time = datetime(*(time.strptime(sync_time, '%m/%d/%Y %H:%M:%S')[0:6]))

         #test
         #comment 2lines
         start_time = item.GetProperty('startTime')
         broadcast_time = datetime(*(time.strptime(start_time, '%m/%d/%Y %H:%M:%S')[0:6]))
         #modify 2 lines
         #start_time = '10/14/2011 11:52:00'
         #broadcast_time = datetime(*(time.strptime(start_time, '%m/%d/%Y %H:%M:%S')[0:6]))

         if current_time < broadcast_time:
            mc.ShowDialogOk('NHL GameCenter Live', 'This game has not started.  Please check back at the specified game start time.')
            return False

        id = item.GetProperty('id')
        gameId = item.GetProperty('gid')
        gameType = item.GetProperty('type')
        gameState = item.GetProperty('gameState')
        season = item.GetProperty('season')

        try:
            link_id = "%04d%02d%04d" % (int(season), int(gameType), int(gameId))
        except:
            link_id = gameId

        if gameFilter == 'live' and 'FINAL' in gameState:
            mc.ShowDialogOk('NHL GameCenter Live', 'This game has ended.  An archived version of the game will be available tomorrow.')
            return False

        blackout = '0'
        if gameFilter == 'live':
            response = urllib.urlopen('http://gamecenter.nhl.com/nhlgeo/blackout?season=%s&gameType=%s&gameId=%s' % (season, gameType, gameId))
            blackout = response.read()

        #test
        # comment 3 lines
        if blackout == '1':
           mc.ShowDialogOk('NHL GameCenter LIVE', 'Due to in-market restrictions, this game is blacked out in your region. Please check local market listings for game availability.')
           return False

        ourl_link = 'http://www.nhl.com/ice/recap.htm?id=%s' % link_id
        twitter = 'NHL %s vs. %s'
        label = twitter % (item.GetProperty('awayName'), item.GetProperty('homeName'))

        item.SetProviderSource("NHL GameCenter Live")
        item.SetThumbnail('http://dir.boxee.tv/apps/nhl/nhl_shield.png')
        item.SetLabel(label)
        item.SetAddToHistory(True)
        item.SetReportToServer(True)

        stream_type = item.GetProperty('video-type')

        #test
        #comment 1 line
        stream_url = item.GetProperty('video-stream')
        #modify 1 line
        #stream_url = 'http://feeds.cdnak.neulion.com/fs/mls/mobile/iphone/video/t1/ced.m3u8'
        auth = generateToken(stream_url, stream_type)

        away_stream = item.GetProperty('away-video-stream')
        home_stream = item.GetProperty('home-video-stream')

        if stream_type == 'hls':

            if away_stream and home_stream:
               response = mc.ShowDialogConfirm('NHL GameCenter Live', 'Please select your preferred broadcast.', 'Away', 'Home')
               if response:
                  stream_url = home_stream
               else:
                  stream_url = away_stream

            params = { '__auth__':auth }
            if stream_url.find('?') != -1:
                stream_url = '%s&%s' % (quote_plus(stream_url), urlencode(params))
            else:
                stream_url = '%s?%s' % (quote_plus(stream_url), urlencode(params))

            item.SetContentType = 'application/vnd.apple.mpegurl'

            if gameFilter == 'live':
               hls_start_url = 'http://ced.neulion.com/hlsutil/hlsstart?url=%s' %  stream_url
               response = urllib.urlopen(hls_start_url)
               hls_start = response.read()
               hls_start_date = datetime.strftime(current_time, "%Y%m%d")
               hls_start_time = datetime(*(time.strptime('%s %s:%s:%s' % (hls_start_date,hls_start[:2], hls_start[2:4], hls_start[4:6]), '%Y%m%d %H:%M:%S')[0:6]))

               tdelta =  broadcast_time - hls_start_time
               offset = str(tdelta)
               response = mc.ShowDialogConfirm('NHL GameCenter Live', 'This game is already in progress. Select to join live or start from the beginning.', 'Beginning', 'Live')
               if response:
                  params = { 'live':'1','quality':'A' }
                  playlist_url = 'playlist://%s&%s' % (stream_url, urlencode(params))
               else:
                  params = { 'startDate': offset,'quality':'A' }
                  playlist_url = 'playlist://%s&%s' % (stream_url, urlencode(params))
            else:
               params = { 'quality':'A' }
               playlist_url = 'playlist://%s&%s' % (stream_url, urlencode(params))

        else:
            params = { '__auth__':auth }
            playlist_url = '%s?%s' % (stream_url, urlencode(params))

        #item.SetPath(playlist_url + '&ourl=' + quote(ourl_link))
        item.SetPath(playlist_url)

        myTracker.trackEvent("Video", "Play", "%s|%s|%s" % ('dsm380', gameFilter, link_id))
        mc.GetPlayer().Play(item)
        return True
    else:
        mc.ShowDialogOk('NHL GameCenter Live', 'There was a problem authenticating with your account. Please contact customer support.')
        user.commitLogout()
        return False

def generateToken(stream, pType):
    index = stream.find('/',7)
    part = stream[index:]
    if pType == 'hls':
        response = urllib.urlopen('http://gamecenter.nhl.com/nhlgeo/dgeth?cdn_type=3&url=%s' % part)
    else:
        response = urllib.urlopen('http://gamecenter.nhl.com/nhlgeo/geth?cdn_type=3&url=%s' % part)
    token = response.read()
    return token

def launch(args):
   user.commitLogin()
   if not args:
      mc.ActivateWindow(14000)
   elif not user.isLoggedIn:
      mc.ShowDialogOk('NHL GameCenter Live', 'Your Boxee box must be linked to an NHL account before you can watch this game.')
      mc.ActivateWindow(14000)
   else:
      gameFilter = mc.GetApp().GetLocalConfig().GetValue('GameFilterByType')

      if gameFilter == 'live' and user.vaultOnly:
         mc.ShowDialogOk('NHL GameCenter Live', 'Your Boxee box is currently linked to an NHL account which has an NHL GameCenter VAULT subscription however an NHL GameCenter LIVE subscription is required to watch live games.')
         return False

      if user.isLoggedIn:
         ourl_link = 'http://www.nhl.com/ice/recap.htm?id=%s' % args['game-id'][0]
         app_link = 'app://nhl/start?%s'
         direct_link = 'http://www.nhl.com/ice/gamecenterlive.htm?id=%s' % args['game-id'][0]
         flash_link = 'flash://nhl.com/src=%s&bx-cookie=%s&bx-ourl=%s'
         item_path = flash_link % (quote_plus(direct_link), quote_plus(user.cookies), quote_plus(args['bx-ourl'][0]))

         title = args['title'][0]
         twitter = '@nhl #%s v #%s'
         alt_label = twitter % (args['awayName'][0], args['homeName'][0])
         alt_label = alt_label.lower()

         alt_label = title

         params = {
            'game-id': str(id),
            'bx-ourl': ourl_link,
            'awayName': args['awayName'][0],
            'homeName': args['homeName'][0]
            }

         app_link = app_link % (urlencode(params))

         item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
         ext = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
         ext.SetLabel(alt_label)
         ext.SetTitle(title)
         #ext.SetDescription(item.GetDescription(), False)
         ext.SetContentType('application/x-shockwave-flash')
         ext.SetThumbnail('http://lavonardo.net/wp/wordpress/wp-content/uploads/2008/02/nhl_shield.png')
         ext.SetProviderSource("NHL GameCenter")
         ext.SetPath(app_link)
         item.SetProviderSource("NHL GameCenter")
         item.SetThumbnail('http://lavonardo.net/wp/wordpress/wp-content/uploads/2008/02/nhl_shield.png')
         item.SetLabel(alt_label)
         item.SetTitle(title)
         item.SetAddToHistory(True)
         item.SetReportToServer(True)
         item.SetExternalItem(ext)

         item.SetPath(item_path)
         item.Dump()
         mc.GetPlayer().Play(item)
         return True
      else:
         mc.ShowDialogOk('NHL GameCenter Live', 'There was a problem authenticating your NHL account. Please contact customer support.')
         user.commitLogout()
         return False


def updateGameView():

   type = config.GetValue('GameFilterByType')

   if not user.isLoggedIn and type != 'highlight':
      return False

   mc.ShowDialogWait()

   baseUrl = 'rss://cedrss.neulion.com/nhlgc/archives/?'
   #baseUrl = 'rss://dir.boxee.tv/apps/nhl/nhl.php?'
   window = mc.GetWindow(14001)
   window.GetControl(1234).SetVisible(False)
   window.GetList(2000).SetItems(mc.ListItems())

   params = {}

   team = config.GetValue('GameFilterByTeam')
   season = config.GetValue('GameFilterBySeason')
   date = config.GetValue('GameFilterByDate')

   if team:
      window.GetButton(1001).SetLabel(teams[team]['short'])

   if type != 'highlight':
      params['user'] = user.username
      params['pass'] = user.password

   if type not in ['live', 'classic', 'highlight']:
      if team: params['team'] = team
      if season: params['season'] = season
      if date: params['date'] = date

   params[type] = 'true'

   if type == 'live':
      params['t'] = int(time.time())

   url = baseUrl + urlencode(params)
   items = mc.GetDirectory(url)
   window.GetList(2000).SetItems(items)

   if items: window.GetControl(1234).SetVisible(False)
   else: window.GetControl(1234).SetVisible(True)

   mc.HideDialogWait()

def updateStandingsView():
   mc.ShowDialogWait()
   window = mc.GetWindow(14003)
   view = config.GetValue('StandingsFilter')
   url = 'rss://dir.boxee.tv/apps/nhl/nhl.php?standings=' + view
   items = mc.GetDirectory(url)
   window.GetList(1003).SetItems(items)
   mc.HideDialogWait()

def loadNewsItems():
   try:
      if (len(mc.GetWindow(14000).GetList(301).GetItems()) == 0):
         mc.ShowDialogWait()
         items = mc.GetDirectory('rss://cedrss.neulion.com/nhlgc/news/')
         mc.HideDialogWait()
         if len(items) > 0:
            mc.GetWindow(14000).GetList(301).SetItems(items)
   except:
      mc.HideDialogWait()

def loadNewsDialg():
   list = mc.GetActiveWindow().GetList(301)
   item = list.GetItem(list.GetFocusedItem())
   items = mc.ListItems()
   items.append(item)
   mc.GetWindow(14005).GetList(3999).SetItems(items)
   return item.GetLabel()

def onLogout():

   if not user.isLoggedIn:
      return False

   mc.ShowDialogWait()
   baseUrl = 'http://dir.boxee.tv/apps/nhl/nhl.php?logout&'
   window = mc.GetWindow(14001)
   params = {}
   params['user'] = user.username
   params['pass'] = user.password
   url = baseUrl + urlencode(params)
   items = mc.Http().Get(url)
   mc.HideDialogWait()


def setGamesSubCategory(buttonId):
   if not user.isLoggedIn and buttonId != 223:
      mc.ShowDialogOk("NHL GameCenter Live", "Your device is not linked with your NHL GameCenter Live account. Link your device using the setting button on the top right of your screen.")
   else:

      config = mc.GetApp().GetLocalConfig()
      if buttonId != 223 and (not browser.archived or not browser.condensed):
         browser.loadAvailableGameDates(user.device_token, 'boxee')

      for id in range(221,226):
         if id != buttonId:
            config.Reset(str(id))
         else:
            config.SetValue(str(id), 'true')
      if buttonId == 221:
         config.SetValue('GameFilterByType', 'live')
      if buttonId == 222:
         config.SetValue('GameFilterByType', 'condensed')
         if browser.type != 'condensed':
            browser.type = 'condensed'
            browser.loadCalendar()
            browser.updateBrowserView()
      if buttonId == 223:
         config.SetValue('GameFilterByType', 'highlight')
      if buttonId == 224:
         config.SetValue('GameFilterByType', 'classic')
      if buttonId == 225:
         config.SetValue('GameFilterByType', 'archive')
         if browser.type != 'archived':
            browser.type = 'archived'
            browser.loadCalendar()
            browser.updateBrowserView()
         else:
            browser.buildGuiCalendar()

   updateGameView()


class Login:
   """
   old school login method, as opposed to using the mc http
   class, which will not always grab all available cookies from a login request
   """

   __post_url = ''
   __post_data = {}
   __cookies = {}
   __cookies_merged = ''
   __user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.7) Gecko/2007091417 Firefox/2.0.0.7'
   __headers = { 'Content-Type': 'application/x-www-form-urlencoded' }
   __result_text = ''


   def __init__(self, url, data):
      self.__post_url = url
      self.__post_data = data


   def override_user_agent(self, userAgent):
      self.__user_agent = userAgent


   def set_additional_headers(self, data):
      self.__headers = dict(self.__headers.items() + data.items())


   def commit(self):
      self.__headers['User-Agent'] = self.__user_agent
      cj = cookielib.CookieJar()
      cookiesProcessor = urllib2.HTTPCookieProcessor(cj)
      opener = urllib2.build_opener(cookiesProcessor)
      urllib2.install_opener(opener)
      params = urllib.urlencode(self.__post_data)
      req = urllib2.Request(self.__post_url, params, self.__headers)
      response = urllib2.urlopen(req)
      self.__result_text = response.read()
      cookie = ""
      for index, val in enumerate(cj):
         cookie += val.name + "=" + val.value + "; "
         self.__cookies[val.name] = val.value
      self.__cookies_merged = cookie


   def get_cookies(self):
      return self.__cookies


   def get_merged_cookies(self):
      return self.__cookies_merged


   def get_result(self):
      return self.__result_text


class nhlDialog:

   title = ''
   message = ''
   config = mc.GetApp().GetLocalConfig()

   def __init__(self):
      self.setDefaultMessage()
      self.config.Reset('dialog_title')
      self.config.Reset('dialog_message')

   def show(self, title='', msg=''):
      if title: self.title = title
      if msg: self.message = msg
      self.config.SetValue('dialog_title', self.title)
      self.config.SetValue('dialog_message', self.message)
      mc.ActivateWindow(14053)

   def close(self):
      xbmc.executebuiltin('Dialog.Close(14053)')
      self.config.Reset('dialog_title')
      self.config.Reset('dialog_message')

   def setDefaultMessage(self):
      self.title = 'SUBSCRIPTION REQUIRED'
      self.message = "To view this content, you'll need an active subscription to [COLOR ff13c3d7]NHL GameCenter LIVE[/COLOR]. (visit nhl.com/boxee)[CR][CR]Please link your Boxee box to your NHL account in the settings panel located at the top right corner of the screen."

class userAccount:
    username = ''
    password = ''
    device_token = ''
    firstName = ''
    cookies = ''
    regCode = ''
    account_details = {}
    isLinking = False
    refresh = False
    isLoggedIn = False
    vaultOnly = False
    hasSubscription = False
    url_login = 'https://gamecenter.nhl.com/nhlgc/secure/login'
    config = mc.GetApp().GetLocalConfig()
    config.Reset('device_linking')

    def __init__(self):
       #on load we'll check for saved account details
       cf = mc.GetApp().GetLocalConfig()
       #cf.Reset('device_token')
       self.username = cf.GetValue('auth_user')
       self.password = cf.GetValue('auth_pwd')
       self.device_token = cf.GetValue('device_token')
       self.commitLogin()

    def commitLogout(self):
       onLogout()
       self.clearStoredCreds()
       self.isLoggedIn = False
       self.username = ''
       self.password = ''
       self.device_token = ''
       self.firstName = ''
       self.cookies = ''
       self.refresh = False
       self.vaultOnly = False
       self.hasSubscription = False
       self.config.Reset('221')
       self.config.Reset('222')
       self.config.Reset('224')
       self.config.Reset('225')
       self.config.SetValue('223', 'true')
       self.config.SetValue('GameFilterByTeam', '')
       self.config.SetValue('GameFilterByType', 'highlight')
       xbmc.executebuiltin('Dialog.Close(14004)')
       mc.ActivateWindow(14000)

    def clearStoredCreds(self):
       cf = mc.GetApp().GetLocalConfig()
       cf.Reset('auth_user')
       cf.Reset('auth_pwd')
       cf.Reset('auth_name')
       cf.Reset('auth_nhl')

    def login(self, token, uao='boxee'):
        log('initiating login...', False, 'login')
        data = {
            'token': urllib.quote(token),
            'uao': urllib.quote(uao)
            }

        auth = Login(self.url_login, data)
        auth.commit()

        result = parseString(auth.get_result())
        code = result.getElementsByTagName('code')[0].firstChild.data

        if code == 'loginfailed':
            self.isLoggedIn = False
            return 0

        if code == 'loginsuccess':
            data = result.getElementsByTagName('data')[0]
            for child in data.childNodes:
                if child.nodeType == child.ELEMENT_NODE:
                    if child.childNodes:
                        self.account_details[ str(child.localName) ] = str(child.firstChild.data)

            self.isLoggedIn = True
            self.cookies = auth.get_merged_cookies()
            return 1

        self.isLoggedIn = False
        self.account_details = {}
        return -1

    def request(self, path, auth=False, data={}):
        try:
            data = False

            try:
                request = urllib2.Request(path)
                if auth and user.isLoggedIn:
                    for cook in self.cookies.split('; '):
                        cook = cook.split('=', 1)
                        if len(cook) == 2:
                            request.add_header(cook[0], cook[1])
                r = urllib2.urlopen(request)
                data = r.read()
            except Exception, e:
                log(e)

            if data:
                return data

            return False

        except Exception, e:
            log(e)
            return False

    def commitLogin(self):
       cf = mc.GetApp().GetLocalConfig()
       if not self.device_token:
          log('NO DEVICE TOKEN!')
          self.isLoggedIn = False
       else:
          mc.ShowDialogWait()
          result = self.login(self.device_token, 'boxee')

          if result > -1:
             if result > 0:
                self.clearStoredCreds()
                if not 'hasSubscription' in self.account_details:
                   self.isLoggedIn = False
                   self.refresh = True
                else:
                   self.isLoggedIn = True
                   if 'vaultSubscription' in self.account_details:
                      self.vaultOnly = self.account_details['vaultSubscription']
                   if 'hasSubscription' in self.account_details:
                      self.hasSubscription = self.account_details['hasSubscription']
                   if 'givenName' in self.account_details:
                      self.firstName = self.account_details['givenName']
                   cf.SetValue('auth_name', self.firstName)
             else:
                self.isLoggedIn = False
                self.clearStoredCreds()
          mc.HideDialogWait()

    def unlinkDevice(self):
       cf = mc.GetApp().GetLocalConfig()
       device_token = cf.GetValue('device_token')

       reg_url = 'http://gamecenter.nhl.com/nhlgc/servlets/unlinkdevice?token=%s' % device_token
       content = mc.Http().Get(reg_url).strip()
       dom = parseString(content)
       statusU = dom.getElementsByTagName('code')[0].childNodes[0].data
       status = unicodedata.normalize('NFKD', statusU).encode('ascii','ignore')
       mc.ShowDialogOk("Test",status)
       if (status != 'updatesuccess'):
          mc.ShowDialogOk("NHL GameCenter Live", "An error has been encountered while unlinking the device. ")
       else:
          mc.ShowDialogOk("NHL GameCenter Live", "You have successfully unlinked your Boxee box from your NHL account.")
          cf.Reset('device_token')

    def linkDevice(self):
       cf = mc.GetApp().GetLocalConfig()

       try:
         device_id = mc.GetDeviceId()
       except:
         cf.Reset('device_linking')
         mc.ShowDialogOk("NHL GameCenter Live", "An error has been encountered while linking the device. Unable to get unique device ID!")
         return

       reg_url = 'http://gamecenter.nhl.com/nhlgc/secure/devicereg?deviceid=%s&devicetype=129' % device_id
       content = mc.Http().Get(reg_url).strip()
       dom = parseString(content)
       status = dom.getElementsByTagName('code')[0].childNodes[0].data
       reg_codeU = dom.getElementsByTagName('regCode')[0].childNodes[0].data
       self.regCode = unicodedata.normalize('NFKD', reg_codeU).encode('ascii','ignore')
       mc.GetWindow(14004).GetLabel(127).SetLabel(self.regCode)
       cf.Reset('device_linking')
       cf.SetValue('device_linking', 'true')

       reg_status_url = 'http://gamecenter.nhl.com/nhlgc/secure/devicereg?code=%s' % self.regCode
       token = ''
       account = ''
       while (cf.GetValue('device_linking')):
          content = mc.Http().Get(reg_status_url).strip()
          dom = parseString(content)
          statusU = dom.getElementsByTagName('code')[0].childNodes[0].data
          status = unicodedata.normalize('NFKD', statusU).encode('ascii','ignore')
          if (status == 'notfound'):
             mc.ShowDialogOk("NHL GameCenter Live", "An error has been encountered while linking the device. The registration code is invalid.")
             break
          elif (status == 'expired'):
             mc.ShowDialogOk("NHL GameCenter Live", "An error has been encountered while linking the device. The registration code has expired. Please try linking again.")
             break
          elif (status == 'registered'):
            token_node = dom.getElementsByTagName('token')[0]
            if token_node.hasChildNodes():
               tokenU = dom.getElementsByTagName('token')[0].childNodes[0].data
               token = unicodedata.normalize('NFKD', tokenU).encode('ascii','ignore')
            if  (token):
               mc.ShowDialogOk("NHL GameCenter Live", "Thank you for linking your NHL account. Enjoy watching NHL hockey on your Boxee.")
               cf.Reset('device_linking')
               cf.Reset('device_token')
               cf.SetValue('device_token', token)
               self.device_token = token
               self.commitLogin()
               break
          time.sleep(10)


class gameBrowser:
   """
   Manages the NHL archive/condensed game dates by season. All data is stored
   within 'virtual calendars' with the ability to navigate through each day of
   each season available and update the accompanying UI elements.
   """

   cal = calendar
   archived = []
   condensed = []
   active_cal = {}
   type = 'archived'
   current = time.gmtime()
   config = mc.GetApp().GetLocalConfig()

   def __init__(self):
      self.type = 'archived'
      self.cal.setfirstweekday(self.cal.SUNDAY)


   def loadAvailableGameDates(self, token, uao):
      """
      Loads up the archived and condensed calendars with the available game
      info. This method requires the user to be authenticated so it cannot
      be called at launch if the user is not authed.
      """

      mc.ShowDialogWait()
      #self.archived = self.parseAvailableDates('http://dir.boxee.tv/apps/nhl/nhl.php?availgames=archived&user=%s&pass=%s' % (user, passwd))
      #self.condensed = self.parseAvailableDates('http://dir.boxee.tv/apps/nhl/nhl.php?availgames=condensed&user=%s&pass=%s' % (user, passwd))
      #self.archived = self.parseAvailableDates('http://gamecenter.nhl.com/nhlgc/servlets/allarchives?isFlex=true&date=true')
      #self.condensed = self.parseAvailableDates('http://gamecenter.nhl.com/nhlgc/servlets/allarchives?isFlex=true&date=true&condensed=true')
      self.archived = self.parseAvailableDates('http://cedrss.neulion.com/nhlgc/load/')
      #self.condensed = self.parseAvailableDates('http://cedrss.neulion.com/nhlgc/load?condensed=true')
      self.loadCalendar()
      mc.HideDialogWait()


   def buildGuiCalendar(self):
      """
      Using the active season/calendar month, builds a valid list of listitems.
      Full month name and item list will be pushed into the UI.
      """
      l = mc.ListItems()
      log('building calendar view')
      for w in self.active_cal['matrix']:
         for day in w:
            i = mc.ListItem()
            if day > 0: i.SetLabel(str(day))
            else: i.SetLabel('-')
            if day == self.active_cal['day']: i.SetProperty('active', 'true')
            if day not in self.active_cal['available']: i.SetProperty('nogames', 'true')
            l.append(i)

      log('setting calendar items to gui')
      mc.GetWindow(14001).GetButton(1003).SetLabel(self.active_cal['calendar_title'])
      mc.GetWindow(14001).GetList(1004).SetItems(l)


   def changeDay(self, day):
      """
      Sets the active calendar day
      """

      self.active_cal['day'] = int(day)
      self.config.SetValue('GameFilterByDate', self.getRequestDate())

      try:
         self.buildGuiCalendar()
      except:
         pass


   def monthPrevious(self):
      """
      Moves the the active calendar to the previous month. Returns false if the
      active calendar is already in the first month of the active season
      """

      active = self.active_cal
      if active['year'] == active['start'][0] and active['month'] == active['start'][1]: return False

      if active['month'] == 1:
         active['year'] -= 1
         active['month'] = 12
      else: active['month'] -= 1

      active['available'] = []
      for g in active['games']:
         if g[0] == active['year'] and g[1] == active['month']:
            active['available'].append(g[2])

      active['day'] = self.active_cal['available'][-1]
      active['calendar_title'] = self.cal.month_name[active['month']].upper()
      active['matrix'] = self.cal.monthcalendar(active['year'], active['month'])
      return True


   def monthNext(self):
      """
      Moves the the active calendar to the next month. Returns false if the
      active calendar is already in the last month of the active season
      """

      active = self.active_cal
      if active['year'] == active['end'][0] and active['month'] == active['end'][1]: return False

      if active['month'] == 12:
         active['year'] += 1
         active['month'] = 1
      else: active['month'] += 1

      active['available'] = []
      for g in active['games']:
         if g[0] == active['year'] and g[1] == active['month']:
            active['available'].append(g[2])

      active['day'] = self.active_cal['available'][-1]
      active['calendar_title'] = self.cal.month_name[active['month']].upper()
      active['matrix'] = self.cal.monthcalendar(active['year'], active['month'])
      return True

   def parseAvailableDates(self, url):
      """
      Retreives the available games xml from neulion. Each season will be
      pushed into its appropriate game type.
      """

      format = "%s-%s Season"
      content = user.request(url, True)

      #print content

      results = parseString(content.strip()).getElementsByTagName('result')[0]
      season = results.getElementsByTagName('season')
      seasons = []
      for sn in season:
         year = str(sn.getAttribute('id'))
         year2 = str(int(year)+1)[2:]
         if len(sn.getElementsByTagName('g')) == 0:
            continue
         start = sn.getElementsByTagName('g')[0].firstChild.data.split('-')[:2]
         end = sn.getElementsByTagName('g')[-1].firstChild.data.split('-')[:2]
         data = [year, {'display': format % (year, year2), 'season_year': str(year)}]
         games = []
         for game in sn.getElementsByTagName('g'):
            date = game.firstChild.data.split(' ')[0]
            games.append(time.strptime(date, "%Y-%m-%d"))
         data[1]['games'] = games
         seasons.append(data)
      return seasons


   def loadCalendar(self, year=False):
      """
      Loads the defualt calendar (most recent year) for the active type
      property. If year is set, the calendar matching that season year will be
      loaded.
      """

      year_available = False
      if self.type == 'condensed':
         calendar = self.condensed
         self.active_cal['type'] = 'condensed'
      else:
         calendar = self.archived
         self.active_cal['type'] = 'archived'

      if not year:
         calendar = calendar[-1][1]
         year_available = True
      else:
         for y in calendar:
            if int(y[0]) == year:
               calendar = y[1]
               year_available = True

      if not year_available:
         return False

      day = calendar['games'][-1]
      self.active_cal['year'] = day[0]
      self.active_cal['month'] = day[1]
      self.active_cal['day'] = day[2]
      self.active_cal['start'] = calendar['games'][0]
      self.active_cal['end'] = calendar['games'][-1]
      self.active_cal['calendar_title'] = self.cal.month_name[day[1]].upper()
      self.active_cal['matrix'] = self.cal.monthcalendar(day[0], day[1])
      self.active_cal['games'] = calendar['games']
      self.active_cal['season_year'] = calendar['season_year']
      self.active_cal['display'] = calendar['display']
      self.active_cal['available'] = []
      for g in self.active_cal['games']:
         if g[0] == day[0] and g[1] == day[1]:
            self.active_cal['available'].append(g[2])

      self.config.SetValue('games_season', self.active_cal['display'])
      self.config.SetValue('GameFilterByDate', self.getRequestDate())
      self.config.SetValue('GameFilterBySeason', self.active_cal['season_year'])

      try:
         self.buildGuiCalendar()
         mc.GetActiveWindow().GetButton(1002).SetLabel(self.active_cal['display'])
      except:
         pass

      return True


   def getRequestDate(self):
      """
      Returns a string of a valid date request parameter for querying nuelion
      servers for game content
      """

      c = self.active_cal
      return "%02i/%02i/%i" % (c['month'], c['day'], c['year'])


   def getAvailableSeasons(self, type=False):
      """
      Returns a list of all available season years and display titles for the
      currently active game type.
      """

      result = []
      lookup = type
      if not type: lookup = self.type
      if lookup == 'condensed': calendar = self.condensed
      else: calendar = self.archived
      for year in calendar:
         result.append( [year[0], year[1]['display']] )
      return result


   def printActiveCal(self):
      """
      Dump the currently active calendar to log in a readable format
      """

      c = self.active_cal
      print 'type: '+str(c['type'])
      print 'year: '+str(c['year'])
      print 'month: '+str(c['month'])+' ('+c['calendar_title']+')'
      print 'day: '+str(c['day'])
      print 'days available: ' + str(len(c['games']))
      print 'season: ' + str(c['season_year']) + ' ('+c['display']+')'
      print 'start: '+str(c['start'])
      print 'end: '+str(c['end'])
      print 'days available (month): ' + str(c['available'])
      print 'calendar: '+str(c['matrix'])


   def updateBrowserView(self):
      """
      Update the required UI elements for the user. All calendar changes should
      be made before hitting this function as to update the UI a little as
      possible.
      """
      window = mc.GetWindow(14001)
      config.SetValue('GameFilterBySeason', str(self.active_cal['season_year']))
      config.SetValue('games_season', self.active_cal['display'])
      config.SetValue('GameFilterByDate', self.getRequestDate())
      window.GetButton(1002).SetLabel(self.active_cal['display'])
      window.GetButton(1003).SetLabel(self.active_cal['calendar_title'])
      self.buildGuiCalendar()

   def setDefaultBrowserView(self):
      """"
      Sets the default (logged out) browser view to highlights only
      """

      self.config.Reset('221')
      self.config.Reset('222')
      self.config.Reset('224')
      self.config.Reset('225')
      self.config.SetValue('223', 'true')
      self.config.SetValue('GameFilterByTeam', '')
      self.config.SetValue('GameFilterByType', 'highlight')


mc.ShowDialogWait()

#init global data
user = userAccount()
browser = gameBrowser()
config = mc.GetApp().GetLocalConfig()
dialog = nhlDialog()
device_token = config.GetValue('device_token')
device_linking = config.GetValue('device_linking')
#mc.ShowDialogOk('DEBUG', device_token)

try:
   if user.isLoggedIn:
      browser.loadAvailableGameDates(user.device_token, 'boxee')
except: pass

mc.HideDialogWait()
