#copyright boxee see license/boxee.txt
import mc
import willowtv
import sys
import cgi

args = False

if sys.argv[1]:
   args = cgi.parse_qs(sys.argv[1])

willowtv.browser.setDefaultBrowserView()
willowtv.launch(args)
