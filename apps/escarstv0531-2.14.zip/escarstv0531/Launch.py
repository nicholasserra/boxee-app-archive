import mc
import MediaflyConfig
import boxeemediafly

import xbmc
import time

boxeemediafly.init()
boxeemediafly.getToken()

mcode = MediaflyConfig.MCODE
if MediaflyConfig.MCODE == "__dev__": mcode = mc.ShowDialogKeyboard("mcode", "mfly", False)

boxeemediafly.setContentSource(mcode, True)
boxeemediafly.showMainWindow()
boxeemediafly.showSplashWindow()
time.sleep(2)
boxeemediafly.authenticateContentSource()

if boxeemediafly.isAuthenticated():
	boxeemediafly.loadChannel()
	# close splash screen
	time.sleep(4)
	xbmc.executebuiltin("Dialog.Close(14001)")
else:
	xbmc.executebuiltin("Dialog.Close(14001)")
	boxeemediafly.close()
