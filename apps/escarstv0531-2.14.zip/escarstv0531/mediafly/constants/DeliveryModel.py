ON_DEMAND = "OnDemand"
BROADCAST = "BroadCast"