import mc
import xbmc
import RestService
from urllib import quote_plus, urlencode

class myTVListPlayer(mc.Player):
    def __init__(self):
        mc.Player.__init__(self, True)
        self.last = self.GetLastPlayerEvent()
        self.call = {
            self.EVENT_NEXT_ITEM    :   self.callbackNextItem,
            self.EVENT_STOPPED      :   self.callbackStopped,
            self.EVENT_ENDED        :   self.callbackEnded,
            self.EVENT_STARTED      :   self.callbackStarted,
            self.EVENT_NONE         :   self.callbackNone }

    def eventStart(self):
        import xbmc
        while True:
            event = self.GetLastPlayerEvent()
            if event != self.last:
                if event in self.call.keys():
                    self.last = event
                    self.call[event]()
                    if event in [self.EVENT_ENDED, self.EVENT_STOPPED]:
                        break
            xbmc.sleep(1000)

    def callbackNextItem(self):
        mc.LogInfo('next callback notification')

    def callbackStopped(self):
        mc.LogInfo('end callback notification')

    def callbackEnded(self):
        mc.LogInfo('end callback notification')

    def callbackStarted(self):
        mc.LogInfo('start callback notification')

    def callbackNone(self):
        mc.LogInfo('none callback notification')

def PlayStream(url, title):
    mc.LogInfo("playing the following url: " + str(url))
    item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_EPISODE)
    item.SetTitle(title)
    item.SetPath(str(url))
    item.SetContentType('application/vnd.apple.mpegurl')
    mc.GetPlayer().Play(item)    

def PlayHlsStream(url, title):
   #set playlist stream bandwith, 0, 1, A (low, high, adaptive)
   params = { 'quality': 'A' }
   #build stream url
   playlist_url = "playlist://%s?%s" % (quote_plus(url), urlencode(params))
   print('PlayHlsStream')
   print(playlist_url)
   #build Boxee listitem and set propertiesk
   item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_EPISODE)
   item.SetPath(playlist_url)
   item.SetLabel(title)
   item.SetContentType('application/vnd.apple.mpegurl')
   #initialize the Boxee player and pass our listitem
   mc.GetPlayer().Play(item)    
   
def PlayEpisode(id):
    mc.ShowDialogWait()
    url = RestService.GetVODURL(id)
    mc.HideDialogWait()
    mc.LogInfo('play episode url ' + str(url))
    PlayHlsStream(url, '')

def PlayChannel(id,title):
    print('Play Channel')
    mc.ShowDialogWait()
    url = RestService.GetChannelURL(id)
    print('Channel URL', url)
    mc.HideDialogWait()
    PlayHlsStream(url, title)

def PlayProgram(id):
	mc.ShowDialogWait()
	urls = RestService.GetProgramEpisodesURLs(id)
	mc.LogInfo('program episodes count ' + str(len(urls)))
	playlist = mc.PlayList(mc.PlayList.PLAYLIST_VIDEO)
	for vid in urls:
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_EPISODE)
		item.SetTitle('Program Video')
		item.SetPath(str(vid))
		item.SetContentType('application/vnd.apple.mpegurl')
		playlist.Add(item)
	mc.HideDialogWait()
	if len(urls) == 0:
		mc.ShowDialogNotification('The program does not contain any episodes')
	else:
		mc.LogInfo('player play selected')
		player = myTVListPlayer()
		player.Play(playlist.GetItem(0))
		player.eventStart()
	
    