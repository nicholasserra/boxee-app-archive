import mc

def updateLabel():
    label = mc.GetActiveWindow().GetLabel(110)
    label.SetLabel('Welcome to myTV')

def updateLabel2():
    label = mc.GetActiveWindow().GetLabel(110)
    label.SetLabel('Live Broadcast')

def updateLabel3():
    label = mc.GetActiveWindow().GetLabel(110)
    label.SetLabel('Video On Demand')

def updateLabel3():
    label = mc.GetActiveWindow().GetLabel(110)
    label.SetLabel('My Video On Demand')
