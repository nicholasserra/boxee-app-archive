import mc
import common
import getchannels
import getgenres
import getfeatured
import getnewreleases
import getcountries
import search
import myTVPlayer
import RestService

device_sn = mc.GetUniqueId()
mc.LogInfo('Device Unique Id ' + device_sn)
#device_sn = '13A17T00248s5s'
device_type_id = 5 #  but for testing we have as 1
rest_url = 'http://www.my-tv.us/mytv.restws.new/RestService.ashx?'

mc.ActivateWindow(14000)