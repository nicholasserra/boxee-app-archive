import mc
import urllib as libb
import xml.dom.minidom
import sys
import Start
import RestService

def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data.encode('utf-8').strip())
    return ''.join(rc)                                 
    
def BindGenresHomepage():
    GenreCollection = mc.ListItems() 
    
    if len(mc.GetActiveWindow().GetList(8000).GetItems())>1:
        mc.GetActiveWindow().GetControl(8000).SetFocus()
        mc.GetActiveWindow().GetControl(8000).SetVisible(True)
        return
    
    strId = ''
    strName = ''
    strSmallDescription = ''
    strBigDescription = ''
    strSmallLogoPath = ''
    strBigLogoPath = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getgenres2&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strBigLogoPath = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        
        if strPosterType == 'genre':
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strBigLogoPath))
            item.SetProperty('uid',str(strId))
            item.SetProperty('type',str(strPosterType))
            GenreCollection.append(item) 
    
    dom.unlink()

    mc.GetActiveWindow().GetList(8000).SetItems(GenreCollection)
    
    #for item in GenreCollection:
    #    i = 0
    #    programtypes = getgenres.GetHomePageProgramTypes(item.GetProperty('uid'))
    #    genres = mc.GetActiveWindow().GetList(8000).GetItems()
    #    for genre in genres:
    #        if genre.GetProperty('uid') == item.GetProperty('uid'):
    #            selectedgenreitem = mc.GetActiveWindow().GetList(8000).GetItem(i)
    #            
    #            i = i + 1
                
        
    #mc.GetActiveWindow().GetControl(8000).SetFocus()
    mc.GetActiveWindow().GetControl(8000).SetVisible(True)

def BindHomePageProgramTypes(genreid):
    ProgramTypeCollection = mc.ListItems()
    
    mc.ShowDialogWait()
    
    items = mc.ListItems()
    mc.GetActiveWindow().GetList(7000).SetItems(items)

    strGenreId = ''
    strGenreName = ''
    strCountryId = ''
    strCountryName = ''
    strId = ''
    strName = ''
    strSmallDescription = ''
    strBigDescription = ''
    strSmallLogoPath = ''
    strBigLogoPath = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getgenres2&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strBigLogoPath = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        
        if strPosterType == 'genre':
            strGenreId = str(strId)
            strGenreName = str(strName)
            
        if strPosterType == 'programtype' and strGenreId == str(genreid):
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strBigLogoPath))
            item.SetProperty('uid',str(strId))
            item.SetProperty('programtypename',str(strName))
            item.SetProperty('genreid',str(strGenreId))
            item.SetProperty('genrename',str(strGenreName))
            item.SetProperty('countryid',str(strCountryId))
            item.SetProperty('countryname',str(strCountryName))
            ProgramTypeCollection.append(item) 
    
    dom.unlink()
    
    #return ProgramTypeCollection
    
    mc.GetActiveWindow().GetList(7000).SetVisible(True)
    mc.GetActiveWindow().GetList(7000).SetItems(ProgramTypeCollection)
    #mc.GetActiveWindow().GetControl(7000).SetProperty('posx',"400")
    #mc.GetActiveWindow().GetControl(7000).SetProperty('posy',"400")
    mc.GetActiveWindow().GetControl(7000).SetFocus()
    
    mc.HideDialogWait()
      
def BindGenres():
    GenreCollection = mc.ListItems() 
    
    mc.GetActiveWindow().GetControl(14000).SetVisible(True)
    mc.GetActiveWindow().GetControl(14001).SetVisible(True)
    mc.GetActiveWindow().GetControl(14002).SetVisible(False)
    mc.GetActiveWindow().GetControl(14003).SetVisible(False)
    mc.GetActiveWindow().GetLabel(13999).SetLabel('Select a Genre to view the sub-categories.')
    
    if len(mc.GetActiveWindow().GetList(14001).GetItems())>1:
        mc.GetActiveWindow().GetControl(14001).SetFocus()
        mc.GetActiveWindow().GetControl(15000).SetVisible(True)
        return
    
    mc.ShowDialogWait()

    strId = ''
    strName = ''
    strSmallDescription = ''
    strBigDescription = ''
    strSmallLogoPath = ''
    strBigLogoPath = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getgenres2&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strBigLogoPath = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        
        if strPosterType == 'genre':
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strBigLogoPath))
            item.SetProperty('uid',str(strId))
            item.SetProperty('countryid','')
            item.SetProperty('countryname','')
            item.SetProperty('genreid',strId)
            item.SetProperty('genrename',strName)
            item.SetProperty('type', str(strPosterType))
            GenreCollection.append(item) 
    
    dom.unlink()

    
    mc.GetActiveWindow().GetList(14001).SetItems(GenreCollection)
    mc.GetActiveWindow().GetControl(14001).SetFocus()
    mc.GetActiveWindow().GetControl(15000).SetVisible(True)
    mc.HideDialogWait()

def BindProgramTypes(id):
    ProgramTypeCollection = mc.ListItems()
    
    mc.ShowDialogWait()
    
    items = mc.ListItems()
    mc.GetActiveWindow().GetList(14003).SetItems(items)

    strGenreId = ''
    strGenreName = ''
    strCountryId = ''
    strCountryName = ''
    strId = ''
    strName = ''
    strSmallDescription = ''
    strBigDescription = ''
    strSmallLogoPath = ''
    strBigLogoPath = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getgenres2&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strBigLogoPath = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        
        if strPosterType == 'genre':
            strGenreId = str(strId)
            strGenreName = str(strName)
            
        if strPosterType == 'programtype' and strGenreId == str(id):
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strBigLogoPath))
            item.SetProperty('uid',str(strId))
            item.SetProperty('programtypename',str(strName))
            item.SetProperty('genreid',str(strGenreId))
            item.SetProperty('genrename',str(strGenreName))
            item.SetProperty('countryid',str(strCountryId))
            item.SetProperty('countryname',str(strCountryName))
            ProgramTypeCollection.append(item) 
    
    dom.unlink()
    print('start binding program type')
    mc.GetActiveWindow().GetControl(14000).SetVisible(True)
    mc.GetActiveWindow().GetControl(14001).SetVisible(False)
    mc.GetActiveWindow().GetControl(14002).SetVisible(False)
    mc.GetActiveWindow().GetControl(14003).SetVisible(True)
    mc.GetActiveWindow().GetList(14003).SetItems(ProgramTypeCollection)
    mc.GetActiveWindow().GetControl(14003).SetFocus()
    mc.GetActiveWindow().GetControl(15000).SetVisible(True)
    print('end binding program type')
    mc.HideDialogWait()

def BindPrograms(genreid, programtypeid):
    ProgramCollection = mc.ListItems()
    
    mc.GetActiveWindow().GetControl(15000).SetVisible(False)
    mc.GetActiveWindow().GetControl(14000).SetVisible(False)
    mc.GetActiveWindow().GetControl(9999).SetVisible(False)
    mc.GetActiveWindow().GetControl(8888).SetVisible(True)
    mc.GetActiveWindow().GetControl(8881).SetVisible(True)
    mc.GetActiveWindow().GetControl(8882).SetVisible(True)
    
    items = mc.ListItems()
    mc.GetActiveWindow().GetList(8882).SetItems(items)

    strGenreId = ''
    strProgramTypeId = ''
    strId = ''
    strName = ''
    strDescription = ''
    strLogo = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getgenres2&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strLogo = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        strDescription = str(getText(poster.getElementsByTagName("shortdescriptionline2")[0].childNodes))
        
        if strPosterType == 'genre':
            strGenreId = str(strId)
        
        if strPosterType == 'programtype':
            strProgramTypeId = str(strId)
            
        if (strPosterType == 'program' or strPosterType == 'episode') and strGenreId == str(genreid) and strProgramTypeId == str(programtypeid):
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strLogo))
            item.SetProperty('uid',str(strId))
            item.SetProperty('genreid',str(strGenreId))
            item.SetProperty('programtypeid',str(strProgramTypeId))
            item.SetProperty('postertype',str(strPosterType))
            item.SetProperty('type',str(strPosterType))
            item.SetProperty('description',strDescription)
            ProgramCollection.append(item) 
    
    dom.unlink()
    
    mc.GetActiveWindow().GetList(8882).SetItems(ProgramCollection)
    mc.GetActiveWindow().GetControl(8882).SetFocus()

def GetProgram(programid):                                                                     
    url = str(Start.rest_url) + 'action=getprogram&id=' + str(programid) + '&deviceid=' + str(Start.device_sn) + '&devicetypeid=' + str(Start.device_type_id)
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
   
    
    posters = dom.getElementsByTagName("item")
    if len(posters) > 0:
        item = RestService.ProcessOneVideoTag(posters[0])
    else:
        item = None
    
    dom.unlink()
    
    return item