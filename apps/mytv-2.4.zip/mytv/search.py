import mc
import urllib as libb
import xml.parsers.expat
import sys     
                        
def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data.encode('utf-8').strip())
    return ''.join(rc)           
      
def Search(episodetitle):   
    mc.ActivateWindow(15000)
    
    mc.ShowDialogWait()
    
    SearchCollection = mc.ListItems()
    
    strId = ''
    strName = ''
                                            
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=search&episodetitle=' + str(episodetitle) + '&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
                                
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("episode")
    for poster in posters:
        strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("title")[0].childNodes))
        strDuration = str(getText(poster.getElementsByTagName("duration")[0].childNodes))
        strPrice = str(getText(poster.getElementsByTagName("price")[0].childNodes))
        strExpiresIn = str(getText(poster.getElementsByTagName("expiresin")[0].childNodes))

        item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        item.SetLabel(strName)
        item.SetProperty('uid',strId)
        item.SetProperty('duration',strDuration)
        item.SetProperty('price',strPrice)
        item.SetProperty('expiresin',strExpiresIn)
        SearchCollection.append(item)
            
    dom.unlink()
    
    mc.GetActiveWindow().GetControl(10001).SetVisible(True)
    mc.GetActiveWindow().GetList(10001).SetItems(SearchCollection)
    
    mc.HideDialogWait()