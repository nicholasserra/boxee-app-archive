from httplib import *
from urlparse import urlparse
import mc
LastStatusCode = None

def ExtractBaseURL(url):
    try: 
        parts = urlparse(url)
        return parts[1]
    except:
        mc.LogInfo('Error parse url')
        return None

def GetUrl(url):
    try:
        baseurl = ExtractBaseURL(url)
        if url.lower().startswith('https'):
            connection = HTTPSConnection(baseurl)
        else:
            connection = HTTPConnection(baseurl)
        try:
            connection.request('GET', url)
            response = connection.getresponse()
            LastStatusCode = response.status  
            mc.LogInfo('last status code ' + str(LastStatusCode)) 
            if response.status == 200:
                value = response.read()
                connection.close()
                return value
            else:
                return None
        except:
            connection.close()
            raise
    except error, (errno, strerror):
        mc.LogInfo('error in GetUrl ' + strerror)
        return None