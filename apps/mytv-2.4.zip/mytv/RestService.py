import Request
import xml.dom.minidom
import Start
import mc
import codecs
from string import strip
import urllib as libb

def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data.encode('utf-8').strip())
    return ''.join(rc) 

def safeGetText(nodecollection):
    if len(nodecollection) > 0:
        nodelist = nodecollection[0].childNodes
        rc = []
        for node in nodelist:
            if node.nodeType == node.TEXT_NODE:
                rc.append(node.data.encode('utf-8').strip())
        return ''.join(rc)
    else:
        return None 

def GetVODURL(id): 
    try:
        url = str(Start.rest_url) + 'action=watchvod&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id) + '&episodeid=' + str(id)
        mc.LogInfo('GetVODURL ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            value = str(getText(document.getElementsByTagName('URL')[0].childNodes))
            document.unlink()
            return value
    except:
        mc.LogInfo('error in GetVODURL ')
        return None

def GetChannelURL(id):
    try:
        url = str(Start.rest_url) + 'action=watchchannel&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id) + '&ChannelId=' + str(id)
        mc.LogInfo('GetChannelURL ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            value = str(getText(document.getElementsByTagName('URL')[0].childNodes))
            document.unlink()
            return value
    except:
        mc.LogInfo('error in GetChannelURL ')
        return None    

def GetProgramEpisodesURLs(id):
    try:
        url = str(Start.rest_url) + 'action=GetVODToWatchFromProgram&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id) + '&ProgramId=' + str(id)
        mc.LogInfo('GetProgramEpisodesURLs ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            values = []
            urltags = document.getElementsByTagName('URL')
            for urltag in urltags:
                values.append(getText(urltag.childNodes))
            document.unlink()
            return values
    except:
        mc.LogInfo('error in GetProgramEpisodesURLs ')
        return None     

def GetChannels(): #-> mc.ListItems
    try:
        url = str(Start.rest_url) + 'action=getchannels&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id)
        mc.LogInfo('GetChannels url ' + url)
        response = Request.GetUrl(url)
        items = mc.ListItems()
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            channelTags = document.getElementsByTagName('channel')
            if len(document.getElementsByTagName('channels')) == 0:
                document.unlink()
                return None
            else:
                for poster in channelTags:
                   item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                   strId = str(getText(poster.getElementsByTagName("Id")[0].childNodes))
                   strName = str(getText(poster.getElementsByTagName("Name")[0].childNodes))
                   strSmallDescription = str(getText(poster.getElementsByTagName("SmallDescription")[0].childNodes)) 
                   strBigDescription = str(getText(poster.getElementsByTagName("BigDescription")[0].childNodes)) 
                   strSmallLogoPath = str(getText(poster.getElementsByTagName("SmallLogoPath")[0].childNodes))
                   strBigLogoPath = str(getText(poster.getElementsByTagName("BigLogoPath")[0].childNodes))
                   strStartDate = str(getText(poster.getElementsByTagName("StartDate")[0].childNodes))
                   strEndDate = str(getText(poster.getElementsByTagName("EndDate")[0].childNodes))
                   item.SetLabel(strName)
                   item.SetDescription(strBigDescription)
                   item.SetThumbnail(strBigLogoPath)
                   item.SetProperty('uid',str(strId))
                   item.SetProperty('description',strSmallDescription)
                   item.SetProperty('channelpurchased','1')
                   item.SetProperty('startdate',strStartDate)
                   item.SetProperty('enddate',strEndDate)
                   items.append(item)
                document.unlink()
                return items
    except:
        mc.LogInfo('error in GetChannels ')
        return None

def GetMyTVChannels(packageid): #-> mc.ListItems
    try:
        url = str(Start.rest_url) + 'action=getmytvchannels&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&PackageId=' + str(packageid) 
        mc.LogInfo('GetMyTVChannels url ' + url)
        response = Request.GetUrl(url)
        items = mc.ListItems()
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            channelTags = document.getElementsByTagName('item')
            if len(document.getElementsByTagName('channel')) == 0:
                document.unlink()
                return None
            else:
                for poster in channelTags:
                   item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                   strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
                   strName = str(getText(poster.getElementsByTagName("title")[0].childNodes))
                   strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))                   
                   strBigLogoPath = str(poster.getElementsByTagName("thumbnail")[0].attributes['url'].value)
                   item.SetLabel(strName)
                   item.SetThumbnail(strBigLogoPath)
                   item.SetDescription(strDescription)
                   item.SetProperty('uid',str(strId))
                   items.append(item)
                document.unlink()
                return items
    except:
        mc.LogInfo('error in GetMyTVChannels ')
        return None

def GetVODPackageChannels(vodpackageid): #-> mc.ListItems
    try:
        items = mc.ListItems()
        
        url = str(Start.rest_url) + 'action=getvodpackagecontent&contenttypeid=3&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&VODPackageId=' + str(vodpackageid) 
        print(url)
        rss = libb.urlopen(url, data=None)
        document = xml.dom.minidom.parseString(rss.read())
        channelTags = document.getElementsByTagName('item')
        for poster in channelTags:
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
            strName = str(getText(poster.getElementsByTagName("title")[0].childNodes))
            strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))                   
            strBigLogoPath = str(poster.getElementsByTagName("thumbnail")[0].attributes['url'].value)
            strType = str(getText(poster.getElementsByTagName("type")[0].childNodes))
            item.SetLabel(strName)
            item.SetThumbnail(strBigLogoPath)
            item.SetDescription(strDescription)
            item.SetProperty('uid',str(strId))
            item.SetProperty('type', strType)
            items.append(item)
        document.unlink()
        
        return items
    except:
        mc.LogInfo('error in GetVODPackageChannels ')
        return None

def CanPlayChannel(channelid):
    try:
        url = str(Start.rest_url) + 'action=canplaychannel&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&channelid=' + str(channelid)
        mc.LogInfo('CanPlayChannel ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            return getText(document.getElementsByTagName('CanPlayChannel')[0].childNodes) == "1";
    except:
        mc.LogInfo('error in CanPlayChannel ')
        return None   

def GetVODPackageVideos(vodpackageid): #-> mc.ListItems
    try:
        items = mc.ListItems()
        
        url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getvodpackagecontent&contenttypeid=2&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&VODPackageId=' + str(vodpackageid) 
        print(url)
        rss = libb.urlopen(url, data=None)
        document = xml.dom.minidom.parseString(rss.read())
        channelTags = document.getElementsByTagName('item')
        for poster in channelTags:
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
            strName = str(getText(poster.getElementsByTagName("title")[0].childNodes))
            strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))                   
            strBigLogoPath = str(poster.getElementsByTagName("thumbnail")[0].attributes['url'].value)
            strType = str(getText(poster.getElementsByTagName("type")[0].childNodes))
            item.SetLabel(strName)
            item.SetThumbnail(strBigLogoPath)
            item.SetDescription(strDescription)
            item.SetProperty('uid',str(strId))
            item.SetProperty('type', strType)
            items.append(item)
        document.unlink()
            
        url = str(Start.rest_url) + 'action=getvodpackagecontent&contenttypeid=1&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&VODPackageId=' + str(vodpackageid) 
        print(url)
        rss = libb.urlopen(url, data=None)
        document = xml.dom.minidom.parseString(rss.read())
        channelTags = document.getElementsByTagName('item')
        for poster in channelTags:
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
            strName = str(getText(poster.getElementsByTagName("title")[0].childNodes))
            strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))                   
            strBigLogoPath = str(poster.getElementsByTagName("thumbnail")[0].attributes['url'].value)
            strType = str(getText(poster.getElementsByTagName("type")[0].childNodes))
            item.SetLabel(strName)
            item.SetThumbnail(strBigLogoPath)
            item.SetDescription(strDescription)
            item.SetProperty('uid',str(strId))
            item.SetProperty('type', strType)
            items.append(item)
        document.unlink()
            
        return items
    except:
        mc.LogInfo('error in GetVODPackageVideos ')
        raise
        return None

def GetCustomerPin():
    try: 
        url = str(Start.rest_url) + 'action=linking&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id)
        mc.LogInfo('GetCustomerPin ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            PinTag = document.getElementsByTagName('PinCode');
            if len(PinTag) == 0:
                document.unlink()
                return None
            else:
                value = getText(PinTag[0].childNodes)
                document.unlink()
                return value
    except:
        mc.LogInfo('error in GetCustomerPin ')
        return None

def GetCustomerInfo():
    try: 
        url = str(Start.rest_url) + 'action=linking&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id)
        mc.LogInfo('GetCustomerPin ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            BillingTag = document.getElementsByTagName('BillingId');
            if len(BillingTag) == 0:
                document.unlink()
                return None
            else:
                value = getText(BillingTag[0].childNodes)
                pin = getText(document.getElementsByTagName('PinCode')[0].childNodes)
                firstname = getText(document.getElementsByTagName('FirstName')[0].childNodes)
                lastname = getText(document.getElementsByTagName('LastName')[0].childNodes)
                document.unlink()
                return { "Billing": value, "Pin": pin, "FirstName": firstname, "LastName": lastname }
    except:
        mc.LogInfo('error in GetCustomerInfo ')
        return None

def GetLinkingCode():
    try:
        url = str(Start.rest_url) + 'action=preregistration&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id)
        mc.LogInfo('GetLinkingCode ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            regCode = document.getElementsByTagName('regCode');
            if len(regCode) == 0:
                document.unlink()
                return None
            else:
                value = getText(regCode[0].childNodes)
                document.unlink()
                return value
    except:
        mc.LogInfo('error in GetLinkingCode ')
        return None

def GetVODPackages(bouquetid,vodpackageid):
        items = mc.ListItems()
        url = str(Start.rest_url) + 'action=getvodpackage&DeviceId=' + str(Start.device_sn) + '&BouquetId=' + bouquetid +'&DeviceTypeId=' + str(Start.device_type_id)
        mc.LogInfo('GetVODPackages: ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            itemTags = document.getElementsByTagName('item')
            for poster in itemTags:
                item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
                strTitle = str(getText(poster.getElementsByTagName("title")[0].childNodes))
                strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))
                strType = str(getText(poster.getElementsByTagName("type")[0].childNodes))
                strPrice = str(getText(poster.getElementsByTagName("Price")[0].childNodes))
                strThumbnail = str(poster.getElementsByTagName("thumbnail")[0].attributes['url'].value)
                strStartDate = str(getText(poster.getElementsByTagName("StartDate")[0].childNodes))
                strEndDate = str(getText(poster.getElementsByTagName("EndDate")[0].childNodes))
                strVODPackageTypeId = str(getText(poster.getElementsByTagName("VODPackageTypeId")[0].childNodes))
                item.SetLabel(strTitle)
                item.SetThumbnail(strThumbnail)
                item.SetProperty('price', strPrice)
                item.SetProperty('uid', str(strId))
                item.SetProperty('type', str(strType))
                item.SetProperty('description', str(strDescription))
                item.SetProperty('startdate', str(strStartDate))
                item.SetProperty('enddate', str(strEndDate))
                item.SetProperty('vodpackagetypeid', str(strVODPackageTypeId))
                items.append(item)
            return items

def GetMyTVPackages():
    try:
        items = mc.ListItems()
        url = str(Start.rest_url) + 'action=getmytvpackages&DeviceId=' + str(Start.device_sn) + '&MemberId=&DeviceTypeId=' + str(Start.device_type_id)
        mc.LogInfo('GetMyTVPackages ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            itemTags = document.getElementsByTagName('item')
            for poster in itemTags:
                item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
                strTitle = str(getText(poster.getElementsByTagName("title")[0].childNodes))
                strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))
                strType = str(getText(poster.getElementsByTagName("type")[0].childNodes))
                strPrice = str(getText(poster.getElementsByTagName("Price")[0].childNodes))
                strThumbnail = str(poster.getElementsByTagName("thumbnail")[0].attributes['url'].value)
                item.SetLabel(strTitle)
                item.SetThumbnail(strThumbnail)
                item.SetProperty('price', strPrice)
                item.SetProperty('uid', str(strId))
                item.SetProperty('type', str(strType))
                item.SetProperty('description', str(strDescription))
                items.append(item)
            return items
                
    except:
        mc.LogInfo('error in GetMyTVPackages ')
        return None        

def ProcessVideoItemTags(itemTags):
    items = mc.ListItems()
    for poster in itemTags:
        item = ProcessOneVideoTag(poster)
        items.append(item)
    return items

def ProcessOneVideoTag(poster):
   
    item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
    strTitle = str(getText(poster.getElementsByTagName("title")[0].childNodes))
    strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))
    strType = str(getText(poster.getElementsByTagName("type")[0].childNodes))
    strPrice = str(getText(poster.getElementsByTagName("Price")[0].childNodes))
    strThumbnail = str(poster.getElementsByTagName("thumbnail")[0].attributes['url'].value)
    strDirector = str(getText(poster.getElementsByTagName("Director")[0].childNodes))
    strGuests = str(getText(poster.getElementsByTagName("Guests")[0].childNodes))
    strCategory = str(getText(poster.getElementsByTagName("category")[0].childNodes))
    strRating = str(getText(poster.getElementsByTagName("Rating")[0].childNodes))
    strLanguage = str(getText(poster.getElementsByTagName("language")[0].childNodes))
    strProgramPurchased = safeGetText(poster.getElementsByTagName("ProgramPurchased"))        
    
    print(strId, strTitle, strType)
    
    item.SetLabel(strTitle)
    item.SetThumbnail(strThumbnail)
    item.SetDescription(strDescription)
    item.SetProperty('price', strPrice)
    item.SetProperty('uid', str(strId))
    item.SetProperty('type', str(strType))
    item.SetProperty('description', str(strDescription))
    item.SetProperty('director', strDirector)
    item.SetProperty('guests', strGuests)
    item.SetProperty('category', strCategory)
    item.SetProperty('rating', strRating)
    item.SetProperty('language', strLanguage)
    if strProgramPurchased != None:
        item.SetProperty('programpurchased', str(strProgramPurchased))
    if strType == 'video':
        strCanBuyEpisode = str(getText(poster.getElementsByTagName("CanBuyEpisode")[0].childNodes))
        item.SetProperty('canbuyepisode', strCanBuyEpisode)
    return item
    

def GetVideoPosterPairs( video ):
    posterpairs = mc.ListItems()
    strDirector = video.GetProperty('director')
    strGuests = video.GetProperty('guests')
    strCategory = video.GetProperty('category')
    strRating = video.GetProperty('rating')
    strLanguage = video.GetProperty('language')
    print (strDirector, strGuests, strCategory, strRating, strLanguage)
    if ( strDirector != None and strDirector != '' ):
        pairDirector = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        pairDirector.SetLabel('Director')
        pairDirector.SetDescription(strDirector)
        posterpairs.append(pairDirector)
    if ( strGuests != None and strGuests != '' ):
        pairGuests = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        pairGuests.SetLabel('Guests')
        pairGuests.SetProperty('display',strGuests)
        posterpairs.append(pairGuests)
    if ( strCategory != None and strCategory != '' ):
        pairCategory = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        pairCategory.SetLabel('Category')
        pairCategory.SetProperty('display',strCategory)
        posterpairs.append(pairCategory)
    if ( strRating != None and strRating != '' ):
        pairRating = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        pairRating.SetLabel('Rating')
        pairRating.SetProperty('display',strRating)
        posterpairs.append(pairRating)
    if ( strLanguage != None and strLanguage != '' ):
        pairLanguage = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        pairLanguage.SetLabel('Language')
        pairLanguage.SetProperty('display',strLanguage)
        posterpairs.append(pairLanguage)
    mc.LogInfo('poster pairs length ' + str(len(posterpairs)))
    return posterpairs

def GetMyVOD():
    try:
        url = str(Start.rest_url) + 'action=myvod&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id)
        mc.LogInfo('GetMyVOD ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            itemTags = document.getElementsByTagName('item')
            return ProcessVideoItemTags(itemTags)                
    except:
        mc.LogInfo('error in GetMyVOD ')
        raise
        return None     
    
def GetProgramVODs(programid):
    try:
        url = str(Start.rest_url) + 'action=getepisodes&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&programid=' + str(programid)
        mc.LogInfo('GetProgramVODs ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            itemTags = document.getElementsByTagName('item')
            return ProcessVideoItemTags(itemTags) 
    except:
        mc.LogInfo('error in GetProgramVODs ')
        return None         
        
def CanPlayProgram(programid):
    try:
        url = str(Start.rest_url) + 'action=canplayprogram&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&programid=' + str(programid)
        mc.LogInfo('CanPlayProgram ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            return getText(document.getElementsByTagName('CanPlayProgram')[0].childNodes) == "1";
    except:
        mc.LogInfo('error in CanPlayProgram ')
        return None           

def CanPlayEpisode(programid):
    try:
        url = str(Start.rest_url) + 'action=canplayepisode&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&episodeid=' + str(programid)
        mc.LogInfo('CanPlayEpisode ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            return getText(document.getElementsByTagName('CanPlayEpisode')[0].childNodes) == "1";
    except:
        mc.LogInfo('error in CanPlayEpisode ')
        return None  

def IsProgramPurchased(programid):
    try:
        url = str(Start.rest_url) + 'action=isprogrampurchased&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&programid=' + str(programid)
        mc.LogInfo('IsProgramPurchased ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            return getText(document.getElementsByTagName('IsProgramPurchased')[0].childNodes) == "1";
    except:
        mc.LogInfo('error in IsProgramPurchased ')
        return None   

def IsVODPurchased(programid):
    try:
        url = str(Start.rest_url) + 'action=isvodpurchased&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&EpisodeId=' + str(programid)
        mc.LogInfo('IsVODPurchased ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            return getText(document.getElementsByTagName('IsVODPurchased')[0].childNodes) == "1";
    except:
        mc.LogInfo('error in IsVODPurchased ')
        return None
    
def BuyProgram(programid, billingid):
    try:
        url = str(Start.rest_url) + 'action=buyprogram&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&programid=' + str(programid) + '&billingid=' + str(billingid)
        mc.LogInfo('BuyProgram ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            if getText(document.getElementsByTagName('status')[0].childNodes) == "success":
                return "success"
            else:
                return getText(document.getElementsByTagName('AuthenticationMessage')[0].childNodes)
    except:
        mc.LogInfo('error in BuyProgram ')
        return None 

def BuyVOD(episodeid, billingid):
    try:
        url = str(Start.rest_url) + 'action=buyvod&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&episodeid=' + str(episodeid) + '&billingid=' + str(billingid)
        mc.LogInfo('BuyVOD ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            if getText(document.getElementsByTagName('status')[0].childNodes) == "success":
                return "success"
            else:
                return getText(document.getElementsByTagName('AuthenticationMessage')[0].childNodes)
    except:
        mc.LogInfo('error in BuyVOD ')
        return None 

def GetEpisode(episodeid):
    try:
        url = str(Start.rest_url) + 'action=getepisode&DeviceId=' + str(Start.device_sn) + '&DeviceTypeId=' + str(Start.device_type_id) + '&id=' + str(episodeid)  
        mc.LogInfo('GetEpisode ' + url)
        response = Request.GetUrl(url)
        if response is None:
            return None
        else:
            document = xml.dom.minidom.parseString(response)
            itemTags = document.getElementsByTagName('item')
            print('before processing onevideotag complete')
            item = ProcessOneVideoTag(itemTags[0])
            print('processing onevideotag complete')
            return item
    except:
        mc.LogInfo('error in GetVOD ')
        return None    