import mc
import urllib as libb
import xml.dom.minidom
import sys
import RestService

def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data.encode('utf-8').strip())
    return ''.join(rc) 

def BindChannels():
    #if len(mc.GetActiveWindow().GetList(11000).GetItems())>1:
    #    mc.GetActiveWindow().GetControl(11000).SetFocus()
    #    return
    try:
        ChannelCollection = mc.ListItems()
        
        items = mc.ListItems()
        mc.GetActiveWindow().GetList(11000).SetItems(items)
        mc.ShowDialogWait()
        #channels = RestService.GetChannels()
        #if channels != None and len(channels) > 0:
            #mc.LogInfo('Settings channels from user account')
            #mc.GetActiveWindow().GetList(11000).SetItems(channels)
        #else:
        strId = ''
        strChannelPurchased = ''
        strStartDate = ''
        strEndDate = ''
        strName = ''
        strDescription = ''
        strLogo = ''
                                                                            
        url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=GetChannel&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
        print(url)
        rss = libb.urlopen(url, data=None)
            
        dom = xml.dom.minidom.parseString(rss.read())
        rss.close()
            
        posters = dom.getElementsByTagName("item")
        for poster in posters:
            strId = str(getText(poster.getElementsByTagName("id")[0].childNodes))
            strChannelPurchased = str(getText(poster.getElementsByTagName("ChannelPurchased")[0].childNodes))
            strStartDate = str(getText(poster.getElementsByTagName("StartDate")[0].childNodes))
            strEndDate = str(getText(poster.getElementsByTagName("EndDate")[0].childNodes))
            strName = str(getText(poster.getElementsByTagName("title")[0].childNodes))
            strDescription = str(getText(poster.getElementsByTagName("description")[0].childNodes))
            strLogo = str(poster.getElementsByTagName("thumbnail")[0].attributes["url"].value)
                
            print(strId, strName)
                
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(strName)
            item.SetThumbnail(strLogo)
            item.SetProperty('uid',str(strId))
            item.SetProperty('description',strDescription)
            item.SetProperty('channelpurchased',strChannelPurchased)
            item.SetProperty('startdate',strStartDate)
            item.SetProperty('enddate',strEndDate)
            ChannelCollection.append(item) 
            
        dom.unlink()    
        mc.LogInfo('Settings channels from entire collection')
        mc.GetActiveWindow().GetList(11000).SetItems(ChannelCollection)
        mc.HideDialogWait()
        #mc.GetActiveWindow().GetControl(11000).SetFocus()
    except:
        mc.LogInfo('Settings channels ERROR')