import mc
import urllib as libb
import xml.parsers.expat
import sys     
                          
def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data.encode('utf-8').strip())
    return ''.join(rc)                                 
      
def BindCountries():
    CountryCollection = mc.ListItems()
    
    mc.GetActiveWindow().GetControl(14000).SetVisible(True)
    mc.GetActiveWindow().GetControl(14001).SetVisible(False)
    mc.GetActiveWindow().GetControl(14003).SetVisible(False)
    mc.GetActiveWindow().GetControl(14002).SetVisible(True)
    mc.GetActiveWindow().GetLabel(13999).SetLabel('Select a Country to view the related VODs.')
    
    if len(mc.GetActiveWindow().GetList(14002).GetItems())>1:
        mc.GetActiveWindow().GetControl(14002).SetFocus()
        mc.GetActiveWindow().GetControl(15000).SetVisible(True)
        return
    
    mc.ShowDialogWait()
    
    strId = ''
    strName = ''
    strSmallDescription = ''
    strBigDescription = ''
    strSmallLogoPath = ''
    strBigLogoPath = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getvodcountries&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strBigLogoPath = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        
        if strPosterType == 'country':
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strBigLogoPath))
            item.SetProperty('uid',str(strId))
            CountryCollection.append(item) 
    
    dom.unlink()
        
    mc.GetActiveWindow().GetList(14002).SetItems(CountryCollection)
    mc.GetActiveWindow().GetControl(14002).SetFocus()
    mc.GetActiveWindow().GetControl(15000).SetVisible(True)
    mc.HideDialogWait()

def BindGenres(countryid):
    GenresCollection = mc.ListItems()
    
    mc.GetActiveWindow().GetControl(14000).SetVisible(True)
    mc.GetActiveWindow().GetControl(14001).SetVisible(True)
    mc.GetActiveWindow().GetControl(14003).SetVisible(False)
    mc.GetActiveWindow().GetControl(14002).SetVisible(False)
    mc.GetActiveWindow().GetLabel(13999).SetLabel('')
    
    mc.GetActiveWindow().GetList(14001).SetItems(GenresCollection)
    
    mc.ShowDialogWait()
    
    strCountryId = ''
    strCountryName = ''
    strId = ''
    strName = ''
    strSmallDescription = ''
    strBigDescription = ''
    strSmallLogoPath = ''
    strBigLogoPath = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getvodcountries&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    print('Binding Genres')
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strBigLogoPath = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        
        if strPosterType == 'country':
            strCountryId = str(strId)
            strCountryName = str(strName)
            
        if strPosterType == 'genre' and strCountryId == str(countryid):
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strBigLogoPath))
            item.SetProperty('uid',str(strId))
            item.SetProperty('genrename',str(strName))
            item.SetProperty('countryid',str(strCountryId))
            item.SetProperty('countryname',str(strCountryName))
            GenresCollection.append(item) 
    
    dom.unlink()
    
    mc.GetActiveWindow().GetList(14001).SetItems(GenresCollection)
    mc.GetActiveWindow().GetControl(14001).SetFocus()
    
    mc.HideDialogWait()

def BindProgramTypes(countryid, genreid):
    ProgramTypeCollection = mc.ListItems()
    
    items = mc.ListItems()
    mc.GetActiveWindow().GetList(14003).SetItems(items)
    
    mc.GetActiveWindow().GetControl(14000).SetVisible(True)
    mc.GetActiveWindow().GetControl(14001).SetVisible(False)
    mc.GetActiveWindow().GetControl(14002).SetVisible(False)
    mc.GetActiveWindow().GetControl(14003).SetVisible(True)
    
    mc.ShowDialogWait()

    strGenreId = ''
    strGenreName = ''
    strCountryId = ''
    strCountryName = ''
    strId = ''
    strName = ''
    strSmallDescription = ''
    strBigDescription = ''
    strSmallLogoPath = ''
    strBigLogoPath = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getvodcountries&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    print('Bind Program Types')
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strBigLogoPath = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        
        if strPosterType == 'country':
            strCountryId = str(strId)
            strCountryName = str(strName)
            
        if strPosterType == 'genre':
            strGenreId = str(strId)
            strGenreName = str(strName)
            
        if strPosterType == 'programtype' and strCountryId == str(countryid) and strGenreId == str(genreid):
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strBigLogoPath))
            item.SetProperty('uid',str(strId))
            item.SetProperty('programtypename',str(strName))
            item.SetProperty('genreid',str(strGenreId))
            item.SetProperty('genrename',str(strGenreName))
            item.SetProperty('countryid',str(strCountryId))
            item.SetProperty('countryname',str(strCountryName))
            ProgramTypeCollection.append(item) 
    
    dom.unlink()
    
    mc.GetActiveWindow().GetList(14003).SetItems(ProgramTypeCollection)
    mc.GetActiveWindow().GetControl(14003).SetFocus()
    
    mc.HideDialogWait()

def BindPrograms(countryid, genreid, programtypeid):
    ProgramCollection = mc.ListItems()
    
    mc.GetActiveWindow().GetControl(15000).SetVisible(False)
    mc.GetActiveWindow().GetControl(14000).SetVisible(False)
    mc.GetActiveWindow().GetControl(9999).SetVisible(False)
    mc.GetActiveWindow().GetControl(8888).SetVisible(True)
    mc.GetActiveWindow().GetControl(8881).SetVisible(True)
    mc.GetActiveWindow().GetControl(8882).SetVisible(True)
    
    mc.GetActiveWindow().GetList(8882).SetItems(ProgramCollection)

    strCountryId = ''
    strGenreId = ''
    strProgramTypeId = ''
    strId = ''
    strName = ''
    strDescription = ''
    strLogo = ''
    strPosterType = ''
                                                                     
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getvodcountries&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
    
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strLogo = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        strDescription = str(getText(poster.getElementsByTagName("shortdescriptionline2")[0].childNodes))
        
   
        
        
        if strPosterType == 'country':
            strCountryId = str(strId)
            
        if strPosterType == 'genre':
            strGenreId = str(strId)
        
        if strPosterType == 'programtype':
            strProgramTypeId = str(strId)
            
        if (strPosterType == 'program' or strPosterType == 'episode') and strCountryId == str(countryid) and strGenreId == str(genreid) and strProgramTypeId == str(programtypeid):
            print(strPosterType, strId, strName)
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(str(strName))
            item.SetThumbnail(str(strLogo))
            item.SetProperty('uid',str(strId))
            item.SetProperty('countryid',str(strCountryId))
            item.SetProperty('genreid',str(strGenreId))
            item.SetProperty('programtypeid',str(strProgramTypeId))
            item.SetProperty('postertype',str(strPosterType))
            item.SetProperty('type',str(strPosterType))
            item.SetProperty('description',strDescription)
            ProgramCollection.append(item) 
    
    dom.unlink()
    
    mc.GetActiveWindow().GetList(8882).SetItems(ProgramCollection)
    mc.GetActiveWindow().GetControl(8882).SetFocus()