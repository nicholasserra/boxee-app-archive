import mc
import urllib as libb
import w
import sys

def GetMyVODs():
    mc.GetActiveWindow().GetLabel(111).SetLabel('Loading...')
    
    channels = []                            
    strElementName = ''
    strId = ''
    strTitle = ''
    strDescription = ''
    strThumbnail = ''
                                
    def start_element(name, attrs):
        print 'Start element:', name, attrs
        strElementName = name
    def end_element(name):
        print 'End element:', name
        if name == 'item':
            channels.append({
                             'Id': strId,
                             'Label': strTitle,
                             'ContentType': 'LiveChannels',
                             'thumb': strThumbnail,
                             'description': strDescription
                            })
    def char_data(data):
        print 'Character data:', repr(data)
        if strElementName == 'id':
            strId = repr(data)
        elif strElementName == 'title':
            strTitle = repr(data)
        elif strElementName == 'description':
            strDescription = repr(data)
        elif strElementName == 'thumbnail':
            strThumbnail = repr(data)
                                    
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?aaction=myvod&deviceid=16C1AE045164&devicetypeid=4'
    rss = libb.urlopen(url, data=None)
                                
    p = xml.parsers.expat.ParserCreate()
    p.StartElementHandler = start_element
    p.EndElementHandler = end_element
    p.CharacterDataHandler = char_data
                                
    p.Parse(rss.read())
    rss.close()
    
    mc.GetActiveWindow().GetLabel(111).SetLabel('')
    
    mc.GetActiveWindow().GetList(120).SetItems(channels)

