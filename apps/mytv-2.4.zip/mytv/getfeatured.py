import mc
import urllib as libb
import xml.parsers.expat
import sys     

 
                        
def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data.encode('utf-8').strip())
    return ''.join(rc)           
      
def BindFeatured():
    if len(mc.GetActiveWindow().GetList(10000).GetItems())>1:
        #mc.GetActiveWindow().GetControl(10000).SetFocus()
        return
                                      
    FeaturedCollection = mc.ListItems()  
    
    strId = ''
    strName = ''
    strDescription = ''
    strLogo = ''
    strPosterType = ''
    strType = ''
                                            
    url = 'http://www.my-tv.us/mytv.restws.new/restservice.ashx?action=getfeatured&deviceid=' + str(mc.GetUniqueId()) + '&devicetypeid=5'
    print(url)
    rss = libb.urlopen(url, data=None)
                                
    dom = xml.dom.minidom.parseString(rss.read())
    rss.close()
    
    posters = dom.getElementsByTagName("poster")
    for poster in posters:
        strId = str(getText(poster.getElementsByTagName("playlist")[0].childNodes))
        strName = str(getText(poster.getElementsByTagName("shortdescriptionline1")[0].childNodes))
        strLogo = str(getText(poster.getElementsByTagName("sdposterurl")[0].childNodes))
        strPosterType = str(getText(poster.getElementsByTagName("postertype")[0].childNodes))
        strType = str(getText(poster.getElementsByTagName("type")[0].childNodes))
        strDescription = str(getText(poster.getElementsByTagName("shortdescriptionline2")[0].childNodes))
        
        item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        item.SetLabel(strName)
        item.SetThumbnail(strLogo)
        item.SetProperty('uid',strId)
        item.SetProperty('type',strType)
        item.SetProperty('description',strDescription)
        FeaturedCollection.append(item)
            
    dom.unlink()
    
    mc.GetActiveWindow().GetControl(10000).SetVisible(True)
    mc.GetActiveWindow().GetList(10000).SetItems(FeaturedCollection)