import mc

def log(s):
    message = '-----------------------------WEALTHTV LOG-------------------------- :%s' % str(s)
    mc.LogInfo(message)