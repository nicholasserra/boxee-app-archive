import os
import urllib, urllib2
import httplib
import simplejson as json
import mc
import re
import random
import socket
import string

def UnicodeReplace(match):
	return unichr(int(match.group(1),16))
        
def log(s):
    message = '-----------------------------WEALTHTV LOG-------------------------- :%s' % str(s)
    mc.LogInfo(message)


def generateDeviceid():
    config = mc.GetApp().GetLocalConfig()    
    deviceid = str(config.GetValue("cookie"))
    if deviceid=="":
        deviceid=str(random.randint(1000000000,9999999999))
        config.SetValue("cookie",deviceid)
    return deviceid
    
def generateToken():
    variant = string.ascii_uppercase + string.digits
    token = str(''.join(random.sample(variant,8)))
    return token
    

def checkStatus(deviceid, token):

    host = 'www.wealthtv.com'
    headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
    try:
        conn = httplib.HTTPConnection(host)
        conn.request("GET", "/subscribe/flash/addIPFirstTime.php?deviceid="+deviceid+"&make=Boxee&model=Boxee&token="+token)
        conn.close()
    except StandardError:
        mc.ShowDialogOk("WealthTV", "Internet Connection problem")
        
    conn.request("GET", "/subscribe/flash/getSubscriptionstatus.php?deviceid="+deviceid)
    response = conn.getresponse()
    data = response.read()
    conn.close()
    return data

def launch(login=True):
    app = mc.GetApp()
    params = mc.Parameters()
    deviceid = generateDeviceid()
    token = generateToken()
    status = checkStatus(deviceid, token)
    params['token']= token
    params['deviceid'] = deviceid
    log(status)
    if status=="3":
        mc.ShowDialogOk("WealthTV", "Please go to www.wealthtv.com/subscribe to add this token and restart the application:                  "+token)
    elif status=="1": 
        log("carry on")
        app.ActivateWindow(14006, params)
    elif status=="0":
        mc.ShowDialogOk("WealthTV", "Your profile is deactivated, please activate it by logging into WealthTV account")
        