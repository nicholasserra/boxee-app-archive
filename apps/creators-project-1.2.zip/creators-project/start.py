import mc
import tracker

myTracker = tracker.Tracker("UA-23103870-1")
myTracker.trackView()

mc.GetApp().ActivateWindow(14000, mc.Parameters())