
import mc,traceback,os
from Headweb.AuthStore import BaseAuthStore
from Util import BoxeeCookieJar

class BoxeeAuthStore(BaseAuthStore):
	"""AuthStore implementation for the Boxee platform"""
	def __init__(self, cookieJar, host):
		BaseAuthStore.__init__(self, cookieJar,  host)

	def _readStoredTrid(self):
		"""This function shall return the trid as stored in local configuration"""
		return mc.GetApp().GetLocalConfig().GetValue('com.headweb.trid')

	def _storeTrid(self, trid):
		"""This function shall store the trid in local configuration"""
		# We never do erase on trid, no need for Reset functionality
		mc.GetApp().GetLocalConfig().SetValue('com.headweb.trid', trid)

	def _getCreds(self):
		"""Fetches credentials for current trid (trid_hash), or None if not found."""
		return mc.GetApp().GetLocalConfig().GetValue('com.headweb.hwpl')

	def _storeCreds(self, hwpl):
		"""Stores credentials for current trid (trid_hash), or removes if hwpl is None"""
		if hwpl == None:
			if mc.GetApp().GetLocalConfig().GetValue('com.headweb.hwpl') == None:
				return

			mc.GetApp().GetLocalConfig().Reset('com.headweb.hwpl')

			# Clear out boxee cookie jar aswell
			jarFile = mc.GetCookieJar()
			if os.path.isfile(jarFile):
				try:
					jar = BoxeeCookieJar(jarFile)
					jar.load(jarFile, True, True) # Ignore discarded/expired

					# Try to remove, raises KeyError if not set
					jar.clear(".headweb.com")

					jar.save(jarFile, True, True) # Again, ignore discarded/expired
				except KeyError:
					pass
				except:
					print "Failed to clear cookies!"

		else:
			mc.GetApp().GetLocalConfig().SetValue('com.headweb.hwpl', hwpl)

