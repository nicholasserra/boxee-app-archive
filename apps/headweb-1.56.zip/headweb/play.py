import mc
import sys
import cgi
import HeadwebObjects

if sys.argv[1]:
	args = cgi.parse_qs(sys.argv[1])
	videoID = args['id'][0]

	# Initiate app 
	appstate = HeadwebObjects.getAppstate()
	# Tell appstate to show this video initally.
	appstate['init-show-content'] = videoID

	# Start main window, this will show login if required
	# and then transfer to that specific video.
	# When the user presses 'esc' he will come back to the main window, not the 
	# RSS feed..
	mc.GetApp().ActivateWindow(14000, mc.Parameters())
else:
	mc.ShowDialogOk('headweb', 'There was a problem playing the requested film (missing parameter)')
