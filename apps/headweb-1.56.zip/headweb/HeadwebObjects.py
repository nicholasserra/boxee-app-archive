from Headweb.API import APIv4
import BoxeeAuthStore

from datetime import datetime
from time import time
from xml.dom import minidom
from copy import deepcopy


class InvalidValueException (Exception):
	def __init__ (self, value = None):
		self.value = value
	
class MissingElementException (Exception):
	def __init__ (self, element = None):
		self.element = element
	
class MissingAttributeException (Exception):
	def __init__ (self, attribute = None):
		self.attribute = attribute
	
class Error (object):
	def __init__ (self, dom = None):
		self.errstr = None
		self.message = None
		if dom != None:
			self.parseDom(dom)
	
	def parseDom(self, dom):
		self.errstr = dom.getAttribute('err')
		self.message = dom.firstChild.nodeValue
	
class Amount (object):
	def __init__ (self, raw = 0.0, full = '0.00 SEK', humanReadable = '0 kr'):
		self.raw = raw
		self.full = full
		self.humanReadable = humanReadable
	
	def parseDom (self, dom):
		if dom.nodeType != minidom.Node.ELEMENT_NODE:
			raise Exception('DOM node is not an element type node.')
		
		if dom.hasAttribute('raw'):
			self.raw = float(dom.getAttribute('raw'))
		else:
			raise Exception('"Amount" entity has no "raw" attribute.')
		
		if dom.hasAttribute('full'):
			self.full = dom.getAttribute('full')
		else:
			raise Exception('"Amount" entity has no "full" attribute.')
		
		if dom.hasChildNodes() and dom.firstChild.nodeType == \
				minidom.Node.TEXT_NODE:
			self.humanReadable = dom.firstChild.nodeValue
		else:
			raise Exception('"Amount" entity has no child text node.')
	
	def __str__ (self):
		return self.humanReadable

class Auth (object):
	def __init__ (self):
		self.preview = None
		self.timeleft
		self.playerurl = None
		self.playerparameters = None

	def parseDom (self, dom):
		# Preview flag - weather the item has a preview or not.
		previewNodes = dom.getElementsByTagName('preview')
		if previewNodes:
			auth.preview = parseBool(previewNodes[0])
		
		# Player URL - Full path to web element handling playback.
		urlNodes = dom.getElementsByTagName('playerurl')
		if urlNodes:
			auth.playerurl = parseString(urlNodes[0])

		# PLayer paramters - URL parameters for player.
		paramNodes = dom.getElementsByTagName('playerparams')
		if paramNodes:
			auth.playerparameters = parseString(oaramNodes[0])

		# Timeleft, number of seconds the item is available.
		timeleftNodes = dom.getElementsByTagName('timeleft')
		if timeleftNodes:
			auth.timeleft = parseInteger(timeleftNodes[0])

class Image (object):
	"""Represents a server-side image object with URL and dimensions."""
	def __init__ (self, url = None, width = None, height = None):
		self.url = None
		self.width = None
		self.height = None
	
	def parseDom (self, node):
		# Process height and width attributes.
		if node.hasAttribute('width'):
			self.width = int(node.getAttribute('width'))
		
		if node.hasAttribute('height'):
			self.height = int(node.getAttribute('height'))
		
		# Text node contents (image URL).
		if node.hasChildNodes() and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
			self.url = node.firstChild.nodeValue
		else:
			raise Exception('Unable to find a text child node (with URL) for image.')

class StreamEntity (object):
	TYPE_FLASH = 'flash'
	TYPE_SILVERLIGHT = 'silverlight'
	STATUS_PUB = 'pub'
	STATUS_SOFTPUB = 'softpub'
	STATUS_PUBWAIT = 'pubwait'
	
	def __init__ (self):
		self.id = None
		self.type = None
		self.status = None
		self.publishingDate = None
		self.runtime = None
		self.price = None
		self.preview = None
		self.rental_allowed = False
		self.rental_allowed_api = False
		self.audios = []
		self.subtitles = []
		self.owned = False # Set by personalized-section in ContentEntity

		self.personalized = False

	def parseDom (self, dom):
		if dom.tagName != 'stream':
			raise Exception('DOM node is not an "stream" element.')
		
		if dom.hasAttribute('id'):
			self.id = int(dom.getAttribute('id'))
		else:
			raise Exception('DOM node has no "id" attribute.')
		
		for child in dom.childNodes:
			if child.tagName == 'price':
				amount = Amount()
				amount.parseDom(child)
				self.price = amount
			
			elif child.tagName == 'status' and child.hasChildNodes and \
					child.firstChild.nodeType == minidom.Node.TEXT_NODE:
				status = child.firstChild.nodeValue
				
				if not status in (StreamEntity.STATUS_PUB, StreamEntity.STATUS_SOFTPUB, StreamEntity.STATUS_PUBWAIT):
					raise Exception('Unknown value for "status" element (' + status + ').')
				self.status = status
			
			elif child.tagName == 'type':
				type = child.firstChild.nodeValue
				if not type in (StreamEntity.TYPE_FLASH, StreamEntity.TYPE_SILVERLIGHT):
					raise Exception('Unknown value for "type" element.')
				self.type = type
			
			elif child.tagName == 'live':
				self.live = child.firstChild.nodeValue == 'true'

			elif child.tagName == 'rental_allowed':
				self.rental_allowed = child.firstChild.nodeValue == 'true'

			elif child.tagName == 'rental_allowed_api':
				self.rental_allowed_api = child.firstChild.nodeValue == 'true'
			
			elif child.tagName == 'pubdate':
				self.publishingDate = int(child.getAttribute('utc'))
			
			elif child.tagName == 'runtime':
				self.runtime = int(child.firstChild.nodeValue)

			elif child.tagName == 'audio':
				# inner element is "language" element, the content is the name
				self.audios.append(child.firstChild.firstChild.nodeValue)

			elif child.tagName == 'subtitle':
				self.subtitles.append(Subtitle(child))
			
			elif child.tagName == 'preview' and child.hasChildNodes and \
					child.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.preview = int(child.firstChild.nodeValue)

	def parsePersonalized(self, dom):
		"""Parse personalized stream info from content request"""
		if dom.tagName != 'stream':
			raise Exception('DOM node is not an "stream" element.')
		
		id = int(dom.getAttribute('id'))
		if self.id != id:
			print "Warn: missmatching stream ID for personalized info, got %d but is %s"\
					% (id, self.id)

			return
	
		self.personalized = True
		for child in dom.childNodes:
			if child.tagName == 'owned':
				if child.firstChild.nodeValue == 'true':
					self.owned = True
				else:
					self.owned = False

			elif child.tagName == 'timeleft':
				self.timeleft = int(child.firstChild.nodeValue)

class PurchaseResponse:
	"""Purchase response object."""
	def __init__ (self):
		self.id = None
		self.state = None
		self.items = []
		self.error = None
	
	def parseDom (self, response):
		purchaseNodes = response.getElementsByTagName('purchase')
		if len(purchaseNodes) == 0:
			raise MissingElementException('purchase')

		purchase = purchaseNodes[0]
		if purchase.hasAttribute('id'):
			self.id = int(purchase.getAttribute('id'))
		else:
			raise MissingAttributeException('id')
		
		# If no 'success' item is available, check for an error element.
		success = False
		for node in purchase.childNodes:
			if node.tagName == 'item':
				# Purchased items
				purchasedItem = PurchasedItem()
				purchasedItem.parseDom(node)
				self.items.append(purchasedItem)

			elif node.tagName == 'state':
				self.state = str(node.nodeValue).lower()

			elif node.tagName == 'failed':
				self.error = Error(node)

			elif node.tagName == 'success':
				success = True

		if not success and self.error == None:
			raise MissingElementException('succes or failed element missing!')

class RedemptionInfo (object):
	def __init__(self):
		self.codeType = None
		self.type = None
		self.item = None
		self.itemId = []
		self.minItems = None
	
	def parseDom(self, response):
		for node in response.childNodes:
			if node.tagName == 'campaign':
				self.codeType = 'campaign'
				self._parseInfo(node)

			elif node.tagName == 'giftcertificate':
				self.codeType = 'giftcertificate'
				self._parseInfo(node)

			elif node.tagName == 'minitems':
				self.minItems = int(n.firstChild.nodeValue)

	def _parseInfo(self, dom):
		for n in dom.childNodes:
			if n.tagName == 'type':
				self.type = n.firstChild.nodeValue
			elif n.tagName == 'item':
				self.item = n.firstChild.nodeValue
			elif n.tagName == 'itemid':
				self.itemId.append(int(n.firstChild.nodeValue))

	
#class SMSPurchase (Purchase):
#	def __init__ (self):
#		self.id = None
#		self.amount = None
#		self.code = None
#		self.number = None
#	
#	def parseDom (self, dom):
#		if not dom.tagName == 'purchase':
#			raise Exception('DOM node is not an "purchase" element.')
#			
#			nodes = dom.getElementsByTagName('sms')
#			if len(nodes) > 0:
#				for child in nodes[0].childNodes:
#					if child.tagName == 'amount':
#						amount = Amount()
#						amount.parseDom(child)
#						self.amount = amount
#					
#					elif child.tagName == 'code' and child.hasChildNodes and \
#							child.firstChild.nodeType == minidom.Node.TEXT_NODE:
#						self.code = child.firstChild.nodeValue
#					
#					elif child.tagName == 'number' and child.hasChildNodes and \
#							child.firstChild.nodeType == minidom.Node.TEXT_NODE:
#						self.number = child.firstChild.nodeValue
#			else:
#				raise Exception('"purchase" element has no "sms" child.')
		
class UserInfo (object):
	def __init__ (self):
		self.userName = None
		self.id = None
		self.balance = None
		self.credits = None
	
	def parseDom (self, dom):
		if dom.tagName != 'user':
			raise Exception('DOM node is not an "user" element.')
		
		if dom.hasAttribute('id'):
			self.id = int(dom.getAttribute('id'))
		else:
			raise Exception('DOM node has no "id" attribute.')
		
		for child in dom.childNodes:
			if child.tagName == 'username' and child.hasChildNodes and \
					child.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.userName = child.firstChild.nodeValue
			
			elif child.tagName == 'balance':
				amount = Amount()
				amount.parseDom(child)
				# Special for currency balance
				amount.nodecimals = child.getAttribute('nodecimals')
				self.balance = amount
			
			elif child.tagName == 'credits' and child.hasChildNodes and \
					child.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.credits = child.firstChild.nodeValue
			
class ContainerEntity(object):
	"""Represents a container entity such as a genre, keyword or directory"""
	def __init__ (self, name = None, id = None):
		self.name = name
		self.id = id
	
	def parseDom (self, dom):
		if dom.tagName not in ('genre', 'keyword', 'directory', 'videocliptype'):
			raise Exception("DOM node is not a valid container entity ('%s')." % dom.tagName)

		if dom.hasAttribute('id'):
			self.id = int(dom.getAttribute('id'))
		else:
			raise Exception('node is missing "id" attribute.')
		
		if dom.hasChildNodes() and dom.firstChild.nodeType == \
				minidom.Node.TEXT_NODE:
			self.name = dom.firstChild.nodeValue
		else:
			raise Exception('node has no child text node for name.')

class ContentEntity (object):
	"""Represents an content entity from the API, ie a movie"""
	def __init__ (self):
		self.id = None
		self.year = None
		self.plot = ""
		self.name = None
		self.originalName = None
		self.url = None
		self.stream = None
		self.cover = []
		self.genre = None
		self.videoclips = []
		self.subscriptions = []
	
	def parseDom (self, dom):
		# If a minidom node was supplied, assume it is an 'item' node.
		if not dom.tagName == 'content':
			raise Exception('DOM node is not an "content" element ("' + \
					dom.tagName + '").')
			
		# Extract the ID of the title/entity itself.
		if not dom.hasAttribute('id'):
			raise Exception('DOM "item" element is missing "id" attribute.')
		self.id = int(dom.getAttribute('id'))
		
		for node in dom.childNodes:
			# Name of movie/title/item.
			if node.tagName == 'name' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.name = node.firstChild.nodeValue
			
			# Check weather we have an original name (optional).
			elif node.tagName == 'originalname' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.name = node.firstChild.nodeValue
			
			elif node.tagName == 'genre' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				# XXX Multiple genres??
				self.genre = node.firstChild.nodeValue
			
			elif node.tagName == 'year' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.year = int(node.firstChild.nodeValue)
			
			elif node.tagName == 'plot' and node.hasChildNodes():
				# CDATA!
				self.plot = node.firstChild.wholeText
			
			# Stream entities
			elif node.tagName == 'stream':
				stream = StreamEntity()
				stream.parseDom(node)
				self.stream = stream

			# Videoclip entities
			elif node.tagName == 'videoclip':
				vc = VideoClipEntity()
				vc.parseDom(node)
				self.videoclips.append(vc)
			
			# Cover images (multiple image resolutions).
			# Example: <cover width="100" height="160">http://foobar.com/image.jpg</cover>
			elif node.tagName == 'cover' and node.hasChildNodes():
				image = Image()
				image.parseDom(node)
				self.cover.append(image)


		# Once parsed all the cover images should be sorted by size (rising).
		self.cover.sort(key = lambda s: s.width * s.height)

	def parsePersonalized(self, dom):
		# If a minidom node was supplied, assume it is an 'item' node.
		if not dom.tagName == 'personalized':
			raise Exception('DOM node is not an "personalized" element ("' + \
					dom.tagName + '").')
			
		# Now, only personalized info we're looking at here is
		# for associated subscriptions which is owned. And the stream, 
		# to check if the actual stream is owned.
		for node in dom.childNodes:
			# Name of movie/title/item.
			if node.tagName == 'subscriptions' and node.hasChildNodes():
				for s in node.childNodes:
					if s.tagName != 'subscription':
						continue

					subscription = Subscription(s)
					if subscription.count < subscription.maxlimit:
						self.subscriptions.append(Subscription(s))
			elif node.tagName == 'stream' and node.hasChildNodes() \
					and self.stream != None:

				self.stream.parsePersonalized(node)

		# If we DIDNT get the stream section above, update to reflect
		# that we really are perzonalied (and not owned)
		self.stream.personalized = True

	
	def getCover (self, quality):
		"""Returns the cover image object matching the quality parameter.
		The quality parameter is a real number (float) between 0.0 and 1.0."""
		
		if quality < 0.0 or quality > 1.0:
			raise ValueError('Quality parameter not in range 0.0 to 1.0.')
		
		index = int(round(quality * (len(self.cover) - 1)))
		
		return self.cover[index]

class Bitrate:
	def __init__(self, dom):
		self.bitrate = dom.getAttribute('rate')
		for node in dom.childNodes:
			if node.tagName == 'width':
				self.width = int(node.firstChild.nodeValue)
			elif node.tagName == 'height':
				self.height = int(node.firstChild.nodeValue)
			elif node.tagName == 'url':
				self.url = node.firstChild.nodeValue

class Subtitle:
	def __init__(self, dom):
		for node in dom.childNodes:
			if node.tagName == 'language':
				# Inner conntent is language name
				self.langid = node.getAttribute('id')
				self.language = node.firstChild.nodeValue
			elif node.tagName == 'url':
				self.url = node.firstChild.nodeValue
			elif node.tagName == 'partial':
				self.partial = node.firstChild.nodeValue == 'true'
			elif node.tagName == 'native':
				self.native = node.firstChild.nodeValue == 'true'

class VideoClipEntity (object):
	VIDEOCLIPTYPE_TRAILER = 18000
	def __init__ (self):
		self.id = None
		self.name = None
		self.type = None
		self.publishingDate = None
		self.bitrates = []
	
	def parseDom (self, dom):
		if dom.tagName != 'videoclip':
			raise Exception('DOM node is not a "videoclip" element.')
		
		if dom.hasAttribute('id'):
			self.id = int(dom.getAttribute('id'))
		else:
			raise Exception('"videoclip" node is missing "id" attribute.')
			
		for node in dom.childNodes:
			# Name of movie/title/item.
			if node.tagName == 'name' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.name = node.firstChild.nodeValue
			
			# Publishing date at Headweb.
			elif node.tagName == 'pubdate':
				self.publishingDate = datetime.fromtimestamp(int(node.getAttribute('utc')))
			
			# Video bitrates
			elif node.tagName == 'bitrate':
				self.bitrates.append(Bitrate(node))

			elif node.tagName == 'videocliptype':
				self.type = int(node.getAttribute('id'))


		# Sort bitrates by res
		self.bitrates.sort(key = lambda s: s.width * s.height)

class PurchasedItem (object):
	"""Represents a purchased item."""
	def __init__ (self, id = None, purchaseId = None, name = None, \
			purchased = None, state = None, timeleft = None, auth = None, content = None):
		self.id = id
		self.purchaseId = purchaseId
		self.name = name
		self.purchased = purchased
		self.state = state
		self.timeleft = timeleft
		self.auth = auth
		self.content = content
		self.error = None
	
	def parseDom (self, dom):
		if dom.nodeType != minidom.Node.ELEMENT_NODE:
			raise Exception('DOM node is not an element node.')
		
		if not dom.tagName == 'item':
			raise Exception('DOM node is not an "item" element.')
			
		# Extract the ID of the title/entity itself.
		if dom.hasAttribute('id'):
			self.id = int(dom.getAttribute('id'))
		else:
			raise Exception('DOM "item" element is missing "id" attribute.')
		
		# Extract the purchase ID.
		if dom.hasAttribute('purchid'):
			self.purchaseId = int(dom.getAttribute('purchid'))
		else:
			raise Exception('DOM "item" element is missing "purchid" attribute.')

		for node in dom.childNodes:
			# Skip irrelevant nodes.
			if node.nodeType != minidom.Node.ELEMENT_NODE:
				continue;
			
			# Name of movie/title/item.
			if node.tagName == 'name' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.name = node.firstChild.nodeValue
			
			# relevant Content entity
			elif node.tagName == 'content':
				content = ContentEntity()
				content.parseDom(node)
				self.content = content

			# Error element in case of purchase failure
			elif node.tagName == 'error':
				self.error = Error(node)
			
			# State of item (available etc).
			elif node.tagName == 'state' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.state = node.firstChild.nodeValue
				if not self.state in ('expired', 'timeleft', 'available'):
					raise Exception('Unrecognized value for "state" element.')
			
			# Time left for rental.
			elif node.tagName == 'timeleft' and node.hasChildNodes() \
					and node.firstChild.nodeType == minidom.Node.TEXT_NODE:
				self.timeleft = int(node.firstChild.nodeValue)
			
			# Date when the item was purchased.
			elif node.tagName == 'purchased':
				if node.hasAttribute('utc'):
					self.purchased = datetime.fromtimestamp(int(node.getAttribute('utc')))

class SubscriptionInfo:
	def __init__(self, dom):

		if not dom.hasAttribute('id'):
			raise Exception('DOM "subscriptioninfo" element is missing "id" attribute.')
		self.id = int(dom.getAttribute('id'))

		for node in dom.childNodes:
			if node.tagName == 'ticketname':
				self.name = node.firstChild.nodeValue

class Subscription:
	def __init__(self, dom):

		if not dom.hasAttribute('id'):
			raise Exception('DOM "subscription" element is missing "id" attribute.')
		self.id = int(dom.getAttribute('id'))

		for node in dom.childNodes:
			if node.tagName == 'status':
				self.status = node.firstChild.nodeValue
			elif node.tagName == 'count':
				self.count = int(node.firstChild.nodeValue)
			elif node.tagName == 'maxlimit':
				self.maxlimit = int(node.firstChild.nodeValue)
			elif node.tagName == 'subscriptioninfo':
				self.info = SubscriptionInfo(node)
	
class Query:
	"""The Query class (or subclasses thereof) represents a result-set
	from the server, generally containing multiple items, with helpers
	for paging etc"""
	# The fields list must be sorted alphabetically for performance on server.
	DEFAULT_FIELDS = 'cover,genre,name,plot,pubdate,rating,stream,year,videoclip'
	DEFAULT_STREAMFIELDS = 'type,preview,live,status,pubdate,price,runtime,rental_allowed,subtitle,audio,pendingrevokedate'
	DEFAULT_LIMIT = 100

	def __init__ (self, api, limit = DEFAULT_LIMIT):
		self.api = api
		self.parameters = None
		self.items = 0
		self.limit = limit
		self.offset = 0
		self.list = []
	
	def _checkInitialParameters (self, **arguments):
		"""Checks that arguments doesn't contain 'limit', 'offset' or 'fields'.
		These are reserved for the paging control mechanism."""
		keys = arguments.keys()
		if 'limit' in keys:
			raise Exception('Named parameter "limit" is not allowed.')
		elif 'offset' in keys:
			raise Exception('Named parameter "offset" is not allowed.')
		elif 'fields' in keys:
			raise Exception('Named parameter "fields" is not allowed.')
	
	@staticmethod
	def _mergeParameters (existingParameters, **newParameters):
		"""Merges a set of keyword parameters with an existing bunch.
		Duplicate keys is an error and throws an exception."""
		
		mergedParameters = deepcopy(existingParameters)
		
		for key, value in newParameters.iteritems():
			if key in existingParameters:
				raise Exception('Error: Duplicate parameter "%s" detected in query.' % key)
			mergedParameters[key] = value
		
		return mergedParameters
	
	def hasNext (self):
		if self.items - self.offset > 0:
			return True
		else:
			return False
	
	def hasPrev (self):
		if self.offset > 0:
			return True
		else:
			return False
	
	def pageNext (self):
		if self.hasNext():
			self.offset = self.offset + self.limit
			# Clamp offset to maximum value (integer multiple of limit).
			if self.offset >= self.items:
				self.offset = int(self.items / self.limit)
			return True
		else:
			return False
			
	def pagePrev (self):
		if self.hasPrev():
			self.offset = self.offset - self.limit
			# Clamp offset to minimum value.
			if self.offset < 0:
				self.offset = 0
			return True
		else:
			return False

	def _parseCommon (self, response):
		if response.tagName != 'response':
			raise Exception('_parseCommon should be passed "response" element.')
		
		if response.hasAttribute('lang'):
			self.language = response.getAttribute('lang')
		
		# If a list is returned then parse the size attributes.
		if not response.hasChildNodes():
			raise Exception('Server XML "response" element has no child elements.')

		for child in response.childNodes:
			if child.tagName == 'list':
				
				if child.hasAttribute('items'):
					self.items = int(child.getAttribute('items'))
				if child.hasAttribute('limit'):
					self.limit = int(child.getAttribute('limit'))
				if child.hasAttribute('offset'):
					self.offset = int(child.getAttribute('offset'))
				
				break
				
	
	def __iter__ (self):
		return self.list.__iter__()
	
	def __next__ (self):
		return self.list.__next__()

	def first(self):
		return self.list[0]
	
	def getItemById (self, id):
		"""Return an item in the query specified by ID. Returns None if no
		matching ID could be found."""
		for item in self.list:
			if item.id == id:
				return item
		return None
	
class SearchQuery (Query):
	def __init__ (self, api, searchString, limit = Query.DEFAULT_LIMIT, \
			**namedParameters):
		Query._checkInitialParameters(self, **namedParameters)
		Query.__init__(self, api, limit)
		self.api = api
		self.searchString = searchString
		self.parameters = namedParameters
		self._query()
	
	def _query (self):
		temporaryParameters = Query._mergeParameters(self.parameters, \
				fields=Query.DEFAULT_FIELDS, streamfields = Query.DEFAULT_STREAMFIELDS, \
				offset=self.offset, limit=self.limit)
		response = self.api.search(self.searchString, **temporaryParameters)
		Query._parseCommon(self, response)
		self.list = []
		
		# First child is list
		for item in response.firstChild.childNodes:
			newItem = ContentEntity()
			newItem.parseDom(item)
			self.list.append(newItem)
	
	def submit (self):
		self._query()
	
	def pageNext (self):
		result = Query.pageNext(self)
		if result:
			self._query()
		return result
	
	def pagePrev (self):
		result = Query.pagePrev(self)
		if result:
			self._query()
		return result
	
class ContainerEntityQuery (Query):
	def __init__ (self, api, entityName, entity = None, limit = Query.DEFAULT_LIMIT, \
			**namedParameters):
		Query._checkInitialParameters(self, **namedParameters)
		Query.__init__(self, api, limit)
		self.entityName = entityName
		self.entity = entity

#		if entity == None and entityName != 'content':
			# for listing all available items, skip limit
		self.limit = -1

		self.parameters = namedParameters
		self._query()
		
	def _query (self):
		fields = Query.DEFAULT_FIELDS
		 
		# For direct content requests, we want personalized info
		# aswell, ie subscriptions.
		if self.entityName == 'content' and \
			self.entity != None and self.entity.isdigit():
			fields += ',personalized'
#			self.parameters['purchasablefields'] = 'name,description'

		temporaryParameters = Query._mergeParameters(self.parameters, \
				fields=fields, streamfields = Query.DEFAULT_STREAMFIELDS, \
				offset=self.offset, limit=self.limit)

		response = self.api._entityReq(self.entityName, self.entity, True, **temporaryParameters)
		Query._parseCommon(self, response)

		self.list = []
		# If we used None as the entity ID then we get a list of container entity names
		if self.entity == None:
			for entity in response.firstChild.childNodes:
				# Call constructor on the appropriate class
				item = ContainerEntity()
				item.parseDom(entity)
				self.list.append(item)

		# Otherwise we queried for content entities below the specific container
		else:
			if self.entityName == 'videocliptype':
				className = VideoClipEntity
			else:
				className = ContentEntity

			if self.entityName == 'content' and \
				response.firstChild.tagName != 'list':
				# Single content item requested. This can contain
				# one 'content' item and one 'personalized' item, undefined
				# order 
				item = className()
				for d in response.childNodes:
					if d.tagName == 'content':
						item.parseDom(d)
					elif d.tagName == 'personalized':
						item.parsePersonalized(d)
					else:
						print "skipping unknown DOM node ", d.tagName

				self.list.append(item)
			else:
				# mulitple items below
				ttot = 0
				timp = 0
				t0 = time()
				for d in response.firstChild.childNodes:
					item = className()
					item.parseDom(d)
					self.list.append(item)

		# Sort by name, unless its some toplist
		if self.entity not in ('bestsell', 'latest'):
			# Sort unless toplist
			self.list.sort(key = lambda s: s.name)
		
	
	def submit (self):
		self._query()
	
	def pageNext (self):
		result = Query.pageNext(self)
		if result:
			self._query()
		return result
	
	def pagePrev (self):
		result = Query.pagePrev(self)
		if result:
			self._query()
		return result


class RentalsQuery (Query):
	def __init__ (self, api, limit = Query.DEFAULT_LIMIT, **namedParameters):
		Query._checkInitialParameters(self, **namedParameters)
		Query.__init__(self, api, limit)
		self.parameters = namedParameters
		# Rental queryes always fetch everything
		self.parameters['limit'] = -1
		# Keep the info to a minimum
		self.parameters['fields'] = 'name'
		self._query()

	def _query (self):
		response = self.api.rentals(**self.parameters)
		Query._parseCommon(self, response)
		self.list = []

		# Generic listing context; first child is list.
		for child in response.firstChild.childNodes:
			rental = PurchasedItem()
			rental.parseDom(child)
			self.list.append(rental)
	
	def submit (self):
		self._query()
	
	def pageNext (self):
		result = Query.pageNext(self)
		if result:
			self._query()
		return result
	
	def pagePrev (self):
		result = Query.pagePrev(self)
		if result:
			self._query()
		return result

class APIAbstraction:
	def __init__ (self):
		# Please dont steal our key.. :) Send an email to 
		# api@headweb.com and you'll get your own for free, documentation
		# can be found at http://opensource.headweb.com/api
		key = 'c9c644f2919f4bd39306487802ce35a9'
		self.api = APIv4(key, BoxeeAuthStore.BoxeeAuthStore)

		# Some cached values
		self.userInfo = None
		self.rentalsCache = None

	def isAuthed(self):
		return self.api.isAuthed()
	
	def login (self, username, password, **namedParameters):
		userInfo = UserInfo()
		response = self.api.login(username, password, **namedParameters)
		userInfo.parseDom(response.firstChild)
		return userInfo

	def logout(self):
		self.userInfo = None
		self.api.logout()
		
	def signUp (self, mail, password, **namedParameters):
		response = self.api.signUp(mail, password, **namedParameters)
		return response
	
	def search (self, searchString, limit = Query.DEFAULT_LIMIT, \
			**namedParameters):
		query = SearchQuery(self.api, searchString, limit, **namedParameters)
		return query
	
#	def keyword (self, keywordId = None, limit = Query.DEFAULT_LIMIT, \
#			**namedParameters):
#		return ContainerEntityQuery(self.api, 'keyword', keywordId, limit, **namedParameters)
	
	def genre (self, genreId = None, limit = Query.DEFAULT_LIMIT, \
			**namedParameters):
		# Fetch serverside by pubdate, since we have limit and paging is non-working..
		# Note that the ContainerEntityQuery sorts alphabetically after it fetched from server!
		namedParameters['sort'] = '-pubdate'
		return ContainerEntityQuery(self.api, 'genre', genreId, limit, **namedParameters)
		
#	def directory (self, directoryId = None, limit = Query.DEFAULT_LIMIT, \
#			**namedParameters):
#		return ContainerEntityQuery(self.api, 'directory', directoryId, limit, **namedParameters)
		
	def content (self, contentId = None, limit = Query.DEFAULT_LIMIT, \
			**namedParameters):
		return ContainerEntityQuery(self.api, 'content', contentId, limit, **namedParameters)
	
#	def videocliptype (self, clipId = None, limit = Query.DEFAULT_LIMIT, \
#			**namedParameters):
#		return ContainerEntityQuery(self.api, 'videocliptype', clipId, limit, **namedParameters)

	def isOwned (self, content):
		"""Check if a certain streamable is owned or not."""
		if content.stream.personalized:
			return content.stream.owned

		rentals = self.rentals()
		for c in rentals:
			if c.state in ('available', 'timeleft'):
				if c.id == id:
					return True

		return False
	
	def purchase (self, payment, items, total, extra  = None, \
			**namedParameters):
		purchase = None
		response = self.api.purchase(payment, items, total, extra)
		purchase = PurchaseResponse()
		purchase.parseDom(response)

		# Flush cached values which most likely have changed now
		self.userInfo = None
		self.rentalsCache = None
		
		return purchase

	def redemptionInfo(self, code):
		response = self.api.redemptionInfo(code)

		ri = RedemptionInfo()
		ri.parseDom(response);

		return ri
	
#	def activate (self, authcode, authmode):
#		"""Activates an SMS purchase."""
#		response = ActivationResponse()
#		parser = self.api.activate(authcode, authmode)
#		response.parseDom(parser.firstChild.firstChild)
#		
#		return response
	
	def user (self):
		if self.userInfo == None or time() - self.userInfoTime > 120:
			self.userInfo = UserInfo()
			response = self.api.user()
			self.userInfo.parseDom(response.firstChild)
			self.userInfoTime = time()

		return self.userInfo
	
	def rentals (self):
		if self.rentalsCache == None or time() - self.rentalsCacheTime > 120:
			self.rentalsCache = RentalsQuery(self.api)
			self.rentalsCacheTime = time()

		return self.rentalsCache
	
	def makeStreamPath(self, streamID, authmode=None, **kwArgs):
		return self.api.makeStreamPath(streamID, authmode, **kwArgs)
	

def parseBoolean (node):
	"""Attempts to parse a minidom node containing a boolean value."""
	text = node.nodeValue
	if text:
		# Remove leading and trailing whitespace and transform to lowercase.
		text = text.strip().lower()
		if text == 'true':
			return True
		elif text == 'false':
			return False
		else:
			raise InvalidValueException(text)
	else:
		raise InvalidValueException(text)

def parseInteger (node):
	"""Attempts to parse a minidom node containing an integer value."""
	text = node.nodeValue
	if text:
		# Remove leading and trailing whitespace and transform to lowercase.
		text = text.strip().lower()
		text = int(text)
	else:
		raise InvalidValueException(text)

def parseReal (node):
	"""Attempts to parse a minidom node containing a real/float value."""
	text = node.nodeValue
	if text:
		# Remove leading and trailing whitespace and transform to lowercase.
		text = text.strip().lower()
		text = float(text)
	else:
		raise InvalidValueException(text)

def parseString (node):
	"""Attempts to parse a minidom node containing a string value."""
	text = node.nodeValue
	if text:
		return text
	else:
		raise InvalidValueException(text)

def parseDate (node):
	"""Attempts to parse a minidom node containing a date value."""
	if node.hasAttribute('utc'):
		date = datetime.fromtimestamp(int(node.getAttribute('utc')))
	else:
		raise MissingAttributeException('utc')
	
	return date

# Create only one single global API instance, this handles
# all session keeping & login stuff. We do NOT want to create
# new instances for every page load, or we'll loose state.
# 
# Use getAPI to obtain the API.
appstate = { 'api' : APIAbstraction(), 'authed':0 }
def getAppstate():
	global appstate
	return appstate

def getAPI():
	return getAppstate()['api']

