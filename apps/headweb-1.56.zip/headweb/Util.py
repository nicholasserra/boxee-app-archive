import time, re, os, cookielib
import traceback, sys

# MozillaCookieJar._really_load doesnt seem to be able
# to properly load curl/boxee cookies. 
# This is BoxeeCookieJar which inherits MozillaCookieJar, but overrides
# the _really_load function with something proper.
class BoxeeCookieJar(cookielib.MozillaCookieJar):
	def _really_load(self, f, filename, ignore_discard, ignore_expires):
		now = time.time()

		contents = f.read()
		if not re.search(self.magic_re, contents):
			f.close()
			raise cookielib.LoadError(
				"%r does not look like a Netscape format cookies file" %
				filename)

		try:
			contents = contents.split('\n')
			for line in contents:

				# last field may be absent, so keep any trailing tab
				if line.endswith("\n"): line = line[:-1]

				# skip comments and blank lines XXX what is $ for?
				if (line.strip().startswith("#") or
					line.strip() == ""):
					continue

				domain, domain_specified, path, secure, expires, name, value = \
					line.split("\t")
				secure = (secure == "TRUE")
				domain_specified = (domain_specified == "TRUE")

				if name == "":
					# cookies.txt regards 'Set-Cookie: foo' as a cookie
					# with no name, whereas cookielib regards it as a
					# cookie with no value.
					name = value
					value = None

				initial_dot = domain.startswith(".")
				assert domain_specified == initial_dot

				discard = False
				if expires == "":
					expires = None
					discard = True

				# assume path_specified is false
				c = cookielib.Cookie(0, name, value,
						None, False,
						domain, domain_specified, initial_dot,
						path, False,
						secure,
						expires,
						discard,
						None,
						None,
						{})
				if not ignore_discard and c.discard:
					continue
				if not ignore_expires and c.is_expired(now):
					continue

				self.set_cookie(c)

		except IOError:
			raise
		except Exception:
			traceback.print_exc(file=sys.stdout)
			raise cookielib.LoadError("invalid Netscape format cookies file %r: %r" %
				(filename, line))


