import mc
import xbmcgui
import os
from xml.dom import minidom
from Headweb.API import APIv4, APIError
from Util import BoxeeCookieJar
from HeadwebObjects import StreamEntity, VideoClipEntity
from  datetime import date
import traceback, sys

BOXEE_PLUGIN_VERSION="1.56"
BOXEE_PLUGIN_DEBUG=False
if BOXEE_PLUGIN_VERSION.find('%') != -1:
	# Set dev version  if the above havn't
	# been replaced
	BOXEE_PLUGIN_VERSION="0.00"

BOXEE_PLUGIN_DEBUG = True
if BOXEE_PLUGIN_DEBUG == True:
	# Debug has been changed in code, not %debug..%
	APIv4.DEBUG = BOXEE_PLUGIN_DEBUG

def utf8(str):
	return unicode(str).encode('utf-8')

def setLabel(id, str):
	return mc.GetActiveWindow().GetLabel(id).SetLabel(unicode(str).encode('utf-8'))

def updateUserinfo(api):
	userdata = api.user()
	balance = userdata.balance.nodecimals
	setLabel(1000, balance)
	setLabel(1100, userdata.userName)

def apiErr2msg(e):
	if e.errstr == 'error.api.invalid.parameter' :
		print " param-err",e.parameterName, e.parameterErrstr, e.parameterReason
		if e.parameterName != None and e.parameterReason != None:
			return utf8('%s: %s' % (e.parameterName.capitalize(), e.parameterReason)) 
		elif e.parameterReason != None:
			return utf8(e.parameterReason) 

	return utf8(e.reason)

		
def initMenu (api, config):
	# Should always be authed
	if not api.isAuthed():
		# If we logout we get droped here
#		mc.ShowDialogOk('Logged out', 'Unexepected logout. Please relogin.')
		mc.GetActiveWindow().ClearStateStack(False)
		mc.ActivateWindow(14002)
		return

	if not mc.GetActiveWindow().GetLabel(1000).IsVisible():
		items = mc.ListItems()
			
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		item.SetLabel('Best sellers')
		items.append(item)
		
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		item.SetLabel('New releases')
		items.append(item)
		
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		item.SetLabel('Genres')
		items.append(item)
		
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		item.SetLabel('Search')
		items.append(item)
		
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		item.SetLabel('My movies')
		items.append(item)
		
		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		item.SetLabel('Logout')
		items.append(item)
		
		mc.GetActiveWindow().GetList(100).SetItems(items)
	
	# Load user data & update balance
	updateUserinfo(api)
	
	# Initial menu choice
	config.SetValue('com.headweb.pagetitle', 'Best sellers')

	# Fetch the topnews
	topnews(api)
	mc.GetActiveWindow().GetLabel(1000).SetVisible(True)
	mc.GetActiveWindow().GetImage(9010).SetVisible(True)
	mc.GetActiveWindow().GetImage(9020).SetVisible(True)

	setLabel(1010, config.GetValue('com.headweb.pagetitle'))

def initFilmMenu (api, id):	
	wnd = mc.GetActiveWindow()
	wnd.GetButton(100).SetVisible(False)
	wnd.GetButton(110).SetVisible(False)
	wnd.GetList(130).SetVisible(False)

	updateUserinfo(api)

	mc.ShowDialogWait()
	contents = api.content(id)
	mc.HideDialogWait()

	content = contents.first()

	# Any trailers?
	wnd.GetButton(110).SetEnabled(False)
	for vc in content.videoclips:
		if vc.type == VideoClipEntity.VIDEOCLIPTYPE_TRAILER:
			wnd.GetButton(110).SetEnabled(True)
			break
	
	items = mc.ListItems()
	
	item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
	item.SetThumbnail(unicode(content.getCover(1).url).encode('utf-8'))
	items.append(item)
	wnd.GetList(130).SetItems(items)

	owned = api.isOwned(content)
	
	# Can we rent it?
	wnd.GetButton(100).SetEnabled(True)
	if not content.stream.rental_allowed or not content.stream.rental_allowed_api:
		wnd.GetButton(100).SetEnabled(False)
	elif content.stream.type != StreamEntity.TYPE_FLASH:
		wnd.GetButton(100).SetEnabled(False)
		mc.ShowDialogOk('This movie is unavailable', 'Silverlight movies are not supported in Boxee.')
	
	setLabel(1010, content.name)
	plot = content.plot
	plot = plot.replace('<p>', '').replace('</p>', "\n\n")
	plot = plot.replace('<b>', '').replace('</b>', '')
	plot = plot.replace('<h2>', '').replace('</h2>', '')
	plot = plot.replace('<br />', "\n").replace('<br/>', "\n")
	setLabel(1020, plot)

	setLabel(1030, str(int(content.stream.runtime/60)) + ' min')
	setLabel(1040, content.year)
	setLabel(1050, content.genre)

	if content.stream.price.raw == 0:
		setLabel(1060, 'Free');
	else:
		setLabel(1060, content.stream.price.humanReadable)

	d = date.fromtimestamp(content.stream.publishingDate)
	setLabel(1070, d.strftime("%Y-%m-%d"))

	audiolang = ', '.join(content.stream.audios)
	setLabel(1080, audiolang)
	
	if len(content.stream.subtitles) == 0:
		subtitles = 'No subtitles'
	else:
		subtitles = ', '.join(map(lambda x: x.language, content.stream.subtitles))

	setLabel(1090, subtitles)
	
	wnd.GetButton(100).SetVisible(True)
	wnd.GetButton(110).SetVisible(True)
	wnd.GetList(130).SetVisible(True)
	
	if wnd.GetButton(100).IsEnabled():
		wnd.GetButton(100).SetFocus()
	elif wnd.GetButton(110).IsEnabled():
		wnd.GetButton(110).SetFocus()
	else:
		wnd.GetButton(120).SetFocus()

	if owned or content.stream.price.raw == 0:
		wnd.GetButton(100).SetLabel('Watch movie')


	return content




def initLogin (api):
	mc.ShowDialogWait()
	data = api.content('bestsell', limit=3)
	mc.HideDialogWait()
	
	items = mc.ListItems()
	i = 0
	for movie in data:
		try:
			if movie.stream != None and i < 3:
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				item.SetThumbnail(unicode(movie.getCover(1.0).url).encode('utf-8'))
				items.append(item)	
				
				i += 1
		except:
			pass

	setLabel(1011, BOXEE_PLUGIN_VERSION)

	mc.GetActiveWindow().GetList(150).SetItems(items)

def menuButtonClicked (api, item, config):
	mc.GetActiveWindow().GetLabel(1110).SetVisible(False)
	mc.GetActiveWindow().GetLabel(1120).SetVisible(False)
	
	if item.GetLabel() == 'Best sellers':
		config.SetValue('com.headweb.pagetitle', item.GetLabel())
		topnews(api)
	elif item.GetLabel() == 'Genres':
		config.SetValue('com.headweb.pagetitle', item.GetLabel())
		genres(api)
	elif item.GetLabel() == 'New releases':
		config.SetValue('com.headweb.pagetitle', item.GetLabel())
		latest(api)
	elif item.GetLabel() == 'Search':
		config.SetValue('com.headweb.pagetitle', item.GetLabel())
		search(api)
	elif item.GetLabel() == 'My movies':
		config.SetValue('com.headweb.pagetitle', item.GetLabel())
		rentals(api)
	elif item.GetLabel() == 'Logout':
		logout(api, config)

def topnews (api):
	setLabel(1010, 'Best sellers')
	mc.ShowDialogWait()
	data = api.content('bestsell', limit=100)
	mc.HideDialogWait()
	listFilms(data)

def genres (api):
	setLabel(1010, 'Genres')
	mc.ShowDialogWait()
	data = api.genre(None)
	mc.HideDialogWait()
	listGenres(data)

def genre (api, item, config):
	setLabel(1010, item.GetLabel())
	mc.ShowDialogWait()
	data = api.genre(item.GetProperty('id'))
	mc.HideDialogWait()
	config.SetValue('com.headweb.pagetitle', item.GetLabel())
	listFilms(data)

def latest (api):
	setLabel(1010, 'New releases')
	mc.ShowDialogWait()
	data = api.content('latest', limit=100)
	mc.HideDialogWait()
	listFilms(data)

def search (api):
	setLabel(1010, 'Search')
	q = mc.ShowDialogKeyboard('Search', '', False)
	if q:
		mc.ShowDialogWait()
		data = api.search(q, limit=40)
		mc.HideDialogWait()
		listFilms(data)
	else:
		data = []
		listFilms(data)
	
def rentals (api):
	setLabel(1010, 'My movies')
	mc.ShowDialogWait()
	data = api.rentals()
	mc.HideDialogWait()
	listRentals(data)

def login (api, config):
	username = mc.ShowDialogKeyboard('Username or e-mail', '', False)
	if username == None:
		return

	if username.strip() == '':
  		mc.ShowDialogOk('Username required', 'You have to enter your username/email.')
		return

	password = mc.ShowDialogKeyboard('Password', '', True)
	if password == None:
		return

	if password.strip() == '':
  		mc.ShowDialogOk('Password required', 'You have to enter your password.')
		return

	mc.ShowDialogWait()
	try:
		userdata = api.login(username, password)
		# Successfull login, close this window to pop back to main window.
		mc.CloseWindow()
	except APIError, e:
		if e.errstr == 'headweb.error.wronguserorpassword':
			mc.ShowDialogOk('Wrong username or password',
					'The username and password you entered didn\'t match.')
		else:
			mc.ShowDialogOk('Failed to authenticate',
					'An error occured while authenticating: '+ apiErr2msg(e) +  
					'\n. Please verify your username and password, also make sure that you\'re connected to the internet.')
	except Exception, e:
		traceback.print_exc(file=sys.stdout)
		mc.ShowDialogOk('Failed to authenticate',
				'An error occured while authenticating. '+ 
				'Please make sure that you\'re connected to the internet. (%s)' %  \
				utf8(str(e)))

	mc.HideDialogWait()

def logout (api, config):
	api.logout()
	initMenu(api, config)

def signUp (api, config):	
	mail = mc.ShowDialogKeyboard('E-mail', '', False)
	if mail == None:
		return

	if mail.strip() == '':
  		mc.ShowDialogOk('E-mail required', 'You have to enter an e-mail.')
		return
	
	password = mc.ShowDialogKeyboard('Password', '', True)
	if password == None:
		return

	if password.strip() == '':
  		mc.ShowDialogOk('Password required', 'You have to enter a password.')
		return
			
	mc.ShowDialogWait()
	try:
		try:
			try:
				api.signUp(mail, password)
				# Successfull signup, lets drop down and login
			except APIError, e:
				mc.ShowDialogOk('Failed to register', apiErr2msg(e))
				return

			# OK; login
			try:
				userdata = api.login(mail, password)
			except APIError, e:
				mc.ShowDialogOk('Failed to login', apiErr2msg(e))
				return

			# Successfull login, close this window to make onunload trigger
			# main window to show.
			mc.CloseWindow()

		except Exception, e:
			traceback.print_exc(file=sys.stdout)
			mc.ShowDialogOk('Failed to authenticate',
					'An error occured while authenticating. '+ 
					'Please make sure that you\'re connected to the internet. (%s)' % \
						utf8(str(e)))
	finally:
		mc.HideDialogWait()

def showMovie (api, item, config):
	mc.ShowDialogWait()
	params = mc.Parameters()
	params['id'] = item.GetProperty('id')

	mc.HideDialogWait()
	mc.GetApp().ActivateWindow(14001, params)

def listFilms (data):	
	items = mc.ListItems()
	i = 0
	for movie in data:
		try:
			if movie.stream != None:
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				item.SetLabel(unicode(movie.name).encode('utf-8'))
				item.SetTitle(unicode(movie.name).encode('utf-8'))
				item.SetThumbnail(unicode(movie.getCover(1.0).url).encode('utf-8'))
				item.SetProperty('id', unicode(movie.id).encode('utf-8'))
				item.SetProperty('streamid', unicode(movie.stream.id).encode('utf-8'))
				item.SetProperty('price', unicode(movie.stream.price).encode('utf-8'))
				items.append(item)	
				
				i += 1
		except:
			pass
	
	mc.GetActiveWindow().GetList(110).SetItems(items)

	mc.GetActiveWindow().GetList(120).SetVisible(False)
	mc.GetActiveWindow().GetList(110).SetVisible(True)
	mc.GetActiveWindow().GetList(110).SetFocus()
	
	if i == 0:
		mc.GetActiveWindow().GetLabel(1120).SetVisible(True)

def listRentals (data):
	items = mc.ListItems()
	i = 0
	for movie in data:
		try:
			if movie.state == 'available' or movie.state == 'timeleft':
				item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
				item.SetLabel(unicode(movie.name).encode('utf-8'))
				item.SetTitle(unicode(movie.name).encode('utf-8'))
				item.SetThumbnail(unicode(movie.content.getCover(1.0).url).encode('utf-8'))
				item.SetProperty('id', unicode(movie.content.id).encode('utf-8'))
				item.SetProperty('streamid', unicode(movie.content.stream.id).encode('utf-8'))
				item.SetProperty('price', 'your')
				items.append(item)
				
				i += 1
		except:
			pass
	
	mc.GetActiveWindow().GetList(110).SetItems(items)

	mc.GetActiveWindow().GetList(120).SetVisible(False)
	mc.GetActiveWindow().GetList(110).SetVisible(True)
	mc.GetActiveWindow().GetList(110).SetFocus()
	
	if i == 0:
		mc.GetActiveWindow().GetLabel(1110).SetVisible(True)

def listGenres (data):
	items = mc.ListItems()
	for genre in data:
		if genre.id == 128535:
			# XXX API is broken, should hide this!
			continue

		item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		item.SetLabel(unicode(genre.name).encode('utf-8'))
		item.SetTitle(unicode(genre.name).encode('utf-8'))
		item.SetProperty('id', unicode(genre.id).encode('utf-8'))
		items.append(item)

	mc.GetActiveWindow().GetList(120).SetItems(items)
	
	mc.GetActiveWindow().GetList(110).SetVisible(False)
	mc.GetActiveWindow().GetList(120).SetVisible(True)
	mc.GetActiveWindow().GetList(120).SetFocus()

def startPurchase (api, content):
	owned = api.isOwned(content)
	price = content.stream.price

	if not owned and price.raw > 0:
		# Non free/not owned, activate payment dialog
		global purchaseDialogData
		purchaseDialogData = {'content': content}

		mc.ActivateWindow(14020)
	else:
		# Free video or owned, just start it.
		_purchaseDoneStartVideo(api, content)

def _performPurchase (api, payment, items, total, redemptionCode=None):
	"""Helper to actually perform a purchase. Returns true on ok, false on error."""
	purchase = api.purchase(payment, items, total, redemptionCode)
	if purchase.error != None:
		err = purchase.error.message
		if purchase.error.errstr == 'headweb.error.purchasefailedearly':
			# Look for item error instead
			err = purchase.items[0].error.message

		mc.ShowDialogOk('The purchase failed', utf8(err))
		return False
	
	return True

def _purchaseDoneStartVideo(api, content):
	"""Helper to start watching an owned/free movie"""
	# Setup subtitle choice dialog.
	if len(content.stream.subtitles)	> 0:
		global subtitleDialogData
		subtitleDialogData = {'content': content}
		# If there are subtitles, call uppon subtitle dialog.
		# the subtitleDialogData can be accessed through HeadwebObj.subtitleDialogData 
		# and is considered valid for the duration of that window.
		
		mc.ActivateWindow(14010)
	else:
		# If there are no subtitles, play movie.
		playMovie(api, content)				

def purchase (api, content):
	user = api.user()
	
	owned = api.isOwned(content)
	price = content.stream.price

	if not owned and user.balance.raw < price.raw:
		mc.ShowDialogOk('Not enough money',
				"You don't have enough money on your account. Please use your computer to fill up your account.")
		return
	else:
		if not owned and price.raw > 0:
			response = mc.ShowDialogConfirm('Rent movie',
					("Are you sure that you want to rent the movie %s? "+
					"%s will be withdrawn from your account. "+
					"The movie will start playing immediately and you'll have "+
					"24 h to watch it.") % (utf8(content.name),
						utf8(price.humanReadable))
					, 'Cancel', 'Rent')
			if not response:
				return
	
	try:
		mc.ShowDialogWait()
		try:
			# Purchase it, unless its free.
			if not owned and price.raw != 0:
				# Returns false on failure
				if not _performPurchase(api, APIv4.PAYMENT_ACCOUNT, [content.stream.id], price.raw):
					return

			# for freeitems and successfull purchases, start watching 
			_purchaseDoneStartVideo(api, content)
		except APIError, e:
			mc.ShowDialogOk('The purchase failed', apiErr2msg(e))
		except Exception, e:
			traceback.print_exc(file=sys.stdout)
			mc.ShowDialogOk('The purchase failed',
					'The purchase could not be processed. (%s)' % utf8(str(e)))

	finally:
		mc.HideDialogWait()

def purchaseWithGiftCard (api, content):
	user = api.user()
	
	owned = api.isOwned(content)
	price = content.stream.price
	redemptionCode = None

	if not owned and price.raw > 0:
		redemptionCode = mc.ShowDialogKeyboard('Enter your code', '', False)
		if not redemptionCode:
			return
	
	try:
		mc.ShowDialogWait()
		try:
			# Purchase it, unless its free.
			if not owned and price.raw != 0:
				ri = api.redemptionInfo(redemptionCode)

				# We only support free items right now.
				if ri.type == 'specific':
					if not content.stream.id in ri.itemId :
						mc.ShowDialogOk('Invalid item',
								'Sorry, this code is not valid for this item.')
						return
					# Else we should be OK.

				elif ri.type == 'freeitem':
					if ri.minItems > 1:
						# Could have a better msg here but..
						mc.ShowDialogOk('Use code on computer',
								'Sorry, this code can not be used in the Boxee app.'+\
										' Please follow the instructions you have received with this code.')
						return

				# For rebate or others, bork.
				elif ri.type == 'rebate':
					mc.ShowDialogOk('Use code on computer',
							'Sorry, rebate codes are currently not supported in our Boxee app.'+\
									' Please use your computer to use this code.')
					return
				else:
					mc.ShowDialogOk('Use code on computer',
							'Sorry, this code can not be used in the Boxee app.'+\
									' Please follow the instructions you have received with this code.')
					return

				# Guess we're good. Go!
				if not _performPurchase(api, APIv4.PAYMENT_CODE, [content.stream.id], 0, redemptionCode):
					return

			# for freeitems and successfull purchases, start watching 
			_purchaseDoneStartVideo(api, content)

		except APIError, e:
			mc.ShowDialogOk('The purchase failed', apiErr2msg(e))
		except Exception, e:
			traceback.print_exc(file=sys.stdout)
			mc.ShowDialogOk('The purchase failed',
					'The purchase could not be processed. (%s)' % utf8(str(e)))

	finally:
		mc.HideDialogWait()

def purchaseWithSubscription(api, content, subscriptionId, subscriptionLabel):
	user = api.user()
	
	owned = api.isOwned(content)
	price = content.stream.price

	if not owned:
		response = mc.ShowDialogConfirm('Rent movie',
				("Are you sure that you want to rent the movie %s? "+
				"One '%s' ticket will be used. "+
				"The movie will start playing immediately and you'll have "+
				"24 h to watch it.") % (utf8(content.name),
					utf8(subscriptionLabel))
				, 'Cancel', 'Rent')
		if not response:
			return

	try:
		mc.ShowDialogWait()
		try:
			if not _performPurchase(api, APIv4.PAYMENT_SUBSCRIPTION, \
						[content.stream.id], 0, subscriptionId):
				return

			# for freeitems and successfull purchases, start watching 
			_purchaseDoneStartVideo(api, content)

		except APIError, e:
			mc.ShowDialogOk('The purchase failed', apiErr2msg(e))
		except Exception, e:
			traceback.print_exc(file=sys.stdout)
			mc.ShowDialogOk('The purchase failed',
					'The purchase could not be processed. (%s)' % utf8(str(e)))

	finally:
		mc.HideDialogWait()
	
def playMovie(api, content, subtitle=-1):
	try:
		userdata = api.user()
		
		listItem = mc.ListItem(mc.ListItem.MEDIA_FILE)
		listItem.SetLabel(utf8(content.name))
		path = api.makeStreamPath(content.stream.id, sublang=subtitle)
#		print "got straempath ",path

		# Clear out any headweb cookies in the boxee cookiejar
		# If we don't, there is risk that an old jsessionid
		# is feed to the browser, creating problems with invalid session
		# and only showing preview instead of full movie.
		jarFile = mc.GetCookieJar()
		if os.path.isfile(jarFile):
			jar = BoxeeCookieJar(jarFile)
			try:
				jar.load(jarFile, True, True) # Ignore discarded/expired

				# Try to remove, raises KeyError if not set
				jar.clear(".headweb.com")

				print "headweb cookies cleared out from boxee-jar; saving"
				jar.save(jarFile, True, True) # Again, ignore discarded/expired
			except KeyError:
				print "No cookies found for clearing"
				pass

		listItem.SetPath(path)

		player = mc.GetPlayer()
		player.Play(listItem)
	except Exception, e:
		traceback.print_exc(file=sys.stdout)
		mc.ShowDialogOk('Video failed', 'Failed to start video (%s)' % utf8(str(e)))

	mc.HideDialogWait()

def playTrailer(content):
	listItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_TRAILER)
		
	listItem.SetLabel(utf8(content.name))
	# Find first trailer
	for vc in content.videoclips:
		if vc.type == VideoClipEntity.VIDEOCLIPTYPE_TRAILER:
			# highest bitrate is last
			br = vc.bitrates[-1]
			listItem.SetPath(utf8(br.url))
			break
	
	player = mc.GetPlayer()
	player.Play(listItem)


