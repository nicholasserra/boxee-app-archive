import sha, cookielib
from API import APIv4

import traceback,sys

class BaseAuthStore(object):
	"""A platform-indepent AuthStore base to be used together with the APIv3 module.
	This is only a base class, which should be extended by an implementation.
	The implementation has to provide a few functions to store one value named 'trid',
	which is device-specific. Generally this wont change after first set.
	It should also store a value named 'hwpl' which will be updated on every 
	authentication.

	If possible, split storage is prefered, ie store trid locally and hwpl on a remote
	server, for example associated with the user account. If multiple devices
	can share the same remote storage, then the hwpl value shall be key'ed on
	the value 'self.trid_hash' (NOT the actual trid!).

	If not possible, they can be stored together on the same device, but this
	means less security.
	"""
	def __init__(self, cookieJar, host):
		self.cookieJar = cookieJar
		self.host = host

		self.trid = None
		self.trid_hash = None
		self.hwplCookie = None

		# Implementation specific
		trid = self._readStoredTrid()

		# Try to find a trid in our local app config
		if trid == None or trid == "":
			# No, trid nothing else to do.
			return

		# Else, we've got a trid, keep it.
		self._setTrid(trid, True)

		# Check for a hwpl cookie at boxee
		try:
			hwpl = self._getCreds()
		except:
			print "Failed to get credentials, ignoring."
			traceback.print_exc(file=sys.stdout)
			return

		if hwpl == None:
			#print "No valid credentials for this trid (%s=>%s)" % (self.trid,self.trid_hash)
			return 

		# Create a cookie and store it in the cookiejar
		hwpl = cookielib.Cookie(version=0, name='hwpl', value=hwpl,
				port=None, port_specified=False,
				domain=self.host, domain_specified=True, domain_initial_dot=True, 
				path='/', path_specified=True, 
				secure=False, expires='1600000000', 
				discard=False, comment=None, comment_url=None, rest={})

		# Push cookies into local cookiestore
		self.cookieJar.set_cookie(hwpl)
		# Keep ref to it for update()
		self.hwplCookie = hwpl

		#print "Credentials found"

	def hasCredentials(self):
		if self.trid != None and self.hwplCookie != None:
			return True

		return False

	def erase(self):
		"""Erases stored credentials for this device"""
		try:
			self._storeCreds(None)
		except:
			print "Failed to clear credentials"
			traceback.print_exc(file=sys.stdout)

		# Never erase trid from local config, we'd like to keep that.
		# always erase hwpl cookie
		try:
			self.cookieJar.clear(self.host, '/', 'hwpl');
		except KeyError:
			pass
		self.hwplCookie = None

	def update(self):
		"""Reads any new cookies out of the cookiejar for new credentials. Should
		be called at least one time after the first request (with the getCookies flag
		set to True) have been made using stored credentials."""

		# Extract values of hwpl/trid from the cookiejar
		hwpl = None
		trid = None
		for c in self.cookieJar:
			if c.name == 'trid':
				trid = c.value
			elif c.name == 'hwpl':
				hwpl = c

		if trid == None:
			raise Exception("Missing 'trid' cookie in local cookiestore!")
		if hwpl == None:
			raise Exception("Missing 'hwpl' cookie in local cookiestore!")

		# If the cookies are identical to what is already stored, ignore it.
		if self.hwplCookie != None and self.hwplCookie.value == hwpl.value:
			return

		# If the trid is new/changed (odd), store it.
		if self.trid != trid:
			if APIv4.DEBUG:
				print "Updating/setting trid %s (old %s)" % (trid, self.trid)

			# update local vars/cookies
			self._setTrid(trid, False) # From cookie, dont re-set it.

			# and store in implementation 
			self._storeTrid(trid)

		# Store the new credentials
		try:
			if APIv4.DEBUG:
				if self.hwplCookie == None:
					print "Storing hwpl creds %s" % hwpl.value
				else:
					print "Updating hwpl creds %s (old %s)" % (hwpl.value,
							self.hwplCookie.value)

			self._storeCreds(hwpl.value)
		except:
			print "Failed to store remote credentials"
			traceback.print_exc(file=sys.stdout)

		# Keep the hwpl cookie for further updates.
		self.hwplCookie = hwpl



	def _setTrid(self, trid, setCookie=True):
		"""Sets the currently used trid & hash it. Should probably only be called
		once at startup, and once at the very first request ever made for this device"""
		self.trid = trid
		self.trid_hash = sha.new(trid.lower()).hexdigest()

		# Store cookie aswell, unless told not to.
		if not setCookie:
			return

		cookie = cookielib.Cookie(version=0, name='trid', value=trid,
				port=None, port_specified=False,
				domain=self.host, domain_specified=True, domain_initial_dot=True, 
				path='/', path_specified=True, 
				secure=False, expires='1600000000', 
				discard=False, comment=None, comment_url=None, rest={})

		self.cookieJar.set_cookie(cookie)


	# The following should be implemented by a subclass
	def _readStoredTrid(self):
		"""This function shall return the trid as stored in local configuration"""
		return None

	def _storeTrid(self, trid):
		"""This function shall store the trid in local configuration"""
		raise Exception("Not implemented in subclass!")

	def _getCreds(self):
		"""Fetches credentials for current trid (trid_hash), or None if not found."""
		raise Exception("Not implemented in subclass!")

	def _storeCreds(self, hwpl):
		"""Stores credentials for current trid (trid_hash), or removes if hwpl is None"""
		raise Exception("Not implemented in subclass!")

