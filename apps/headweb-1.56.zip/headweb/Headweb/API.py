import urllib, urllib2, urlparse, re, cookielib,sys, traceback
from xml.dom import minidom
from time import time

class APIError(Exception):
	def __init__(self, errstr, reason):
		self.errstr = errstr
		self.reason = reason

		self.parameterName = None
		self.parameterErrstr = None
		self.parameterReason = None

	def __str__(self):
		# Do not return reason here, 'print'ing it might have unforseen
		# consequences such as python encoding problems..
		return "%s" % self.errstr


class APIv4:
	# Class constants / default values.
	VERSION = 4
	DEFAULT_LIMIT = 10
	DEFAULT_OFFSET = 0

	DEBUG = False
	PAYMENT_ACCOUNT = 'account'
	PAYMENT_CODE = 'code'
	PAYMENT_SUBSCRIPTION = 'subscription'


	def debug(self, *str):
		if not APIv4.DEBUG:
			return

		for s in str:
			print s
	
	def __init__ (self, key, authStoreClass, host = 'api.headweb.com'):
		"""Default constructor, takes API host server and API key."""
		self.host = host
		self.apiKey = key

		self.cookieJar = cookielib.CookieJar()
		self.authed = False
		self.jsessionid = None

		self.authStore = authStoreClass(self.cookieJar, self.host)

		self.apiFilter = 'filter(-adult,-stream(silverlight))'

		self.lang = 'en'

		self.debug("APIv4 init")
		if self.authStore.hasCredentials():
			# Perform an initial request to authenticate session for
			# the authstore.
			# The authstore indicates that we got stored credentials,
			# and should have updated the cookiejar accordingly.
			try:
				# Init new session
				self._req('/',
						True, # in HTTPS
						False,
						True) # And fetch cookies

				# _req performs authStore.update automatically for all requests.
			except APIError, e:
				self.debug("Failed to pre-auth: ", e)
			except:
				print "Unexecpected error when fetching "+\
						"user while we have credentials"
				traceback.print_exc(file=sys.stdout)

	
	def search (self, searchString, **keywordArguments):
		"""Performs a search and matches the supplied string against
				keywords, plot and other elements of each content node."""
		
		return self._req('/search/' + urllib.quote(searchString) + '/' + self.apiFilter)
	
	def genre (self, id=None, **kwArgs):
		"""Returns content belonging to a specific genre.
		If id is not set, a list of genres is returned. """
		return self._entityReq('genre', id, True, **kwArgs)

	def keyword (self, id=None, **kwArgs):
		"""Returns content belonging to a specific keyword.
		If id is not set, a list of keywords is returned. """
		return self._entityReq('genre', id, True, **kwArgs)

	def directory(self, id=None, **kwArgs):
		"""Returns content belonging to a specific directory.
		If id is not set, a list of directory is returned. """
		return self._entityReq('directory', id, True, **kwArgs)

	def videocliptype(self, id=None, **kwArgs):
		"""Returns videoclips belonging to a specific videocliptype.
		If id is not set, a list of videocliptypes is returned. """
		return self._entityReq('directory', id, True, **kwArgs)

	def content(self, id=None, **kwArgs):
		"""Returns all contents or a specific content if 'id' is set."""
		return self._entityReq('content', id, False, **kwArgs)

	def _entityReq(self, what, id, doFilter, **kwArgs):
		"""Generic function to fetch a list of items, or a specific item.
		The 'what' parameter indicates what entity type we're fetching, for example genre,
		keyword, content.
		If a specific ID is set, we go one step deeper and fetch that specific entity.
		If doFilter is set, we add the default filter. Note that filtering is not always
		applicable (for example when showing specific content)!
		"""
		uri = '/'+what
		if id != None:
			uri += '/' + str(id)
		
		if doFilter:
			uri += '/filter(-adult,-stream[silverlight])'

		return self._req(uri, **kwArgs)
	

	def login (self, username, password, **kwArgs):
		"""Performs a user login. Will request a persistent login, and the credentials
		will be stored in the Boxee credential store.
		If successfull, all subsequent requests will be executed in a logged in 
		session.
		"""
		
		# Perform a persistent login. This will give us a hwpl cookie which 
		# we can store and feed into the credentials service @ boxee without
		# exposing/storing the users password.
		result = self._req('/user/login', True, True, True,
				username=username,
				password=password,
				persistent='true')
		
		# No need to update authStore, done in _req

		return result
	
	def signUp (self, mail, password, **kwArgs):
		"""Performs a user login. Will request a persistent login, and the credentials
		will be stored in the Boxee credential store.
		If successfull, all subsequent requests will be executed in a logged in 
		session.
		"""
		
		kwArgs['email'] = mail
		kwArgs['password'] = password
		kwArgs['agreeterms'] = 'true'
		
		result = self._req('/user/create', True, True, **kwArgs)
		
		return result
	
	def logout(self):
		"""Explicitly logout, destroying any login cookies both serverside and clientside"""
		self.authStore.erase()
		self._req('/user/logout')

	def isAuthed(self):
		return self.authed
	
	def user (self, **kwArgs):
		"""Returns information about the currently logged in user."""
		return self._req('/user', False, **kwArgs)
	
	def rentals (self, **kwArgs):
		"""Returns a list of active rentals for the logged in user."""
		kwArgs['fields'] = 'stream,cover'
		return self._req('/user/rentals/'+self.apiFilter, **kwArgs)
		
	def purchase (self, payment, item, total, extra = None, **kwArgs):				
		# Check 'payment' parameter for valid values.
		if not payment in (APIv4.PAYMENT_ACCOUNT,
				APIv4.PAYMENT_CODE,
				APIv4.PAYMENT_SUBSCRIPTION):
			raise Exception('Invalid value for payment parameter("' + payment + '").')

		# ALL payment requires login
		if not self.authed:
			raise Exception('Payment requested without login.')

		kwArgs['payment'] = payment
		kwArgs['item'] = str(item[0])
		kwArgs['total'] = "%.2f" % total
		
		if payment == APIv4.PAYMENT_CODE:
			kwArgs['redemptioncode'] = str(extra)
			kwArgs['total'] = '0'
		elif payment == APIv4.PAYMENT_SUBSCRIPTION:
			kwArgs['subscription'] = str(extra)
			kwArgs['total'] = '0'
		
		return self._req('/purchase/0', False, False, False, **kwArgs)

	def redemptionInfo(self, code): 
		kwArgs = {'redemptioncode': code}

		return self._req('/purchase/redemptinfo', False, False, False, **kwArgs);

	def activate (self, id, authcode, **keywordParameters):
		"""Activates an SMS purchase initiated via a call to "purchase".
		Argument 'id' should be the ID of the purchased item (stream).
		"""
		cleanedCode = authcode.upper()
		return self._req('/purchase/activate',
				False, True,
				authcode=cleanedCode,
				id=id);

	def makeStreamPath (self, stream, authmode=None, **kwArgs):
		if authmode != None:
			kwArgs['authmode'] = authmode

		url, data = self._buildReqUrl("/player/plex/%d" % int(stream), False, False, **kwArgs)

		# Find ? and inject jsessionid before
		qpos = url.find('?')
		url = url[0:qpos] + ';jsessionid=' + self.jsessionid + url[qpos:]

		return url

	def _buildReqUrl (self, uri, https, post, **kwArgs):
		# Build URL
		url = "http"
		if https:
			url += "s://"
		else:
			url += "://"

		url += self.host + \
				"/v" + str(self.__class__.VERSION) + \
				uri

		# Add API key to data
		kwArgs['apikey'] = self.apiKey

		# Encode any kwArgs to post/get-data
		data = urllib.urlencode(kwArgs)

		if not post:
			# For GET requests, add kwArgs to URL
			if url.find('?') == -1:
				url += "?" + data
			else:
				url += "&" + data

		return url, data

	def _req (self, uri, https=False, post=False, getCookies=False, **kwArgs):
		"""Dispatches a request to the API.
		
		Arguments:
			uri - String: URI to call, beginning with /
			https - Boolean: perform HTTPS request instead of regular HTTP.
			post - Boolean: perform a POST request instead of GET request.
			getCookies - Boolean: extract any new cookies from the request

		Any other arguments are sent as data with the request.

		If getCookies is False we will return the parsed request as is.
		If getCookies is True we will return a tuple with the parsed request first, followed
		by a set of cookielib.Cookies.
		"""

		# always go with english for now
		if self.lang != None and kwArgs.get('lang') == None:
			kwArgs['lang'] = self.lang

		url, data = self._buildReqUrl(uri, https, post, **kwArgs)

		# For non post-requests, clear out data so we dont do a POST
		if not post:
			data = None
		
		request = urllib2.Request(url, data)

		# Create a opener
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cookieJar))

		# Dispatch request, read response
		self.debug("Dispatching request to "+url)
		t1 = time()
		response = opener.open(request)
		responseData = response.read()
		response.close()
		t2 = time()

		self.debug("Got response, remote took %.4fs" % (t2-t1))
		t1 = time()
		responseBody, authed = self._parseResponse(responseData)
		t2 = time()
		self.debug("Parsing response took %.4fs" % (t2-t1))

		self.authed = authed

		# Always extract cookies, we need to know if we have
		# updated JSESSSIONID etc..
		self.cookieJar.extract_cookies(response, request)

		# Fetch jsessionid
		for c in self.cookieJar:
			if c.name == 'JSESSIONID' and \
				c.value != self.jsessionid:
				self.jsessionid = c.value
				self.debug("Got new JSESSIONID: "+self.jsessionid)
				break

		try:
			if not self.authed:
				self.authStore.erase()
			else:
				# Always call update on authStore, if this is a subsequent req this will
				# be a no-op
				self.authStore.update()
		except:
			print "Unexecpected error when updating authstore "+\
					"in %s req", uri
			traceback.print_exc(file=sys.stdout)

		#self.debug("Got cookies: ", self.cookieJar)

		# Return parsed response
		return responseBody

	def _parseResponse (self, response):
		"""Creates an XML parser instance and performs basic error checking
		before passing the entire parser object back to the calle. Returns the 'response' object."""
		parser = minidom.parseString(response)
		authed = False
		if parser.hasChildNodes() and parser.firstChild.tagName == 'response':
			response = parser.firstChild
			if response.hasChildNodes():
				error = None
				for dom in response.childNodes:
					if dom.tagName == 'error':
						errstr = dom.getAttribute('err')
						reason = dom.firstChild.nodeValue
						error = APIError(errstr, reason)
					elif dom.tagName == 'parameter' and error != None:
						# XXX This assumes error element is first!
						pname = dom.getAttribute('name')
						perr  = dom.getAttribute('err')
						preason = dom.firstChild.nodeValue
						error.parameterName = pname
						error.parameterErrstr = perr
						error.parameterReason = preason

				if error != None:
					raise error

			# Always check if we're logged in
			if response.getAttribute('username') != '':
				authed = True

			return response,authed

		raise Exception('Server XML has no root "response" element.')




