import mc
import HeadwebObjects
import HeadwebObj
import Headweb
import BoxeeAuthStore

# Work around boxee caching
# change to 1 when testing,  no need to reload
# in production release.
if 1:
	print "Reloading code"
	reload(Headweb)
	reload(Headweb.API)
	reload(Headweb.AuthStore)
	reload(BoxeeAuthStore)
	reload(HeadwebObj)
	reload(HeadwebObjects)

# Keep track of login/logout state so we can know
# how to navigate pages since boxee ClearStateStack stuff doesn't seem to 
# work
appstate = HeadwebObjects.getAppstate()
# Uncomment this to test the transfer-to-specific-video feature
# which play.py utilizes
#appstate['init-show-content'] = 248877

# Start main window
mc.GetApp().ActivateWindow(14000, mc.Parameters())

