MY_CHANNELS_TITLE = "My Channels"
MY_CHANNELS_SLUG = "__mychannels__"

POPULAR_CHANNELS_TITLE = "Popular Channels"
POPULAR_CHANNELS_SLUG = "__popularchannels__"

BROWSE_SOURCES_TITLE = "Browse Content Sources"
BROWSE_SOURCES_SLUG = "__browsecontentsources__"