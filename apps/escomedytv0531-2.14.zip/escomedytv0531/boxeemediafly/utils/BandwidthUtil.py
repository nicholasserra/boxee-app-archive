import time, urllib2

speed = 500

def getSpeed(url = None):
	global speed
	if url:
		try:
			start = time.clock()
			response = urllib2.urlopen(url)
			sizeKbytes = len(response.read())/1000*8
			end = time.clock()
			timeDelta = end - start
			speed = int(sizeKbytes / timeDelta)
		except Exception, e:
			pass
	return speed
