import mc

params = mc.Parameters()
mc.GetApp().ActivateWindow(14000, params)

last_list_item = None