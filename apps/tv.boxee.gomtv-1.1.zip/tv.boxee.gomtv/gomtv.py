import cookielib
import mc
import re
import urllib
import urllib2
import simplejson as json

#API_URL = 'https://ssl.gomtv.net/boxee/';
API_URL = 'http://ssl.gomtv.net/boxee/';
PLAYKEY_URL = 'http://ssl.gomtv.net/boxee/playkey.gom';

class MainMenu:

    @staticmethod
    def login(username, password):
        cj = cookielib.CookieJar()
        print '11111111: %s' % cj
        cookiesProcessor = urllib2.HTTPCookieProcessor(cj)
        print '22222222: %s' % cookiesProcessor
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        print '33333333: %s' % headers
        params = urllib.urlencode({ "id": username, "pw": password })
        print '44444444: %s' % params
        opener = urllib2.build_opener(cookiesProcessor)
        print '55555555: %s' % opener
        urllib2.install_opener(opener)
        print '66666666:'
        req = urllib2.Request(API_URL, params, headers)
        print '77777777: %s' % req
        response = urllib2.urlopen(req).read()
        print '88888888: %s' % response
        #response = re.sub(r'^/\*-secure-\n', '', response)
        #response = re.sub(r'\n\*/$', '', response)
        response = json.loads(response)
        print '99999999: %s' % response

        if response.get('result_code') != 1:
            return False

        data = response.get('data')
        print '11112222: %s' % data

        cookies = ''
        for index, val in enumerate(cj):
            cookies += val.name + "=" + val.value + ";"
        print '33334444: %s' % cookies
        return {'cookies': cookies}

    @staticmethod
    def checkKey(uno, key):
        cj = cookielib.CookieJar()
        print '11111111: %s' % cj
        cookiesProcessor = urllib2.HTTPCookieProcessor(cj)
        print '22222222: %s' % cookiesProcessor
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        print '33333333: %s' % headers
        params = urllib.urlencode({ "uno": uno, "key": key })
        print '44444444: %s' % params
        opener = urllib2.build_opener(cookiesProcessor)
        print '55555555: %s' % opener
        urllib2.install_opener(opener)
        print '66666666:'
        req = urllib2.Request(PLAYKEY_URL, params, headers)
        print '77777777: %s' % req
        response = urllib2.urlopen(req).read()
        print '88888888: %s' % response
        #response = re.sub(r'^/\*-secure-\n', '', response)
        #response = re.sub(r'\n\*/$', '', response)
        response = json.loads(response)
        print '99999999 response %s' % response

        if response.get('result_code') != 1:
            return False

        data = response.get('data')
        pkey = data.get('pkey')
        playkey = pkey.encode('utf-8')
        tkey = data.get('dummy')
        #dummy = tkey.encode('utf-8')
        print '11112222 playkey: %s' % playkey
        print '11112222 dummy: %s' % tkey
        return {'playkey': playkey, 'dummy': tkey}

