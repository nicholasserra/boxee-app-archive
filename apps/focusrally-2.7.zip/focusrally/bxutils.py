__module__ = "Mediafly API"
__author__ = "Neil Layne"
__url__ = "http://codeorangelabs.com/"
__version__ = "1.0"

from xml.dom import minidom
import mc, os


# Set debug mode for Development/Testing #
debug = False

# Short prefix for debug lines #
appPrefix = 'MF'

# Local user's confiuration information for app. #
config = mc.GetApp().GetLocalConfig()

''' No longer needed due to mc.GetActiveWindow()
def get_window():
	# Return the last launched window ID (cast as int) #
	return int(config.GetValue('activeWindow'))
'''

def set_pagetype(pageType):
	log_message('Setting Pagetype: ' + str(pageType))
	config.SetValue('pageType', str(pageType).lower())


def get_pagetype():
	log_message('Getting Pagetype: ' + config.GetValue('pageType'))
	return str(config.GetValue('pageType'))
	
def launch_window(winID, pageType = 'none', params = False):
	
	# Parameters to pass to window. #
	parameters = mc.Parameters()
	
	# Set page type. #
	set_pagetype(pageType)
	
	# If parameters were passed, add them. #
	if params:
		for i in params: parameters[i] = params[i]
	
	# Ask Boxee to launch the given window. #
	mc.GetApp().ActivateWindow(winID, parameters)
	
	# Store active window ID. #
	#config.SetValue('activeWindow', str(winID))
	
	log_message('Launching Window: ' + str(winID))

def clean_string(string):
	# Boxee can be a bit picky about its strings. #
	string = string.encode('utf-8', 'replace')
	string = string.replace('<br />', ' ')
	string = str(string)
	return string


def log_message(message, error = False):
	message = str(message)
	
	# Set message prefix. #
	if error:
		message = "%s-ERROR: %s" % (appPrefix, message)
	else:
		message = "%s-DEBUG: %s" % (appPrefix, message)
		
	# If 'debug', just dump all messages to mc.log. #
	if debug:
		print message
		return
	
	# In normal usage, put messages through API. #
	if error:
		mc.LogError(message)
	else:
		mc.LogDebug(message)


def check_version(appName):
	# Inspired by Fuzz's UpdateNotice. #
	descriptor = '%s%s%s' % (mc.GetApp().GetAppDir(), os.sep, 'descriptor.xml')
	saved = config.GetValue('currentversion')
	current = minidom.parse(descriptor).getElementsByTagName('version')[0].firstChild.nodeValue
	
	# If the current version is not in the config, set it.
	if not saved:
		config.SetValue('currentversion', str(current))
		mc.ShowDialogNotification(str("You have been updated to %s version: %s. " % (appName, current)))
		return
	
	if float(current) > float(saved):
		config.SetValue('currentversion', str(current))
		mc.ShowDialogNotification(str("You have been updated to %s version: %s. " % (appName, current)))

def get_xml(url):
	# Inspired by DPK's getRSS. #
	uaString = "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.1.7) Gecko/20091221 Firefox/3.5.7 (.NET CLR 3.5.30729)"
	
	http = mc.Http()
	http.SetHttpHeader("User-Agent", uaString)
	xml = http.Get(str(url))
	return minidom.parseString(xml)
