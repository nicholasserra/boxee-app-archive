###############################################################################
#[ APP SPECIFIC VARIABLES ]####################################################
#	update descriptor.xml
#		- change id, name, description, thumbnail
#	update mfConfig.py
#		- change mCode
#		- change title
#		- change isDerivative
###############################################################################
mCode = "focusrally"
title = "Focus Rally America"
isDerivativeApp = True