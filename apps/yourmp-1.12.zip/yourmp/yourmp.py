# Your MP Boxee application
# (C) Liam Green-Hughes 2010
# Licenced under GPL - so it's open source, go crazy!
# More information at http://www.greenhughes.com/apps/yourmp
# -*- coding: utf-8 -*-

import urllib
import simplejson
import mc
import os
import os.path
import sgmllib
import string
import datetime
import xbmc
import re
import pickle

BASE_URL = "http://www.theyworkforyou.com"
PW_URL = "http://www.publicwhip.org.uk/mp.php?mpid=%d&display=everyvote"
MAX_VOTES = 50 
QR_GEN_URL = "http://chart.apis.google.com/chart?cht=qr&chs=200x166&chl=%s&chld=L|4"
API_PROXY = "http://yourmp-apiproxy.appspot.com/"


# This parses the HTML of the votes for an MP from publicwhip.org.uk
# very much adapted from http://code.activestate.com/recipes/52281-strip-tags-and-javascript-from-html-page-leaving-o/
class PublicWhipParser(sgmllib.SGMLParser):

    # These are the HTML tags that we will leave intact
    valid_tags = ('table', 'td')

    from htmlentitydefs import entitydefs # replace entitydefs from sgmllib
    
    def __init__(self):
        sgmllib.SGMLParser.__init__(self)
        self.headings = ('house', 'date', 'subject', 'majmin', 'party_vote' , 'role')
        self.heading_pointer = 0
        self.vote_details = {}
        self.votes = []
        self.vote_item = ()
        self.in_votes_table = False
        self.in_vote_item = False
        self.in_vote_detail = False
        self.detail_text = ''
        self.endTagList = [] 
        self.months = {'Jan':1, 'Feb':2, 'Mar':3, 'Apr':4, 'May':5, 'Jun':6, 'Jul':7, 'Aug':8, 'Sep':9, 'Oct':10, 'Nov':11, 'Dec':12}
        
    def handle_data(self, data):
        if self.in_vote_item:
            self.detail_text = self.detail_text + data

    def handle_charref(self, name):
        if name == '8212':
           self.detail_text = "%s-" % self.detail_text 
        else:
           self.detail_text = "%s&#%s;" % (self.detail_text, name)
        
    def handle_entityref(self, name):
        c = ''
        if self.entitydefs.has_key(name): 
            x = ';'
        else:
            # this breaks unstandard entities that end with ';'
            x = ''
        self.detail_text = "%s&%s%s" % (self.detail_text, name, x)
    
    def unknown_starttag(self, tag, attrs):
        if self.in_vote_item and tag == "td":
            self.in_vote_detail = True
        elif self.in_votes_table and tag == 'tr':
            if ('class', 'odd') in attrs or ('class', 'even') in attrs:
                self.in_vote_item = True
        elif tag == "table" and ('class', 'votes') in attrs:
            self.in_votes_table = True
            
        # grab the path for the vote
        if self.in_vote_item and tag == 'a':
            for attr in attrs:
                if 'href' in attr:
                    self.vote_details['path'] = "%s/%s" % ('http://www.publicwhip.org.uk/', attr[1])
            
                
    def unknown_endtag(self, tag):
        if self.in_vote_detail and tag == "td":
            self.in_vote_detail = False
            key = self.headings[ self.heading_pointer ]
            self.vote_details[ key ] = self.detail_text.replace("&nbsp;", " ")
            self.heading_pointer = self.heading_pointer + 1
            self.detail_text = ''
        elif self.in_vote_item:
            if tag == "tr":
               if 'date' in self.vote_details: 
                   rawdate = self.vote_details['date'].split(' ')
                   self.vote_details['date'] = datetime.date(int(rawdate[2]), self.months[rawdate[1]], int(rawdate[0]))
               self.in_vote_item = False                
               self.votes.append(self.vote_details)
               self.vote_details = {}
               self.heading_pointer = 0
   
        elif self.in_votes_table and tag == "table":
            self.in_votes_table = False  

# Class to parse the HTML for a division from publicwhip.org.uk and extract the details            
class PublicWhipDivisionParser(sgmllib.SGMLParser):

    # These are the HTML tags that we will leave intact
    valid_tags = ('p', 'em')
    cleanups = {"&nbsp;":" ", "Debate in Parliament | Source | Edit (learn more) | Discussion": "", "&quot;":"\"", "\r": "", "\n":"[CR]", ",": "$COMMA", "$": "$$", "&#163;":"£"}

    from htmlentitydefs import entitydefs # replace entitydefs from sgmllib
    
    def __init__(self):
        sgmllib.SGMLParser.__init__(self)
        self.details = {}
        self.in_mpondivision = False
        self.in_title = False
        self.in_motion = False
        self.detail_text = ''
        
    def handle_data(self, data):
        if self.in_title or self.in_motion or self.in_mpondivision:
            self.detail_text = self.detail_text + data

    def handle_charref(self, name):
        if self.in_title or self.in_motion or self.in_mpondivision:
            if name == '8212':
                self.detail_text = "%s-" % self.detail_text 
            else:
                self.detail_text = "%s&#%s;" % (self.detail_text, name)
        
    def handle_entityref(self, name):
        if self.in_title or self.in_motion or self.in_mpondivision:
            c = ''
            if self.entitydefs.has_key(name): 
                x = ';'
            else:
                # this breaks unstandard entities that end with ';'
                x = ''
            self.detail_text = "%s&%s%s" % (self.detail_text, name, x)
    
    def unknown_starttag(self, tag, attrs):
        if tag == 'p' and ('class', 'mpondivision') in attrs:
            self.in_mpondivision = True
        elif tag == 'em':
            self.detail_text = self.detail_text + '[B][I]'
        elif tag == 'h1':
            self.in_title = True
        elif tag == 'div'  and ('class', 'motion') in attrs:
            self.in_motion = True           
                
    def unknown_endtag(self, tag):
        if tag == 'p' and self.in_mpondivision:
            self.in_mpondivision = False
            self.details['mpondivision'] = self.detail_text.replace("&nbsp;", " ")
            self.detail_text = ''
        elif tag == 'em':
            self.detail_text = self.detail_text + '[/I][/B]'
        elif tag == 'h1':
            self.in_title = False
            self.details['title'] = self.detail_text.replace("&nbsp;", " ")
            self.detail_text = ''
        elif tag == 'div'  and self.in_motion:
            self.in_motion = False
            # add the mpinmotion text to start
            self.detail_text = "%s\n%s" % (self.details['mpondivision'], self.detail_text)
            del self.details['mpondivision'] 
            # clean up newlines
            npattern = re.compile("\n{2,}")
            self.detail_text = npattern.sub("[CR][CR]", self.detail_text)
            dpattern = re.compile("Description automatically extracted from the debate,\s+please edit it to make it better.")
            self.detail_text = dpattern.sub("", self.detail_text)
            # Clean up text for TV display
            for s in self.cleanups.keys():
                self.detail_text = self.detail_text.replace(s, self.cleanups[s])
            
            self.details['motion'] = self.detail_text.strip()
            self.detail_text = '' 

#
# Main app code
#

api_key = ""
awake = False

#
# Retrieve API key for proxy from LocalConfig or if not present request one from the server
#
def GetAPIProxyKey():
    retval = {}
    retval['api_proxy_key'] = mc.GetApp().GetLocalConfig().GetValue("api_proxy_key")
    if retval['api_proxy_key'] == '':
        # Ask server to allocate an api_proxy_key
        http = mc.Http()
        rawdata = http.Get(API_PROXY + 'request_proxy_key')
        data = {}
        try:
            data = simplejson.loads(rawdata)
        except ValueError:
            data['error'] = "Could not understand response."
        if 'api_proxy_key' in data:
            mc.GetApp().GetLocalConfig().SetValue("api_proxy_key", str(data['api_proxy_key']))
            retval['api_proxy_key'] = str(data['api_proxy_key'])
        elif 'error' in data:
            retval['error'] = "API Proxy Error: %s" % data['error']   
    return retval

#
# Make an API call to theyworkforyou.com
#
def CallAPI(function, params):
    global api_key  
    retval = {}
    cached_data_values = {}
    keepgoing = True  
    http = mc.Http()
    #
    # This app can communicate directly with theyworkforyou.com but you need your own
    # api key. This can be obtained from their website. Once you get this copy and
    # paste the key into a file named "twfyapikey.txt" in the root directory of this
    # application. If this key is not present requests will be sent through a proxy
    # that was specially built for this app. If this is the case the app will 
    # automatically get a key to use that proxy.
    #
    
    if api_key == '':
        apikeyfile = os.path.join(mc.GetApp().GetAppDir(), "twfyapikey.txt")
        api_key = 'USE_PROXY' # fallback to using api proxy
        # Try to load API key from local file
        if os.path.exists(apikeyfile):
            fh_apikey = open(apikeyfile, 'r')
            for line in fh_apikey:
                if line[:1] != '#':
                    api_key = line.strip()
                    mc.LogInfo("Your MP: They Work For You API key read from local file.")
            fh_apikey.close()            
    
    # Proxy and native requests for twfy info have slightly different urls   
    url = ''
    pstack = []    
    if api_key == 'USE_PROXY':
        # make sure we have a key for the api proxy
        api_proxy_key = GetAPIProxyKey()
        if 'error' in api_proxy_key:
            keepgoing = False
            retval['error'] = api_proxy_key['error']
        else:
            url = API_PROXY + 'api_proxy?'
            pstack.append("api_proxy_key=" + api_proxy_key['api_proxy_key'])
            pstack.append("function=" + function)
    else:
        # TWFY API key present so go direct
        url = BASE_URL + '/api/' + function + '?'
        pstack.append('key=' + api_key) 
    
    if keepgoing:
        # Append args for function
        for key in params.keys():
            pstack.append(key + '=' + urllib.quote(params[key]))
        url = url + '&'.join(pstack)
        
        # is this url cached in the config? if it is less than one hour old use that
        cached_data = mc.GetApp().GetLocalConfig().GetValue("url-cache:" + url)
        if cached_data:
            cached_data_values = pickle.loads(cached_data)
            data_age = datetime.datetime.utcnow() - cached_data_values['time']
            if data_age.seconds > 3600:
                # data is old - throw it away
                mc.GetApp().GetLocalConfig().Reset("url-cache:" + url)
                cached_data_values = {}
            else:
                retval = cached_data_values['data']
                del cached_data_values['data'] 
        if len(cached_data_values) == 0:
            rawdata = http.Get(url)       
            if not http.GetHttpResponseCode() == 200:
                keepgoing = False
                viaproxy = ''
                if api_key == 'USE_PROXY':
                    viaproxy = " (via proxy) "
                retval['error'] = "Could not download data from theyworkforyou.com%s. HTTP Error code: %d." % (viaproxy, http.GetHttpResponseCode())
    
    # If we have got this far we have a response from a server
    if keepgoing and len(cached_data_values) == 0:
        try:
            retval = simplejson.loads(rawdata)
            
            # obtain a new API Proxy key next time app starts if for some reason this one is not valid
            if 'error' in retval and retval['error'] == 'Not a valid API Proxy Key':
                mc.GetApp().GetLocalConfig().Reset("api_proxy_key")
        except ValueError:
            retval['error'] = "Could not understand response from server."
            keepgoing = False
    
    # copy data to return value and obtain images and qr codes
    if keepgoing and len(cached_data_values) == 0:        
        for key in retval.keys():
            retval[key] = str(retval[key])
            if key == 'image':
                # don't redownload if it exists already
                localpath =  os.path.join(mc.GetApp().GetAppDir(), 'cache',  "mppic-%s"  % os.path.basename(retval[key]))
                if not os.path.exists(localpath):
                    http.Download(BASE_URL + retval[key], localpath)
                retval[key] = localpath
            elif key == 'mp_website':
                # generate qr code
                SetInfoLine("Obtaining QR code from Google Chart API...")
                localpath =  os.path.join(mc.GetApp().GetAppDir(), 'cache',  "mpqr-%s.png"  % urllib.quote_plus(retval['mp_website']))
                # only download if the file does not exist already
                if not os.path.exists(localpath):
                    http.Download(QR_GEN_URL % retval['mp_website'], localpath)
                retval['qr_code'] = localpath   
                
    if 'error' in retval:
        mc.LogError(retval['error']) 
    else:
        # cache the data
        mc.GetApp().GetLocalConfig().SetValue("url-cache:"+url, pickle.dumps({'time':datetime.datetime.utcnow(), 'data':retval}))        
    return retval

#
# Gets the information for an MP by postcode.
# Returns a dictionary of basic information.
#
def GetMP(postcode):
    data = CallAPI("getMP", {'postcode':postcode, 'always_return':'1'})
    retval = {}
    if 'error' in data:
        retval['error'] = "Details: [I]%s[/I]. [CR][CR]Would you like to try again?" % data['error']
    else:
        retval['member_id'] = int(data['member_id'])
        if 'image' in data:
            retval['image'] = data['image']
        else:
            retval['image'] = 'defaultperson.png'
        retval['constituency'] = data['constituency'].upper()
        retval['represented_by'] = "%s %s" % (data['first_name'], data['last_name'])
        retval['party'] = data['party']
        retval['twfy_url'] = BASE_URL + data['url']
    
    if 'person_id' in data:
        info = CallAPI("getMPInfo", {'id':data['person_id'], 'fields':'mp_website'})  
        if 'mp_website' in info:
            retval['has_website'] = True
            retval['mp_website'] = info['mp_website']       
            retval['qr_code'] = info['qr_code']  
        else:
            retval['has_website'] = False
            retval['mp_website'] = 'Not available'
            retval['qr_code'] = 'not_available'  
    return retval

#
# Download and parse a list of votes for an MP
#    
def GetVotingList(member_id):
   html = ''
   http = mc.Http()
   html = http.Get(PW_URL % member_id).replace("\n","")
   SetInfoLine("Parsing information from [B]publicwhip.org.uk[/B]....")
   parser = PublicWhipParser()
   parser.feed(html)
   parser.close()
   return parser.votes;

#
# Inserts the information from the parsed votes onto the screen
#
def PopulateVotingList(member_id):
    votes = GetVotingList(member_id)
    itemList = mc.ListItems()
    lineno = 0
    for vote in votes:
        if lineno > MAX_VOTES:
            break
        else:
            lineno = lineno + 1
        if 'subject' in vote:
            item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
            item.SetDate(vote['date'].year, vote['date'].month, vote['date'].day)
            item.SetTitle("Vote Details")
            item.SetLabel(vote['subject'])
            item.SetProperty("party_vote", vote['party_vote'])
            item.SetProperty("majmin", vote['majmin'])
            item.SetProperty("role", vote['role'])
            item.SetPath(vote['path'])
            itemList.append(item)
    if len(itemList) == 0:
        mc.GetWindow(14000).GetControl(140).SetVisible(False)
        mc.GetWindow(14000).GetControl(141).SetVisible(True)
    else:
        mc.GetWindow(14000).GetControl(140).SetVisible(True)
    vlist = mc.GetWindow(14000).GetList(450)
    vlist.SetItems(itemList)  
    
#
# Handler for change postcode button, resets app
#    
def ChangePostCode():
    Init(True)

#
# Called when app starts up, gets the infomation and populates elements on screen
# @param reset Set to true to clear stored postcode and prompt user for a new one
#    
def Init(reset=False):
    mc.ShowDialogWait()
    # Make sure cache directory exists
    cachedir = os.path.join(mc.GetApp().GetAppDir(), 'cache')
    if not os.path.isdir(cachedir):
        os.mkdir(cachedir)
    # if the vote detail section was open and we are returning from screensaver - close it
    if mc.GetWindow(14000).GetControl(510).IsVisible():
        CloseVoteDetails()
    # build page
    nopostcode = True
    config = mc.GetApp().GetLocalConfig()
    goodbye = False
    mp_details = {}
    mainwin = mc.GetWindow(14000)
    postcode = config.GetValue("postcode")
    default_postcode = postcode
    
    if reset:
        mc.GetApp().GetLocalConfig().Reset("postcode")
        postcode = False
    
    if postcode:
        nopostcode = False
        SetInfoLine("Getting information from [B]theyworkforyou.com[/B]...")
        mp_details = GetMP(postcode)
    if 'error' in mp_details:
        mc.HideDialogWait()
        onwards = mc.ShowDialogConfirm("Sorry, there has been an error...", mp_details['error'], "No", "Yes")
        if onwards:
            mc.ShowDialogWait()
            nopostcode = True
        else:
            goodbye = True

    while nopostcode:
        postcode = mc.ShowDialogKeyboard("Please enter your postcode to look up your MP", default_postcode, False).upper()
        if postcode.strip() == '':
            mp_details['error'] = 'No postcode entered![CR][CR]Would you like to try again?'
        else:
            mp_details = GetMP(postcode)
            mainwin.GetControl(110).SetVisible(False)
            
        if 'error' in mp_details:
            mc.HideDialogWait()
            onwards = mc.ShowDialogConfirm("Sorry, there has been an error...", mp_details['error'], "No", "Yes")
            if onwards:
                mc.ShowDialogWait()
            else:
                nopostcode = False
                goodbye = True
        else:
            nopostcode = False
            config.SetValue("postcode", postcode)

    if goodbye:
        mc.HideDialogWait()
        mc.CloseWindow()
    else:
        mainwin.GetImage(110).SetTexture(mp_details['image'])
        mainwin.GetLabel(125).SetLabel(	mp_details['represented_by'] )
        subtitle = "[UPPERCASE]%s [COLOR grey]%s[/COLOR][/UPPERCASE]" % (mp_details['constituency'], mp_details['party'])
        mainwin.GetLabel(301).SetLabel(subtitle)
        mainwin.GetLabel(132).SetLabel(	mp_details['mp_website'] )
        mainwin.GetLabel(135).SetLabel(	postcode )
        mainwin.GetImage(240).SetTexture(mp_details['qr_code'])
        mainwin.GetControl(220).SetVisible( mp_details['has_website'] )  
        mainwin.GetControl(230).SetFocus()
    
        # populate the voting list
        # but don't repopulate voting list if just waking from screensaver
        if not mc.GetWindow(14000).GetControl(110).IsVisible():
            SetInfoLine("Getting information from [B]publicwhip.org.uk[/B]....")
            PopulateVotingList(mp_details['member_id'])
        SetInfoLine(False)
        mainwin.GetControl(110).SetVisible(True)
        mc.HideDialogWait()
 
# 
# Changes message on footer line
# @param message string of message to show or False to change back to default message
#   
def SetInfoLine(message):
    if message == False:
        message = "Application by [B]Liam Green-Hughes[/B]. Information provided by [B]theyworkforyou.com[/B] and [B]publicwhip.org.uk[/B]."
    mc.GetWindow(14000).GetLabel(330).SetLabel(message)

#
# Shows an information box to explain the QR code
#    
def ShowQRInfo():
    mc.ShowDialogOk("Information on QR Codes", "Use your mobile phone to read the QR Codes on this page to reach the MP's website.[CR]For more information on QR codes see: http://en.wikipedia.org/wiki/QR_Code")

#
# Switches image to show QR code instead of picture of mp
#
def ShowQRCode():
    mainwin = mc.GetWindow(14000)
    # if QR code already visible show the info box
    if mainwin.GetControl(240).IsVisible():
        mc.ShowDialogOk("Information on QR Codes", "Use your mobile phone to read the QR Codes on this page to reach the MP's website.[CR]For more information on QR codes see: http://en.wikipedia.org/wiki/QR_Code")
    else:
        mc.GetActiveWindow().PushState()
        mainwin.GetControl(110).SetVisible( False ) 
        mainwin.GetControl(210).SetVisible( True ) 
        mainwin.GetButton(220).SetLabel( "What's a QR Code?" ) 
        mainwin.GetControl(240).SetVisible( True )
        

#
# Switches image to show picture of mp instead of QR code 
#
def ShowMPImage():
    mc.GetActiveWindow().PopState()
     
#
# Shows information for a vote and populates screen elements
# @param pw_vote_url string URL of vote information page on publicwhip.org.uk - this is stored in list item
#   
def ShowVoteDetails(pw_vote_url):
    mc.GetActiveWindow().PushState()
    mc.ShowDialogWait()
    SetInfoLine("Obtaining details for division from publicwhip.org.uk...")
    mainwin = mc.GetWindow(14000)
    http = mc.Http()
    html = http.Get(pw_vote_url)
    if not http.GetHttpResponseCode() == 200:
        mc.HideDialogWait()
        SetInfoLine(False)
        mc.ShowDialogOk("Error", "Sorry, could not get the details for this division.[CR]HTTP Error code %d" % http.GetHttpResponseCode()) 
    else:
        parser = PublicWhipDivisionParser()
        parser.feed(html)
        parser.close()
        mainwin.GetControl(400).SetVisible(False)
        mainwin.GetControl(500).SetVisible(True)
        mainwin.GetControl(140).SetVisible(False)
        mainwin.GetControl(141).SetVisible(False)
        mainwin.GetControl(142).SetVisible(True)
        mainwin.GetLabel(142).SetLabel(parser.details['title'])
        # update textbox solution from http://www.cuvedev.net/2010/04/boxee-python-dev/
        xbmc.executebuiltin("Control.SetLabel(510,%s)" % parser.details['motion'])
        mainwin.GetControl(580).SetFocus() 
        mc.HideDialogWait()
        SetInfoLine(False)

#
# Back button handler in vote details - does same as pressing back button on remote
#    
def CloseVoteDetails():
    mc.GetActiveWindow().PopState()
    
