import urllib
import mc
import threading
import adultfilter

class Search:

  def __init__(self, searchText):
    self.searchText = searchText
    self.askedAdult = False


class SearchManager:
  
  sharedState = None

  API_URL = "http://www.blinkx.com/thirdparty/boxee/boxee-api.php"
  #API_URL = "http://BLINKX_WEBSITE()/thirdparty/boxee/boxee-api.php"

  def __init__(self):
    if SearchManager.sharedState == None:
      SearchManager.sharedState = dict()

      SearchManager.sharedState["search"] = None
      SearchManager.sharedState["channelName"] = "popular"
      SearchManager.sharedState["playlist"] = None
      SearchManager.sharedState["focus"] = None
      SearchManager.sharedState["showAdult"] = False
      SearchManager.sharedState["lastPage"] = None
      SearchManager.sharedState["lastContentURL"] = None

    self.__dict__ = SearchManager.sharedState

  def adultFilter(self):
    mc.LogError("%s %s %s" % (self.showAdult, self.search, self.search.askedAdult))
    if not self.showAdult and self.search != None and self.search.askedAdult == False:
      for term in adultfilter.adultTerms:
        if self.search.searchText.find(term) > -1:
          return True

    return False

  def checkAndSetContentUrl(self, displayList, url, loadingImage):
    if self.lastContentURL != url:
      displayList.SetItems(mc.ListItems())

      loadingImage.SetVisible(True)

      self.lastContentURL = url
      
      http = mc.Http()
      
      # We will take advantage of Boxee's mandatory caching policy to make this load quicker.
      content = http.Get(url)

      displayList.SetContentURL(url)
      #displayList.SetItems(content)

      loadingImage.SetVisible(False)
  
  def doChannelSearch(self, displayList, loadingImage):
    if self.channelName != None:
      searchURL = "%s?channel=%s" % (SearchManager.API_URL, self.channelName)
      self.checkAndSetContentUrl(displayList, searchURL, loadingImage)
    else:
      searchURL = SearchManager.API_URL
      self.checkAndSetContentUrl(displayList, searchURL, loadingImage)

  def doSearch(self, displayList, label, loadingImage):
    if self.search != None:
      escapedSearchText = urllib.quote_plus(self.search.searchText).strip()
      
      label.SetLabel("Showing search results for \"" + self.search.searchText + "\"")
      searchURL = "%s?query=%s&maxresults=25&%s" % (SearchManager.API_URL, escapedSearchText, self.getAdultParameter())

      self.checkAndSetContentUrl(displayList, searchURL, loadingImage)

  def doPlaylist(self, displayList):
    displayList.SetItems(self.playlist)
  
  def getAdultParameter(self):
    if self.showAdult:
      return "safefilter=false"
    else:
      return ""


class PlayerController:
  sharedState = None

  def __init__(self):
    if PlayerController.sharedState == None:
      PlayerController.sharedState = dict()

      PlayerController.sharedState["player"] = mc.Player(True)
      
      PlayerController.sharedState["player"].SetLastPlayerEvent(mc.Player.EVENT_NONE)
      PlayerController.sharedState["shouldBePlaying"] = False
      PlayerController.sharedState["playlist"] = list()
      PlayerController.sharedState["noVideoWindow"] = False
      PlayerController.sharedState["currentIndex"] = 0
      PlayerController.sharedState["imageWatchThread"] = None

    self.__dict__ = PlayerController.sharedState
    
  def playItemFullscreen(self, itemIndex, listItems):
    ## There is no way to get the app's volume via javascript. So, we
    ## must force it to be 100% to ensure consistency between the app and
    ## the flash player.
    try:
      if mc.IsEmbedded():
        self.playlist = mc.PlayList(mc.PlayList.PLAYLIST_VIDEO)
        self.playlist.Clear()
        
        for video in listItems:
          self.playlist.Add(video)
        
        if (self.player.IsPlaying()):
          self.player.Stop()
        self.deferredPlayThread = DeferredPlayThread(self.player, self.playlist, itemIndex)
      else:
        currentListItem = listItems[itemIndex]
        self.player.Play(currentListItem)
    except AttributeError:
      currentListItem = listItems[itemIndex]
      self.player.Play(currentListItem)
        

    

class VideoWindowWatchThread:
  
  PRESKIP_LIMIT = 3

  def __init__(self):
    self.lastTime = 0

    self.event = threading.Event()
    self.thread = threading.Thread(target=self.tick, args=(self.event, 1.0))

    self.thread.start()
  
  def tick(self, event, every):
    playerController = PlayerController()

    player = playerController.player

    while True:
      event.wait(every)
      if (event.isSet()):
        break
      
      if player.GetLastPlayerEvent() == player.EVENT_ENDED and playerController.shouldBePlaying:
        if self.lastTime <= VideoWindowWatchThread.PRESKIP_LIMIT:
          playerController.playPrevious()
        else:
          playerController.playNext()
          
          player.SetLastPlayerEvent(player.EVENT_STARTED)

      if player.IsPlaying():
        self.lastTime = player.GetTime()

class DeferredPlayThread:
  def __init__(self, player, playlist, index):
    self.player = player
    self.index = index
    self.playlist = playlist

    self.event = threading.Event()
    self.thread = threading.Thread(target=self.tick, args=(self.event, 0.5))
    
    self.thread.start()
  
  def tick(self, event, every):

    while True:
      event.wait(every)
      if (event.isSet()):
        break
      
      if not self.player.IsPlaying():
        self.player.PlaySelected(self.index, mc.PlayList.PLAYLIST_VIDEO)
        
        volume = self.player.GetVolume()
        self.player.SetVolume(volume)
        event.set()

