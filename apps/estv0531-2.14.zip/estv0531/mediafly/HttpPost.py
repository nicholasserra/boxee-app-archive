import urllib
from mediafly.models import ChannelModel, DocumentModel, EpisodeModel, ShowModel
from mediafly.errors import MediaflyError,  MediaflyServerError
from mediafly.models import UserModel
from mediafly.models import ContentSourceModel
from mediafly.models import TokenModel
from mediafly.models import RequestModel
import urllib2
from xml.dom import minidom

# Mediafly API Methods
ADD_CONTENT_SOURCE = "Mediafly.ContentSources.AddContentSource"
ADD_EPISODE_RATE = "Mediafly.Episodes.AddEpisodeRating"
ADD_FAVOURITE_EPISODE = "Mediafly.Episodes.AddFavoriteEpisode"
ADD_FAVOURITE_SHOW = "Mediafly.Shows.AddFavoriteShow"
ADD_SHOW_RATE = "Mediafly.Shows.AddShowRating"
CREATE_DEVICE_ID = "Mediafly.Devices.CreateDeviceId"
AUTHENTICATE_DEVICE_FOR_CONTENT_SOURCE = "Mediafly.ContentSources.AuthenticateDeviceForSource"
AUTHENTICATE_USER_FOR_CONTENT_SOURCE = "Mediafly.ContentSources.AuthenticateUserForSource"
BIND_USER_TO_CONTENT_SOURCE = "Mediafly.ContentSources.BindUser"
UNBIND_USER_TO_CONTENT_SOURCE = "Mediafly.ContentSources.UnbindUser"
BROWSE_CONTENT_SOURCES = "Mediafly.ContentSources.Browse"
GENERATE_ASSOCIATION_CODE = "Mediafly.Authentication.GetUserAssociationCode"
GET_BOUND_USERS_FOR_CONTENT_SOURCES = "Mediafly.ContentSources.GetBoundUsers"
GET_CHANNEL = "Mediafly.Channels.GetChannel"
GET_CHANNELS = "Mediafly.Channels.GetChannels"
GET_CONTENT_SOURCES = "Mediafly.ContentSources.GetContentSources"
GET_EPISODE_INFO = "Mediafly.Episodes.GetEpisodeInfo"
GET_EPISODES_FOR_SHOW = "Mediafly.Shows.GetEpisodesForShow"
GET_NEXT_EPISODE_FOR_CHANNEL = "Mediafly.Channels.GetNextEpisodeForChannel"
GET_NEXT_EPISODE_FOR_SHOW = "Mediafly.Shows.GetNextEpisodeForShow"
GET_PREVIOUS_EPISODE_FOR_CHANNEL = "Mediafly.Shows.GetPrevEpisodeForShow"
GET_PREVIOUS_EPISODE_FOR_SHOW = "Mediafly.Shows.GetPrevEpisodeForShow"
GET_SHOW_INFO = "Mediafly.Shows.GetShowInfo"
GET_TOKEN = "Mediafly.Authentication.GetToken"
LOG_MEDIA_FAILURE = "Mediafly.Logging.LogMediaFailure"
POST_ACTION = "Mediafly.Experience.PostAction"
POST_IMPRESSION = "Mediafly.Experience.PostImpression"
REMOVE_CONTENT_SOURCE = "Mediafly.ContentSources.RemoveContentSource"
REMOVE_EPISODE_RATE = "Mediafly.Episodes.RemoveEpisodeRating"
REMOVE_FAVOURITE_EPISODE = "Mediafly.Episodes.RemoveFavoriteEpisode"
REMOVE_FAVOURITE_SHOW = "Mediafly.Shows.RemoveFavoriteShow"
REMOVE_SHOW_RATE = "Mediafly.Shows.RemoveShowRating"
QUERY = "Mediafly.Search.Query"
SUBSCRIBE = "Mediafly.Subscriptions.Subscribe"
UNSUBSCRIBE = "Mediafly.Subscriptions.Unsubscribe"

TOKEN_ERROR_CODE = 20
API_URL = ""
APP_ID = ""

tokenModel = None
requestModel = None
isDebug = False

def init(applicationId, apiUrl, debug = False):
	global APP_ID, API_URL, isDebug
	APP_ID = applicationId
	API_URL = apiUrl
	isDebug = debug

def getContentSources():
	requestModel = RequestModel.createInstance(GET_CONTENT_SOURCES)
	xml = post(requestModel)

	contentSourceModels = []
	for contentSourceXml in xml.getElementsByTagName('contentSource'):
		contentSourceModels.append(ContentSourceModel.createInstances(contentSourceXml))
	return contentSourceModels

def getBoundUsers(contentSourceModel):
	requestModel = RequestModel.createInstance(GET_BOUND_USERS_FOR_CONTENT_SOURCES, contentSourceModel, False, False, {"contentSources" : contentSourceModel.slug});
	xml = post(requestModel)

	userModels = []
	users = xml.getElementsByTagName("contentSource")[0].getElementsByTagName("users")[0].getElementsByTagName("user")
	for userXml in users:
		userModels.append( UserModel.createInstance(userXml))
	return userModels
	
def bindUserToContentSource(contentSourceModel, username, password, pin):
	requestModel = RequestModel.createInstance(BIND_USER_TO_CONTENT_SOURCE, contentSourceModel, True, False, {"accountName" : username, "password" : password, "pin" : pin})
	xml = post(requestModel)

def unbindUserToContentSource(contentSourceModel, username):
	requestModel = RequestModel.createInstance(UNBIND_USER_TO_CONTENT_SOURCE, contentSourceModel, True, False, {"accountName" : username})
	xml = post(requestModel)

def browseContentSources():
	requestModel = RequestModel.createInstance(BROWSE_CONTENT_SOURCES)
	xml = post(requestModel)
	
	contentSourceModels = []
	for contentSourceXml in xml.getElementsByTagName("contentSource"):
		contentSourceModels.append(ContentSourceModel.createInstances(contentSourceXml))
	return contentSourceModels

def addContentSource(code):
	requestModel = RequestModel.createInstance(ADD_CONTENT_SOURCE, args={"code" : code})
	xml = post(requestModel)
	
	return ContentSourceModel.createInstances(xml)

def removeContentSource(contentSourceModel):
	#TODO test method
	requestModel = RequestModel.createInstance(REMOVE_CONTENT_SOURCE, contentSourceModel)
	xml = post(requestModel)

def getEpisodesForShow(showSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(GET_EPISODES_FOR_SHOW, contentSourceModel, args={"showSlug" : showSlug, "includeShow" : "YES", "limit" : "50"})
	xml = post(requestModel)

	episodeModels = []
	for episodeXml in xml.getElementsByTagName("episode"):
		episodeModels.append(EpisodeModel.createInsance(episodeXml))

	return episodeModels

def _nodesToModels(xml, parentChannelModel):
	models = []
	for modelXml in xml:
		model = None
		if modelXml.localName == "document":
			model = DocumentModel.createInsance(modelXml)
		if modelXml.localName == "episode":
			model = EpisodeModel.createInsance(modelXml)
			model.channel = parentChannelModel
			model.channelSlug = parentChannelModel.slug
		if modelXml.localName == "channel":
			model = ChannelModel.createInstance(modelXml)
			model.parentChannel = parentChannelModel
			model.parentChannelSlug = parentChannelModel.slug
		if model: models.append(model)

	return models

def getChannelList(channelSlug, contentSourceModel):
	#TODO test method
	requestModel = RequestModel.createInstance(GET_CHANNELS, contentSourceModel, args={"recursive" : "yes", "channelSlug" : channelSlug})
	xml = post(requestModel)

	parentChannelModel = ChannelModel()
	parentChannelModel.slug = "__root__"
	
	return _nodesToModels(xml.childNodes, parentChannelModel)

def getChannel(channelSlug, contentSourceModel, episodeImageWidth=None, episodeImageHeight=None, channelImageWidth=None, channelImageHeight=None):
	args={"channelSlug" : channelSlug, "includeShow" : "YES"}
	if episodeImageWidth and episodeImageHeight:
		args["episodeImageSize"] = "%sx%s" % (episodeImageWidth, episodeImageHeight)
	if channelImageWidth and channelImageHeight:
		args["channelImageSize"] = "%sx%s" % (channelImageWidth, channelImageHeight)
	requestModel = RequestModel.createInstance(GET_CHANNEL, contentSourceModel, args=args )
	xml = post(requestModel)

	parentChannelModel = ChannelModel.createInstance(xml)

	return _nodesToModels(xml.childNodes, parentChannelModel)

def getToken(thirdPartyId, deviceName = None, osVersion = None, appVersion = None):
	args = {"thirdPartyUserID" : thirdPartyId}
	if deviceName: args["deviceName"] = deviceName
	if osVersion: args["osVersion"] = osVersion
	if appVersion: args["appVersion"] = appVersion
	
	requestModel = RequestModel.createInstance(GET_TOKEN, None, False, False, args)
	xml = post(requestModel)
	
	token = TokenModel.createInstance(xml)
	return token

def generateAssociationCode():
	#TODO test method
	requestModel = RequestModel.createInstance(GENERATE_ASSOCIATION_CODE)
	xml = post(requestModel)

	return xml.getAttribute("value")

def getShowInfo(showSlug, contentSourceModel, episodeImageWidth=None, episodeImageHeight=None, channelImageWidth=None, channelImageHeight=None):
	args={"showSlug" : showSlug, "recentEpisodes" : "50"}
	if episodeImageWidth and episodeImageHeight:
		args["episodeImageSize"] = "%sx%s" % (episodeImageWidth, episodeImageHeight)
	if channelImageWidth and channelImageHeight:
		args["channelImageSize"] = "%sx%s" % (channelImageWidth, channelImageHeight)
	requestModel = RequestModel.createInstance(GET_SHOW_INFO, contentSourceModel, args=args)
	xml = post(requestModel)

	showXml = xml.getElementsByTagName("show")[0]
	showModel = ShowModel.createInstance(showXml)

	episodeModels = []
	for episodeXml in showXml.getElementsByTagName("episode"):
		episodeModel = EpisodeModel.createInsance(episodeXml)
		episodeModel.showModel = showModel
		episodeModels.append(episodeModel)

	return episodeModels

def getEpisodeInfo(episodeSlug, contentSourceModel, episodeImageWidth=None, episodeImageHeight=None, channelImageWidth=None, channelImageHeight=None):
	args={"episodeSlug" : episodeSlug , "includeShow" : "YES"}
	if episodeImageWidth and episodeImageHeight:
		args["episodeImageSize"] = "%sx%s" % (episodeImageWidth, episodeImageHeight)
	if channelImageWidth and channelImageHeight:
		args["channelImageSize"] = "%sx%s" % (channelImageWidth, channelImageHeight)
	requestModel = RequestModel.createInstance(GET_SHOW_INFO, contentSourceModel, args=args)
	requestModel = RequestModel.createInstance(GET_EPISODE_INFO, contentSourceModel, args=args)
	xml = post(requestModel)

	episodeModel = EpisodeModel.createInsance(xml.getElementsByTagName("episode")[0])
	return episodeModel

def postAction(episodeSlug, contentSourceModel, type, action, position = None, url = None, length = None, time = None):
	args = {"slug" : episodeSlug, "type" : type, "action" : action}
	if position: args["position"] = position
	if url: args["url"] = url
	if length: args["length"] = length
	if time: args["time"] = time
	requestModel = RequestModel.createInstance(POST_ACTION, contentSourceModel, False, True, args)
	xml = post(requestModel)

def postImpression(sourceAtStartSlug, contentSourceModel, url, slug=None):
	args = {"sourceAtStart" : sourceAtStartSlug, "sourceAtImpression" : contentSourceModel.slug, "url" : url}
	if slug: args["slug"] = slug

	requestModel = RequestModel.createInstance(POST_IMPRESSION, contentSourceModel, False, False, args)
	xml = post(requestModel)

def authenticateDeviceForSource(contentSourceModel, username=None, password=None):
	args = {}
	if username: args["username"] = username
	if password: args["password"] = password

	requestModel = RequestModel.createInstance(AUTHENTICATE_DEVICE_FOR_CONTENT_SOURCE, contentSourceModel, True, False, args)
	xml = post(requestModel)

def authenticateUserForSource(contentSourceModel, username, password, pin):
	args = {}
	if username: args["username"] = username
	if password: args["password"] = password
	args["pin"] = pin
	requestModel = RequestModel.createInstance(AUTHENTICATE_USER_FOR_CONTENT_SOURCE, contentSourceModel, True, False, args)
	xml = post(requestModel)

def addFavoriteShow(showSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(ADD_FAVOURITE_SHOW, contentSourceModel, args={"showSlug" : showSlug})
	xml = post(requestModel)

def removeFavoriteShow(showSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(REMOVE_FAVOURITE_SHOW, contentSourceModel, args={"showSlug" : showSlug})
	xml = post(requestModel)

def addFavoriteEpisode(episodeSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(ADD_FAVOURITE_EPISODE, contentSourceModel, args={"episodeSlug" : episodeSlug})
	xml = post(requestModel)

def removeFavoriteEpisode(episodeSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(REMOVE_FAVOURITE_EPISODE, contentSourceModel, args={"episodeSlug" : episodeSlug})
	xml = post(requestModel)

def addShowRating(showSlug, contentSourceModel, rating):
	requestModel = RequestModel.createInstance(ADD_SHOW_RATE, contentSourceModel, args={"showSlug" : showSlug, "rating" : str(rating)})
	xml = post(requestModel)

def removeShowRating(showSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(REMOVE_SHOW_RATE, contentSourceModel, args={"showSlug" : showSlug})
	xml = post(requestModel)

def createDeviceId():
	requestModel = RequestModel.createInstance(CREATE_DEVICE_ID)
	xml = post(requestModel)
	return xml.data

def addEpisodeRating(episodeSlug, contentSourceModel, rating):
	requestModel = RequestModel.createInstance(ADD_EPISODE_RATE, contentSourceModel, args={"episodeSlug" : episodeSlug, "rating" : str(rating)})
	xml = post(requestModel)

def removeEpisodeRating(episodeSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(REMOVE_EPISODE_RATE, contentSourceModel, args={"episodeSlug" : episodeSlug})
	xml = post(requestModel)

def subscribe(slug, contentSourceModel, type):
	requestModel = RequestModel.createInstance(SUBSCRIBE, contentSourceModel, args={"slug" : slug, "subscriptionType" : type})
	xml = post(requestModel)

def subscribeShow(showSlug, contentSourceModel):
	subscribe(showSlug, contentSourceModel, "show")

def subscribeEpisode(episodeSlug, contentSourceModel):
	subscribe(episodeSlug, contentSourceModel, "episode")

def unsubscribe(slug, contentSourceModel, type):
	requestModel = RequestModel.createInstance(UNSUBSCRIBE, contentSourceModel, args={"slug" : slug, "type" : type})
	xml = post(requestModel)

def unsubscribeShow(showSlug, contentSourceModel):
	unsubscribe(showSlug, contentSourceModel, "show")

def unsubscribeEpisode(episodeSlug, contentSourceModel):
	unsubscribe(episodeSlug, contentSourceModel, "episode")

def search(term, contentSourceModel, limit=10):
	requestModel = RequestModel.createInstance(QUERY, contentSourceModel, args={"term" : term, "searchType" : "episode", "includeShow" : "YES", "limit" : limit})
	xml = post(requestModel)

	showModels = []
	for showXml in xml.getElementsByTagName("show"):
		showModels.append(ShowModel.createInstance(showXml))

	episodeModels = []
	for episodeXml in xml.getElementsByTagName("episode"):
		episodeModels.append(EpisodeModel.createInsance(episodeXml))

	return episodeModels

def getNextEpisodeForShow(currentEpisodeSlug, showSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(GET_NEXT_EPISODE_FOR_SHOW, contentSourceModel, args={"episodeSlug" : currentEpisodeSlug, "showSlug" : showSlug, "includeShow" : "YES"})
	xml = post(requestModel)

	episodeModel = EpisodeModel.createInsance(xml.getElementsByTagName("episode")[0])
	return episodeModel

def getPreviousEpisodeForShow(currentEpisodeSlug, showSlug, contentSourceModel):
	requestModel = RequestModel.createInstance(GET_PREVIOUS_EPISODE_FOR_SHOW, contentSourceModel, args={"episodeSlug" : currentEpisodeSlug, "showSlug" :showSlug, "includeShow" : "YES"})
	xml = post(requestModel)

	episodeModel = EpisodeModel.createInsance(xml.getElementsByTagName("episode")[0])
	return episodeModel


def getNextEpisodeForChannel(currentEpisodeSlug, channelSlug, contentSourceModel):
	return getNextEpisodeForShow(currentEpisodeSlug, channelSlug, contentSourceModel)

def getPreviousEpisodeForChannel(currentEpisodeSlug, channelSlug, contentSourceModel):
	return getPreviousEpisodeForShow(currentEpisodeSlug, channelSlug, contentSourceModel)

def logMediaFailure(episodeSlug, url, failureType, messageCode, message, timecode, contentSourceModel):
	#TODO test method
	args = {}
	args["episodeSlug"] = episodeSlug
	args["url"] = url
	args["failureType"] = failureType
	args["messageCode"] = messageCode
	args["message"] = message
	args["timecode"] = timecode

	requestModel = RequestModel.createInstance(LOG_MEDIA_FAILURE, contentSourceModel, False, True, args)
	xml = post(requestModel)

def repost(requestModel):
	return post(requestModel)

def setToken(newTokenModel):
	global tokenModel
	tokenModel = newTokenModel

def post(requestModel):
	global tokenModel

	if tokenModel is None and requestModel.apiMethod not in [GET_TOKEN, CREATE_DEVICE_ID]:
		raise MediaflyError("No token")

	if requestModel.contentSourceModel != None:
		if requestModel.contentSourceModel.defaultUser != None:
			requestModel.args["user_context"] = requestModel.contentSourceModel.defaultUser.getUserContext()
			requestModel.args["identityMode"] = requestModel.contentSourceModel.defaultUser.getIdentityMode()
		requestModel.args["source"] = requestModel.contentSourceModel.slug
	
	apiUrl = API_URL
	urlArgs = requestModel.args.copy()
	
	if requestModel.secure:
		apiUrl = apiUrl.replace("http://", "https://")

	if tokenModel:
		urlArgs["token"] = tokenModel.value
	urlArgs["app_id"] = APP_ID
	urlArgsString = urllib.urlencode(urlArgs)
	
	url = apiUrl + requestModel.apiMethod + "?" +urlArgsString
	
	response = urllib2.urlopen(url)
	data = response.read()
	if isDebug:
		print "HttpPost.post - " + url
		print "================================================================"
		print str(data)
		print "================================================================"
	xml = minidom.parseString(data)

	if checkResponse(xml):
		if xml.firstChild.childNodes.length > 0:
			return xml.firstChild.childNodes[0]
		else:
			return None
	else:
		errCode = xml.getElementsByTagName('err')[0].getAttribute('code')
		errMessage = xml.getElementsByTagName('err')[0].getAttribute('message')
		raise  MediaflyServerError(errCode, errMessage)

def checkResponse(xml):
	responseStatus = xml.getElementsByTagName('response')[0].getAttribute('status')
	if responseStatus =='ok':
		return True
	else:
		#TODO properly get error code/text
		return False