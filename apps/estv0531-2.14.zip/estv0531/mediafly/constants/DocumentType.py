PDF = "pdf"
HTML = "html"
PNG = "png"