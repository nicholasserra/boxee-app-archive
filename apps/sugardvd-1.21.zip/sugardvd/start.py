import mc
import re
import urllib2
import xbmc
import sugar
import time
import urllib

validation = 'fail'

global regtoken
global boxeeID
global cspeed

''' Get users download speed '''
def test_conn():
    response = urllib2.urlopen('http://oddesse.hs.llnwd.net/o41/u/speed_3.bin');
    myrate = chunk_read(response)
    if (myrate < 2.7):
        uspeed = '600'
    else:
        uspeed = '2500'
    return uspeed
    
''' chunk_read for getting download bandwidth '''
def chunk_read(response, chunk_size=8192):
    total_size = response.info().getheader('Content-Length').strip()
    total_size = int(total_size)
    tick1 = time.time()
    while 1:
        chunk = response.read(chunk_size)
        if not chunk:
            tick2 = time.time()
            dl_time = tick2 - tick1
            myrate = (8 * total_size) / (1024 * 1024 * dl_time)
            break
    return myrate
    
def check_auth(regtoken):
    '''    The regtoken exists, so check that it's authorized here, otherwise move on to the linking process   '''
 
    URL = 'http://www.sugardvd.com/boxee/validate?%s'
    params = urllib.urlencode({'RegToken': regtoken, 'deviceID': boxeeID})
    fileHandle = urllib2.urlopen(URL % params)
    str0 = fileHandle.read()
    fileHandle.close()
    response = re.search('<validate>(.*)<\/validate>', str0)
    validation = response.group(1)
    return validation

    

mc.ActivateWindow(14000)
mc.ActivateWindow(14009)

try:
    boxeeID = mc.GetDeviceId()
except:
    mc.ShowDialogOk('Platform not supported', 'Sorry, SugarDVD currently requires the D-Link boxee box.  Please contact remarks@sugardvd.com for more info.')
    xbmc.executebuiltin("Dialog.Close(14009)")

'''    Retrieve stored RegToken, if it exists '''
config = mc.GetApp().GetLocalConfig()
regtoken = config.GetValue('1')

if regtoken:
    validation = check_auth(regtoken)
    if validation == 'pass':
        mc.GetWindow(14009).GetLabel(189).SetLabel('Checking Connection Speed')

        ''' Get client's bandwidth and set speed for content '''
        cspeed = test_conn()
        
        xbmc.executebuiltin("Dialog.Close(14009)")

        ''' This is the end of the beginning for validated users - they're in! '''
    else:
        message0 = 'To access SugarDVD on Boxee, you must have an active account. Click OK to attempt relinking to your account now.'
        mc.ShowDialogOk('Sorry your registration is no longer valid.', message0)

if validation == 'fail':
    '''   At this point we have determined that the Boxee does not have a valid stored reg token,
    so we will ask the user to link their Boxee now  '''
  
    URL = 'http://www.sugardvd.com/boxee/getRegCode?%s'

    params = urllib.urlencode({'deviceID': boxeeID})
    fileHandle = urllib2.urlopen(URL % params)

    str1 = fileHandle.read()
    fileHandle.close()

    response = re.search('<regCode>(.*)<\/regCode>', str1)
    regcode = response.group(1)

    '''    This is where we come back to if they failed to link their account below '''
    success = 0
    while (success < 1):

        message1 = 'To link your account, please visit sugardvd.com/boxee and enter the following code: ' + regcode
        mc.ShowDialogOk('Please link your account before clicking OK', message1)

        '''    User clicked OK indicating they have linked the box on the website -
        verify that the code is linked before proceeding    '''

        URL = 'http://www.sugardvd.com/boxee/getRegResult?%s'

        params = urllib.urlencode({'regCode': regcode})
    
        fileHandle = urllib2.urlopen(URL % params)
        str2 = fileHandle.read()
        fileHandle.close()

        response = re.search('<status>(.*)<\/status>', str2)
        status = response.group(1)
    
        if status == 'success':
            validation = 'pass'
            success = 1
            '''    If success = 1, proceed.  Otherwise, go back to top of Linking process '''
        else:
            if not mc.ShowDialogConfirm('Account not linked!', 'Please try linking your account again now', 'Not now', 'OK'):
                xbmc.executebuiltin("Dialog.Close(14009)")
                success = 2

    if (success < 2):            
        '''    Account linking succeeded so here we store the returned RegToken for future access '''        
        response = re.search('<regToken>(.*)<\/regToken>', str2)
        regtoken = response.group(1)

        config = mc.GetApp().GetLocalConfig()
        config.SetValue('1',regtoken)
        name = config.GetValue('1')

        ''' Registration completed successfully, test the users bandwidth now '''

        mc.GetWindow(14009).GetLabel(189).SetLabel('Checking Connection Speed')
        cspeed = test_conn()

        xbmc.executebuiltin("Dialog.Close(14009)")
        mc.GetActiveWindow().GetControl(320).SetVisible(True)
 