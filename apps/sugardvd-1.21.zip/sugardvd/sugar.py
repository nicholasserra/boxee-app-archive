import mc
import urllib
import urllib2
import re
import md5
import string
import xbmc
    
def newlist(dir, path):
    window = mc.GetActiveWindow()
    window.GetControl(220).SetFocus()
    window.GetImage(199).SetTexture(path)
    mc.ShowDialogWait()
    items = mc.GetDirectory(dir)
    window.GetList(120).SetItems(items)
    xbmc.sleep(2500)
    mc.HideDialogWait()
    window.GetControl(120).SetFocus()
    return[window]
    
def play(content, regtoken, boxeeID, cspeed):
   params = urllib.urlencode({'RegToken': regtoken, 'device': boxeeID})
   
   URL = 'http://www.sugardvd.com/streamauth/' + content + '_' + cspeed + '.mp4?%s'
   fileHandle = urllib2.urlopen(URL % params)
   str5 = fileHandle.read()
   fileHandle.close()
   
   myparse = re.search('<item_path>(.*)<\/item_path>', str5)
   item_path = myparse.group(1)
 
   item = mc.GetApp().GetLaunchedListItem() # get the item that app was launched with
   item.SetPath(item_path) # set the new path
   mc.GetPlayer().Play(item) # play the modified video item
