#
# livestream Client
# A Python module for interacting with the livestream API.
#
# Written by nick.dima@gmail.com, 1 March 2011
#

import urllib
import urllib2
import simplejson as json
import mc
import re
from BeautifulSoup import BeautifulSoup

teams = {'Boston': 		{'name': 'Blazers',		'channel': 'bostonblazers'},
		'Buffalo': 		{'name': 'Bandits',		'channel': 'buffalobandits'},
		'Calgary': 		{'name': 'Roughnecks',	'channel': 'calgaryroughnecks'},
		'Colorado': 	{'name': 'Mammoth',		'channel': 'coloradomammoth'},
		'Edmonton': 	{'name': 'Rush',		'channel': 'edmontonrush'},
		'Minnesota': 	{'name': 'Swarm',		'channel': 'minnesotaswarm'},
		'Philadelphia': {'name': 'Wings',		'channel': 'philadelphiawings'},
		'Rochester': 	{'name': 'Knighthawks', 'channel': 'rochesterknighthawks'},
		'Toronto': 		{'name': 'Rock', 		'channel': 'torontorock'},
		'Washington': 	{'name': 'Stealth',		'channel': 'washingtonstealth'}}

foldersData = None
foundFolder = None

def searchForFolder(folders, folder_id):
	global foundFolder
	if 'directory' in folders:
		if type(folders['directory']).__name__=='dict':
			if str(folders['directory']['@id']) == folder_id:
				foundFolder = folders['directory']
			else:
				searchForFolder(folders['directory'], folder_id)
		else:
			for folder in folders['directory']:
				if str(folder['@id']) == folder_id:
					foundFolder = folder
				else:
					searchForFolder(folder, folder_id)

class Livestream:
    def __init__(self, path="api.channel.livestream.com", version="/2.0", format=".json"):
        self.path = path
        self.version = version
        self.format = format
    
    def request(self, channel, path):
        path = 'http://x' + channel + 'x.' + self.path + self.version + path
        print path
        request = urllib2.Request(path)
        try:
            r = urllib2.urlopen(request)
        except urllib2.HTTPError, e:
            print "Error!: " + str(e)
            return False
        
        data = r.read()
        
        if data:
            print data
            return json.loads(data)
        else:
            return False
    
    def getFolders(self, channel):
        data = self.request(channel, "/listplaylists" + self.format)
        if data:
            return data
        else:
            return False
    
    def getClips(self, channel, playlist):
        params = {
                  'id': playlist,
                  'maxresults' : '100'
        }
        data = self.request(channel, "/listclips" + self.format + "?" + urllib.urlencode(params))
        if data:
            return data
        else:
            return False
    
    def getGames(self, path="http://www.livestream.com/networks/network_events?name=NLLNetwork"):
        request = urllib2.Request(path)
        try:
            r = urllib2.urlopen(request)
        except urllib2.HTTPError, e:
            print "Error!: " + str(e)
            return False
        
        data = r.read()
        html = BeautifulSoup(data)
        results = html.ul.findAll('li')
        games = []
        for result in results:
        	teams = re.match(r"(?P<away>\w+) @ (?P<home>\w+)", result.div.h4.contents[0])
        	button = result.find('a', {'class' : re.compile("button*.")})
        	
        	game = {}
        	game['away_team'] = str(teams.group('away'))
        	game['home_team'] = str(teams.group('home'))
        	game['channel'] = str(result.div.a.contents[0].strip())
        	live = result.find('p', {'class' : 'live'})
        	if live:
        		game['date'] = "LIVE NOW"
        	else:
        		game['date'] = str(result.find('p', {'class' : 'date'}).contents[0]) + ' ' + str(result.find('p', {'class' : 'time'}).contents[0].strip())
        	game['action'] = str(button.contents[0].strip())
        	game['path'] = str(button['href'])
        	games.append(game)
        
        return games

class Publisher:
    def __init__(self, windowId):
        self.windowId = windowId
        self.webhost = "http://www.livestream.com"
    
    def publishGamesToList(self, listId, games):
    	listItems = mc.ListItems()
    	focus = 0
    	for game in games:
    		if game['action'] == 'Replay' or game['action'] == 'Watch':
    			listItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
    			listItem.SetContentType("application/x-shockwave-flash")
    		else:
    			listItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    		global teams
    		listItem.SetLabel('%(away_team)s @ %(home_team)s' % game)
    		listItem.SetPath(self.webhost + game['path'])
    		listItem.SetProperty("date_time", game['date'])
    		listItem.SetProperty("away_team", game['away_team'] + '\n' + teams[game['away_team']]['name'])
    		listItem.SetProperty("home_team", game['home_team'] + '\n' + teams[game['home_team']]['name'])
    		listItem.SetProperty("away_team_logo", 'nll_team_logo_' + game['away_team'].lower() + '.png')
    		listItem.SetProperty("home_team_logo", 'nll_team_logo_' + game['home_team'].lower() + '.png')
    		if game['action'] == 'RSVP':
    			game['action'] = 'Channel'
    		listItem.SetProperty("action", game['action'])
    		listItem.SetProperty("channel", game['channel'])
    		listItem.SetProperty("banner", 'nll_team_banner_' + game['away_team'].lower() + '.png')
    		listItem.SetProperty("team", game['away_team'] + ' ' + teams[game['away_team']]['name'])
    		if focus == 0 and game['action'] == 'Watch':
    			focus = len(listItems)
    		listItems.append(listItem)
    	list = mc.GetWindow(self.windowId).GetList(listId)
    	list.SetItems(listItems)
    	print "focus is on: " + str(focus)
    	list.SetFocusedItem(focus)
    
    def publishChannelsToList(self, listId):
    	global teams
    	listItems = mc.ListItems()
    	for city, team in teams.iteritems():
    		listItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    		listItem.SetLabel("Watch " + city + ' ' + team['name'])
    		listItem.SetProperty("team", city + ' ' + team['name'])
    		listItem.SetProperty("channel", team['channel'])
    		listItem.SetProperty("banner", 'nll_team_banner_' + city.lower() + '.png')
    		listItems.append(listItem)
    	list = mc.GetWindow(self.windowId).GetList(listId)
    	list.SetItems(listItems)
    
    def publishChannelToList(self, listId, channel, folder='0'):
    	api = Livestream()
    	listItems = mc.ListItems()
    	global foldersData
    	if folder == '0':
    		folders = api.getFolders(channel)
    		foldersData = folders['channel']
    		folders = folders['channel']['directory']
    	else:
    		global foundFolder
    		searchForFolder(foldersData, folder)
    		folders = foundFolder
    		print "search came back with: " + str(folders)
    	
    	if 'directory' in folders:
	    	if type(folders['directory']).__name__=='dict':
	    		listItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
	    		listItem.SetLabel(str(folder['directory']['@title']))
	    		listItem.SetProperty('folder_id', str(folder['directory']['@id']))
	    		listItems.append(listItem)
	    	else:
		    	for folder in folders['directory']:
		    		listItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
		    		listItem.SetLabel(str(folder['@title']))
		    		listItem.SetProperty('folder_id', str(folder['@id']))
		    		listItems.append(listItem)
    	clips = api.getClips(channel, str(folders['@id']))
    	for clip in clips['channel']['item']:
    		listItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
    		listItem.SetContentType("application/x-shockwave-flash")
    		listItem.SetLabel(str(clip['title']))
    		listItem.SetPath(str(clip['link']))
    		listItem.SetThumbnail(str(clip['thumbnail']['@url']))
    		listItems.append(listItem)
    	list = mc.GetWindow(self.windowId).GetList(listId)
    	list.SetItems(listItems)