import mc
import time
import urllib

API_URL = 'http://wtr.wherever.tv/BoxeeService.wtvrss'
config = mc.GetApp().GetLocalConfig()
window = mc.GetActiveWindow()
class Controller:

    @staticmethod
    def Login(username, password):
        mc.LogInfo("==>> Controller.Login("+ username + ", " + password +") - Begin")
        
        response = mc.Http().Get(API_URL + "?action=Login&screenName="+ username + "&password="+ password)

        mc.LogDebug("--> Server Response :"+ response)

        if len(response) == 0:
            
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')
            
        elif cmp(response, "None") == 1: 

            mc.ShowDialogOk("Authentication Failure", 'Invalid username or password.')

        else:
                       
            window.GetControl(9010).SetVisible(False)
            window.GetControl(9020).SetVisible(True)
            
            config.SetValue("userId", response)
            Controller.GetMyChannels()

        mc.LogInfo("==>> Controller.Login() - exit") 
            
    @staticmethod
    def Logout():
        mc.LogInfo("==>> Controller.Logout()")

        config.ResetAll()
        window.ClearStateStack(True)
        window.GetControl(9010).SetVisible(True)
        window.GetControl(9011).SetFocus()
        
        window.GetControl(9020).SetVisible(False)
        
        mc.LogInfo("==>> Controller.Logout() - exit")
        
    @staticmethod
    def GetMyChannels():
        mc.LogInfo("==>> Controller.GetMyChannels() - Begin ")
        mc.ShowDialogWait()
        userId = config.GetValue("userId")
        tmsecs = str(time.clock()).replace(".", "")

        Controller.ActivateControl(9021)
        window.GetLabel(9028).SetLabel("Select")
        window.GetButton(9022).SetLabel("")		
        window.GetLabel(9026).SetLabel("")
        response = mc.Http().Get(API_URL + "?action=MyGuide&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9040).SetContentURL(API_URL + "?action=MyGuide&uid=" + userId + "&t=" + tmsecs)		
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
        window.GetControl(9040).SetFocus()
        
        window.GetControl(9060).SetVisible(False)
        window.GetControl(9038).SetVisible(True) 
        mc.LogInfo("==>> Controller.GetMyChannels() - exit and tmsecs = "+tmsecs)
        mc.HideDialogWait()

    @staticmethod
    def GetTopTenChannels():
        mc.LogInfo("==>> Controller.GetTopTenChannels() - Begin ")  
        userId = config.GetValue("userId");
        tmsecs = str(time.clock()).replace(".", "")
        
        window.GetLabel(9026).SetLabel("Top Ten")
        window.GetButton(9022).SetLabel("")
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
        window.GetLabel(9028).SetLabel("")
        
        window.GetControl(9030).SetVisible(False)  
        Controller.ActivateControl(9031)
        response=mc.Http().Get(API_URL + "?action=TopTen&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9040).SetContentURL(API_URL + "?action=TopTen&uid=" + userId + "&t=" + tmsecs)
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
        window.GetControl(9040).SetFocus()
        
        window.GetControl(9060).SetVisible(False)

        config.SetValue("level", "1")
        window.GetControl(9038).SetVisible(True)  
        mc.LogInfo("==>> Controller.GetTopTenChannels() - exit")

    @staticmethod
    def GetLastTenChannels():
        mc.LogInfo("==>> Controller.GetLastTenChannels() - Begin ") 
        userId = config.GetValue("userId");
        tmsecs = str(time.clock()).replace(".", "")
        
        window.GetLabel(9026).SetLabel("Last Ten")
        window.GetButton(9022).SetLabel("")
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
        window.GetLabel(9028).SetLabel("")

        window.GetControl(9030).SetVisible(False)  
        Controller.ActivateControl(9032)
        response=mc.Http().Get(API_URL + "?action=LastTen&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')
            return
        
        window.GetList(9040).SetContentURL(API_URL + "?action=LastTen&uid=" + userId + "&t=" + tmsecs)
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
        window.GetControl(9040).SetFocus()
		#list = window.GetList(9060)
		#if not list:
		#	mc.LogInfo("list empty last ten")
		
        window.GetControl(9060).SetVisible(False)        

        config.SetValue("level", "1")
        window.GetControl(9038).SetVisible(True)  
        mc.LogInfo("==>> Controller.GetLastTenChannels() - exit")

    @staticmethod
    def GetCountries():
        mc.LogInfo("==>> Controller.GetCountries( ) - Begin")
        config.SetValue("ContentType", "Country")
        config.SetValue("level", "1")
        
        window.GetLabel(9026).SetLabel("Country")
        window.GetButton(9022).SetLabel("")
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
        window.GetLabel(9028).SetLabel("")
        
        window.GetControl(9030).SetVisible(False)  
        Controller.ActivateControl(9033)
        
        window.GetControl(9040).SetVisible(False)
        response=mc.Http().Get(API_URL + "?action=countries")
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9060).SetContentURL(API_URL + "?action=countries")
        window.GetList(9060).Refresh()
		#list = window.GetList(9060)
		#if not list:
		#	mc.LogInfo("list empty get countries")
        window.GetControl(9060).SetVisible(True)
        window.GetControl(9050).SetVisible(False)
        window.GetControl(9060).SetFocus()
        window.GetControl(9039).SetVisible(True)  
        mc.LogInfo("==>> Controller.GetCountries() - exit")
		
    @staticmethod
    def GetGenres():
        mc.LogInfo("==>> Controller.GetGenres( ) - Begin") 
        config.SetValue("ContentType", "Genre")
        config.SetValue("level", "1")
        
        window.GetLabel(9026).SetLabel("Genres")
        window.GetButton(9022).SetLabel("")
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
        window.GetLabel(9028).SetLabel("")
        
        window.GetControl(9030).SetVisible(False)  
        Controller.ActivateControl(9034)

        window.GetControl(9040).SetVisible(False)
        response=mc.Http().Get(API_URL + "?action=genres")
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9060).SetContentURL(API_URL + "?action=genres")
        window.GetList(9060).Refresh()
        window.GetControl(9060).SetVisible(True)
        window.GetControl(9050).SetVisible(False)
        window.GetControl(9060).SetFocus()
        window.GetControl(9039).SetVisible(True)  
        mc.LogInfo("==>> Controller.GetGenres() - exit")
        
    @staticmethod
    def GetLanguages():
        mc.LogInfo("==>> Controller.GetLanguages( ) - Begin")
        config.SetValue("ContentType", "Language")
        config.SetValue("level", "1")
        
        window.GetLabel(9026).SetLabel("Language")
        window.GetButton(9022).SetLabel("")
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
        window.GetLabel(9028).SetLabel("")
        
        window.GetControl(9030).SetVisible(False)  
        Controller.ActivateControl(9035)
        
        window.GetControl(9040).SetVisible(False)
        response=mc.Http().Get(API_URL + "?action=languages")
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9060).SetContentURL(API_URL + "?action=languages")
        window.GetList(9060).Refresh()
        window.GetControl(9060).SetVisible(True)
        window.GetControl(9050).SetVisible(False)
        window.GetControl(9060).SetFocus()
        window.GetControl(9039).SetVisible(True)  
        mc.LogInfo("==>> Controller.GetLanguages() - exit")
        
    @staticmethod
    def GetTags():
        mc.LogInfo("==>> Controller.GetTags( ) - Begin") 
        config.SetValue("ContentType", "Tag")
        config.SetValue("level", "1")
        
        window.GetLabel(9026).SetLabel("Tags")
        window.GetButton(9022).SetLabel("")
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
        window.GetLabel(9028).SetLabel("")
        
        window.GetControl(9030).SetVisible(False)  
        Controller.ActivateControl(9036)

        window.GetControl(9040).SetVisible(False)
        response=mc.Http().Get(API_URL + "?action=tags")
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9060).SetContentURL(API_URL + "?action=tags")
        window.GetList(9060).Refresh()
        window.GetControl(9060).SetVisible(True)
        window.GetControl(9050).SetVisible(False)
        window.GetControl(9060).SetFocus()
        window.GetControl(9039).SetVisible(True)  
        mc.LogInfo("==>> Controller.GetTags() - exit")

    @staticmethod
    def SearchChannels():
        mc.LogInfo("==>> Controller.searchChannels(" + config.GetValue("keyword")  + " ) - Begin")
	
        key = config.GetValue("keyword")
        userId = config.GetValue("userId")
        tmsecs = str(time.clock()).replace(".", "")
		
        key = urllib.quote(key.encode("utf8"))   
        window.GetLabel(9028).SetLabel("Select")
        response=mc.Http().Get(API_URL + "?action=search&key=" + key + "&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9040).SetContentURL(API_URL + "?action=search&key=" + key + "&uid=" + userId + "&t=" + tmsecs)
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
		
        window.GetControl(9040).SetFocus()
        window.GetControl(9038).SetVisible(True) 
        window.GetControl(9060).SetVisible(False)
		
        mc.LogInfo("==>> Controller.searchChannels() - exit")
        
    @staticmethod
    def SearchByCountry( ):
        mc.LogInfo("==>> Controller.SearchByCountry() - Begin")

        list = window.GetList(9060)
        itemNumber = list.GetFocusedItem()
        config.SetValue("itemNumber", str(itemNumber))
        item = list.GetItem(itemNumber)
        country = item.GetLabel().replace(' ', '-')
        mc.LogInfo("--> Label : " + country)
        
        userId = config.GetValue("userId")
        tmsecs = str(time.clock()).replace(".", "")
        
		
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue.png")
        window.GetLabel(9028).SetLabel(item.GetLabel())
        response=mc.Http().Get(API_URL + "?action=ByCountry&country=" + country + "&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        window.GetList(9040).SetContentURL(API_URL + "?action=ByCountry&country=" + country + "&uid=" + userId + "&t=" + tmsecs)
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
        window.GetControl(9040).SetFocus()
        window.GetControl(9038).SetVisible(True)
        window.GetControl(9060).SetVisible(False)
    
        config.SetValue("level", "2")
        #window.GetControl(9038).SetVisible(True) 
        mc.LogInfo("==>> Controller.SearchByCountry() - Exit")

    @staticmethod
    def SearchByGenre( ):
        mc.LogInfo("==>> Controller.SearchByGenre() - Begin")

        list = window.GetList(9060)
        itemNumber = list.GetFocusedItem()
        config.SetValue("itemNumber", str(itemNumber))
        item = list.GetItem(itemNumber)

        mc.LogInfo("--> Label : " + item.GetLabel())

        genre = item.GetLabel()
        userId = config.GetValue("userId")
        tmsecs = str(time.clock()).replace(".", "")
        
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue.png")
        window.GetLabel(9028).SetLabel(genre)
        response=mc.Http().Get(API_URL + "?action=ByGenre&genre="+ genre + "&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        
        window.GetList(9040).SetContentURL(API_URL + "?action=ByGenre&genre="+ genre + "&uid=" + userId + "&t=" + tmsecs)
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
        window.GetControl(9040).SetFocus()
        window.GetControl(9038).SetVisible(True)
        window.GetControl(9060).SetVisible(False)
        
        config.SetValue("level", "2")
	#	window.GetControl(9038).SetVisible(True) 
        mc.LogInfo("==>> Controller.SearchByGenre() - Exit")

    @staticmethod
    def SearchByLanguage( ):
        mc.LogInfo("==>> Controller.SearchByLanguage() - Begin")
            
        list = window.GetList(9060)
        itemNumber = list.GetFocusedItem()
        config.SetValue("itemNumber", str(itemNumber))
        item = list.GetItem(itemNumber)

        mc.LogInfo("--> Label : " + item.GetLabel())

        language = item.GetLabel()
        userId = config.GetValue("userId")
        tmsecs = str(time.clock()).replace(".", "")
        
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue.png")
        window.GetLabel(9028).SetLabel(language)
        response=mc.Http().Get(API_URL + "?action=ByLanguage&language=" + language + "&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        
        window.GetList(9040).SetContentURL(API_URL + "?action=ByLanguage&language=" + language + "&uid=" + userId + "&t=" + tmsecs)
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
        window.GetControl(9040).SetFocus()
        window.GetControl(9038).SetVisible(True)
        window.GetControl(9060).SetVisible(False)
        
        config.SetValue("level", "2")
	#	window.GetControl(9038).SetVisible(True) 
        mc.LogInfo("==>> Controller.SearchByLanguage() - Exit")

    @staticmethod
    def SearchByTag( ):
        mc.LogInfo("==>> Controller.SearchByTag() - Begin")

        list = window.GetList(9060)
        itemNumber = list.GetFocusedItem()
        config.SetValue("itemNumber", str(itemNumber))
        item = list.GetItem(itemNumber)
        
        mc.LogInfo("--> Label : " + item.GetLabel())

        tag = item.GetLabel()
        userId = config.GetValue("userId")
        tmsecs = str(time.clock()).replace(".", "")
        
        window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue.png")
        window.GetLabel(9028).SetLabel(tag)
        response=mc.Http().Get(API_URL + "?action=ByTag&tag=" + tag + "&uid=" + userId + "&t=" + tmsecs)
        if len(response) == 0:
            mc.ShowDialogOk("Connection Failed", 'We are sorry, either your internet connection is not working or the WhereverTV servers are down. Pleae try again later.')        		
            return
        
        window.GetList(9040).SetContentURL(API_URL + "?action=ByTag&tag=" + tag + "&uid=" + userId + "&t=" + tmsecs)
        window.GetList(9040).Refresh()
        window.GetControl(9040).SetVisible(True)
        window.GetControl(9050).SetVisible(True)
        window.GetControl(9040).SetFocus()
        window.GetControl(9038).SetVisible(True)
        window.GetControl(9060).SetVisible(False)
        
        config.SetValue("level", "2")
	#	window.GetControl(9038).SetVisible(True) 
        mc.LogInfo("==>> Controller.SearchByTag() - Exit")        

    @staticmethod
    def AddToGuide(channelId):
        mc.LogInfo("==>> Controller.AddToGuide("+ channelId +") - Begin")
        
        path = API_URL + "?action=Add&cid="+ channelId + "&uid=" + config.GetValue("userId")

        mc.LogInfo("--> PATH: " + path)

        response = mc.Http().Get(path)

        mc.LogDebug("--> Server Response :"+ response)
        
        if response:
            
            mc.ShowDialogOk("Operation Successful", 'This channel has successfully been added to your guide.')
            Controller.GetMyChannels()
    
        else:
            mc.ShowDialogOk("Operation Failure", 'Sorry. We are are unable to add this channel to your guide. Either it has been removed or is temporarily unavailable. Please try again later')
        
        mc.LogInfo("==>> Controller.AddToGuide() - Exit")

    @staticmethod
    def RemoveFromGuide(channelId):
        mc.LogInfo("==>> Controller.RemoveFromGuide("+ channelId+") - Begin")
    
        path = API_URL + "?action=Remove&cid="+ channelId + "&uid=" + config.GetValue("userId")

        mc.LogInfo("--> PATH: " + path)
        
        response = mc.Http().Get(path)

        mc.LogDebug("--> Server Response :"+ response)
        
        if response: 

            mc.ShowDialogOk("Operation Successful", 'This channel has successfully been removed from your guide.')
            Controller.GetMyChannels()
            
        else:
            mc.ShowDialogOk("Operation Failure", 'Sorry. We are unable to remove this channel from your guide. Please try again later.')
        
        mc.LogInfo("==>> Controller.RemoveFromGuide() - Exit")

    @staticmethod
    def GoBack():
        mc.LogInfo("==>> Controller.GoBack () Begin ")
        
        if config.GetValue("level") == "2":
            mc.LogInfo("==>> Loading CategoryList...")
            window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
            window.GetLabel(9028).SetLabel("")
            
            window.GetControl(9040).SetVisible(False)
            
            window.GetControl(9060).SetVisible(True)
            window.GetControl(9050).SetVisible(False)
            window.GetControl(9060).SetFocus()
            window.GetList(9060).SetFocusedItem(int(config.GetValue("itemNumber")))
            
            config.SetValue("level", "1")
            
        elif config.GetValue("level") == "1":
            mc.LogInfo("==>> Loading MyGuide...")
            window.GetImage(9027).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/bg/arrow-blue1.png")
            window.GetLabel(9028).SetLabel("")
            
            window.GetControl(9040).SetVisible(True)
            window.GetControl(9050).SetVisible(True)
            window.GetControl(9040).SetFocus()

            window.GetControl(9060).SetVisible(False)
            
            Controller.GetMyChannels()
            
            config.SetValue("level", "0")
            
        mc.LogInfo("==>> Controller.GoBack () End")

    @staticmethod
    def ActivateControl(controlId):
        id = config.GetValue("activeControl")
        mc.LogInfo("--> Active Control ID: " + id)
        config.Reset(id)
        config.SetValue("activeControl", str(controlId))
        config.SetValue(str(controlId), "True")
        
