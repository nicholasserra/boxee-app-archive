AUDIO = "Audio"
VIDEO = "Video"
UNKNOWN = "Unknown"