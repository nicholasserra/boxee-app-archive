import mc

window = mc.GetWindow(14001)

def setBackground(url):
	window.GetImage(100).SetTexture(url)