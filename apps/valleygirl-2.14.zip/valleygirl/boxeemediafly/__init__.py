import boxeemediafly, mc, MediaflyConfig, xbmc
from boxeemediafly import AuthenticationManager, MediaManager, utils
from boxeemediafly.utils import ThirdPartyIdUtil, StringUtils
from boxeemediafly.constants import Assets
from mediafly import HttpPost
from mediafly.errors import MediaflyServerError
from mediafly.models import ChannelModel, ContentSourceModel, DocumentModel, EpisodeModel
from windows import SplashWindow

API_URL = "http://api.mediafly.com/api/rest/3.1/"
APP_ID = "d4cf391e9b7940ba8757c3febd236d19"

CS_SUPPORTS_FAVORITES = "contentsource_supportsfavorites"
CS_SUPPORTS_SUBSCRIPTIONS = "contentsource_supportssubscriptions"
CS_SUPPORTS_USER_BINDINGS = "contentsource_supportsuserbindings"
CS_SUPPORTS_RATINGS = "contentsource_supportsratings"
CS_ISSEARCHABLE = "contentsource_issearchable"

CS_ASSET_SPLASH = "contentsource_asset_splash"
CS_ASSET_BACKGROUND = "contentsource_asset_background"
CS_ASSET_BANNER = "contentsource_asset_banner"
CS_ASSET_BRANDING_HOME = "contentsource_asset_branding_home"
CS_ASSET_BRANDING_LOWER = "contentsource_asset_branding_lower"

ROOT_SLUG = "__root__"

launchContentSourceModel = None
contentSourceModel = None
config = mc.GetApp().GetLocalConfig()

def init():
	"""
	Initializes mediafly api.  Must be done first.
	"""
	HttpPost.init(APP_ID, API_URL)
	initAppSettings()

def initAppSettings():
	config.Reset("isloggedin")

	config.SetValue(CS_ASSET_SPLASH, "")
	config.SetValue(CS_ASSET_BACKGROUND, "")
	config.SetValue(CS_ASSET_BANNER, "")
	config.SetValue(CS_ASSET_BRANDING_HOME, "")
	config.SetValue(CS_ASSET_BRANDING_LOWER, "")

	config.SetValue("page_title_text_color", MediaflyConfig.PAGE_TITLE_TEXT_COLOR)
	config.SetValue("item_selection_border_color", MediaflyConfig.ITEM_SELECTION_BORDER_COLOR)
	config.SetValue("item_selection_text_color", MediaflyConfig.ITEM_SELECTION_TEXT_COLOR)
	config.SetValue("info_title_text_color", MediaflyConfig.INFO_TITLE_TEXT_COLOR)

def getToken():
	"""
	Gets and sets token for mediafly api.
	"""
	mc.ShowDialogWait()
	thirdPartyId = ThirdPartyIdUtil.getThirdPartyId()
	tokenModel = HttpPost.getToken(thirdPartyId, osVersion=mc.GetInfoString("System.BuildVersion"))
	HttpPost.setToken(tokenModel)
	mc.HideDialogWait()

def callMediaflyFunction(func, retry, *args):
	try:
		return func(*args)
	except MediaflyServerError, e:
		# handle invalid token
		if retry and e.code in ["20","21"]:
			getToken()
			setContentSource(contentSourceModel.mcode)
			authenticateContentSource()

			if isAuthenticated() == False:
				mc.ShowDialogNotification("Error Authenticating...")
				close()
			else:
				# Try the function call again.  This time without retying.
				return callMediaflyFunction(func, False, *args)
		else:
			mc.LogError(str(e))
			raise

def setContentSource(mcode, isLaunchSource = False):
	"""
	Sets content source for the app based on mcode
	"""
	mc.ShowDialogWait()
	newContentSourceModel = callMediaflyFunction(HttpPost.addContentSource, True, mcode)
	setContentSourceModel(newContentSourceModel, isLaunchSource)
	mc.HideDialogWait()

def isAuthenticated():
	if contentSourceModel.authenticated or contentSourceModel.requiresAuthentication == False:
		# allows unbound users
		if contentSourceModel.allowsUnboundUsers:
			return True
		
		# requires user and is authenticated
		if contentSourceModel.defaultUser:
			if contentSourceModel.defaultUser.requiresAuthentication == False:
				return True
			elif contentSourceModel.defaultUser.authenticated:
				return True

	return False

def close():
	MediaManager.stopThread()
	mc.ActivateWindow(10482)

def setContentSourceModel(newContentSourceModel, isLaunchSource = False):
	"""
	Sets content source for the app based on contentSourceModel
	"""
	global contentSourceModel
	global launchContentSourceModel

	contentSourceModel = newContentSourceModel
	if isLaunchSource: launchContentSourceModel = newContentSourceModel
	
	# set skin variables
	_setAppVariable(contentSourceModel.supportsUserBindings, CS_SUPPORTS_USER_BINDINGS)
	_setAppVariable(contentSourceModel.supportsRatings, CS_SUPPORTS_RATINGS)
	_setAppVariable(contentSourceModel.supportsFavorites, CS_SUPPORTS_FAVORITES)
	_setAppVariable(contentSourceModel.supportsSubscriptions, CS_SUPPORTS_SUBSCRIPTIONS)
	_setAppVariable(contentSourceModel.isSearchable, CS_ISSEARCHABLE)

	config.SetValue(CS_ASSET_SPLASH, getAssetPath(Assets.SPLASH))
	config.SetValue(CS_ASSET_BACKGROUND, getAssetPath(Assets.BACKGROUND))
	config.SetValue(CS_ASSET_BANNER, getAssetPath(Assets.BANNER))
	config.SetValue(CS_ASSET_BRANDING_HOME, getAssetPath(Assets.RIGHT_HOME))
	config.SetValue(CS_ASSET_BRANDING_LOWER, getAssetPath(Assets.RIGHT_LOWER))

def showMainWindow():
	"""
	Shows the main window
	"""
	from windows import MainWindow
	mc.ActivateWindow(14000)
	MainWindow.clearItems()

def showSplashWindow():
	"""
	Shows spash screen
	"""
	postImpression(getAssetPath(Assets.SPLASH))
	mc.ActivateWindow(14001)

def getAssetPath(asset):
	slug = StringUtils.CleanString(contentSourceModel.slug)
	url = "http://csassets.mediafly.com/%s/%s" % (slug, asset)

	return url

def postImpression(url, slug = None):
	if contentSourceModel.postImpressions:
		callMediaflyFunction(HttpPost.postImpression, True, launchContentSourceModel.slug, contentSourceModel, url, slug)

def _updateIsLoggedIn():
	"""
	Updates App setting islogged in
	"""
	if boxeemediafly.contentSourceModel.defaultUser is None:
		config.Reset("isloggedin")
		return
	
	if boxeemediafly.contentSourceModel.defaultUser.authenticated or not boxeemediafly.contentSourceModel.defaultUser.requiresAuthentication:
		config.SetValue("isloggedin", "True")
	else:
		config.Reset("isloggedin")

def _setAppVariable(condition, key):
	if condition:
		config.SetValue(key, "True")
	else:
		config.Reset(key)

def authenticateContentSource():
	mc.ShowDialogWait()
	AuthenticationManager.authenticateContentSource(boxeemediafly.contentSourceModel)
	_updateIsLoggedIn()
	mc.HideDialogWait()

def bindUser():
	mc.ShowDialogWait()
	if AuthenticationManager.addUserForContentSource(contentSourceModel):
		boxeemediafly.loadChannel()
		_updateIsLoggedIn()
	mc.HideDialogWait()

def unbindUser():
	mc.ShowDialogWait()
	if AuthenticationManager.unbindDefaultUserForContentSource(contentSourceModel):
		if isAuthenticated():
			boxeemediafly.loadChannel()
			_updateIsLoggedIn()
		else:
			close()
	mc.HideDialogWait()

def loadChannel(title = "", channelSlug="__root__"):
	from windows import MainWindow
	mc.ShowDialogWait()
	# clear the list
	MainWindow.clearItems()
	#load/set new items
	if channelSlug=="__root__": title = StringUtils.CleanString(contentSourceModel.title)
	try:
		models = callMediaflyFunction(HttpPost.getChannel, True, channelSlug, contentSourceModel, 175, 175, 175, 175)
		listItems = utils.ModelsToListItems(models)
		MainWindow.setTitle(title)
		MainWindow.setItems(listItems)
	except:
		mc.ShowDialogNotification("Error loading Channel...")
	mc.HideDialogWait()

def loadShow(title, showSlug):
	from windows import MainWindow
	mc.ShowDialogWait()
	# clear the list
	MainWindow.clearItems()
	#load/set new items
	try:
		models = callMediaflyFunction(HttpPost.getShowInfo, True, showSlug, contentSourceModel, 175, 175, 175, 175)
		listItems = utils.ModelsToListItems(models)
		MainWindow.setTitle(title)
		MainWindow.setItems(listItems)
	except:
		mc.ShowDialogNotification("Error loading Show...")
	mc.HideDialogWait()

def loadSearch(search):
	from windows import MainWindow
	mc.ShowDialogWait()
	# clear the list
	MainWindow.clearItems()
	#load/set new items
	try:
		models = callMediaflyFunction(HttpPost.search, True, search, contentSourceModel, 50)
		listItems = utils.ModelsToListItems(models)
		MainWindow.setItems(listItems)
	except:
		mc.ShowDialogNotification("Error loading Search...")
	mc.HideDialogWait()

def addFavoriteEpisode(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		callMediaflyFunction(HttpPost.addFavoriteEpisode, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Added Favorite Episode: " + item.GetLabel())
		item.SetProperty("isEpisodeFavorite", "True")
	except:
		mc.ShowDialogNotification("Error Adding Favorite Episode")
	mc.HideDialogWait()

def addFavoriteShow(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("showSlug")
		callMediaflyFunction(HttpPost.addFavoriteEpisode, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Added Favorite Show: " + item.GetProperty("showTitle"))
		item.SetProperty("isShowFavorite", "True")
	except:
		mc.ShowDialogNotification("Error Adding Favorite Episode")
	mc.HideDialogWait()
	
def removeFavoriteEpisode(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		callMediaflyFunction(HttpPost.removeFavoriteEpisode, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Removed Favorite Episode: " + item.GetLabel())
		item.SetProperty("isEpisodeFavorite", "")
	except:
		mc.ShowDialogNotification("Error Adding Favorite Episode")
	mc.HideDialogWait()
	
def removeFavoriteShow(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("showSlug")
		callMediaflyFunction(HttpPost.removeFavoriteShow, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Removed Favorite Show: " + item.GetProperty("showTitle"))
		item.SetProperty("isShowFavorite", "")
	except:
		mc.ShowDialogNotification("Error Adding Favorite Episode")
	mc.HideDialogWait()

def subscribeEpisode(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		callMediaflyFunction(HttpPost.subscribeEpisode, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Subscribe Episode: " + item.GetTitle())
		item.SetProperty("isEpisodeSubscription", "True")
	except:
		mc.ShowDialogNotification("Error Adding Episode Subscription")
	mc.HideDialogWait()

def unsubscribeEpisode(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		callMediaflyFunction(HttpPost.unsubscribeEpisode, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Removed Episode Subscription: " + item.GetTitle())
		item.SetProperty("isEpisodeSubscription", "")
	except:
		mc.ShowDialogNotification("Error Removing Episode Subscription")
	mc.HideDialogWait()

def subscribeShow(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("showSlug")
		callMediaflyFunction(HttpPost.subscribeShow, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Subscribe Show: " + item.GetTitle())
		item.SetProperty("isShowSubscription", "True")
	except:
		mc.ShowDialogNotification("Error Adding Show Subscription")
	mc.HideDialogWait()

def unsubscribeShow(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("showSlug")
		callMediaflyFunction(HttpPost.unsubscribeEpisode, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Removed Show Subscription: " + item.GetTitle())
		item.SetProperty("isShowSubscription", "")
	except:
		mc.ShowDialogNotification("Error Removing Show Subscription")
	mc.HideDialogWait()

def addEpisodeRating(item, rating):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		callMediaflyFunction(HttpPost.addEpisodeRating, True, slug, contentSourceModel, rating)
		mc.ShowDialogNotification("Set Episode Rating")
		item.SetProperty("userRating", str(rating))
		item.SetProperty("roundedUserRating", str(round(float(rating) * 2) / 2))
	except:
		mc.ShowDialogNotification("Error Rating Episode")
	mc.HideDialogWait()

def removeEpisodeRating(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		callMediaflyFunction(HttpPost.removeEpisodeRating, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Removed Episode Rating")
		item.SetProperty("userRating", "0")
		item.SetProperty("roundedUserRating", "")
	except:
		mc.ShowDialogNotification("Error Rating Episode")
	mc.HideDialogWait()

def addShowRating(item, rating):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("showSlug")
		callMediaflyFunction(HttpPost.addShowRating, True, slug, contentSourceModel, rating)
		mc.ShowDialogNotification("Set Show Rating")
		item.SetProperty("roundedShowUserRating", str(round(float(rating) * 2) / 2))
	except:
		mc.ShowDialogNotification("Error Rating Show")
	mc.HideDialogWait()

def removeShowRating(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("showSlug")
		callMediaflyFunction(HttpPost.removeShowRating, True, slug, contentSourceModel)
		mc.ShowDialogNotification("Removed Show Rating")
		item.SetProperty("roundedShowUserRating", "")
	except:
		mc.ShowDialogNotification("Error Rating Show")
	mc.HideDialogWait()

def showFullScreen():
	MediaManager.showFullScreen()

def playItems(items, index):
	MediaManager.playItems(contentSourceModel, items, index)

def playItem(item, useActionMenu = False):
	MediaManager.playItem(contentSourceModel, item, useActionMenu)
	
def playNextShowEpisode(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		showSlug = item.GetProperty("showSlug")
		model = callMediaflyFunction(HttpPost.getNextEpisodeForShow, True, slug, showSlug, contentSourceModel)
		play(utils.EpisodeModelToListItem(model))
	except:
		mc.ShowDialogNotification("Error playing next episode in show")
	mc.HideDialogWait()

def playPreviousShowEpisode(item):
	mc.ShowDialogWait()
	try:
		slug = item.GetProperty("slug")
		showSlug = item.GetProperty("showSlug")
		model = callMediaflyFunction(HttpPost.getPreviousEpisodeForShow, True, slug, showSlug, contentSourceModel)
		play(utils.EpisodeModelToListItem(model))
	except:
		mc.ShowDialogNotification("Error playing previous episode in show")
	mc.HideDialogWait()

def postAction(episodeSlug, mediaType, action, position = None):
	try:
		callMediaflyFunction(HttpPost.postAction, True, episodeSlug, contentSourceModel, mediaType, action, position)
	except:
		#TODO look at handling error
		pass