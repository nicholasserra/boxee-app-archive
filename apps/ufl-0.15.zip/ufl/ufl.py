from BeautifulSoup import BeautifulStoneSoup
import urllib2
import datetime
import mc

def get_season():
	url = "http://www.ufl-football.com/schedule/rss_feed"
	response = urllib2.urlopen(url)
	xml = response.read()
	soup = BeautifulStoneSoup(xml)
	games = soup.fetch('item')
	game_info = []
	for game in games:
		title = game.title.text.split(',')
		team_names = title[0].split(' vs ')
		date = title[1].strip()
		time = game.description.text[362:367]
		week = game.description.text[707:714]
		game_info.append([[date,time,week],team_names])
	return game_info


def get_team_image(team):
	"""returns the url for the team"""
	if team == "Sacramento Mountain Lions":
		return "Sacramento.png"
	elif team == "Hartford Colonials":
		return "Hartford.png"
	elif team == "Omaha Nighthawks":
		return "Omaha.png"
	elif team == "Las Vegas Locomotives":
		return "LasVegas.png"
	elif team == "Florida Tuskers":
		return "Florida.png"		

def get_small_team_image(team):
	"""returns the url for the team"""
	if team == "Mountain Lions":
		return "sacramento2.png"
	elif team == "Colonials":
		return "hartford2.png"
	elif team == "NightHawks":
		return "omaha2.png"
	elif team == "Locomotives":
		return "lasvegas2.png"
	elif team == "Tuskers":
		return "florida2.png"
		
def next_game_info(season,today):
	"""creates a list for boxee to render with the next games info"""
	for game in season:
		game_time = datetime.datetime(int(game[0][0][:4]),int(game[0][0][5:7]),int(game[0][0][8:10]),int(game[0][1][:2]),int(game[0][1][3:]))
		diff = game_time - today
		if (diff.days < 0):
			season.remove(game)
	next_game = season[0]
	date = str(next_game[0][0][5:7]+"/"+next_game[0][0][8:10]+"/"+next_game[0][0][0:4])
	time = str(next_game[0][1])
	week = str(next_game[0][2])
	team_a = next_game[1][0]
	team_b = next_game[1][1]
	image_a = get_team_image(team_a)
	image_b = get_team_image(team_b)
	game_time_label = mc.GetWindow(14000).GetLabel(1402)
	game_time_label.SetLabel(date + " @ " + time)
	team_a_image = mc.GetWindow(14000).GetImage(1403)
	team_a_image.SetTexture(image_a)
	team_b_image = mc.GetWindow(14000).GetImage(1404)
	team_b_image.SetTexture(image_b)
	mc.GetWindow(14000).GetList(3100).SetFocusedItem(2*int(week[5:7])-2)
	return season[0]


def short_team_name(team):
	"""take a team name and returns its shorter name"""
	if team == "Sacramento Mountain Lions":
		return "SAC"
	elif team == "Hartford Colonials":
		return "HRT"
	elif team == "Omaha Nighthawks":
		return "OMA"
	elif team == "Las Vegas Locomotives":
		return "LV"
	elif team == "Florida Tuskers":
		return "FL"	


def season_standings(base_group):
	"""gets season standings for all teams"""
	url = "http://www.ufl-football.com/"
	response = urllib2.urlopen(url)
	html = response.read()
	soup = BeautifulStoneSoup(html)
	result_table = soup.fetch('div', {'class':'results'})[0].table
	i=0
	standings = []
	for team in result_table.findAll("tr")[1:10]:
		if i % 2 == 0:
			tds = team.findAll('td')
			# team, W, L, T, %, Pf, Pa
			team = tds[0].img.contents[0].strip()
			wins = tds[1].strong.contents[0]
			losses = tds[2].strong.contents[0]
			ties = tds[3].strong.contents[0]
			percent = tds[4].contents[0]
			pf = tds[5].contents[0]
			pa = tds[6].contents[0]
			standings.append([team, wins, losses, ties, percent, pf, pa])
		i=i+1
	start = base_group+1
	for standing in standings:
		logo = mc.GetActiveWindow().GetImage(start)
		logo.SetTexture(get_small_team_image(standing[0]))
		win = mc.GetActiveWindow().GetLabel(start+10)
		win.SetLabel(str(standing[1]))
		loss = mc.GetActiveWindow().GetLabel(start+20)
		loss.SetLabel(str(standing[2]))
		tie = mc.GetActiveWindow().GetLabel(start+30)
		tie.SetLabel(str(standing[3]))
		pct = mc.GetActiveWindow().GetLabel(start+40)
		pct.SetLabel(str(standing[4]))
		pfor = mc.GetActiveWindow().GetLabel(start+50)
		pfor.SetLabel(str(standing[5]))
		pagnst = mc.GetActiveWindow().GetLabel(start+60)
		pagnst.SetLabel(str(standing[6]))
		start = start + 1

def season_info(season,list_id):
	"""returns a list of games in the season"""
	itemList = mc.ListItems()
	for game in season:
		date = str(game[0][0][5:7]+"/"+game[0][0][8:10]+"/"+game[0][0][0:4])
		time = str(game[0][1])
		week = str(game[0][2]).strip()
		game_time = datetime.datetime(int(game[0][0][:4]),int(game[0][0][5:7]),int(game[0][0][8:10]),0,0)
		four_day = datetime.timedelta(days=4)
		next_week = datetime.datetime.today() - four_day
		if game_time >= next_week:
			item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
			team_a = str(game[1][0])
			team_b = str(game[1][1])
			teams = team_a + " vs. " + team_b
			item.SetLabel(teams)
			item.SetThumbnail("logo.png")
			item.SetProperty('team_a',get_team_image(game[1][0]))
			item.SetProperty('team_b',get_team_image(game[1][1]))
			item.SetProperty('week',week)
			item.SetProperty('date',date)
			item.SetProperty('time',time)
			description = date + " @ " + time + "\n" + week + "\n\n Games are watchable on or after Game time and are available on the top row of previous screen."
			#item.SetDescription(description)
			#if len(week[5:7]) == 1:
			#long_week = "0"+week[5:7]
			#else:
			#long_week = week[5:7]
			#link = "http://www.ufl-football.com/livestreaming/2010REG"+long_week+short_team_name(team_a)+"@"+short_team_name(team_b)
			#item.SetPath(link)
			itemList.append(item)
	return itemList
