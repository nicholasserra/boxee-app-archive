import urllib
import urllib2
import cookielib
import re
import mc
import simplejson as json

appkey = "375055722b4041732b7e7da773"
limit = 18

def clean_html_entities(text):
    ''' Convert html entities '''
    try:
        text = text.replace('&#8217;', "'")
        text = text.replace('&#8220;', '"')
        text = text.replace('&#8221;', '"')
        text = text.replace('&#160;', '')
        text = text.replace('&amp;', '&')
        text = text.replace('&gt;', '>')
        text = text.replace('&lt;', '<')
        text = text.replace('&quot;', '"')
        text = text.replace('&iacute;', 'i')
        text = text.replace('&#39;', "'")
        text = text.replace('&rsquo;', "'")
    except:
        pass
    return text



#def play_youporn_link(item):
#    link = ('http://www.youporn.com%s' % item.GetPath())
#    data = 'user_choice=Enter'
#    http = mc.Http()
#    http.SetUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.77 Safari/535.7')
#    http.SetHttpHeader('Cookie', 'age_check=1; expires=Thu, 27-Oct-30 00:01:18 GMT; domain=.youporn.com; path=/')
#    result = http.Post(link, data)
#    url = re.findall("video_url.*?:.*?(http.*?)'", result, re.I)[0]
#    url = url.replace('%26', '&')
#    item.SetPath(url)
#    mc.GetPlayer().Play(item)



def get_youporn_videos(items, section, page = 0):
    """ method to get some video items from the youporn api
        section can be 'rating','most_viewed','top_rated' """
    try:
        offset = int(page)*limit
        cj = cookielib.CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        link = ('http://www.youporn.com/api/videos-search/appkey/%s/limit/%d/offset/%d/orientation/straight/sort/%s/' % (appkey, limit, offset, section))
        ck = cookielib.Cookie(version=0, name='age_verified', value='1', port=None, port_specified=False, domain='www.youporn.com', domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None})
        cj.set_cookie(ck)
        resp = opener.open(link)
        results = json.load(resp)
        resp.close()
    except Exception,e:
        mc.ShowDialogOk('Error', str(e))
        print "ERROR: "+str(e)
    for video in range(1,limit+1):
        try:
            title = results[video]['title']
            url = results[video]['ipad_url']
            thumb = results[video]['image']
            views = results[video]['views']
            duration = results[video]['duration_formatted']
            rating = results[video]['rating']
            if rating:
                rating = int(float(rating)/10.0+0.5)
            else:
                rating = 0
            item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
            item.SetLabel(str(title))
            item.SetProperty('runtime', str(duration))
            item.SetThumbnail(str(thumb))
            item.SetPath(str(url))
            item.SetProperty('views', str(views))
            item.SetProperty('rating', str(rating))
            item.SetProperty('adult', 'true')
            item.SetReportToServer(False)
            items.append(item)
            continue
        except Exception,e:
            print "ERROR: "+str(e)
            
def search_youporn_videos(items, query, page = 0):
    """docstring for search_youporn_videos"""
    try:
        offset = int(page)*limit
        cj = cookielib.CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        link = ('http://www.youporn.com/api/videos-search/appkey/%s/limit/%d/offset/%d/orientation/straight/search/%s/sort/rating/' % (appkey, limit, offset, query))
        ck = cookielib.Cookie(version=0, name='age_verified', value='1', port=None, port_specified=False, domain='www.youporn.com', domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None})
        cj.set_cookie(ck)
        resp = opener.open(link)
        results = json.load(resp)
        resp.close()
    except Exception,e:
        mc.ShowDialogOk('Error', str(e))
        print "ERROR: "+str(e)
    for video in range(1,limit+1):
        try:
            title = results[video]['title']
            url = results[video]['ipad_url']
            thumb = results[video]['image']
            views = results[video]['views']
            duration = results[video]['duration_formatted']
            rating = results[video]['rating']
            if rating:
                rating = int(float(rating)/10.0+0.5)
            else:
                rating = 0
            item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
            item.SetLabel(str(title))
            item.SetProperty('runtime', str(duration))
            item.SetThumbnail(str(thumb))
            item.SetPath(str(url))
            item.SetProperty('views', str(views))
            item.SetProperty('rating', str(rating))
            item.SetProperty('adult', 'true')
            item.SetReportToServer(False)
            items.append(item)
            continue
        except Exception,e:
            print "ERROR: "+str(e)