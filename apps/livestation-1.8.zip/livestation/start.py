import mc
import os

params = mc.Parameters()

try:
    if os.name == "posix":
        params['showlogin'] = "True"
        mc.GetApp().ActivateWindow(14000, params)
    else:
        params['showlogin'] = "False"
        mc.GetApp().ActivateWindow(14000, params)   

except:
        params['showlogin'] = "False"
        mc.GetApp().ActivateWindow(14000, params)