import urllib2
import urllib
import elementtree.ElementTree as ET
import string
import mc

class ElementWrapper:
    def __init__(self, element):
        self._element = element
    def __getattr__(self, tag):
        if tag.startswith("__"):
            raise AttributeError(tag)
        return self._element.findtext(tag)

class pollWolfgang:
    def __init__(self):
        self.host = "http://concerts.wolfgangsvault.com"
        self.namespace = "{http://wolfgangsvault.com/webservices/}"       
    
    def request(self, path):
        # Add debugging to post
        #h=urllib2.HTTPHandler(debuglevel=1)
        #opener = urllib2.build_opener(h)
        #urllib2.install_opener(opener)
        request = urllib2.Request(path)
        try:
            r = urllib2.urlopen(request)
        except urllib2.HTTPError, e:
            return "Failed"
        
        xml = r.read()
               
        return xml
    
    def auth(self, username, password):
        path = self.host + "/ws/concert.asmx/CreateSession?login=" + username + "&password=" + password
        xml = self.request(path)

        if xml != "Failed":
            response = ET.fromstring(xml)
    
            d = {
                'SessionID': response.findtext(self.namespace + "SessionID"),
                'IsSessionValid': response.findtext(self.namespace + "IsSessionValid"),
                'ScreenName': response.findtext(self.namespace + "Customer/" + self.namespace + "ScreenName"),
                'Email': response.findtext(self.namespace + "Customer/" + self.namespace + "Email"),
                'Login': response.findtext(self.namespace + "Customer/" + self.namespace + "Login"),
                'LastName': response.findtext(self.namespace + "Customer/" + self.namespace + "LastName"),
                'FirstName': response.findtext(self.namespace + "Customer/" + self.namespace + "FirstName"),
                'CustomerID': response.findtext(self.namespace + "Customer/" + self.namespace + "CustomerID"),
                'IsWVIPMember': response.findtext(self.namespace + "Customer/" + self.namespace + "IsWVIPMember"),
                'IsDisabled': response.findtext(self.namespace + "Customer/" + self.namespace + "IsDisabled")
            }
       
            if d["IsSessionValid"] == "false":
                return "Invalid"
            elif d["IsDisabled"] == "true":
                return "Disabled"
            else:      
                return d
        else:
            return "Failed"
    
    def AddConcertFavorite(self, SessionID, ConcertID):
        path = self.host + "/ws/concert.asmx/AddConcertFavorite?ConcertID=" + str(ConcertID) + "&SessionID=" + str(SessionID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"
        
    def AddMyPlayListFavorite(self, SessionID, PlaylistID):
        path = self.host + "/ws/concert.asmx/AddMyPlayListFavorite?PlaylistID=" + str(PlaylistID) + "&SessionID=" + str(SessionID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"
        
    def AddTrackToMyPlayList(self, SessionID, TrackID, MyPlaylistID):
        path = self.host + "/ws/concert.asmx/AddTrackToMyPlayList?SessionID=" + str(SessionID) + "&TrackID=" + str(TrackID) + "&MyPlaylistID=" + str(MyPlaylistID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"
    
    def GetArtistListing(self, alphakey="A"):
        path = self.host + "/ws/concert.asmx/GetArtistListing?"
        xml = self.request(path)
        
        if alphakey.isdigit():
            alphakey = "OTHER"
               
        if xml != "Failed":
            response = ET.fromstring(xml)
            
            d = []
            
            for artist in response.findall("ArtistLight"):
                artist = ElementWrapper(artist)
                
                if artist.AlphaKey == alphakey:
                    d.append({
                        'ArtistID': artist.ArtistID,
                        'ArtistName': artist.FriendlyName,
                        'SeoUrlName': artist.SeoUrlName,
                        'DisplayName': artist.DisplayName,
                        'AlphaKey': artist.AlphaKey,
                        'ArtistImage': "http://images.wolfgangsvault.com/artists/" + artist.ArtistID + ".jpg"
                    })
             
            return d
        else:
            return "Failed"
    
    def GetArtistsByGenreID(self, GenreID):
        path = self.host + "/ws/concert.asmx/GetArtistsByGenreID?GenreID=" + GenreID
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            
            d = []
            
            for artist in response.findall("ArtistLight"):
                artist = ElementWrapper(artist)
                d.append({
                    'ArtistID': artist.ArtistID,
                    'ArtistName': artist.FriendlyName,
                    'FriendlyName': artist.FriendlyName,
                    'Name': artist.Name,
                    'SeoUrlName': artist.SeoUrlName,
                    'DisplayName': artist.DisplayName,
                    'AlphaKey': artist.AlphaKey,
                    'ArtistImage': "http://images.wolfgangsvault.com/artists/" + artist.ArtistID + ".jpg"
                })
             
            return d
        else:
            return "Failed"
    
    def GetCollectionListing(self):
        path = self.host + "/ws/concert.asmx/GetCollectionListing?"
        xml = self.request(path)

        if xml != "Failed":
            response = ET.fromstring(xml)
            
            d = []
            
            for collection in response.findall("Collection"):
                collection = ElementWrapper(collection)
                d.append({
                    'CollectionID': collection.CollectionID,
                    'Name': collection.Name,
                    'SeoUrlName': collection.SeoUrlName,
                })
             
            return d
        else:
            return "Failed"
    
    def GetConcert(self, ConcertID, SessionID, Hostname):
        path = self.host + "/ws/concert.asmx/GetConcert?ConcertID=" + ConcertID + "&SessionID=" + SessionID + "&Hostname=" + Hostname
        xml = self.request(path)        
               
        if xml != "Failed":
            response = ET.fromstring(xml)
            
            details = {
                'DetailSummaryAbstract': response.findtext('DetailSummaryAbstract'),
                'Description': response.findtext('Description'),
                'ShowTime': response.findtext('ShowTime'),
                'TotalTrackTime': response.findtext('TotalTrackTime'),
                'TrackCount': response.findtext('TrackCount'),
                'Title': response.findtext('Title'),
                'DescriptionCallout': response.findtext('DescriptionCallout'),
                'Byline': response.findtext('Byline'),
                'SeoUrlName': response.findtext('SeoUrlName'),
                'PublishDate': response.findtext('PublishDate'),
                'PublishDateFormattedSort': response.findtext('PublishDateFormattedSort'),
                'IsStreamable': response.findtext('IsStreamable'),
                'EventID': response.findtext('ConcertID/EventID'),
                'ArtistID': response.findtext('ConcertID/ArtistID'),
                'ConcertID': response.findtext('ConcertID/ConcertID'),
                'PublishDate': response.findtext('PublishDate'),
                'ConcertTypeID': response.findtext('ConcertType/ConcertTypeID'),
                'ConcertTypeName': response.findtext('ConcertType/Name'),
                'GlobalRating': response.findtext('GlobalRating/DecimalScore'),
                'CollectionID': response.findtext('Collection/CollectionID'),
                'CollectionName': response.findtext('Collection/Name'),
                'DateFormatted': response.findtext('Event/DateFormatted'),  
                'DateString': response.findtext('Event/DateString'),
                'VenueID': response.findtext('Event/Venue/VenueID'),
                'Location': response.findtext('Event/Venue/Location'),
                'VenueName': response.findtext('Event/Venue/Name'),   
                'SmallImage': "/concerts/" + response.findtext('SmallImage/Image/FileName'),
                'LargeImage': "/concerts/" + response.findtext('LargeImage/Image/FileName')           
            }
            
            artist = {
                'ArtistID': response.findtext('Artist/ArtistID'),
                'ArtistFriendlyName': response.findtext('Artist/FriendlyName'),
                'ArtistName': response.findtext('Artist/Name'),
                'ArtistSeoUrlName': response.findtext('Artist/SeoUrlName'),
                'ArtistUrl': response.findtext('Artist/Url'),
                'FileName': response.findtext('Artist/Image/FileName'),
                'VirtualFilePath': response.findtext('Artist/Image/VirtualFilePath'),
            }
            
            tracks = []
            for track in response.findall("Tracks/Track"):
                wrappedtrack = ElementWrapper(track)
                tracks.append({
                    'TrackNumber': wrappedtrack.TrackNumber,
                    'TrackID': wrappedtrack.TrackID,
                    'Duration': wrappedtrack.Duration,
                    'DurationInSeconds': wrappedtrack.DurationInSeconds,
                    'Description': wrappedtrack.Description,
                    'OriginalVersion': wrappedtrack.OriginalVersion,
                    'IsDownloadable': wrappedtrack.IsDownloadable,
                    'SongID': track.findtext('Song/SongID'),
                    'Name': track.findtext('Song/Name')
                })
                
            related = []
            for concert in response.findall("./RelatedConcerts/Concerts/Concert"):
                concert = ElementWrapper(concert)
                related.append({
                    'ConcertID': concert.ConcertID,
                    'EventID': concert.EventID,
                    'ArtistID': concert.ArtistID,
                    'SeoUrlName': concert.SeoUrlName,
                    'Venue': concert.Venue,
                    'VenueLocation': concert.VenueLocation,
                    'DateFormatted': concert.DateFormatted,
                    'DateString': concert.DateString,
                    'ArtistName': concert.ArtistName,
                    'ArtistFriendlyName': concert.ArtistFriendlyName,
                    'CollectionName': concert.CollectionName,
                    'CollectionID': concert.CollectionID,
                    'TotalTrackTime': concert.TotalTrackTime,
                    'TrackCount': concert.TrackCount,
                    'IsAvailableForDownload': concert.IsAvailableForDownload,
                    'IsFreeDownload': concert.IsFreeDownload,
                    'PriceLabel': concert.PriceLabel,
                    'ConcertTypeName': concert.ConcertTypeName,
                    'ConcertTypeID': concert.ConcertTypeID
                })
            
            d = [details, artist, tracks, related]
            return d
        else:
            return "Failed"
   
    def GetConcertFavorites(self, SessionID):
        path = self.host + "/ws/concert.asmx/GetConcertFavorites?SessionID=" + SessionID
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for concert in response.findall("ConcertListing"):
                wrappedconcert = ElementWrapper(concert)
                
                details = {
                    'ShowTime': wrappedconcert.ShowTime,
                    'TotalTrackTime': wrappedconcert.TotalTrackTime,
                    'TrackCount': wrappedconcert.TrackCount,
                    'IsAvailableForDownload': wrappedconcert.IsAvailableForDownload,
                    'Description': response.findtext('Description'),
                    'IsFreeDownload': wrappedconcert.IsFreeDownload,
                    'PriceLabel': wrappedconcert.PriceLabel,
                    'Title': wrappedconcert.Title,
                    'SeoUrlName': wrappedconcert.SeoUrlName,
                    'DetailSummaryAbstract': wrappedconcert.DetailSummaryAbstract,
                    'DetailSessionSummaryAbstract': wrappedconcert.DetailSessionSummaryAbstract,
                    'DetailUrl': wrappedconcert.DetailUrl,
                    'IsStreamable': wrappedconcert.IsStreamable,
                    'PublishDate': wrappedconcert.PublishDate,
                    'DetailUrl': wrappedconcert.DetailUrl,
                    'DetailUrl': wrappedconcert.DetailUrl,
                    'ConcertID': wrappedconcert.DetailUrl,
                    'DateFormatted': concert.findtext('Event/DateFormatted'),  
                    'DateString': concert.findtext('Event/DateString'),
                    'EventID': concert.findtext('ConcertID/EventID'),
                    'ArtistID': concert.findtext('ConcertID/ArtistID'),
                    'ConcertID': concert.findtext('ConcertID/ConcertID'),
                    'Location': concert.findtext('Event/Venue/Location'),
                    'ConcertTypeID': concert.findtext('ConcertType/ConcertTypeID'),
                    'ConcertTypeName': concert.findtext('ConcertType/Name'),
                    'VenueName': concert.findtext('Event/Venue/Name'),
                    'SmallImage': "/concerts/" + concert.findtext('SmallImage/Image/FileName'),
                    'LargeImage': "/concerts/" + concert.findtext('LargeImage/Image/FileName')
                }
                
                artist = {
                    'ArtistID': concert.findtext('Artist/ArtistID'),
                    'ArtistFriendlyName': concert.findtext('Artist/FriendlyName'),
                    'ArtistName': concert.findtext('Artist/Name'),
                    'ArtistSeoUrlName': concert.findtext('Artist/SeoUrlName'),
                    'ArtistUrl': concert.findtext('Artist/Url'),
                }
                
                tracks = []
                for track in concert.findall("FirstTrack/Track"):
                    wrappedtrack = ElementWrapper(track)
                    tracks.append({
                        'TrackNumber': wrappedtrack.TrackNumber,
                        'TrackID': wrappedtrack.TrackID,
                        'Duration': wrappedtrack.Duration,
                        'DurationInSeconds': wrappedtrack.DurationInSeconds,
                        'Description': wrappedtrack.Description,
                        'OriginalVersion': wrappedtrack.OriginalVersion,
                        'IsDownloadable': wrappedtrack.IsDownloadable,
                        'SongID': track.findtext('Song/SongID'),
                        'Name': track.findtext('Song/Name')
                    })
                
                d.append([details, artist, tracks])
                        
            return d
        else:
            return "Failed"

    def GetConcertSummary(self, ConcertID):
        path = self.host + "/ws/concert.asmx/GetConcertSummary?ConcertID=" + ConcertID
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.text
        else:
            return "Failed"
    
    def GetConcertsByArtistIDWithRelatedArtists(self, ArtistID):
        path = self.host + "/ws/concert.asmx/GetConcertsByArtistIDWithRelatedArtists?ArtistID=" + str(ArtistID)
        xml = self.request(path)
       
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for concert in response.findall("Concert"):
                concert = ElementWrapper(concert)
                d.append({
                    'ConcertID': concert.ConcertID,
                    'EventID': concert.EventID,
                    'ArtistID': concert.ArtistID,
                    'SeoUrlName': concert.SeoUrlName,
                    'Venue': concert.Venue,
                    'VenueLocation': concert.VenueLocation,
                    'DateFormatted': concert.DateFormatted,
                    'DateString': concert.DateString,
                    'ArtistName': concert.ArtistName,
                    'ArtistFriendlyName': concert.ArtistFriendlyName,
                    'CollectionName': concert.CollectionName,
                    'CollectionID': concert.CollectionID,
                    'TotalTrackTime': concert.TotalTrackTime,
                    'TrackCount': concert.TrackCount,
                    'IsAvailableForDownload': concert.IsAvailableForDownload,
                    'IsFreeDownload': concert.IsFreeDownload,
                    'PriceLabel': concert.PriceLabel,
                    'ConcertTypeName': concert.ConcertTypeName,
                    'ConcertTypeID': concert.ConcertTypeID,
                    'ArtistImage': "http://images.wolfgangsvault.com/artists/" + concert.ArtistID + ".jpg"
                })
                        
            return d
        else:
            return "Failed"
 
    def GetConcertsByCollectionID(self, CollectionID):
        path = self.host + "/ws/concert.asmx/GetConcertsByCollectionID?CollectionID=" + str(CollectionID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for concert in response.findall("Concert"):
                concert = ElementWrapper(concert)
                d.append({
                    'ConcertID': concert.ConcertID,
                    'EventID': concert.EventID,
                    'ArtistID': concert.ArtistID,
                    'SeoUrlName': concert.SeoUrlName,
                    'Venue': concert.Venue,
                    'VenueLocation': concert.VenueLocation,
                    'DateFormatted': concert.DateFormatted,
                    'DateString': concert.DateString,
                    'ArtistName': concert.ArtistName,
                    'ArtistFriendlyName': concert.ArtistFriendlyName,
                    'CollectionName': concert.CollectionName,
                    'CollectionID': concert.CollectionID,
                    'TotalTrackTime': concert.TotalTrackTime,
                    'TrackCount': concert.TrackCount,
                    'IsAvailableForDownload': concert.IsAvailableForDownload,
                    'IsFreeDownload': concert.IsFreeDownload,
                    'PriceLabel': concert.PriceLabel,
                    'ConcertTypeName': concert.ConcertTypeName,
                    'ConcertTypeID': concert.ConcertTypeID,
                    'ArtistImage': "http://images.wolfgangsvault.com/artists/" + concert.ArtistID + ".jpg"
                })
                        
            return d
        else:
            return "Failed"

    def GetConcertVaultTypeAheadMobile(self, search):
        search = search.replace(" ", "+")
        path = self.host + "/ws/concert.asmx/GetConcertVaultTypeAheadMobile?prefixText=" + search
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for item in response.findall("i"):
                item = ElementWrapper(item)
                d.append({
                    'ArtistID': item.k,
                    'ArtistName': item.v,
                    'ArtistImage': "http://images.wolfgangsvault.com/artists/" + item.k + ".jpg"
                })
            return d
        else:
            return "Failed"
    
    def GetFeaturedConcerts(self):
        path = self.host + "/ws/concert.asmx/GetFeaturedConcerts?"
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for concert in response.findall("./Concerts/*/Concert"):
                concert = ElementWrapper(concert)
                d.append({
                    'ConcertID': concert.ConcertID,
                    'EventID': concert.EventID,
                    'ArtistID': concert.ArtistID,
                    'SeoUrlName': concert.SeoUrlName,
                    'Venue': concert.Venue,
                    'VenueLocation': concert.VenueLocation,
                    'DateFormatted': concert.DateFormatted,
                    'DateString': concert.DateString,
                    'ArtistName': concert.ArtistName,
                    'ArtistFriendlyName': concert.ArtistFriendlyName,
                    'CollectionName': concert.CollectionName,
                    'CollectionID': concert.CollectionID,
                    'TotalTrackTime': concert.TotalTrackTime,
                    'TrackCount': concert.TrackCount,
                    'IsAvailableForDownload': concert.IsAvailableForDownload,
                    'IsFreeDownload': concert.IsFreeDownload,
                    'PriceLabel': concert.PriceLabel,
                    'ConcertTypeName': concert.ConcertTypeName,
                    'ConcertTypeID': concert.ConcertTypeID
                })
                        
            return d
        else:
            return "Failed"
        
    def GetFeaturedItems(self):
        path = self.host + "/ws/concert.asmx/GetFeaturedItems?"
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for concert in response.findall("ConcertsOfTheWeekCollection/ConcertOfTheWeek/ConcertListing"):
                wrappedconcert = ElementWrapper(concert)
                
                details = {
                    'ShowTime': wrappedconcert.ShowTime,
                    'TotalTrackTime': wrappedconcert.TotalTrackTime,
                    'TrackCount': wrappedconcert.TrackCount,
                    'IsAvailableForDownload': wrappedconcert.IsAvailableForDownload,
                    'IsFreeDownload': wrappedconcert.IsFreeDownload,
                    'PriceLabel': wrappedconcert.PriceLabel,
                    'Title': wrappedconcert.Title,
                    'SeoUrlName': wrappedconcert.SeoUrlName,
                    'Description': wrappedconcert.DetailSummaryAbstract,
                    'DetailSessionSummaryAbstract': wrappedconcert.DetailSessionSummaryAbstract,
                    'DetailUrl': wrappedconcert.DetailUrl,
                    'IsStreamable': wrappedconcert.IsStreamable,
                    'PublishDate': wrappedconcert.PublishDate,
                    'DetailUrl': wrappedconcert.DetailUrl,
                    'ConcertID': concert.findtext('ConcertID/ConcertID'),
                    'EventID': concert.findtext('ConcertID/EventID'),
                    'ArtistID': concert.findtext('ConcertID/ArtistID'),
                    'ConcertTypeID': concert.findtext('ConcertType/ConcertTypeID'),
                    'ConcertTypeName': concert.findtext('ConcertType/Name'),
                    'DateFormatted': concert.findtext('Event/DateFormatted'),
                    'DateString': concert.findtext('Event/DateString'),
                    'VenueID': concert.findtext('Event/Venue/VenueID'),
                    'Location': concert.findtext('Event/Venue/Location'),
                    'VenueName': concert.findtext('Event/Venue/Name'),
                    'SmallImageFileName': concert.findtext('SmallImage/Image/FileName'),
                    'SmallImageVirtualFilePath': concert.findtext('SmallImage/Image/VirtualFilePath'),
                    'LargeImageFileName': concert.findtext('LargeImage/Image/FileName'),
                    'LargeImageVirtualFilePath': concert.findtext('LargeImage/Image/VirtualFilePath'),
                    'SmallImage': "/concerts/" + concert.findtext('SmallImage/Image/FileName'),
                    'LargeImage': "/concerts/" + concert.findtext('LargeImage/Image/FileName') 
                }
                
                artist = {
                    'ArtistID': concert.findtext('Artist/ArtistID'),
                    'ArtistFriendlyName': concert.findtext('Artist/FriendlyName'),
                    'ArtistName': concert.findtext('Artist/Name'),
                    'ArtistSeoUrlName': concert.findtext('Artist/SeoUrlName'),
                    'ArtistUrl': concert.findtext('Artist/Url'),
                }
                
                tracks = []
                for track in concert.findall("FirstTrack/Track"):
                    wrappedtrack = ElementWrapper(track)
                    tracks.append({
                        'TrackNumber': wrappedtrack.TrackNumber,
                        'TrackID': wrappedtrack.TrackID,
                        'Duration': wrappedtrack.Duration,
                        'DurationInSeconds': wrappedtrack.DurationInSeconds,
                        'Description': wrappedtrack.Description,
                        'OriginalVersion': wrappedtrack.OriginalVersion,
                        'IsDownloadable': wrappedtrack.IsDownloadable,
                        'SongID': track.findtext('Song/SongID'),
                        'Name': track.findtext('Song/Name')
                    })
                
                d.append([details, artist, tracks])
                        
            return d
        else:
            return "Failed"
    
    def GetFeaturedPlaylists(self,MaxEntries=0):
        path = self.host + "/ws/concert.asmx/GetFeaturedPlaylists?"
        if MaxEntries != 0:
        	path = self.host + "/ws/concert.asmx/GetFeaturedPlaylistsLimited?MaxEntries=" + str(MaxEntries)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            
            d = []
            for playlist in response.findall("MyPlaylistListing"):
                wrappedplaylist = ElementWrapper(playlist)
                
                d.append({
                    'MyPlaylistID': wrappedplaylist.MyPlaylistID,
                    'Name': wrappedplaylist.Name,
                    'DateCreated': wrappedplaylist.DateCreated,
                    'LastModified': wrappedplaylist.LastModified,
                    'IsShuffleMode': wrappedplaylist.IsShuffleMode,
                    'TrackCount': wrappedplaylist.TrackCount,
                    'IsPublic': wrappedplaylist.IsPublic,
                    'IsPublicSystemList': wrappedplaylist.IsPublicSystemList,
                    'DurationInSeconds': wrappedplaylist.DurationInSeconds,
                    'TotalTrackTime': wrappedplaylist.TotalTrackTime,
                    'SeoUrlName': wrappedplaylist.SeoUrlName,
                    'ScreenName': wrappedplaylist.ScreenName,
                    'CustomerID': wrappedplaylist.CustomerID,
                    'PerformerSummary': wrappedplaylist.PerformerSummary,
                    'Summary': wrappedplaylist.Summary,
                    'IsOwnerChangeNotificationEnabled': wrappedplaylist.IsOwnerChangeNotificationEnabled,
                    'DetailUrl': wrappedplaylist.DetailUrl,
                    'GlobalRating': wrappedplaylist.GlobalRating                    
                })
            return d                
        else:
            return "Failed"
    
    def GetGenreListing(self):
        path = self.host + "/ws/concert.asmx/GetGenreListing?"
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for genre in response.findall("Genre"):
                genre = ElementWrapper(genre)
                d.append({
                    'GenreID': genre.GenreID,
                    'Name': genre.Name,
                    'SeoUrlName': genre.GenreID
                })
                        
            return d
        else:
            return "Failed"

    def GetMostPlayedConcerts(self):
        path = self.host + "/ws/concert.asmx/GetMostPlayedConcerts?"
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            n = 0
            for concert in response.findall("Concert"):
                concert = ElementWrapper(concert)
                d.append({
                    'ConcertID': concert.ConcertID,
                    'EventID': concert.EventID,
                    'ArtistID': concert.ArtistID,
                    'SeoUrlName': concert.SeoUrlName,
                    'Venue': concert.Venue,
                    'VenueLocation': concert.VenueLocation,
                    'DateFormatted': concert.DateFormatted,
                    'DateString': concert.DateString,
                    'ArtistName': concert.ArtistName,
                    'ArtistFriendlyName': concert.ArtistFriendlyName,
                    'CollectionName': concert.CollectionName,
                    'CollectionID': concert.CollectionID,
                    'TotalTrackTime': concert.TotalTrackTime,
                    'TrackCount': concert.TrackCount,
                    'IsAvailableForDownload': concert.IsAvailableForDownload,
                    'IsFreeDownload': concert.IsFreeDownload,
                    'PriceLabel': concert.PriceLabel,
                    'ConcertTypeName': concert.ConcertTypeName,
                    'ConcertTypeID': concert.ConcertTypeID,
                    'ArtistImage': "http://images.wolfgangsvault.com/artists/" + concert.ArtistID + ".jpg"
                })
                n = n + 1
                if n >= 10:
                    break
                        
            return d
        else:
            return "Failed"
    
    def GetMyPlaylist(self, SessionID, PlaylistID):
        path = self.host + "/ws/concert.asmx/GetMyPlayList?SessionID=" + str(SessionID) + "&PlaylistID=" + str(PlaylistID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            
            wrappedplaylist = ElementWrapper(response)
            details = {
                'MyPlaylistID': wrappedplaylist.MyPlaylistID,
                'Name': wrappedplaylist.Name,
                'DateCreated': wrappedplaylist.DateCreated,
                'LastModified': wrappedplaylist.LastModified,
                'IsShuffleMode': wrappedplaylist.IsShuffleMode,
                'IsPublic': wrappedplaylist.IsPublic,
                'IsPublicSystemList': wrappedplaylist.IsPublicSystemList,
                'PerformerSummary': wrappedplaylist.PerformerSummary,
                'Summary': wrappedplaylist.Summary,
                'SeoUrlName': wrappedplaylist.SeoUrlName,
                'DurationInSeconds': wrappedplaylist.DurationInSeconds,
                'TotalTrackTime': wrappedplaylist.TotalTrackTime,
                'ScreenName': wrappedplaylist.ScreenName,
                'CustomerID': wrappedplaylist.CustomerID,
                'IsOwnerChangeNotificationEnabled': wrappedplaylist.IsOwnerChangeNotificationEnabled,
                'CustomerRating': wrappedplaylist.CustomerRating,
                'GlobalRating': wrappedplaylist.GlobalRating,
                'Count': response.findtext('MyPlaylistTracks/Count')
            }
                               
            tracks = []
            for track in response.findall("*/MyPlaylistTrack"):
                wrappedtrack = ElementWrapper(track)
                tracks.append({
                    'MyPlaylistTrackID': wrappedtrack.MyPlaylistTrackID,
                    'SortOrder': wrappedtrack.SortOrder,
                    'DateAdded': wrappedtrack.DateAdded,
                    'IsConcertPurchasable': wrappedtrack.IsConcertPurchasable,
                    'ConcertForPurchaseID': wrappedtrack.ConcertForPurchaseID,
                    'TrackNumber': wrappedtrack.TrackNumber,
                    'ShowTime': track.findtext('ConcertListingWithArtistImage/ShowTime'),
                    'Title': track.findtext('ConcertListingWithArtistImage/Title'),
                    'SeoUrlName': track.findtext('ConcertListingWithArtistImage/SeoUrlName'),
                    'ConcertID': track.findtext('ConcertListingWithArtistImage/ConcertID/ConcertID'),
                    'EventID': track.findtext('ConcertListingWithArtistImage/ConcertID/EventID'),
                    'ArtistID': track.findtext('ConcertListingWithArtistImage/ConcertID/ArtistID'),
                    'DateFormatted': track.findtext('ConcertListingWithArtistImage/Event/DateFormatted'),
                    'DateString': track.findtext('ConcertListingWithArtistImage/Event/DateString'),
                    'VenueID': track.findtext('ConcertListingWithArtistImage/Event/Venue/VenueID'),
                    'Location': track.findtext('ConcertListingWithArtistImage/Event/Venue/Location'),
                    'VenueName': track.findtext('ConcertListingWithArtistImage/Event/Venue/Name'),
                    'EventSeoUrlName': track.findtext('ConcertListingWithArtistImage/Event/Venue/SeoUrlName'),
                    'EventUrl': track.findtext('ConcertListingWithArtistImage/Event/Venue/Url'),
                    'MerchandiseUrl': track.findtext('ConcertListingWithArtistImage/Event/Venue/MerchandiseUrl'),
                    'ArtistFriendlyName': track.findtext('ConcertListingWithArtistImage/Artist/FriendlyName'),
                    'ArtistName': track.findtext('ConcertListingWithArtistImage/Artist/Name'),
                    'ArtistSeoUrlName': track.findtext('ConcertListingWithArtistImage/Artist/SeoUrlName'),
                    'ArtistUrl': track.findtext('ConcertListingWithArtistImage/Artist/Url'),
                    'ArtistFileName': track.findtext('ConcertListingWithArtistImage/Artist/Image/FileName'),
                    'ArtistVirtualFilePath': track.findtext('ConcertListingWithArtistImage/Artist/Image/VirtualFilePath'),
                    'LargeImage': "/concerts/" + track.findtext('ConcertListingWithArtistImage/ConcertImageLarge/Image/FileName'),
                    'TrackNumber': track.findtext('Track/TrackNumber'),
                    'TrackID': track.findtext('Track/TrackID'),
                    'Duration': track.findtext('Track/Duration'),
                    'DurationInSeconds': track.findtext('Track/DurationInSeconds'),
                    'Description': track.findtext('Track/Description'),
                    'OriginalVersion': track.findtext('Track/OriginalVersion'),
                    'PublishDate': track.findtext('Track/PublishDate'),
                    'IsDownloadable': track.findtext('Track/IsDownloadable'),
                    'SongID': track.findtext('Track/Song/SongID'),
                    'SongName': track.findtext('Track/Song/Name'),
                    'GlobalRating': track.findtext('Track/GlobalRating')
                })
                
            d = [details, tracks]
                        
            return d
        else:
            return "Failed"
    
    def GetMyPlaylistListing(self, SessionID):
        path = self.host + "/ws/concert.asmx/GetMyPlayListListing?SessionID=" + str(SessionID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            
            for playlist in response.findall("MyPlaylistListing"):
                wrappedplaylist = ElementWrapper(playlist)
                d.append({
                    'MyPlaylistID': wrappedplaylist.MyPlaylistID,
                    'Name': wrappedplaylist.Name,
                    'DateCreated': wrappedplaylist.DateCreated,
                    'LastModified': wrappedplaylist.LastModified,
                    'IsShuffleMode': wrappedplaylist.IsShuffleMode,
                    'TrackCount': wrappedplaylist.TrackCount,
                    'IsPublic': wrappedplaylist.IsPublic,
                    'IsPublicSystemList': wrappedplaylist.IsPublicSystemList,
                    'DurationInSeconds': wrappedplaylist.DurationInSeconds,
                    'TotalTrackTime': wrappedplaylist.TotalTrackTime,
                    'SeoUrlName': wrappedplaylist.SeoUrlName,
                    'ScreenName': wrappedplaylist.ScreenName,
                    'CustomerID': wrappedplaylist.CustomerID,
                    'PerformerSummary': wrappedplaylist.PerformerSummary,
                    'Summary': wrappedplaylist.Summary,
                    'IsOwnerChangeNotificationEnabled': wrappedplaylist.IsOwnerChangeNotificationEnabled,
                    'DetailUrl': wrappedplaylist.DetailUrl,
                    'GlobalRating': wrappedplaylist.GlobalRating
                })
                        
            return d
        else:
            return "Failed"
        
    def GetMyPlaylistListingWithFavorites(self, SessionID):
        path = self.host + "/ws/concert.asmx/GetMyPlayListListingWithFavorites?SessionID=" + str(SessionID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return xml
        else:
            return "Failed"

    def GetRadioPlaylist(self, StationID, SessionID):
        path = self.host + "/ws/concert.asmx/GetRadioPlayList?SessionID=" + str(SessionID) + "&StationID=" + str(StationID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            d = []
            for track in response.findall("TrackWithConcertListing"):
                wrappedtrack = ElementWrapper(track)
                d.append({
                    'TrackID': wrappedtrack.TrackID,
                    'Duration': wrappedtrack.Duration,
                    'DurationInSeconds': wrappedtrack.DurationInSeconds,
                    'TrackNumber': wrappedtrack.TrackNumber,
                    'Description': wrappedtrack.Description,
                    'OriginalVersion': wrappedtrack.OriginalVersion,
                    'PublishDate': wrappedtrack.PublishDate,
                    'PublishDateFormatted': wrappedtrack.PublishDateFormatted,
                    'PublishDateRFC822': wrappedtrack.PublishDateRFC822,
                    'IsDownloadable': wrappedtrack.IsDownloadable,
                    'PublishDateRFC822': wrappedtrack.PublishDateRFC822,
                    'SongID': track.findtext('Song/SongID'),
                    'SongName': track.findtext('Song/Name'),
                    'ShowTime': track.findtext('ConcertListingWithArtistImage/ShowTime'),
                    'Title': track.findtext('ConcertListingWithArtistImage/Title'),
                    'SeoUrlName': track.findtext('ConcertListingWithArtistImage/SeoUrlName'),
                    'ConcertID': track.findtext('ConcertListingWithArtistImage/ConcertID/ConcertID'),
                    'EventID': track.findtext('ConcertListingWithArtistImage/ConcertID/EventID'),
                    'ArtistID': track.findtext('ConcertListingWithArtistImage/ConcertID/ArtistID'),
                    'DateFormatted': track.findtext('ConcertListingWithArtistImage/Event/DateFormatted'),
                    'DateString': track.findtext('ConcertListingWithArtistImage/DateString'),
                    'VenueID': track.findtext('ConcertListingWithArtistImage/Event/Venue/VenueID'),
                    'Location': track.findtext('ConcertListingWithArtistImage/Event/Venue/Location'),
                    'VenueName': track.findtext('ConcertListingWithArtistImage/Event/Venue/Name'),
                    'EventSeoUrlName': track.findtext('ConcertListingWithArtistImage/Event/Venue/SeoUrlName'),
                    'EventUrl': track.findtext('ConcertListingWithArtistImage/Event/Venue/Url'),
                    'MerchandiseUrl': track.findtext('ConcertListingWithArtistImage/Event/Venue/MerchandiseUrl'),
                    'ArtistFriendlyName': track.findtext('ConcertListingWithArtistImage/Artist/FriendlyName'),
                    'ArtistName': track.findtext('ConcertListingWithArtistImage/Artist/Name'),
                    'ArtistSeoUrlName': track.findtext('ConcertListingWithArtistImage/Artist/SeoUrlName'),
                    'ArtistUrl': track.findtext('ConcertListingWithArtistImage/Artist/Url'),
                    'ArtistFileName': track.findtext('ConcertListingWithArtistImage/Artist/Image/FileName'),
                    'ArtistVirtualFilePath': track.findtext('ConcertListingWithArtistImage/Artist/Image/VirtualFilePath'),
                    'PurchasableAudioCount': track.findtext('ConcertListingWithArtistImage/PurchasableAudio/Count'),
                    'PurchasableAudioConcertForPurchaseID': track.findtext('ConcertListingWithArtistImage/PurchasableAudio/ConcertForPurchase/ConcertForPurchaseID'),
                    'PurchasableAudioPrice': track.findtext('ConcertListingWithArtistImage/PurchasableAudio/ConcertForPurchase/Price'),
                    'PurchasableAudioWVIPPrice': track.findtext('ConcertListingWithArtistImage/PurchasableAudio/ConcertForPurchase/WVIPPrice'),
                    'PurchasableAudioAudioFormat': track.findtext('ConcertListingWithArtistImage/PurchasableAudio/ConcertForPurchase/AudioFormat/Name'),
                    'PurchasableAudioKbps': track.findtext('ConcertListingWithArtistImage/PurchasableAudio/ConcertForPurchase/AudioFormat/Kbps'),
                    'ConcertImageLargeFileName': track.findtext('ConcertListingWithArtistImage/ConcertImageLarge/Image/FileName'),
                    'ConcertImageLargeVirtualFilePath': track.findtext('ConcertListingWithArtistImage/ConcertImageLarge/Image/VirtualFilePath'),
                    'ConcertImageLargeHostname': track.findtext('ConcertListingWithArtistImage/ConcertImageLarge/Image/Hostname')
                })
                        
            return d
        else:
            return "Failed"
        
    def GetSingleTrackConcert(self, TrackID):
        path = self.host + "/ws/concert.asmx/GetSingleTrackConcert?TrackID=" + str(TrackID)
        xml = self.request(path)
        
        if xml != "Failed":
            track = ET.fromstring(xml)
            wrappedtrack = ElementWrapper(track)
            d = {
                'ShowTime': wrappedtrack.ShowTime,
                'ImageName': wrappedtrack.ImageName,
                'TotalTrackTime': wrappedtrack.TotalTrackTime,
                'TrackCount': wrappedtrack.TrackCount,
                'ConcertID': track.findtext('ConcertID/ConcertID'),
                'EventID': track.findtext('ConcertID/EventID'),
                'ArtistID': track.findtext('ConcertID/ArtistID'),
                'VenueID': track.findtext('Event/Venue/VenueID'),
                'Location': track.findtext('Event/Venue/Location'),
                'VenueName': track.findtext('Event/Venue/Name'),
                'EventSeoUrlName': track.findtext('Event/Venue/SeoUrlName'),
                'EventUrl': track.findtext('Event/Venue/Url'),
                'MerchandiseUrl': track.findtext('Event/Venue/MerchandiseUrl'),
                'ArtistFriendlyName': track.findtext('Artist/FriendlyName'),
                'ArtistName': track.findtext('Artist/Name'),
                'ArtistSeoUrlName': track.findtext('Artist/SeoUrlName'),
                'ArtistUrl': track.findtext('Artist/Url'),
                'ArtistFileName': track.findtext('Artist/Image/FileName'),
                'ArtistVirtualFilePath': track.findtext('Artist/Image/VirtualFilePath'),
                'PurchasableAudioCount': track.findtext('PurchasableAudio/Count'),
                'PurchasableAudioConcertForPurchaseID': track.findtext('PurchasableAudio/ConcertForPurchase/ConcertForPurchaseID'),
                'PurchasableAudioPrice': track.findtext('PurchasableAudio/ConcertForPurchase/Price'),
                'PurchasableAudioWVIPPrice': track.findtext('PurchasableAudio/ConcertForPurchase/WVIPPrice'),
                'PurchasableAudioAudioFormat': track.findtext('PurchasableAudio/ConcertForPurchase/AudioFormat/Name'),
                'PurchasableAudioKbps': track.findtext('PurchasableAudio/ConcertForPurchase/AudioFormat/Kbps'),
                'PurchasableAudioKbps': track.findtext('PurchasableAudio/ConcertForPurchase/AudioFormat/Kbps'),
                'TrackNumber': track.findtext('Track/TrackNumber'),
                'TrackID': track.findtext('Track/TrackID'),
                'Duration': track.findtext('Track/Duration'),
                'DurationInSeconds': track.findtext('Track/DurationInSeconds'),
                'Description': track.findtext('Track/Description'),
                'OriginalVersion': track.findtext('Track/OriginalVersion'),
                'PublishDate': track.findtext('Track/PublishDate'),
                'IsDownloadable': track.findtext('Track/IsDownloadable'),
                'SongID': track.findtext('Track/Song/SongID'),
                'SongName': track.findtext('Track/Song/Name'),
                'GlobalRating': track.findtext('Track/GlobalRating')
            }
                        
            return d
        else:
            return "Failed"
        
    def GetStreamingAuthorization(self, SessionID):
        path = self.host + "/ws/concert.asmx/GetStreamingAuthorization?SessionID=" + str(SessionID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            wrappedresponse = ElementWrapper(response)
            d = {
                 'LimitStreaming': wrappedresponse.LimitStreaming,
                 'MinutesRemaining': wrappedresponse.MinutesRemaining,
                 'ExtendLimitMinutes': wrappedresponse.ExtendLimitMinutes
            }
            return d
        else:
            return "Failed"

    def LogTrackPlay(self, SessionID, TrackID, PlayerType, RadioStation):
        path = self.host + "/ws/concert.asmx/LogTrackPlay?SessionID=" + str(SessionID) + "&TrackID=" + str(TrackID) + "&PlayerType=" + str(PlayerType) + "&RadioStation=" + str(RadioStation)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"

    def LogTrackPlayReturnMinutesRemaining(self, SessionID, TrackID, PlayerType, RadioStation):
        path = self.host + "/ws/concert.asmx/LogTrackPlayReturnMinutesRemaining?SessionID=" + str(SessionID) + "&TrackID=" + str(TrackID) + "&PlayerType=" + str(PlayerType) + "&RadioStation=" + str(RadioStation)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"
        
    def LogTrackPlayReturnMinutesRemaining(self, SessionID, TrackID, PlayerType, RadioStation):
        path = self.host + "/ws/concert.asmx/LogTrackPlayReturnMinutesRemaining?SessionID=" + str(SessionID) + "&TrackID=" + str(TrackID) + "&PlayerType=" + str(PlayerType) + "&RadioStation=" + str(RadioStation)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"
        
    def RateConcert(self, SessionID, ConcertID, RatingScaleID):
        path = self.host + "/ws/concert.asmx/RateConcert?SessionID=" + str(SessionID) + "&ConcertID=" + str(ConcertID) + "&RatingScaleID=" + str(RatingScaleID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"

    def RateMyPlayList(self, SessionID, PlaylistID, RatingScaleID):
        path = self.host + "/ws/concert.asmx/RateMyPlayList?SessionID=" + str(SessionID) + "&PlaylistID=" + str(PlaylistID) + "&RatingScaleID=" + str(RatingScaleID)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"

    def RegisterUser(self, Email, Password, GenderID, BirthYear, ScreenName):
        path = self.host + "/ws/concert.asmx/RegisterUser?Email=" + str(Email) + "&FirstName=" + "Boxee" + "&LastName=" + "User" + "&Password=" + str(Password) + "&GenderID=" + str(GenderID) + "&BirthYear=" + str(BirthYear) + "&AnonymousTypeID=" + "1" + "&ScreenName=" + str(ScreenName)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            
            d = {
                'ResultCode': response.findtext(self.namespace + "ResultCode"),
                'Message': response.findtext(self.namespace + "Message"),
                'SessionID': response.findtext(self.namespace + "SessionID")
            }
                      
            if d["ResultCode"] == "0":
                return d
            else:
                return d["Message"]
        else:
            return "Failed"
        
    def SetAccountMinutesRemaining(self, SessionID, MinutesRemaining, Password):
        path = self.host + "/ws/concert.asmx/SetAccountMinutesRemaining?Email=" + str(RegisterUser) + "&FirstName=" + str(FirstName) + "&LastName=" + str(LastName)
        xml = self.request(path)
        
        if xml != "Failed":
            response = ET.fromstring(xml)
            return response.findtext('./')
        else:
            return "Failed"
        
class Publisher:
    def __init__(self, WinID, ListID):
        self.WinID = WinID
        self.ListID = ListID
        self.host = "http://concerts.wolfgangsvault.com"
        self.webhost = "http://www.wolfgangsvault.com"
        
    def publishConcerts(self, concerts):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Publishing concerts... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        container = mc.ListItems()
        for concert in concerts:              
            newitem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            newitem.SetLabel(concert[0]["Title"])
            newitem.SetTitle(concert[1]["ArtistFriendlyName"] + " - " + concert[0]["Title"])
            newitem.SetThumbnail("http://images.wolfgangsvault.com" + concert[0]["LargeImage"])
            try:
                newitem.SetDescription(str(concert[0]["Description"]), True)
            except UnicodeEncodeError:
                newitem.SetDescription("This description contains bad unicode.", True)
            newitem.SetProperty("ArtistID", concert[0]["ArtistID"])
            newitem.SetProperty("EventID", concert[0]["EventID"])
            newitem.SetProperty("ConcertID", concert[0]["ConcertID"])
            newitem.SetProperty("Location", concert[0]["Location"])
            newitem.SetProperty("Date", concert[0]["DateFormatted"])
            newitem.SetProperty("ConcertTypeID", concert[0]["ConcertTypeID"])
            newitem.SetProperty("Venue", concert[0]["VenueName"])
            newitem.SetProperty("Artist", concert[1]["ArtistFriendlyName"])
            newitem.SetProperty("TrackCount", concert[0]["TrackCount"])
            newitem.SetProperty("TotalTrackTime", concert[0]["TotalTrackTime"])
            try:
                newitem.SetProperty("ArtistImage", "http://images.wolfgangsvault.com/artists/" + concert[1]["FileName"])
            except KeyError:
                pass            
            songlisting = ""
            n = 1
            for song in concert[2]:
                songlisting = songlisting + str(n) + ". " + song["Name"] + "[CR]"
                n = n + 1
            newitem.SetProperty("SongListing", songlisting)
            newitem.SetPath(self.host + "/" + concert[0]["SeoUrlName"])
            container.append(newitem)
        mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)
    
    def publishConcertSummaries(self, summaries):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Publishing concert summaries... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        container = mc.ListItems()
        for summary in summaries:                   
            newitem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            newitem.SetLabel(summary["ArtistFriendlyName"])
            newitem.SetTitle(summary["ArtistFriendlyName"])
            newitem.SetThumbnail(summary["ArtistImage"])
            try:
                newitem.SetDescription("From the " + summary["CollectionName"] + "collection.", True)
            except UnicodeEncodeError:
                newitem.SetDescription("This description contains bad unicode.", True)
            newitem.SetProperty("ArtistID", summary["ArtistID"])
            newitem.SetProperty("EventID", summary["EventID"])
            newitem.SetProperty("ConcertID", summary["ConcertID"])
            newitem.SetProperty("Location", summary["VenueLocation"])
            newitem.SetProperty("Date", summary["DateFormatted"])
            newitem.SetProperty("ConcertTypeID", summary["ConcertTypeID"])
            newitem.SetProperty("Venue", summary["Venue"])
            newitem.SetProperty("Artist", summary["ArtistFriendlyName"])
            newitem.SetProperty("TrackCount", summary["TrackCount"])
            newitem.SetProperty("TotalTrackTime", summary["TotalTrackTime"])
            newitem.SetPath(self.host + "/" + summary["SeoUrlName"])
            container.append(newitem)
        mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)
    
    def publishPlaylists(self, playlists):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Publishing playlists... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        container = mc.ListItems()
        for playlist in playlists:
            if not playlist:
                mc.GetActiveWindow().GetControl(999).SetVisible(True)
            else:
                newitem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                newitem.SetLabel(playlist["Name"])
                newitem.SetTitle(playlist["Name"])
                try:
                    newitem.SetDescription(str(playlist["Summary"]), True)
                except UnicodeEncodeError:
                    newitem.SetDescription("This description contains bad unicode.", True)
                newitem.SetProperty("MyPlaylistID", playlist["MyPlaylistID"])
                newitem.SetProperty("DateCreated", playlist["DateCreated"])
                newitem.SetProperty("LastModified", playlist["LastModified"])
                newitem.SetProperty("IsShuffleMode", playlist["IsShuffleMode"])
                newitem.SetProperty("TrackCount", playlist["TrackCount"])
                newitem.SetProperty("IsPublic", playlist["IsPublic"])
                newitem.SetProperty("IsPublicSystemList", playlist["IsPublicSystemList"])
                newitem.SetProperty("DurationInSeconds", playlist["DurationInSeconds"])
                newitem.SetProperty("TotalTrackTime", playlist["TotalTrackTime"])
                newitem.SetProperty("ScreenName", playlist["ScreenName"])
                newitem.SetProperty("CustomerID", playlist["CustomerID"])
                newitem.SetProperty("PerformerSummary", playlist["PerformerSummary"])
                newitem.SetProperty("IsOwnerChangeNotificationEnabled", playlist["IsOwnerChangeNotificationEnabled"])
                newitem.SetProperty("DetailUrl", playlist["DetailUrl"])    
                newitem.SetProperty("GlobalRating", playlist["GlobalRating"])           
                newitem.SetPath(self.host + "/" + playlist["SeoUrlName"])
                container.append(newitem)
            mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)
    
    def publishSearch(self, results):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Publishing search results... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        container = mc.ListItems()
        for result in results:
            if not result:
                mc.GetActiveWindow().GetControl(999).SetVisible(True)
            else:
                newitem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                try:
                    newitem.SetLabel(result["ArtistName"])
                except TypeError:
                    continue
                newitem.SetTitle(result["ArtistName"])
                newitem.SetThumbnail(result["ArtistImage"])
                newitem.SetProperty("ArtistID", result["ArtistID"])       
                newitem.SetPath(self.host + "/artists/" + result["ArtistID"])
                container.append(newitem)
            mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)
    
    def publishSelection(self, items, type):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Publishing selection " + type + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        container = mc.ListItems()
        
        if type == "Artist":
            ID = "ArtistID"
        elif type == "Collection":
            ID = "CollectionID"
        elif type == "Genre":
            ID = "GenreID"
        
        for item in items:
            if not item:
                mc.GetActiveWindow().GetControl(999).SetVisible(True)
            else:
                newitem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                newitem.SetLabel(item["Name"])
                newitem.SetTitle(item["Name"])
                newitem.SetProperty("Selection", type)
                newitem.SetProperty(ID, item[ID])       
                newitem.SetPath(self.host + item["SeoUrlName"])
                container.append(newitem)
            mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)
    
    def playConcert(self, ConcertID, SessionID, Membership):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Publishing concert " + str(ConcertID) + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        tempPoller = pollWolfgang()
        params = mc.Parameters()
        playlist = mc.PlayList(mc.PlayList.PLAYLIST_MUSIC)
        container = mc.ListItems()
        myPlayer = mc.GetPlayer()
        
        concert = tempPoller.GetConcert(ConcertID, SessionID, "concerts.wolfgangsvault.com")
                           
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Queuing playlist... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        if myPlayer.IsPlaying():
            myPlayer.Stop()        
        playlist.Clear()       
        n = 1
        for item in concert[2]:        
            newitem = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            newitem.SetLabel(str(n) + ". " + item["Name"])
            newitem.SetTitle(str(n) + ". " + item["Name"])
            newitem.SetThumbnail("http://images.wolfgangsvault.com" + concert[0]["LargeImage"])
            newitem.SetArtist(concert[1]["ArtistFriendlyName"])
            duration = item["DurationInSeconds"].split(".")
            newitem.SetDuration(int(duration[0]))
            date = concert[0]["DateString"].split("/")
            newitem.SetDate(int(date[2]), int(date[1]), int(date[0]))
            newitem.SetAlbum(concert[0]["VenueName"])
            newitem.SetProperty("Location", concert[0]["Location"])
            newitem.SetProperty("DateFormatted", concert[0]["DateFormatted"])
            newitem.SetProperty("SongID", item["SongID"])
            newitem.SetProperty("TrackNumber", item["TrackNumber"])
            newitem.SetProperty("IsDownloadable", item["IsDownloadable"])
            newitem.SetProperty("TotalTrackTime", "Total Time: [B]" + concert[0]["TotalTrackTime"] + "[/B]")
            newitem.SetProperty("TrackCount", "Tracks: [B]" + concert[0]["TrackCount"] +"[/B]")
            newitem.SetProperty("SeoUrlName", concert[0]["SeoUrlName"])
            if Membership == "true":
                newitem.SetPath("http://bx.wolfgangsvault.com/audio/192/" + str(item["TrackID"]) + ".mp3")
            else:
                newitem.SetPath("http://bx.wolfgangsvault.com/audio/96/" + str(item["TrackID"]) + ".mp3")
            
            try:
                description = concert[0]["Description"]
                description = description.replace("<br />", "[CR]")
                newitem.SetDescription(str(description), True)
            except UnicodeEncodeError:
                newitem.SetDescription("This description is currently unavailable.", True)
                
            if len(description) == 0:
                newitem.SetDescription("Read more about this concert at wolfgangsvault.com", True)
            
            ext = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            ext.SetTitle(concert[1]["ArtistFriendlyName"] + " at " + concert[0]["VenueName"] + ", " + concert[0]["DateFormatted"] + " in @concertvault")
            ext.SetLabel(concert[1]["ArtistFriendlyName"] + " at " + concert[0]["VenueName"] + ", " + concert[0]["DateFormatted"] + " in @concertvault")
            ext.SetDescription(newitem.GetDescription(), False)
            ext.SetContentType("audio/mpeg")
            ext.SetThumbnail(newitem.GetThumbnail())
            ext.SetProviderSource("Wolfgang's Vault")
            extparams = {
                'title':        concert[1]["ArtistFriendlyName"] + " at " + concert[0]["VenueName"] + ", " + concert[0]["DateFormatted"] + " in @concertvault",
                'alt-label':    concert[1]["ArtistFriendlyName"] + " at " + concert[0]["VenueName"] + ", " + concert[0]["DateFormatted"] + " in @concertvault",
                'ConcertID':   ConcertID,
                'description':  newitem.GetDescription(),
                'bx-ourl':      self.webhost + concert[0]["SeoUrlName"],
                'thumbnail':    newitem.GetThumbnail(),
            }
            ext.SetPath("app://tv.gonzee.wolfgangsvault/launch?%s" % (urllib.urlencode(extparams)))
            newitem.SetExternalItem(ext)
                
            container.append(newitem)
            playlist.Add(newitem)
            n = n + 1
        
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Switching to play window... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        params["artist"] = concert[1]["ArtistFriendlyName"]
        params["venue"] = concert[0]["VenueName"]
        params["description"] = newitem.GetDescription()
        params["date"] = concert[0]["DateFormatted"]
        params["image"] = "http://images.wolfgangsvault.com" + concert[0]["LargeImage"]
        if Membership == "true":
            params["membership"] = "Bitrate: [B]192k[/B]"
        else:    
            params["membership"] = "Bitrate: [B]96k[/B][CR]Sign up for a WVIP account to listen at 192k."
             
        
        mc.GetApp().ActivateWindow( 14001, params )
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Playing playlist... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        myPlayer.PlaySelected(0)
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Loading list container... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)
        
    def playPlaylist(self, PlaylistID, SessionID, Membership):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Playling playlist " + str(PlaylistID) + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        tempPoller = pollWolfgang()
        params = mc.Parameters()
        boxeePlaylist = mc.PlayList(mc.PlayList.PLAYLIST_MUSIC)
        container = mc.ListItems()
        myPlayer = mc.GetPlayer()
        
        playlist = tempPoller.GetMyPlaylist(SessionID, PlaylistID)
        
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Queuing playlist... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        if myPlayer.IsPlaying():
            myPlayer.Stop()        
        boxeePlaylist.Clear()       
        n = 1
        
        for item in playlist[1]:
            
            mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Processing track " + str(n) + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
                       
            newitem = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            newitem.SetLabel(str(n) + ". " + item["SongName"])
            newitem.SetTitle(str(n) + ". " + item["SongName"])
            newitem.SetArtist(item["ArtistFriendlyName"])
            newitem.SetThumbnail("http://concerts.wolfgangsvault.com/common/images/playlist.jpg")
            duration = item["DurationInSeconds"].split(".")
            newitem.SetDuration(int(duration[0]))
            date = item["DateString"].split("/")
            newitem.SetDate(int(date[2]), int(date[1]), int(date[0]))
            newitem.SetAlbum(item["VenueName"])
            newitem.SetProperty("Location", item["Location"])
            newitem.SetProperty("SongID", item["SongID"])
            newitem.SetProperty("DateFormatted", item["DateFormatted"])
            newitem.SetProperty("TrackNumber", item["TrackNumber"])
            newitem.SetProperty("IsDownloadable", item["IsDownloadable"])
            if Membership == "true":
                newitem.SetPath("http://bx.wolfgangsvault.com/audio/192/" + str(item["TrackID"]) + ".mp3")
            else:
                newitem.SetPath("http://bx.wolfgangsvault.com/audio/96/" + str(item["TrackID"]) + ".mp3")
                
            try:
                description = playlist[0]["Summary"]
                description = description.replace("<br />", "[CR]")
                newitem.SetDescription(str(description), True)
            except UnicodeEncodeError:
                newitem.SetDescription("This description is not currently available.", True)
                
            ext = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            ext.SetTitle(item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault")
            ext.SetLabel(item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault")
            ext.SetDescription(newitem.GetDescription(), False)
            ext.SetContentType("audio/mpeg")
            ext.SetThumbnail(newitem.GetThumbnail())
            ext.SetProviderSource("Wolfgang's Vault")
            extparams = {
                'title':        item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault",
                'alt-label':    item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault",
                'PlaylistID':   PlaylistID,
                'description':  newitem.GetDescription(),
                'bx-ourl':      self.webhost + playlist[0]["SeoUrlName"],
                'thumbnail':    newitem.GetThumbnail(),
            }
            ext.SetPath("app://tv.gonzee.wolfgangsvault/launch?%s" % (urllib.urlencode(extparams)))
            newitem.SetExternalItem(ext)
            
            
            container.append(newitem)
            boxeePlaylist.Add(newitem)
            n = n + 1
        
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Switching to play window... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        params["artist"] = playlist[0]["Name"]
        params["venue"] = playlist[0]["PerformerSummary"]
        params["description"] = playlist[0]["Summary"]
        params["date"] = "Playlist Created: " +  playlist[0]["DateCreated"]
        params["image"] = newitem.GetThumbnail()
        if Membership == "true":
            params["membership"] = "Bitrate: [B]192k[/B]"
        else:    
            params["membership"] = "Bitrate: [B]96k[/B][CR]Sign up for a WVIP account to listen at 192k."
             
        
        mc.GetApp().ActivateWindow( 14001, params )
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Playing playlist... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        myPlayer.PlaySelected(0)
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Loading list container... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)

    def playRadio(self, StationID, SessionID, Membership):
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Playling Radio Station " + str(StationID) + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        tempPoller = pollWolfgang()
        params = mc.Parameters()
        boxeePlaylist = mc.PlayList(mc.PlayList.PLAYLIST_MUSIC)
        container = mc.ListItems()
        myPlayer = mc.GetPlayer()
        
        playlist = tempPoller.GetRadioPlaylist(StationID, SessionID)
        
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Queuing playlist... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        if myPlayer.IsPlaying():
            myPlayer.Stop()        
        boxeePlaylist.Clear()       
        n = 1
        
        for item in playlist:
            
            mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Processing track " + str(n) + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
            mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Artist: " + item["ArtistFriendlyName"] + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
            mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Thumbnail:  " + "http://images.wolfgangsvault.com" + "/artists/" + item["ArtistFileName"] + "... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
                       
            newitem = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            try:
                newitem.SetLabel(str(n) + ". " + item["SongName"])
                newitem.SetTitle(str(n) + ". " + item["SongName"])
            except TypeError:
                newitem.SetLabel(str(n) + ". " + "Unknown")
                newitem.SetTitle(str(n) + ". " + "Unknown")
            newitem.SetArtist(item["ArtistFriendlyName"])
            newitem.SetThumbnail("http://images.wolfgangsvault.com" + "/artists/" + item["ArtistFileName"])
            try:
            	newitem.SetAlbum(item["VenueName"])
            except UnicodeEncodeError:
            	newitem.SetAlbum("Unknown Venue")
            newitem.SetProperty("Location", item["Location"])
            newitem.SetProperty("SongID", item["SongID"])
            newitem.SetProperty("DateFormatted", item["DateFormatted"])
            newitem.SetProperty("TrackNumber", item["TrackNumber"])
            newitem.SetProperty("IsDownloadable", item["IsDownloadable"])
            if Membership == "true":
                newitem.SetPath("http://bx.wolfgangsvault.com/audio/192/" + str(item["TrackID"]) + ".mp3")
            else:
                newitem.SetPath("http://bx.wolfgangsvault.com/audio/96/" + str(item["TrackID"]) + ".mp3")
            try:
                newitem.SetDescription(str(item["Description"]), True)
            except UnicodeEncodeError:
                newitem.SetDescription("This description is not currently available.", True)
            
            ext = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            ext.SetTitle(item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault")
            ext.SetLabel(item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault")
            ext.SetDescription(newitem.GetDescription(), False)
            ext.SetContentType("audio/mpeg")
            ext.SetThumbnail(newitem.GetThumbnail())
            ext.SetProviderSource("Wolfgang's Vault")
            extparams = {
                'title':        item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault",
                'alt-label':    item["ArtistFriendlyName"] + " at " + item["VenueName"] + ", " + item["DateFormatted"] + " in @concertvault",
                'StationID':   StationID,
                'description':  newitem.GetDescription(),
                'bx-ourl':      self.webhost + item["SeoUrlName"],
                'thumbnail':    newitem.GetThumbnail(),
            }
            ext.SetPath("app://tv.gonzee.wolfgangsvault/launch?%s" % (urllib.urlencode(extparams)))
            newitem.SetExternalItem(ext)
            
            container.append(newitem)
            boxeePlaylist.Add(newitem)
            n = n + 1
        
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Switching to play window... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        params["artist"] = item["ArtistFriendlyName"]
        params["venue"] = item["VenueName"]
        params["description"] = newitem.GetDescription()
        params["date"] = "Playlist Created: " +  item["PublishDate"]
        params["image"] = newitem.GetThumbnail()
        if Membership == "true":
            params["membership"] = "Bitrate: [B]192k[/B]"
        else:    
            params["membership"] = "Bitrate: [B]96k[/B][CR]Sign up for a WVIP account to listen at 192k."
             
        
        mc.GetApp().ActivateWindow( 14001, params )
        mc.GetActiveWindow().GetControl(201).SetVisible(False)
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Playing playlist... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        myPlayer.PlaySelected(0)
        mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Loading list container... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)
         
class ui:
    def __init__(self):
        self.window = mc.GetActiveWindow()
    
    def showDetail(self):       
        self.window.PushState()
        self.window.GetControl(9000).SetVisible(True)
        self.window.GetControl(9001).SetFocus()
    
    def hideDetail(self, ListID):
        self.window.PushState()
        self.window.GetControl(9000).SetVisible(False)
        self.window.GetControl(ListID).SetFocus()
        
    def showAuth(self):
        self.window.PushState()
        self.window.GetControl(8000).SetVisible(True)
        self.window.GetControl(8400).SetFocus()
                
    def hideAuth(self, ListID):
        self.window.PushState()
        self.window.GetControl(8000).SetVisible(False)
        self.window.GetControl(ListID).SetFocus()