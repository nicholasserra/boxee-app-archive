
import mc
import sc2casts
 
mc.ActivateWindow(14000)
