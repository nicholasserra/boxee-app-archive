import mc
import re
import time
import random
import xml.dom.minidom
import os
import os.path
import urllib
from xml.dom.minidom import Node

def init():
	region = mc.GetApp().GetLocalConfig().GetValue("region")
	if region == "":
		region = "it"
	
	set_region(region)
		
	if region == "it":
		mc.GetApp().ActivateWindow(14002, mc.Parameters())
		load_feed_new(0)
	else:
		mc.GetApp().ActivateWindow(14000, mc.Parameters())
		load_feed_new(1)
	
	return False

def get_poster(url, id):
	if url != "":
		region = mc.GetApp().GetLocalConfig().GetValue("region")
		temp_path = str(mc.GetTempDir())
		fname = temp_path + region + "_" + id + ".jpg"
		try:
			if os.path.isfile(fname):
				return fname
			else:
				urllib.urlretrieve(url, fname)
				if os.path.getsize(fname)==0:
					os.remove(fname)
					return ""
				else:
					return fname
		except:
			os.remove(fname)
			return fname
	else:
		return ""

def set_region(sigla):
	region = mc.GetApp().GetLocalConfig().GetValue("region")
	ga = "/boxee/" + region + "/set_region/" + sigla
	google_analytics(ga)
	mc.GetApp().GetLocalConfig().SetValue("region", sigla) 
	return False

def load_feed_new(id):
	mc.ShowDialogWait()
	mc.GetApp().GetLocalConfig().Reset("selecteditem")
	region = mc.GetApp().GetLocalConfig().GetValue("region")
	if id == 0:
		lista = "top_film"
	elif id == 1:
		lista = "al_cinema"
	elif id == 2:
		lista = "prossimamente"
	elif id == 3:
		lista = "novita"
	elif id == 4:
		lista = "homevideo"
	ga = "/boxee/" + region + "/" + lista
	google_analytics(ga)
	intid = 100 + id
	strid = str(intid)
	
	windowid = 14000
	if region == "it":
		windowid = 14002
		url = "http://boxee.cinetrailer.tv/xml/movie_" + str(id) + ".xml"
	else:
		url = "http://boxee.cinetrailer.tv/xml/movie_" + region + "_" + str(id) + ".xml"
		
	mc.GetApp().GetLocalConfig().SetValue("selectedbutton", strid)
	
	dom = xml.dom.minidom.parse(urllib.urlopen(url))
	movies = dom.getElementsByTagName("movie")
	items = mc.ListItems()
	for movie in movies:
		try:
			ntrailer = int(movie.getElementsByTagName("ntrailer")[0].firstChild.nodeValue)
		except:
			ntrailer = 0
		if ntrailer > 0:
			try:
				titolo = str(movie.getElementsByTagName("titolo")[0].firstChild.toxml("utf-8"))
				titolo = titolo[9:len(titolo)-3]
			except Exception, e:
				mc.ShowDialogOk("errore titolo", str(e))
				titolo = ""
			try:
				generi = str(movie.getElementsByTagName("generi")[0].firstChild.toxml("utf-8"))
			except:
				generi = ""
			try:
				screenshot = str(movie.getElementsByTagName("screenshot")[0].firstChild.nodeValue)
			except:
				screenshot = ""
			try:
				last_video = str(movie.getElementsByTagName("last_video")[0].firstChild.nodeValue)
			except:
				last_video = ""
			try:
				id_movie = str(movie.getElementsByTagName("id_movie")[0].firstChild.nodeValue)
			except:
				id_movie = ""
			try:
				poster = str(movie.getElementsByTagName("poster")[0].firstChild.nodeValue)
			except:
				poster = ""
			try:
				premiere_date = str(movie.getElementsByTagName("premiere_date")[0].firstChild.nodeValue)
			except:
				premiere_date = ""
			try:
				annodiproduzione = int(movie.getElementsByTagName("annodiproduzione")[0].firstChild.nodeValue)
			except:
				annodiproduzione = 0
			try:
			  item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
			  #item.SetContentType("video/flv")
			  item.SetPath(id_movie)
			  item.SetProperty("id_movie", id_movie)
			  item.SetProperty("last_video", last_video)
			  #item.SetThumbnail(screenshot)
			  #item.SetThumbnail(screenshot + "?" + timestamp())
			  item.SetImage(0, screenshot)
			  item.SetImage(1, poster)
			  #item.SetProperty("poster", get_poster(poster, id_movie))
			  item.SetProperty("ntrailer", str(ntrailer))
			  item.SetLabel(titolo)
			  item.SetGenre(generi)
			  item.SetDescription(generi)
			  item.SetYear(annodiproduzione)
			  if premiere_date != "":
			  	item.SetDate(int(premiere_date[:4]), int(premiere_date[5:7]), int(premiere_date[8:10]))
			  	item.SetProperty("datauscitacinema", mc.GetApp().GetLocalConfig().GetValue("str_in_theaters") + ": " + item.GetDate())
			  if ntrailer > 1:
			  	item.SetProperty("nvideo", str(ntrailer) + " " + mc.GetApp().GetLocalConfig().GetValue("str_video_plr"))
			  else:
			  	item.SetProperty("nvideo", str(ntrailer) + " " + mc.GetApp().GetLocalConfig().GetValue("str_video_sng"))
			  items.append(item)
			  
			except Exception, e:
				mc.ShowDialogOk("error", str(e))
	
	mc.GetActiveWindow().GetList(150).SetItems(items)
	set_buttons(intid)
	mc.GetWindow(windowid).GetControl(150).SetFocus()
	mc.HideDialogWait()
	return False

def google_analytics(page):
	url = "http://boxee.cinetrailer.tv/func/ga.aspx?utmac=MO-118523-26&utmn=" + str(random.randint(0, 2147483647)) + "&guid=ON&utmp=" + page
	sg = mc.Http()
	html = sg.Get(url)
	return False

def getText(L):
	title = ""
	for node2 in L:
		for node3 in node2.childNodes:
			if node3.nodeType == Node.TEXT_NODE:
				title += node3.data
	return title

def set_buttons(intid):
	region = mc.GetApp().GetLocalConfig().GetValue("region")
	windowid = 14000
	startbid = 101
	if region == "it":
		windowid = 14002
		startbid = 100
	
	for i in range(startbid, 105):
		str_menu = "str_menu_" + str(i-100)
		if i == intid:
			mc.GetWindow(windowid).GetButton(i).SetLabel("      [B]" + mc.GetApp().GetLocalConfig().GetValue(str_menu) + "[/B]")
			mc.GetWindow(windowid).GetControl(i).SetEnabled(False)
		else:
			mc.GetWindow(windowid).GetButton(i).SetLabel("   [B]" + mc.GetApp().GetLocalConfig().GetValue(str_menu) + "[/B]")
			mc.GetWindow(windowid).GetControl(i).SetEnabled(True)
	
	mc.GetWindow(windowid).GetButton(110).SetLabel("   [B]Region: " + region.upper() + "[/B]")
	mc.GetWindow(windowid).GetControl(150).SetFocus()
	return False
	
def set_region(region):
	mc.GetApp().GetLocalConfig().SetValue("region", region)
	
	if region == "it":
		str_menu_0="Top Film"
		str_menu_1="Ora al Cinema"
		str_menu_2="Prossimamente"
		str_menu_3="Nuovi Trailer"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Video"
		str_video_of="di"
		str_in_theaters="Al cinema dal"
		str_homevideo="Disponibile in Home Video"
		str_info="Info"
		str_info_description = "<p>Scopri Cinetrailer anche sul web all'indirizzo:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>Potrai organizzare la tua serata grazie al veloce e intuitivo <strong>Trova Cinema</strong>, condividere i trailer con i tuoi amici su <strong>Facebook</strong> e tanto altro ancora!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Premi OK per tornare alla home del servizio</p>"
	elif region == "nl":
		str_menu_0=""
		str_menu_1="Nu in de bioscoop"
		str_menu_2="Binnenkort"
		str_menu_3="Nieuwste trailers"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Videos"
		str_video_of="van"
		str_in_theaters="In de bioscopen uit"
		str_homevideo="Avaiable in Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "fr":
		str_menu_0=""
		str_menu_1="Au cinéma"
		str_menu_2="Bientôt"
		str_menu_3="Dernière"
		str_menu_4="Home Video"
		str_video_sng="Vidéo"
		str_video_plr="Vidéos"
		str_video_of="de"
		str_in_theaters="Date de la première"
		str_homevideo="Disponibles dans Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "ch-fr":
		str_menu_0=""
		str_menu_1="Au cinéma"
		str_menu_2="Bientôt"
		str_menu_3="Dernière"
		str_menu_4="Home Video"
		str_video_sng="Vidéo"
		str_video_plr="Vidéos"
		str_video_of="de"
		str_in_theaters="Date de la première"
		str_homevideo="Disponibles dans Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "de":
		str_menu_0=""
		str_menu_1="Jetzt im Kino"
		str_menu_2="Bald im Kino"
		str_menu_3="Neueste Kinotrailer"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Videos"
		str_video_of="von"
		str_in_theaters="In theaters von"
		str_homevideo="Lieferbar in Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "ch":
		str_menu_0=""
		str_menu_1="Jetzt im Kino"
		str_menu_2="Bald im Kino"
		str_menu_3="Neueste Kinotrailer"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Videos"
		str_video_of="von"
		str_in_theaters="In theaters von"
		str_homevideo="Lieferbar in Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "dk":
		str_menu_0=""
		str_menu_1="Aktuel i biografen"
		str_menu_2="Kommer"
		str_menu_3="Nyeste trailers"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Videoer"
		str_video_of="of"
		str_in_theaters="I biografer fra"
		str_homevideo="Avaiable i Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "fi":
		str_menu_0=""
		str_menu_1="Elokuvateattereissa"
		str_menu_2="Tulevat ensi-illat"
		str_menu_3="Uusimmat trailerit"
		str_menu_4="Home Video"
		str_video_sng="Videota"
		str_video_plr="Videto"
		str_video_of="/"
		str_in_theaters="Teattereissa alk."
		str_homevideo="Tarjotut in Home Video"
		str_info="Agentuurin"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "es":
		str_menu_0=""
		str_menu_1="Ahora en cines"
		str_menu_2="Próximamente"
		str_menu_3="Nuevos tráilers"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Videos"
		str_video_of="de"
		str_in_theaters="En los cines desde"
		str_homevideo="Disponible en Home Video"
		str_info="Información"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "se":
		str_menu_0=""
		str_menu_1="Nu på bio"
		str_menu_2="Kommer på bio"
		str_menu_3="Nyaste biotrailrarna"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Videos"
		str_video_of="av"
		str_in_theaters="På biografer från"
		str_homevideo="Avaiable i Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
	elif region == "uk":
		str_menu_0=""
		str_menu_1="Now in Cinemas"
		str_menu_2="Coming Soon"
		str_menu_3="Newest Trailers"
		str_menu_4="Home Video"
		str_video_sng="Video"
		str_video_plr="Videos"
		str_video_of="of"
		str_in_theaters="In theaters from"
		str_homevideo="Avaiable in Home Video"
		str_info="Info"
		str_info_description = "<p>You can find Cinetrailer on the web simply typing the following url in your browser:</p><p style=\"font-size:30px;font-weight:bold;\">http://cinetrailer.it</p>\
		<p>You can find full movie info, cast, news, photos and share them with your friends on <strong>Facebook</strong>... and more to come!</p>\
		<p style=\"margin-top:200px;font-size:20px;text-align:center\">Press OK to go back to main menu</p>"
		
	mc.GetApp().GetLocalConfig().SetValue("str_menu_0", str_menu_0)
	mc.GetApp().GetLocalConfig().SetValue("str_menu_1", str_menu_1)
	mc.GetApp().GetLocalConfig().SetValue("str_menu_2", str_menu_2)
	mc.GetApp().GetLocalConfig().SetValue("str_menu_3", str_menu_3)
	mc.GetApp().GetLocalConfig().SetValue("str_menu_4", str_menu_4)
	mc.GetApp().GetLocalConfig().SetValue("str_video_sng", str_video_sng)
	mc.GetApp().GetLocalConfig().SetValue("str_video_plr", str_video_plr)
	mc.GetApp().GetLocalConfig().SetValue("str_video_of", str_video_of)
	mc.GetApp().GetLocalConfig().SetValue("str_in_theaters", str_in_theaters)
	mc.GetApp().GetLocalConfig().SetValue("str_homevideo", str_homevideo)
	mc.GetApp().GetLocalConfig().SetValue("str_info", str_info)
	mc.GetApp().GetLocalConfig().SetValue("str_info_description", str_info_description)


def timestamp():
	lt = time.localtime(time.time())
	return "%02d%02d%04d%02d%02d%02d" % (lt[2], lt[1], lt[0], lt[3], lt[4], lt[5])
