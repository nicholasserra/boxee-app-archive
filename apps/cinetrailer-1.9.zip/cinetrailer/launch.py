import cinetrailer
import mc

mc.GetApp().GetLocalConfig().Reset("selectedbutton")
cinetrailer.init()

