from mediafly.models import MediaModel
from boxeemediafly.utils import StringUtils
import mediafly.constants.DocumentType as DocumentType
import mediafly.constants.ModelType as ModelType
import datetime
import mc

def ModelsToListItems(models):
	items = mc.ListItems()
	for model in models:
		newModel = ModelToListItem(model)
		if newModel:
			items.append(ModelToListItem(model))
	return items

def ModelToListItem(model):
	instance = None
	if model.modelType == ModelType.CONTENTSOURCE:
		instance = ContentSourceModelToListItem(model)
	elif model.modelType == ModelType.CHANNEL:
		instance = ChannelModelToListItem(model)
	elif model.modelType == ModelType.EPISODE:
		instance = EpisodeModelToListItem(model)
	elif model.modelType == ModelType.DOCUMENT:
		# only handle html and png documents
		if model.docType == DocumentType.HTML or model.docType == DocumentType.PNG:
			instance = DocumentModelToListItem(model)

	if not instance is None:
		instance.SetProperty("isMediaflyItem", "True")
	
	return instance

def ContentSourceModelToListItem(model):
	# @type model ContentSourceModel

	item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
	
	item.SetTitle(StringUtils.CleanString(model.title))
	item.SetThumbnail(StringUtils.CleanString(model.imageUrl))
	item.SetDescription(StringUtils.CleanString(model.description))
	item.SetProperty("slug", StringUtils.CleanString(model.slug))
	item.SetProperty("modelType", StringUtils.CleanString(model.modelType))

	item.SetProperty("provider", StringUtils.CleanString(model.provider))
	item.SetProperty("imageUrlAlt1",StringUtils.CleanString(model.imageUrlAlt1))
	item.SetProperty("imageUrlAlt2", StringUtils.CleanString(model.imageUrlAlt2))
	item.SetProperty("requiresAuthentication", model.requiresAuthentication)
	item.SetProperty("requiresSSL",model.requiresSSL)
	item.SetProperty("mcode", StringUtils.CleanString(model.mcode))
	item.SetProperty("allowsUnboundUsers", model.allowsUnboundUsers)
	item.SetProperty("supportsUserBindings", model.supportsUserBindings)
	item.SetProperty("usernameRequired", model.usernameRequired)
	item.SetProperty("passwordRequired", model.passwordRequired)
	item.SetProperty("passwordEncryptionRequired", StringUtils.CleanString(model.passwordEncryptionRequired))
	item.SetProperty("encryptionType", StringUtils.CleanString(model.encriptionType))
	item.SetProperty("encryptionKey", StringUtils.CleanString(model.encryptionKey))
	item.SetProperty("encryptionKeyType", StringUtils.CleanString(model.encryptionType))
	item.SetProperty("isUserRemovable", StringUtils.CleanString(model.isUserRemovable))
	item.SetProperty("createAccountUrl", StringUtils.CleanString(model.createAccountUrl))
	item.SetProperty("linkAccountUrl", StringUtils.CleanString(model.linkAccountUrl))

	item.SetProperty("authenticated", StringUtils.CleanString(model.authenticated))
	item.SetProperty("authenticationModel", StringUtils.CleanString(model.authenticationModel))

	item.SetProperty("supportsRatings", model.supportsRatings)
	item.SetProperty("supportsFavorites", model.supportsFavorites)
	item.SetProperty("supportsSubscriptions", model.supportsSubscriptions)
	item.SetProperty("supportsExperiences", model.supportsExperiences)
	item.SetProperty("postImpressions", model.postImpressions)
	item.SetProperty("contentCachingAllowed", model.contentCachingAllowed)
	item.SetProperty("isSearchable", model.isSearchable)

	return item

def ChannelModelToListItem(model):
	# @type model ChannelModel

	item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
	item.SetTitle(StringUtils.CleanString(model.title))
	item.SetLabel(StringUtils.CleanString(model.title))
	item.SetThumbnail(StringUtils.CleanString(model.imageUrl))
	item.SetDescription(StringUtils.CleanString(model.description))
	item.SetProperty("slug", StringUtils.CleanString(model.slug))
	item.SetProperty("modelType", StringUtils.CleanString(model.modelType))

	item.SetProperty("totalEpisodes", StringUtils.CleanString(model.totalEpisodes))
	item.SetProperty("episodeCount", StringUtils.CleanString(model.episodeCount))
	item.SetProperty("channelCount", StringUtils.CleanString(model.channelCount))
	item.SetProperty("parentSlug", StringUtils.CleanString(model.parentChannelSlug))

	# Boxee Specific skin booleans
	item.SetProperty("isChannel", "true")

	return item

def EpisodeModelToListItem(model):
	# @type model EpisodeModel
	
	item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)

	item.SetTitle(StringUtils.CleanString(model.title))
	item.SetLabel(StringUtils.CleanString(model.title))
	item.SetThumbnail(StringUtils.CleanString(model.imageUrl))
	item.SetDescription(StringUtils.CleanString(model.description))

	item.SetProperty("slug", StringUtils.CleanString(model.slug))
	item.SetProperty("modelType", StringUtils.CleanString(model.modelType))

	item.SetPath(StringUtils.CleanString(model.url))
	if model.duration is not None:
		item.SetDuration(model.duration)
		item.SetProperty('formattedDuration', str(datetime.timedelta(seconds=model.duration)))

	item.SetProperty("published", StringUtils.CleanString(model.published))

	item.SetProperty("showSlug", StringUtils.CleanString(model.showSlug))
	item.SetProperty("showTitle", StringUtils.CleanString(model.showTitle))
	item.SetProperty("channelSlug", StringUtils.CleanString(model.channelSlug))
	item.SetProperty("resumable", str(model.resumable))
	item.SetProperty("seekable", str(model.seekable))
	item.SetProperty("screenCapImageUrl", StringUtils.CleanString(model.screenCapImageUrl))

	item.SetProperty("downloadModel", StringUtils.CleanString(model.downloadModel))
	item.SetProperty("deliveryModel", StringUtils.CleanString(model.deliveryModel))
	item.SetProperty("broadcastState", StringUtils.CleanString(model.broadcastState))
	item.SetProperty("onDemandEpisodeSlug", StringUtils.CleanString(model.onDemandEpisodeSlug))

	item.SetProperty("position", StringUtils.CleanString(model.position))
	item.SetProperty("bookmark", StringUtils.CleanString(model.bookmark))

	#Syndication Model Members
	item.SetProperty("mediaType", StringUtils.CleanString(model.mediaType))

	# Managable Members
	item.SetProperty("averageRating", StringUtils.CleanString(model.averageRating)[:3])
	item.SetProperty("userRating", StringUtils.CleanString(model.userRating)[:3])
	item.SetProperty("totalRatings", StringUtils.CleanString(model.totalRatings))
	item.SetProperty("favoriteType", StringUtils.CleanString(model.favoriteType))
	item.SetProperty("subscriptionType", StringUtils.CleanString(model.subscriptionType))

	# PPV Members
	item.SetProperty("websiteUrl", StringUtils.CleanString(model.websiteUrl))
	item.SetProperty("ppvModel", StringUtils.CleanString(model.ppvModel))
	item.SetProperty("supportingMaterialsUrl", StringUtils.CleanString(model.supportingMaterialsUrl))
	item.SetProperty("purchaseUrl", StringUtils.CleanString(model.purchaseUrl))
	item.SetProperty("isPurchased", str(model.isPurchased))
	item.SetProperty("currency", StringUtils.CleanString(model.currency))
	item.SetProperty("price", str(model.price))

	# media
	item.SetProperty("mediaCount", str(len(model.media)))
	curMediaItem = -1 #start at 0 since we incriment in for loop
	for mediaModel in model.media:
		# @type mediaModel MediaModel
		curMediaItem += 1
		item.SetProperty("media%s.containerType" % curMediaItem, StringUtils.CleanString(mediaModel.containerType))
		item.SetProperty("media%s.contentType" % curMediaItem, StringUtils.CleanString(mediaModel.contentType))
		item.SetProperty("media%s.bitrate" % curMediaItem, StringUtils.CleanString(mediaModel.bitRate))
		item.SetProperty("media%s.width" % curMediaItem, StringUtils.CleanString(mediaModel.width))
		item.SetProperty("media%s.height" % curMediaItem, StringUtils.CleanString(mediaModel.height))
		item.SetProperty("media%s.url" % curMediaItem, StringUtils.CleanString(mediaModel.url))
		item.SetProperty("media%s.streamingServer" % curMediaItem, StringUtils.CleanString(mediaModel.streamingServer))
		item.SetProperty("media%s.streamingResource" % curMediaItem, StringUtils.CleanString(mediaModel.streamingResource))

	# Boxee Specific skin variables
	item.SetProperty("isEpisode", "true")
	item.SetProperty("icon", StringUtils.CleanString(model.mediaType).lower())
	
	if model.averageRating:
		item.SetProperty("roundedAverageRating", str(round(float(model.averageRating)*2)/2))
	if model.userRating:
		item.SetProperty("roundedUserRating", str(round(float(model.userRating)*2)/2))

	if "Episode" in model.favoriteType:
		item.SetProperty("isEpisodeFavorite", "True")
	if "Show" in model.favoriteType:
		item.SetProperty("isShowFavorite", "True")

	if "Episode" in model.subscriptionType:
		item.SetProperty("isEpisodeSubscription", "True")
	if "Show" in model.subscriptionType:
		item.SetProperty("isShowSubscription", "True")

	if model.showModel:
		if model.showModel.averageRating:
			item.SetProperty("roundedShowAverageRating", str(round(float(model.showModel.averageRating)*2)/2))
		if model.showModel.userRating:
			item.SetProperty("roundedShowUserRating", str(round(float(model.showModel.userRating)*2)/2))

	return item

def DocumentModelToListItem(model):
	# @type model DocumentModel
	
	item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
	item.SetTitle(StringUtils.CleanString(model.title))
	item.SetLabel(StringUtils.CleanString(model.title))
	item.SetThumbnail(StringUtils.CleanString(model.imageUrl))
	item.SetDescription(StringUtils.CleanString(model.description))
	item.SetProperty("slug", StringUtils.CleanString(model.slug))
	item.SetProperty("modelType", StringUtils.CleanString(model.modelType))

	item.SetPath(StringUtils.CleanString(model.url))
	item.SetPath(StringUtils.CleanString(model.websiteUrl))
	item.SetProperty("role", StringUtils.CleanString(model.role))
	item.SetProperty("docType", StringUtils.CleanString(model.docType))
	item.SetProperty("docClass", StringUtils.CleanString(model.docClass))

	# Boxee Specific skin variables
	item.SetProperty("isDocument", "true")
	item.SetProperty("icon", StringUtils.CleanString(model.docType).lower())

	return item