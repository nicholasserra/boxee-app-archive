class MediaflyError(Exception):
	"""
	General Mediafly Error
	"""
	def __init__(self, text):
		self.text = text
	def __str__(self):
		return repr(self.text)

class MediaflyServerError(Exception):
	"""
	Mediafly Error returned by server
	"""
	def __init__(self, code, text):
		self.code = code
		self.text = text
	def __str__(self):
		return repr(self.text)