STREAM_ONLY = "StreamOnly"
DOWNLOADABLE_PROTECTED = "DownloadableProtected"
DOWNLOADABLE_SHAREABLE = "DownloadableShareable"