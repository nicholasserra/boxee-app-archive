import mc

mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Launching home window. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
params = mc.Parameters()
params["title"] = "Home"
mc.GetApp().ActivateWindow( 14000, params )