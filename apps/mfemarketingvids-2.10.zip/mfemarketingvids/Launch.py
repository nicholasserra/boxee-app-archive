import mc
import MediaflyConfig
import boxeemediafly

import xbmc
import time

boxeemediafly.init()
boxeemediafly.getToken()

mcode = MediaflyConfig.MCODE
if MediaflyConfig.MCODE == "__dev__": mcode = mc.ShowDialogKeyboard("mcode", "mfly", False)

boxeemediafly.setContentSource(mcode, True)
boxeemediafly.authenticateContentSource()
boxeemediafly.showMainWindow()
boxeemediafly.showSplashWindow()

if boxeemediafly.isAuthenticated():
	boxeemediafly.loadChannel()
	# close splash screen
	time.sleep(4)
	xbmc.executebuiltin("Dialog.Close(14001)")
else:
	mc.ShowDialogNotification("Error Authenticating...")
	boxeemediafly.close()
