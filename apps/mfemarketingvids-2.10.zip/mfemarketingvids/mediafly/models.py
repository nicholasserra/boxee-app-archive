from mediafly.constants import ModelType, BroadcastState, IdentityType
from operator import attrgetter

class Model(object):
	"""
	Base class for all Mediafly Models.
	Changes string representation of object to include all class name and all atrributes.
	"""
	def __init__(self, modelType = ModelType.UNKNOWN):
		self.modelType = modelType

	def __str__(self):
		return (self.__class__.__name__+"(%i):\n" % id(self)) + "\n".join(["  %s: %s" % (key, self.__dict__[key]) for key in sorted(set(self.__dict__))])

	def __repr__(self):
		return self.__str__()

class BindingMethodModel(Model):
	"""
	Mediafly Binding Method Model
	"""
	def __init__(self):
		Model.__init__(self, ModelType.BINDINGMETHODMODEL)
		self.type = None

	@classmethod
	def createInstance(cls, xml):
		"""
		Creates Binding Method Model from xml
		"""
		instance = BindingMethodModel()
		instance.type = xml.getAttribute('type')

		return instance

class ChannelModel(Model):
	"""
	Mediafly Channel Model
	"""
	def __init__(self):
		Model.__init__(self, ModelType.CHANNEL)
		self.totalEpisodes = None
		self.episodeCount = None
		self.channelCount = None
		self.parentChannelSlug = None

		self.parentChannel = None
		self.subChannels = []

		self.imageUrl = None
		self.title = None
		self.slug = None
		self.description = None

	@classmethod
	def createInstance(cls, xml):
		"""
		Creates Channel Model from xml
		"""
		instance = ChannelModel()
		instance.episodeCount = xml.getAttribute("episodeCount")
		instance.totalEpisodes = xml.getAttribute("totalEpisodes")
		instance.channelCount = xml.getAttribute("channelCount")
		instance.parentChannelSlug = xml.getAttribute("parentChannelSlug")

		instance.imageUrl = xml.getAttribute("imageUrl")
		instance.title = xml.getAttribute("name")
		instance.slug = xml.getAttribute("slug")

		for channelXml in xml.getElementsByTagName("channel"):
			subChannel = ChannelModel.createInstance(channelXml)
			subChannel.parentChannel = instance
			instance.subChannels.append(subChannel)

		return instance

class ContentSourceModel(Model):
	"""
	Mediafly Content Source Model
	"""
	def __init__(self):
		Model.__init__(self, ModelType.CONTENTSOURCE)
		self.provider = None
		self.imageUrlAlt1 = None
		self.imageUrlAlt2 = None
		self.requiresAuthentication = None
		self.requiresSSL = None
		self.mcode = None
		self.allowsUnboundUsers = None
		self.supportsUserBindings = None
		self.usernameRequired = None
		self.passwordRequired = None
		self.passwordEncryptionRequired = None
		self.encryptionType = None
		self.encryptionKey = None
		self.encryptionKeyType = None
		self.isUserRemovable = None
		self.createAccountUrl = None
		self.linkAccountUrl = None

		self.authenticated = None
		self.authenticationModel = None

		self.supportsRatings = None
		self.supportsFavorites = None
		self.supportsSubscriptions = None
		self.supportsExperiences = None
		self.postImpressions = None
		self.contentCachingAllowed = None
		self.isSearchable = None

		self.bindingMethods = None

		self.boundUsers = None
		self.defaultUser = None

		self.imageUrl = None
		self.title = None
		self.slug = None
		self.description = None

	def setUserBindings(self, userModels):
		self.boundUsers = userModels
		self.defaultUser = None
		for bounduser in self.boundUsers:
			if bounduser.defaultUser:
				self.defaultUser = bounduser
				return

	def usesBindingMethod(self, bindingMethodType):
		for bindingmethod in self.bindingMethods:
			if bindingmethod.type ==  bindingMethodType:
				return True
		return False

	@classmethod
	def createInstances(cls, xml):
		"""
		Creates Content Source Model from xml
		"""
		instance = ContentSourceModel()

		instance.provider = xml.getAttribute('provider')
		instance.imageUrlAlt1 = xml.getAttribute('imageUrlAlt1')
		instance.imageUrlAlt2 = xml.getAttribute('imageUrlAlt2')
		instance.requiresAuthentication = xml.getAttribute('requiresAuthentication')=="true"
		instance.requiresSSL = xml.getAttribute('requiresSSL')=="true"
		instance.mcode = xml.getAttribute('mcode')
		instance.allowsUnboundUsers = xml.getAttribute('allowsUnboundUsers')=="true"
		instance.supportsUserBindings = xml.getAttribute('supportsUserBindings')=="true"

		instance.usernameRequired = xml.getAttribute('usernameRequired')=="true"
		instance.passwordRequired = xml.getAttribute('passwordRequired')=="true";
		instance.passwordEncryptionRequired = xml.getAttribute('passwordEncryptionRequired')=="true"
		instance.encryptionType = xml.getAttribute('encryptionType');
		instance.encryptionKey = xml.getAttribute('encryptionKey');
		instance.encryptionKeyType = xml.getAttribute('encryptionKeyType');
		instance.isUserRemovable = xml.getAttribute('isUserRemovable');
		instance.createAccountUrl = xml.getAttribute("createAccountUrl")
		instance.linkAccountUrl = xml.getAttribute("linkAccountUrl")

		instance.supportsRatings = xml.getAttribute('supportsRatings')=="true"
		instance.supportsFavorites = xml.getAttribute('supportsFavorites')=="true"
		instance.supportsSubscriptions = xml.getAttribute('supportsSubscriptions')=="true"
		instance.supportsExperiences = xml.getAttribute('supportsExperiences')=="true"
		instance.postImpressions = xml.getAttribute('postImpressions')=="true"
		instance.contentCachingAllowed = xml.getAttribute('contentCachingAllowed')=="true"

		instance.isSearchable = xml.getAttribute('isSearchable')=="true"

		instance.authenticated = xml.getAttribute('authenticated')=="true"

		instance.imageUrl = xml.getAttribute('imageUrl')
		instance.title = xml.getAttribute('title')
		instance.slug = xml.getAttribute('slug')
		instance.description = xml.getAttribute('description')

		instance.bindingMethods = []
		for bindingMethodXml in xml.getElementsByTagName('bindingMethods')[0].getElementsByTagName('bindingMethod'):
			instance.bindingMethods.append(BindingMethodModel.createInstance(bindingMethodXml))

		return instance
		
class DocumentModel(Model):
	"""
	Mediafly Document Model
	"""

	def __init__(self):
		Model.__init__(self, ModelType.DOCUMENT)
		self.slug = None
		self.url = None
		self.role = None
		self.docType = None
		self.docClass = None

		self.websiteUrl = None
		self.imageUrl = None
		self.title = None
		self.description = None

	@classmethod
	def createInsance(cls, xml):
		"""
		Creates Document Model from xml
		"""
		instance = DocumentModel()
		instance.slug = xml.getAttribute("slug")
		instance.url = xml.getAttribute("url")
		instance.role = xml.getAttribute("role")

		instance.docType = xml.getAttribute("docType")
		instance.docClass = xml.getAttribute("class")
		
		instance.websiteUrl = xml.getAttribute("webSiteUrl")
		instance.imageUrl = xml.getAttribute("imageUrl")
		instance.title = xml.getAttribute("title")
		instance.description = xml.getAttribute("description")

		return instance

class EpisodeModel(Model):
	"""
	Mediafly Episode Model
	"""

	def __init__(self):
		Model.__init__(self, ModelType.EPISODE)

		self.url = None
		self.duration = None
		self.published = None
		self.showSlug = None
		self.showTitle = None
		self.channel = None
		self.channelSlug = None
		self.resumable = None
		self.seekable = None
		self.media = [];
		self.screenCapImageUrl = None

		self.currentMediaIndex = None

		self.downloadModel = None
		self.deliveryModel = None
		self.broadcastState = BroadcastState.ON_DEMAND
		self.onDemandEpisodeSlug = None

		self.position = None
		self.showModel = None
		self.bookmark = None

		#Model Members
		self.imageUrl = None
		self.title = None
		self.slug = None
		self.description = None

		#Syndication Model Members
		self.mediaType = None

		# Managable Members
		self.averageRating = None
		self.totalRatings = None
		self.userRating = None
		self.favoriteType = None
		self.subscriptionType = None

		# PPV Members
		self.websiteUrl = None
		self.ppvModel = None
		self.supportingMaterialsUrl = None
		self.purchaseUrl = None
		self.isPurchased = None
		self.currency = None
		self.price = None

	def getCurrentMediaModel(self):
		if self.media != None:
			if len(self.media) > 0:
				return self.media[self.currentMediaIndex]
		return None

	@classmethod
	def createInsance(cls, xml):
		"""
		Creates Episode Model from xml
		"""
		instance = EpisodeModel()

		instance.mediaType = xml.getAttribute("mediaType")
		instance.url = xml.getAttribute("url")
		instance.published = xml.getAttribute("published")
		instance.showSlug = xml.getAttribute("showSlug")
		instance.showTitle = xml.getAttribute("showTitle")
		instance.channel = xml.getAttribute("channel")
		instance.channelSlug = xml.getAttribute("channelSlug")

		instance.bookmark = xml.getAttribute("bookmark")
		instance.resumable = xml.getAttribute("resumable")=="true"
		instance.seekable = xml.getAttribute("seekable")== "true"

		if xml.hasAttribute("duration"):
			instance.duration = int(xml.getAttribute("duration"))

		instance.downloadModel = xml.getAttribute("downloadModel")
		instance.deliveryModel = xml.getAttribute("deliveryModel")
		instance.broadcastState = xml.getAttribute("broadcastState")
		instance.onDemandEpisodeSlug = xml.getAttribute("onDemandEpisodeSlug")

		instance.websiteUrl = xml.getAttribute("webSiteUrl")
		instance.ppvModel = xml.getAttribute("ppvModel");
		instance.supportingMaterialsUrl = xml.getAttribute("supportingMaterialsUrl")
		if xml.hasAttribute("price"):
			instance.price = float(xml.getAttribute("price"))
		else:
			instance.price = 0
		instance.currency = xml.getAttribute("currency")
		instance.purchaseUrl = xml.getAttribute("purchaseUrl")
		instance.isPurchased = xml.getAttribute("isPurchased")=="true"

		instance.imageUrl = xml.getAttribute('imageUrl')
		instance.title = xml.getAttribute('title')
		instance.slug = xml.getAttribute('slug')
		instance.description = xml.getAttribute('description')

		instance.screenCapImageUrl = xml.getAttribute("screenCapImageUrl")

		instance.averageRating = xml.getAttribute("averageRating")
		instance.totalRatings = xml.getAttribute("totalRatings")
		instance.userRating = xml.getAttribute("userRating")

		instance.favoriteType = xml.getAttribute("favoriteType")
		instance.subscriptionType = xml.getAttribute("subscriptionType")

		instance.media = []
		for mediaXml in xml.getElementsByTagName("media"):
			instance.media.append(MediaModel.createInstance(mediaXml))

		if len(instance.media)>0 and instance.duration==0:
			instance.duration = instance.media[0].duration

		instance.media.sort(key=lambda x:(x.width, x.bitRate))

		showXml = xml.getElementsByTagName("show")
		if len(showXml)>0:
			instance.showModel = ShowModel.createInstance(showXml[0])

		return instance

class MediaModel(Model):
	"""
	Mediafly Media Model
	"""
	def __init__(self):
		Model.__init__(self, ModelType.MEDIA)
		self.containerType = None
		self.contentType = None
		self.audioCodec = None
		self.videoCodec = None
		self.bitRate = None
		self.channels = None
		self.frameRate = None
		self.width = None
		self.height = None
		self.samplingRate = None
		self.url = None
		self.duration = None
		self.grouping = None
		self.streamingServer = None
		self.streamingResource = None
		self.streamLoggingUrl = None
	
	def isRtmp(self):
		if self.streamingServer == None: return False
		return self.streamingServer.startswith("rtmp://")

	@classmethod
	def createInstance(cls, xml):
		"""
		Creates Media Model from xml
		"""
		instance = MediaModel()

		instance.containerType = xml.getAttribute("containerType")
		instance.contentType = xml.getAttribute("contentType")
		instance.audioCodec = xml.getAttribute("audioCodec")
		instance.videoCodec = xml.getAttribute("videoCodec")
		instance.bitRate = xml.getAttribute("bitRate")
		instance.channels = xml.getAttribute("channels")
		instance.frameRate = xml.getAttribute("frameRate")
		instance.width = xml.getAttribute("width")
		instance.height = xml.getAttribute("height")
		instance.samplingRate = xml.getAttribute("samplingRate")
		instance.url = xml.getAttribute("url")
		instance.grouping = xml.getAttribute("grouping")
		instance.streamingServer = xml.getAttribute("streamingServer")
		instance.streamingResource = xml.getAttribute("streamingResource")
		instance.streamLoggingUrl = xml.getAttribute("streamLoggingUrl")

		if (xml.hasAttribute("duration")):
			instance.duration = xml.getAttribute("duration")

		return instance
	
class RequestModel(Model):
	"""
	Mediafly Request Model
	"""
	def __init__(self, apiMethod, contentSourceModel, secure, quiet, args):
		Model.__init__(self, ModelType.REQUEST)
		self.apiMethod = apiMethod
		self.contentSourceModel = contentSourceModel
		self.secure = secure
		self.quiet = quiet
		self.args = args

	@classmethod
	def createInstance(cls, apiMethod, contentSourceModel = None, secure = False, quiet = False,  args = {}):
		"""
		Creates Request Model
		"""
		return RequestModel(apiMethod, contentSourceModel, secure, quiet, args)

class ShowModel(Model):
	"""
	Mediafly Show Model
	"""
	def __init__(self):
		Model.__init__(self, ModelType.SHOW)

		# Model Members
		self.imageUrl = None
		self.title = None
		self.slug = None
		self.description = None
		self.modelType = ModelType.SHOW

		#Syndication Model Members
		self.mediaType = None

		# Managable Members
		self.averageRating = None
		self.totalRatings = None
		self.userRating = None
		self.favoriteType = None
		self.subscriptionType = None

		# PPV Members
		self.websiteUrl = None
		self.ppvModel = None
		self.supportingMaterialsUrl = None
		self.purchaseUrl = None
		self.isPurchased = None
		self.currency = None
		self.price = None

	@classmethod
	def createInstance(cls, xml):
		"""
		Creates Show Model from xml
		"""
		instance = ShowModel()

		instance.imageUrl = xml.getAttribute('imageUrl')
		instance.title = xml.getAttribute('title')
		instance.slug = xml.getAttribute('slug')
		instance.description = xml.getAttribute('description')
		instance.mediaType = xml.getAttribute("mediaType")

		instance.averageRating = xml.getAttribute("averageRating")
		instance.totalRatings = xml.getAttribute("totalRatings")
		instance.userRating = xml.getAttribute("userRating")

		instance.favoriteType = xml.getAttribute("favoriteType")
		instance.subscriptionType = xml.getAttribute("subscriptionType")

		instance.websiteUrl = xml.getAttribute("webSiteUrl")
		instance.ppvModel = xml.getAttribute("ppvModel")
		instance.supportingMaterialsUrl = xml.getAttribute("supportingMaterialsUrl")
		if xml.hasAttribute("price"):
			instance.price = float(xml.getAttribute("price"))
		else:
			instance.price = 0
		instance.currency = xml.getAttribute("currency")
		instance.purchaseUrl = xml.getAttribute("purchaseUrl")
		instance.isPurchased = xml.getAttribute("isPurchased")=="true"

		return instance

class TokenModel(Model):
	"""
	Mediafly Token Model
	"""

	def __init__(self):
		Model.__init__(self, ModelType.TOKEN)
		self.value = None

	@classmethod
	def createInstance(cls, xml):
		"""
		Creates Token Model from xml
		"""
		instance = TokenModel()
		
		instance.value = xml.firstChild.data
		return instance

class UserModel(Model):
	"""
	Mediafly User Model
	"""

	def __init__(self):
		Model.__init__(self, ModelType.USER)
		self.accountName = None
		self.defaultUser = None
		self.ssiToken = None
		self.mcode = None
		self.requiresAuthentication = None

		self.authenticated = None
		self.authenticationModel = None

	def getUserContext(self):
		if self.ssiToken:
			return self.ssiToken
		else:
			return self.accountName

	def getIdentityMode(self):
		if self.ssiToken:
			return IdentityType.SSI_TOKEN
		else:
			return IdentityType.SSI_DEVICE

	@classmethod
	def createInstance(cls, xml):
		"""
		Creates User Model from xml
		"""
		instance = UserModel()

		instance.accountName = xml.getAttribute("accountName")
		instance.defaultUser = xml.getAttribute("default")=="true"
		instance.requiresAuthentication = xml.getAttribute("requiresAuthentication")=="true"

		if xml.hasAttribute("authenticated"):
			instance.authenticated = xml.getAttribute("authenticated").lower()=="true"
		if xml.hasAttribute("authenticationModel"):
			instance.authenticationModel = xml.getAttribute("authenticationModel")

		return instance

	@classmethod
	def getDefaultUser(cls, userModels):
		for userModel in userModels:
			if userModel.defaultUser:
				return userModel
		return None

	@classmethod
	def createSSITokenInstance(cls, ssiToken, mCode):
		instance = UserModel()

		instance.defaultUser = True
		instance.ssiToken = ssiToken
		instance.mcode = mCode

		return instance