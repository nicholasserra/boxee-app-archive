NONE = "None"
USERNAME_PASSWORD = "UsernamePassword"
USERNAME_PASSWORD_PIN = "UsernamePasswordPin"
PIN = "Pin"