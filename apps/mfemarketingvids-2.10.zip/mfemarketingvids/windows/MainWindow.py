import boxeemediafly, mc, xbmc
from boxeemediafly.constants import Assets
from mediafly.constants import ModelType

window = mc.GetWindow(14000)
rating = 0

def saveState():
	window.GetControl(200).SetFocus()
	window.PushState()

def _getTitleList():
	"""
	Gets list used for background, banner, and title
	"""
	list = window.GetList(100)
	if len(list.GetItems())<1:
		titleItem = mc.ListItem()
		titleItems = mc.ListItems()
		titleItems.append(titleItem)
		list.SetItems(titleItems)
		list.Refresh()
		list.SetFocusedItem(0)
	return list

def _getTitleItem():
	"""
	Gets item used for background, banner, and title
	"""
	return _getTitleList().GetItem(0)

def _getItem():
	"""
	Gets the current item in the main list
	"""
	list = window.GetList(200)
	return list.GetItem(list.GetFocusedItem())

def setTitle(text):
	"""
	Sets the title on the top of the window.
	"""
	_getTitleItem().SetLabel(text)

def setButtonCaption(text):
	"""
	Sets the caption of the button row
	"""
	window.GetLabel(320).SetLabel(text)

def clearItems():
	itemList = window.GetList(200)
	itemList.SetItems(mc.ListItems())
	itemList.Refresh()

def setItems(items):
	"""
	Sets the items on the page
	"""
	itemList = window.GetList(200)
	itemList.SetItems(items)
	itemList.Refresh()

	#post impressions
	boxeemediafly.postImpression(boxeemediafly.getAssetPath(Assets.BANNER))
	if len(items)>0 and (items[0].GetProperty("isDocument") or items[0].GetProperty("isEpisode")):
		boxeemediafly.postImpression(boxeemediafly.getAssetPath(Assets.RIGHT_LOWER))
	else:
		boxeemediafly.postImpression(boxeemediafly.getAssetPath(Assets.RIGHT_HOME))


def handleItem(item):
	modeltype = item.GetProperty("modelType")
	if modeltype == ModelType.CONTENTSOURCE:
		#TODO handle content source
		mc.ShowDialogNotification("TODO: Handle Content Source")
		pass
	elif modeltype == ModelType.CHANNEL:
		handleChannelItem(item)
	elif modeltype == ModelType.EPISODE:
		window.GetControl(311).SetFocus()
	elif modeltype == ModelType.DOCUMENT:
		window.GetControl(318).SetFocus()
	else:
		pass

def handleChannelItem(item):
	saveState()
	boxeemediafly.loadChannel(item.GetTitle(), item.GetProperty("slug"))
	window.GetControl(200).SetFocus()

def items_onClick():
	handleItem(_getItem())

# Ratings ######################################################################

def _changeRatingStars(id, amt):
	'''
	Changes rating by amt and then updates id with the correct image
	'''
	global rating
	image = window.GetImage(id)
	rating+=amt

	if(rating>5): rating = 5
	if(rating<0): rating = 0
	
	image.SetTexture(mc.GetApp().GetAppMediaDir() + "/media/ratings/com.mediafly-rating-%s.0.png" % rating)

def rateShow_onFocus():
	global rating
	rating = 3
	_changeRatingStars(304, 0)

def rateShow_onLeft():
	_changeRatingStars(304, -1)

def rateShow_onRight():
	_changeRatingStars(304, 1)

def rateShow_onClick():
	if rating > 0:
		boxeemediafly.addShowRating(_getItem(), rating)
	else:
		boxeemediafly.removeShowRating(_getItem())

def rateEpisode_onFocus():
	# reset initial rating to 0
	global rating
	rating = 3
	_changeRatingStars(302, 0)

def rateEpisode_onLeft():
	_changeRatingStars(302, -1)

def rateEpisode_onRight():
	_changeRatingStars(302, 1)

def rateEpisode_onClick():
	if rating > 0:
		boxeemediafly.addEpisodeRating(_getItem(), rating)
	else:
		boxeemediafly.removeEpisodeRating(_getItem())

# Top Menu #####################################################################
def login_onClick():
	"""
	Prompts user for login information and attemts to bind user
	"""
	boxeemediafly.bindUser()

def logout_onClick():
	"""
	Logs out user
	"""
	boxeemediafly.unbindUser()

def search_onClick():
	search = mc.ShowDialogKeyboard("Search:", "", False)
	if search:
		saveState()
		setTitle("Search: "+search)
		boxeemediafly.loadSearch(search)
		window.GetControl(200).SetFocus()

def nowPlaying_onClick():
	boxeemediafly.showFullScreen()
	
# Episode Items ################################################################

def play_onClick():
	focusedItem = _getItem()
	focusItems()
	list = window.GetList(200)
	index = 0

	if focusedItem.GetProperty('ppvModel')=="BindingRequired":
		result = mc.ShowDialogConfirm("Login Required", "You must be logged in to view this item.  Would you like to login now?", "No", "Yes")
		if result: boxeemediafly.bindUser()
	else:
		mc.ShowDialogWait()
		# filter for audio/video only
		episodeItems = mc.ListItems()
		for item in window.GetList(200).GetItems():
			if item.GetProperty("modelType") == ModelType.EPISODE:
				episodeItems.append(item)
				if item.GetProperty('slug') == focusedItem.GetProperty('slug'):
					index = len(episodeItems)-1

		boxeemediafly.playItems(episodeItems, index)
		mc.HideDialogWait()

def launch_onClick():
	boxeemediafly.playItem(_getItem(), False)

def info_onClick():
	boxeemediafly.playItem(_getItem(), True)

def moreEpisodes_onClick():
	item = _getItem()
	showSlug = item.GetProperty("showSlug")
	if showSlug:
		saveState()
		boxeemediafly.loadShow(item.GetProperty("showTitle"), showSlug)
		window.GetControl(200).SetFocus()
	else:
		mc.ShowDialogNotification("Error loading more episodes...")

def updateBubbleFavoriteEpisode():
	button = window.GetToggleButton(314)
	label = window.GetLabel(320)
	if button.IsSelected():
		label.SetLabel("Remove Episode Favorite")
	else:
		label.SetLabel("Favorite Episode")

def favoriteEpisode_onFocus():
	updateBubbleFavoriteEpisode()

def favoriteEpisode_onClick():
	boxeemediafly.addFavoriteEpisode(_getItem())
	updateBubbleFavoriteEpisode()

def favoriteEpisode_altClick():
	boxeemediafly.removeFavoriteEpisode(_getItem())
	updateBubbleFavoriteEpisode()


def updateBubbleFavoriteShow():
	button = window.GetToggleButton(315)
	label = window.GetLabel(320)
	if button.IsSelected():
		label.SetLabel("Remove Show Favorite")
	else:
		label.SetLabel("Favorite Show")
			
def favoriteShow_onFocus():
	updateBubbleFavoriteShow()

def favoriteShow_onClick():
	boxeemediafly.addFavoriteShow(_getItem())
	updateBubbleFavoriteShow()

def favoriteShow_altClick():
	boxeemediafly.removeFavoriteShow(_getItem())
	updateBubbleFavoriteShow()

def updateBubbleSubscribeEpisode():
	button = window.GetToggleButton(316)
	label = window.GetLabel(320)
	if button.IsSelected():
		label.SetLabel("Unsubscribe Episode")
	else:
		label.SetLabel("Subscribe Episode")

def subscribeEpisode_onFocus():
	updateBubbleSubscribeEpisode()

def subscribeEpisode_onClick():
	boxeemediafly.subscribeEpisode(_getItem())
	updateBubbleFavoriteEpisode()

def subscribeEpisode_altClick():
	boxeemediafly.unsubscribeEpisode(_getItem())
	updateBubbleFavoriteEpisode()

def updateBubbleSubscribeShow():
	button = window.GetToggleButton(317)
	label = window.GetLabel(320)
	if button.IsSelected():
		label.SetLabel("Unsubscribe Show")
	else:
		label.SetLabel("Subscribe Show")

def subscribeShow_onFocus():
	updateBubbleSubscribeShow()

def subscribeShow_onClick():
	boxeemediafly.subscribeShow(_getItem())
	updateBubbleSubscribeShow()

def subscribeShow_altClick():
	boxeemediafly.unsubscribeShow(_getItem())
	updateBubbleSubscribeShow()

def tryFocusShowRating():
	if boxeemediafly.config.GetValue(boxeemediafly.CS_SUPPORTS_RATINGS):
		window.GetControl(303).SetFocus()

def focusItems():
	list = window.GetList(200)
	focus = list.GetFocusedItem()-1
	xbmc.executebuiltin('SetFocus(200, %s)' % focus)

def rightpanel_onLeft():
	focusItems()