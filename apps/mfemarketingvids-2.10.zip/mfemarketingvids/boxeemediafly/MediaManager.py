import boxeemediafly
import thread
import mc, xbmc, math
from mediafly.models import MediaModel
from mediafly.constants import ModelType, MediaType, PostAction
from boxeemediafly.utils import BandwidthUtil, StringUtils
from urllib import urlencode, quote_plus
from operator import attrgetter
from threading import Thread

class MediaflyMediaPlayer(mc.Player):
	def __init__(self):
		# call constructor
		mc.Player.__init__(self, True)

################################################################################

class MediaflyMediaPlayerThread(Thread):
	def __init__(self,  player = None, usePostActions = False):
		Thread.__init__(self)

		self.player = player
		self.usePostActions = usePostActions
		
		self.item = None
		self.closing = False
		self.lastUpdate = 0
		self.currentTime = 0

	def run(self):
		self.player.SetLastPlayerEvent(mc.Player.EVENT_NONE)
		self.monitor()

	def close(self):
		self.closing = True

	def isRealItem(self, item):
		if item is None: return False
		return not item.GetPath() == ""

	def areEqual(self, item1, item2):
		if item1 is None or item2 is None: return False
		return item1.GetProperty("slug") == item2.GetProperty("slug")

	def isFromOurApp(self, item):
		if item is None: return False
		return item.GetProperty("appId") == mc.GetApp().GetId()

	def stopItem(self):
		self.onStopped()
		self.item = None
		
	def monitor(self):
		while True:
			# get the latest player event and get the item
			event = self.player.GetLastPlayerEvent()
			playingItem = self.player.GetPlayingItem()

			if event == mc.Player.EVENT_STARTED:
				# if the started postaction has yet to be sent
				if self.isRealItem(playingItem):
					if self.isFromOurApp(playingItem):
						try: self.currentTime = _player.GetTime()
						except: pass
						if not self.areEqual(self.item, playingItem):
							if self.isFromOurApp(self.item): self.stopItem()
							self.item = playingItem
							self.onStarted()
						else:
							self.onPlaying()
					else:
						self.close()
				self.item = playingItem

			elif event == mc.Player.EVENT_STOPPED:
				self.player.SetLastPlayerEvent(mc.Player.EVENT_NONE)
				if self.isRealItem(self.item): self.stopItem()


			xbmc.sleep(1500)

			if self.closing:
				if self.isRealItem(self.item): self.stopItem()
				break

		mc.LogDebug("MediaflyMediaPlayer => kill MediaflyMediaPlayerThread")

	def onStarted(self):
		mc.LogDebug("MediaflyMediaPlayer => onStarted \ttitle [%s]\tslug [%s]\tpath [%s]" % (self.item.GetTitle(), self.item.GetProperty('slug'), self.item.GetPath()))
		showFullScreen()
		if self.usePostActions:
			self.lastUpdate = 0
			boxeemediafly.postAction(self.item.GetProperty("slug"), self.item.GetProperty("mediaType"), PostAction.PLAY)

	def onPlaying(self):
		mc.LogDebug("MediaflyMediaPlayer => onPlaying \ttitle [%s]\tslug [%s]\tpath [%s]" % (self.item.GetTitle(), self.item.GetProperty('slug'), self.item.GetPath()))
		# update after 30 secs of time difference
		
		if self.usePostActions:
			if math.fabs(self.lastUpdate - self.currentTime) > 30:
				boxeemediafly.postAction(self.item.GetProperty("slug"), self.item.GetProperty("mediaType"), PostAction.PLAYING, self.currentTime)
				self.lastUpdate = self.currentTime

	def onStopped(self):
		mc.LogDebug("MediaflyMediaPlayer => onStopped \ttitle [%s]\tslug [%s]\tpath [%s]" % (self.item.GetTitle(), self.item.GetProperty('slug'), self.item.GetPath()))
		if self.usePostActions and self.item:
			boxeemediafly.postAction(self.item.GetProperty("slug"), self.item.GetProperty("mediaType"), PostAction.STOP, self.currentTime)
			item = None

################################################################################

_player = MediaflyMediaPlayer()
_playerThread = None

def playItems(contentSource, mfItems, index):
	global _player
	playlist = mc.PlayList(mc.PlayList.PLAYLIST_VIDEO)
	playlist.Clear()

	# speed test to find kbps
	speedTestUrl = mfItems[0].GetThumbnail().replace("300x300", "600x600")
	BandwidthUtil.getSpeed(speedTestUrl)

	# loop through each item creating a playable item
	for mfItem in mfItems:
		playlist.Add(createPlayItemFromEpisode(mfItem))

	# stop the current player
	_player.Stop()
	while _player.IsPlaying():
		xbmc.sleep(500)

	if contentSource.supportsExperiences:
		startPlayerThread()
		playlist.Play(index)
	else:
		stopThread()
		playlist.Play(index)
	showFullScreen()

def playItem(contentSource, mfItem, useActionMenu = False):
	modelType = mfItem.GetProperty("modelType")
	playItem = None
	
	if modelType == ModelType.DOCUMENT:
		playItem = _createPlayItem(mc.ListItem.MEDIA_VIDEO_OTHER, mfItem, mfItem.GetPath(), "text/html")
	elif modelType == ModelType.EPISODE:
		playItem = createPlayItemFromEpisode(mfItem, True)
		
	if playItem:
		if useActionMenu:
			_player.PlayWithActionMenu(playItem)
		else:
			_player.Play(playItem)

def stopThread():
	global _playerThread
	if _playerThread and _playerThread.isAlive():
		_playerThread.close()
		_player.Stop()

		while _playerThread.isAlive():
			xbmc.sleep(500)

def startPlayerThread():
	#TODO switch to usePostAction
	global _playerThread
	if _playerThread is None or not _playerThread.isAlive():
		_playerThread = MediaflyMediaPlayerThread(_player, True)
		_playerThread.start()

def isPlayingVideo():
	return _player.IsPlayingVideo()

def isPlayingAudio():
	return _player.IsPlayingAudio()

def lockActions():
	_player.LockPlayerAction(mc.Player.XAPP_PLAYER_ACTION_NEXT)

def unlockActions():
	_player.LockPlayerAction(mc.Player.XAPP_PLAYER_ACTION_NONE)

def showFullScreen():
	if isPlayingVideo():
		showFullScreenVideo()
	else:
		showFullScreenVisualization()

def showFullScreenVideo():
	mc.ActivateWindow(12005)

def showFullScreenVisualization():
	mc.ActivateWindow(12006)

################################################################################
# Playable list items
################################################################################

def createPlayItemFromEpisode(item, testSpeed = False):
	episodeItem = None

	# build media list
	media = []
	for i in range(StringUtils.StringToInt(item.GetProperty("mediaCount"))):
		mediaItem = MediaModel()
		mediaItem.containerType = item.GetProperty("media%s.containerType" % i)
		mediaItem.contentType = item.GetProperty("media%s.contentType" % i)
		mediaItem.bitRate = item.GetProperty("media%s.bitrate" % i)
		mediaItem.width = StringUtils.StringToInt(item.GetProperty("media%s.width" % i))
		mediaItem.height = StringUtils.StringToInt(item.GetProperty("media%s.height" % i))
		mediaItem.url = item.GetProperty("media%s.url" % i)
		mediaItem.streamingServer = item.GetProperty("media%s.streamingServer" % i)
		mediaItem.streamingResource = item.GetProperty("media%s.streamingResource" % i)		
		media.append(mediaItem)

	# find HLS items.  Play if supported.  Otherwise remove from media list
	for mediaItem in media:
		if mediaItem.containerType == "HLS":
			if _supportsHLS():
				episodeItem = _createHlsItem(item, mediaItem)
			else:
				media.remove(mediaItem)

	# find the right video to play... all hls container types are removed
	# search through items according to algorithm on mediafly api website
	# finding a video closest to screen size.  then we use a target bitrate
	# and try to use anything close
	if episodeItem is None:
		if len(media)>0:
			targetBitrate = BandwidthUtil.getSpeed(testSpeed)
			screenWidth = 1280
			screenHeight = 720
			bestMedia = []
			minDelta = -1

			for mediaItem in media:
				delta = (mediaItem.width-screenWidth) * (mediaItem.height-screenHeight)
				if delta == minDelta:
					bestMedia.append(mediaItem)
				elif minDelta ==-1 or delta < minDelta:
					bestMedia = []
					bestMedia.append(mediaItem)
					minDelta = delta

			# find best item in items
			bestMedia.sort(key=attrgetter('bitRate'))
			bestMediaItem = bestMedia[0]
			for i in range(1, len(bestMedia)):
				bitRate = bestMedia[i].bitRate
				if bitRate > bestMediaItem.bitRate and bitRate <= targetBitrate:
					bestMediaItem = bestMedia[i]

			if bestMediaItem.isRtmp():
				episodeItem = _createRtmpItem(item, bestMediaItem)
			else:
				episodeItem = _createNormalItem(item, bestMediaItem)
		elif item.GetPath():
			episodeItem = _createNormalItem(item)
		else:
			mc.ShowDialogNotification("No suitable stream found")

	return episodeItem

def _createPlayItem(mediaType, mediaflyListItem, path, titleSuffix="", contentType = None):
	"""
	Generic function to created a playable item.
	"""
	playItem = mc.ListItem(mediaType)
	playItem.SetProviderSource("Mediafly")
	playItem.SetPath(path)

	externalItem = mc.ListItem(mediaType)
	externalItem.SetProviderSource("Mediafly")
	externalItem.SetPath(mediaflyListItem.GetProperty("websiteUrl"))

	if contentType:
		playItem.SetContentType(contentType)

	# copy items from original listitem
	playItem.SetTitle(mediaflyListItem.GetTitle() + " " +titleSuffix)
	playItem.SetLabel(mediaflyListItem.GetLabel() + " " +titleSuffix)
	playItem.SetThumbnail(mediaflyListItem.GetThumbnail())
	playItem.SetDescription(mediaflyListItem.GetDescription())
	playItem.SetProperty("slug", mediaflyListItem.GetProperty("slug"))
	playItem.SetProperty("showSlug", mediaflyListItem.GetProperty("showSlug"))
	playItem.SetProperty("channelSlug", mediaflyListItem.GetProperty("channelSlug"))
	playItem.SetProperty("mediaType", mediaflyListItem.GetProperty("mediaType"))
	playItem.SetProperty("appId", mc.GetApp().GetId())

	externalItem.SetTitle(mediaflyListItem.GetTitle())
	externalItem.SetLabel(mediaflyListItem.GetLabel())
	externalItem.SetThumbnail(mediaflyListItem.GetThumbnail())
	externalItem.SetDescription(mediaflyListItem.GetDescription())

	playItem.SetExternalItem(externalItem)

	return playItem

def _supportsHLS():
	"""
	Determines if this version of boxee supports hls based on version
	"""
	version = mc.GetInfoString("System.BuildVersion").split(".")
	if int(version[0]) > 1: return True # > version 1
	if version[0]=="1" and int(version[1]) >= 2: return True # >= version 1.1
	return False

def _createHlsItem(item, mediaModel):
	"""
	Plays hls stream
	http://developer.boxee.tv/HTTP_Live_Support
	"""
	params = { 'quality': 'A'}
	playlistUrl = "playlist://%s?%s" % (quote_plus(mediaModel.url), urlencode(params))
	return _createPlayItem(mc.ListItem.MEDIA_VIDEO_OTHER, item, playlistUrl, "[HLS]", mediaModel.contentType)

def _createRtmpItem(item, mediaModel):
	playItem = _createPlayItem(mc.ListItem.MEDIA_VIDEO_OTHER, item, mediaModel.streamingServer+"/"+mediaModel.streamingResource, "[RTMP:%skbps]" % mediaModel.bitRate,  mediaModel.contentType)
	playItem.SetProperty("PlayPath", mediaModel.streamingResource)
	playItem.SetProperty("TcUrl", mediaModel.streamingServer)
	return playItem

def _createNormalItem(item, mediaModel = None,):
	if mediaModel:
		playItem = _createPlayItem(mc.ListItem.MEDIA_VIDEO_OTHER, item, mediaModel.url, "[%skbps]" % mediaModel.bitRate, mediaModel.contentType)
	else:
		if item.GetProperty("mediaType") == MediaType.AUDIO:
			playItem = _createPlayItem(mc.ListItem.MEDIA_AUDIO_OTHER, item, item.GetPath())
		else:
			playItem = _createPlayItem(mc.ListItem.MEDIA_VIDEO_OTHER, item, item.GetPath())
	return playItem