import mc, boxeemediafly
from mediafly.errors import MediaflyServerError
from mediafly import HttpPost
from mediafly.constants import BindingMethodType

def authenticateContentSource(contentSourceModel):
	mc.LogInfo("requiresAuthentication: " + str(contentSourceModel.authenticated) + ", authenticated: "+ str(contentSourceModel.authenticated))
	if contentSourceModel.requiresAuthentication and not contentSourceModel.authenticated:
		# requires authentication prompt for username/password
		username = None
		password = None
		if contentSourceModel.usernameRequired:
			username = mc.ShowDialogKeyboard("Username", "", False)
		if contentSourceModel.passwordRequired:
			password = mc.ShowDialogKeyboard("Password", "", True)

		# if auth fails ask user to try again
		if not authenticatedForDevice(contentSourceModel, username, password):
			if mc.ShowDialogConfirm("Error Authenticating", "Would you like to try again?", "No", "Yes"):
				authenticateContentSource(contentSourceModel)
	else:
		getBoundUsers(contentSourceModel)

def authenticatedForDevice(contentSourceModel, username = None, password = None):
	try:
		boxeemediafly.callMediaflyFunction(HttpPost.authenticateDeviceForSource, True, contentSourceModel, username, password)
		contentSourceModel.authenticated = True
		authenticateContentSource(contentSourceModel)
		return True
	except MediaflyServerError, e:
		mc.LogError("Error Authenticating Content Source: "+str(e))
		return False

def addUserForContentSource(contentSourceModel):
	
	if len(contentSourceModel.bindingMethods) > 1:
		mc.LogInfo("TODO: bindingMethods > 1")

	bindingMethod = contentSourceModel.bindingMethods[0].type

	if bindingMethod == BindingMethodType.USERNAME_PASSWORD_PIN:
		username = mc.ShowDialogKeyboard("Username", "", False)
		password = mc.ShowDialogKeyboard("Password", "", True)
		pin = mc.ShowDialogKeyboard("Pin", "", True)
		return bindUserForContentSource(contentSourceModel, username, password, pin)
	elif bindingMethod == BindingMethodType.USERNAME_PASSWORD:
		username = mc.ShowDialogKeyboard("Username", "", False)
		password = mc.ShowDialogKeyboard("Password", "", True)
		return bindUserForContentSource(contentSourceModel, username, password)
	elif bindingMethod == BindingMethodType.PIN:
		pin = mc.ShowDialogKeyboard("Pin", "", True)
		return bindUserForContentSource(contentSourceModel, "", "", pin)
	else:
		mc.ShowDialogNotification("Unknown binding method: " + bindingMethod)
		mc.LogError("Unknown binding method: "+ bindingMethod)
		return False


def bindUserForContentSource(contentSourceModel, username="", password="", pin=""):
	try:
		boxeemediafly.callMediaflyFunction(HttpPost.bindUserToContentSource, True, contentSourceModel, username, password, pin)
		getBoundUsers(contentSourceModel)
		return True
	except MediaflyServerError, e:
		mc.ShowDialogNotification("Error logging in")
		mc.LogError("Error Binding User: "+ str(e))
		return False

def unbindDefaultUserForContentSource(contentSourceModel):
	try:
		return unbindUserForContentSource(contentSourceModel, contentSourceModel.defaultUser.accountName)
	except Exception, e:
		mc.LogError("Unknown error Unbinding user: "+ str(e))
		return False

def unbindUserForContentSource(contentSourceModel, username):
	try:
		boxeemediafly.callMediaflyFunction(HttpPost.unbindUserToContentSource, True, contentSourceModel, username)
		getBoundUsers(contentSourceModel)
		return True
	except MediaflyServerError, e:
		mc.ShowDialogNotification("Error logging out")
		mc.LogError("Error Unbinding user: "+ str(e))
		return False

def authenticateUserForContentSource(contentSourceModel, username="", password="", pin=""):
	try:
		boxeemediafly.callMediaflyFunction(HttpPost.authenticateUserForSource, True, contentSourceModel, username, password, pin)
		getBoundUsers(contentSourceModel)
		return True
	except MediaflyServerError, e:
		#mc.ShowDialogNotification("Error Authenticating User")
		mc.LogError("Error Authenticating User: "+ str(e))
		return False

def getBoundUsers(contentSourceModel):
	boundUsers = boxeemediafly.callMediaflyFunction(HttpPost.getBoundUsers, True, contentSourceModel)

	mc.LogInfo("allowsUnboundUsers:"	+ str(contentSourceModel.allowsUnboundUsers))

	# if no bound users and not allow unbound
	if len(boundUsers) == 0 and not contentSourceModel.allowsUnboundUsers:
		addUserForContentSource(contentSourceModel)
		return

	if len(boundUsers) > 1:
		#TODO handle more then 1 bound user
		mc.LogError("More then one bound user.  Defaulting to first user.")

	contentSourceModel.setUserBindings(boundUsers)

	if contentSourceModel.defaultUser:
		mc.LogInfo("contentSourceModel.defaultUser.requiresAuthentication: " + str(contentSourceModel.defaultUser.requiresAuthentication) + ",  contentSourceModel.defaultUser.authenticated: " + str(contentSourceModel.defaultUser.authenticated))
		if contentSourceModel.defaultUser.requiresAuthentication and contentSourceModel.defaultUser.authenticated != True:
			authenticationModel = contentSourceModel.defaultUser.authenticationModel
			if authenticationModel == BindingMethodType.USERNAME_PASSWORD:
				username = mc.ShowDialogKeyboard("Username", "")
				password = mc.ShowDialogKeyboard("Password", "", True)
				if not authenticateUserForContentSource(contentSourceModel, username, password):
					if mc.ShowDialogConfirm("Error Authenticating", "Would you like to try again?", "No", "Yes"):
						getBoundUsers(contentSourceModel)
			elif authenticationModel == BindingMethodType.PIN:
				pin = mc.ShowDialogKeyboard("Pin", "", True)
				if not authenticateUserForContentSource(contentSourceModel, "", "", pin):
					if mc.ShowDialogConfirm("Error Authenticating", "Would you like to try again?", "No", "Yes"):
						authenticateContentSource(contentSourceModel)
			else:
				mc.ShowDialogNotification("Unhandled authentication model: "+authenticationModel)