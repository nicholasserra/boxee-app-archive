def CleanString(string):
	"""
	Encodes string as utf-8 and removes html characters
	"""
	if string:
		string = string.encode("utf-8", "replace")
		string = string.replace("<br />", "\n")
		string = str(string)
		return string
	else:
		return ''

def StringToInt(string):
	"""
	Converts string to int returning 0 for blank strings
	"""
	string = string.strip()
	try:
		return int(string)
	except:
		return 0