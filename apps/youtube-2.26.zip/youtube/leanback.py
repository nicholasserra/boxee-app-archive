import mc
from urllib import quote

try:
    geo = mc.GetGeoLocation()
    lang = mc.GetSystemLanguage()

    print "####################"
    print lang
    print geo
    print "####################"

    if not geo:
        geo = 'us'

    if lang == 'English':
        lang = 'en'
    elif lang == 'Spanish':
        lang = 'es'
    elif lang == 'French':
        lang = 'fr'
    elif lang == 'German':
        lang = 'de'
    elif lang == 'Japanese':
        lang = 'ja'
    elif lang == 'Italian':
        lang = 'it'
    elif lang == 'Swedish':
        lang = 'sv'
    elif lang == 'Hebrew':
        lang = 'he'
    elif lang == 'Danish':
        lang = 'da'
    elif lang == 'Dutch':
        lang = 'dl'
    elif lang == 'Russian':
        lang = 'ru'
    elif lang == 'Turkish': 
        lang = 'tr'
    elif lang == 'Arabic':
        lang = 'ar'
    elif lang == 'Portuguese':
        lang = 'pt'
    elif lang == 'Norwegian':
        lang = 'no'
    elif lang == 'Finnish':
        lang = 'fi'
    elif lang == 'Czech':
        lang = 'cs'
    elif lang == 'Polish':
        lang = 'pl'
    else:
        lang = 'en'

    item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
    item.SetLabel('YouTube')
    item.SetPath('https://www.youtube.com/leanbacklite?lang=%s&country=%s' % (str(lang), str(geo).upper()))
    mc.GetPlayer().Play(item)

except:
    # if all else fails, default to en_US
    item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
    item.SetLabel('YouTube')
    item.SetPath('https://www.youtube.com/leanbacklite')
    mc.GetPlayer().Play(item)

