import mc
import urllib
import urllib2
import time, random, md5
from xml.dom import minidom

currentCategory = 0

def filterString( aString ):
   	if aString.find(u'\u2019') >= 0 : 
  		aString = aString.replace(u'\u2019', '\'')

   	if aString.find(u'\u2013') >= 0 : 
   		aString = aString.replace(u'\u2013', '\'')
   		
   	if aString.find(u'\u2026') >= 0 : 
   		aString = aString.replace(u'\u2026', '\'')

   	if aString.find(u'\xe9') >= 0 : 
   		aString = aString.replace(u'\xe9', '\'')
   		
   	return str( aString )

def startLoading():
	mc.GetWindow(14000).GetList(100).SetVisible( False )
	mc.GetWindow(14000).GetControl(2000).SetVisible( True )
	
def stopLoading():
	mc.GetWindow(14000).GetList(100).SetVisible( True )
	mc.GetWindow(14000).GetControl(2000).SetVisible( False )
	
def hideTabs():
	mc.GetWindow(14000).GetToggleButton(150).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(151).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(152).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(153).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(154).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(155).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(156).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(157).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(158).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(159).SetSelected( False )
	mc.GetWindow(14000).GetToggleButton(160).SetSelected( False )
	
def getTabID():

	tabID = 0
	
	if currentCategory == 0:
		tabID = 150
	elif currentCategory == 1:
		tabID = 151
	elif currentCategory == 2:
		tabID = 152
	elif currentCategory == 3:
		tabID = 153
	elif currentCategory == 4:
		tabID = 154
	elif currentCategory == 5:
		tabID = 155
	elif currentCategory == 6:
		tabID = 156
	elif currentCategory == 7:
		tabID = 157
	elif currentCategory == 8:
		tabID = 158
	elif currentCategory == 9:
		tabID = 159
	elif currentCategory == 10:
		tabID = 160
		
	return tabID
	
def displayAppropriateGroup():

	hideTabs()
	
	title = "Break.com"
	if currentCategory == 0:
		title += " > Homepage"
		trackAnalyticsEvent( "Homepage" )
	elif currentCategory == 1:
		title += " > Galleries"
	elif currentCategory == 2:
		title += " > Sports"
		trackAnalyticsEvent( "ChannelSports" )
	elif currentCategory == 3:
		title += " > Break Classics"
		trackAnalyticsEvent( "ChannelBreakClassics" )
	elif currentCategory == 4:
		title += " > Break Originals"
		trackAnalyticsEvent( "ChannelBreakOriginals" )
	elif currentCategory == 5:
		title += " > Epic Fails"
		trackAnalyticsEvent( "ChannelEpicFails" )
	elif currentCategory == 6:
		title += " > Game Trailers"
		trackAnalyticsEvent( "ChannelGameTrailers" )
	elif currentCategory == 7:
		title += " > Horror"
		trackAnalyticsEvent( "ChannelHorror" )
	elif currentCategory == 8:
		title += " > Movie Trailers"
		trackAnalyticsEvent( "ChannelMovieTrailers" )
	elif currentCategory == 9:
		title += " > Pranks"
		trackAnalyticsEvent( "ChannelPranks" )
	elif currentCategory == 10:
		title += " > Search"
		trackAnalyticsEvent( "Search" )
		
	tabID = getTabID()		
	mc.GetWindow(14000).GetLabel(600).SetLabel(title)
	mc.GetWindow(14000).GetToggleButton(tabID).SetSelected( True )

	if currentCategory < 10:
		mc.LogInfo( "Show channel controls" );
		mc.GetWindow(14000).GetControl(4000).SetVisible( True )
		mc.GetWindow(14000).GetControl(4001).SetVisible( False )
	else:
		mc.LogInfo( "Show search controls" );
		mc.GetWindow(14000).GetControl(4000).SetVisible( False )
		mc.GetWindow(14000).GetControl(4001).SetVisible( True )		

def fetchHomepage():

	mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fetching homepage... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	request = urllib2.Request("http://api.break.com/invoke/homepage/1/50")	
	
	try:
	    r = urllib2.urlopen(request)
	except urllib2.HTTPError, e:
	    mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Homepage request failed! " + str(e) + " %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	else:
	    itemList = mc.ListItems()

	    xml = r.read()
	    dom = minidom.parseString( xml )
	    
	    contentList = dom.getElementsByTagName( 'Content' )
	    
	    for contentItem in contentList:	    
	    	item = mc.ListItem( mc.ListItem.MEDIA_VIDEO_CLIP )
	    	
	    	item.SetProperty( "contentID", filterString( contentItem.getElementsByTagName('ContentID')[0].firstChild.data ) )
	    	item.SetLabel( filterString( contentItem.getElementsByTagName("ContentTitle")[0].firstChild.data ) )
	    	item.SetTitle( item.GetLabel() )
	    	item.SetDescription( filterString( contentItem.getElementsByTagName("ContentDescription")[0].firstChild.data ) )
	    	item.SetThumbnail( filterString( contentItem.getElementsByTagName("ThumbNailURL")[0].firstChild.data ) )
	    	item.SetPath( filterString( contentItem.getElementsByTagName("SourceVideo")[0].firstChild.data ) )
	    	item.SetDirector( filterString( contentItem.getElementsByTagName("Submitter")[0].firstChild.data ) )
	    	item.SetDuration( int( contentItem.getElementsByTagName("RunLength")[0].firstChild.data ) )
	    	item.SetViewCount( int( contentItem.getElementsByTagName("ViewCount")[0].firstChild.data ) )
	    	item.SetContentRating( filterString( contentItem.getElementsByTagName("MaturityRating")[0].firstChild.data ) )
	    	
	    	itemList.append( item )
	    	  
		theList = mc.GetWindow(14000).GetList(100)
		theList.SetItems( itemList )

def fetchGalleries():

	mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fetching gallery list %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	request = urllib2.Request("http://api.break.com/invoke/listgalleries/1/50")	
	
	try:
	    r = urllib2.urlopen(request)
	except urllib2.HTTPError, e:
	    mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Gallery list request failed! " + str(e) + " %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	else:
	    itemList = mc.ListItems()

	    xml = r.read()
	    dom = minidom.parseString( xml )
	    	    
	    contentList = dom.getElementsByTagName( 'Content' )
	    
	    for contentItem in contentList:	    
	    	item = mc.ListItem( mc.ListItem.MEDIA_PICTURE )
	    	
	    	item.SetProperty( "contentID", filterString( contentItem.getElementsByTagName('ContentID')[0].firstChild.data ) )
	    	item.SetLabel( filterString( contentItem.getElementsByTagName("ContentTitle")[0].firstChild.data ) )
	    	item.SetDescription( filterString( contentItem.getElementsByTagName("ContentDescription")[0].firstChild.data ) )
	    	item.SetThumbnail( filterString( contentItem.getElementsByTagName("ContentStaticURL")[0].firstChild.data ) )
	    	item.SetPath( "" )
	    	
	    	itemList.append( item )
	    	  
		theList = mc.GetWindow(14000).GetList(100)
		theList.SetItems( itemList )
	    
def fetchChannel(channelID):

	mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fetching channel... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	request = urllib2.Request("http://api.break.com/invoke/channel/" + channelID + "/1/50/PG/")
	
	try:
	    r = urllib2.urlopen(request)
	except urllib2.HTTPError, e:
	    mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Channel request failed! " + str(e) + " %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	else:
	    itemList = mc.ListItems()

	    xml = r.read()
	    dom = minidom.parseString( xml )
	    
	    contentList = dom.getElementsByTagName( 'Content' )
	    
	    for contentItem in contentList:	    
	    	item = mc.ListItem( mc.ListItem.MEDIA_VIDEO_CLIP )
	    	
	    	item.SetProperty( "contentID", filterString( contentItem.getElementsByTagName('ContentID')[0].firstChild.data ) )
	    	item.SetLabel( filterString( contentItem.getElementsByTagName("ContentTitle")[0].firstChild.data ) )
	    	item.SetDescription( filterString( contentItem.getElementsByTagName("ContentDescription")[0].firstChild.data ) )	    	
	    	item.SetThumbnail( filterString( contentItem.getElementsByTagName("ThumbNailURL")[0].firstChild.data ) )
	    	item.SetPath( filterString( contentItem.getElementsByTagName("ContentStaticURL")[0].firstChild.data ) )
	    	item.SetDuration( int( contentItem.getElementsByTagName("RunLength")[0].firstChild.data ) )
	    	item.SetViewCount( int( contentItem.getElementsByTagName("ViewCount")[0].firstChild.data ) )
	    	item.SetContentRating( filterString( contentItem.getElementsByTagName("MaturityRating")[0].firstChild.data ) )

	    	itemList.append( item )
	        	        
		theList = mc.GetWindow(14000).GetList(100)
		theList.SetItems( itemList )
	    
def fetchGallery(galleryID):

	mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fetching gallery - " + galleryID + " %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	request = urllib2.Request("http://api.break.com/invoke/gallery/" + galleryID + "/1/100/")
	
	try:
	    r = urllib2.urlopen(request)
	except urllib2.HTTPError, e:
	    mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Channel request failed! " + str(e) + " %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	else:
	    itemList = mc.ListItems()

	    xml = r.read()
	    dom = minidom.parseString( xml )
	    
	    header = dom.getElementsByTagName( 'ContentCollection' )
	    countNode = header[0].attributes["TotalCount"]
	    theCount = filterString( countNode.value )
	    
	    mc.LogInfo( "Total items: " + theCount )
	    
	    contentList = dom.getElementsByTagName( 'Content' )
	    
	    imageIndex = 1
	    
	    for contentItem in contentList:	    
	    	item = mc.ListItem( mc.ListItem.MEDIA_PICTURE )
	    	
	    	item.SetProperty( "contentID", filterString( contentItem.getElementsByTagName('ContentID')[0].firstChild.data ) )
	    	item.SetLabel( filterString( contentItem.getElementsByTagName("ContentTitle")[0].firstChild.data ) )
	    	item.SetPath( filterString( contentItem.getElementsByTagName("ContentStaticURL")[0].firstChild.data ) )
	    	item.SetAuthor( str( imageIndex ) )
	    	item.SetDescription( theCount )
	    	
	    	itemList.append( item )
	    	
	    	imageIndex += 1
	        	        
		theList = mc.GetWindow(14001).GetList(101)
		theList.SetItems( itemList )

def fetchForSearch(searchTerm):

	mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Fetching homepage... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	request = urllib2.Request("http://api.break.com/invoke/search/" + searchTerm + "/1/50")	
	
	try:
	    r = urllib2.urlopen(request)
	except urllib2.HTTPError, e:
	    mc.LogInfo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Homepage request failed! " + str(e) + " %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
	else:
	    itemList = mc.ListItems()

	    xml = r.read()
	    dom = minidom.parseString( xml )
	    
	    contentList = dom.getElementsByTagName( 'Content' )
	    
	    for contentItem in contentList:	    
	    	item = mc.ListItem( mc.ListItem.MEDIA_VIDEO_CLIP )
	    	
	    	item.SetProperty( "contentID", filterString( contentItem.getElementsByTagName('ContentID')[0].firstChild.data ) )
	    	item.SetLabel( filterString( contentItem.getElementsByTagName("ContentTitle")[0].firstChild.data ) )
	    	item.SetDescription( filterString( contentItem.getElementsByTagName("ContentDescription")[0].firstChild.data ) )
	    	item.SetThumbnail( filterString( contentItem.getElementsByTagName("ThumbNailURL")[0].firstChild.data ) )
	    	item.SetPath( filterString( contentItem.getElementsByTagName("SourceVideo")[0].firstChild.data ) )
	    	item.SetDirector( filterString( contentItem.getElementsByTagName("Submitter")[0].firstChild.data ) )
	    	item.SetDuration( int( contentItem.getElementsByTagName("RunLength")[0].firstChild.data ) )
	    	item.SetViewCount( int( contentItem.getElementsByTagName("ViewCount")[0].firstChild.data ) )
	    	item.SetContentRating( filterString( contentItem.getElementsByTagName("MaturityRating")[0].firstChild.data ) )
	    	
	    	itemList.append( item )
	    	  
		theList = mc.GetWindow(14000).GetList(102)
		theList.SetItems( itemList )
		
def playFocusedItem(windowID,listID):

	player = mc.GetPlayer()
	theList = mc.GetWindow(windowID).GetList(listID)
	index = theList.GetFocusedItem()
	theItems = theList.GetItems()
	focusedItem = theList.GetItem(index)
	player.Play(focusedItem)
	
	trackAnalyticsEvent("VideoPlay")

def uuid():
  """
    Generates a universally unique ID.
    Any arguments only create more randomness.
  """
  t = long( time.time() * 1000 )
  r = long( random.random()*100000000000000000L )
  try:
    a = socket.gethostbyname( socket.gethostname() )
  except:
    # if we can't get a network address, just imagine one
    a = random.random()*100000000000000000L
  data = str(t)+' '+str(r)+' '+str(a)
  data = md5.md5(data).hexdigest()
  return data
	
def getUniqueID():

	config = mc.GetApp().GetLocalConfig()
	unique = config.GetValue( "uniqueID" )
	
	if not unique:
		
		unique = uuid()
		config.SetValue( "uniqueID", unique )
	
	return unique
	
def trackAnalyticsEvent(eventName):

	unique = getUniqueID()	
	trackURL = "http://stats.break.com/invoke.gif?type=PlatformAnalytics&deviceid=Boxee&userid=" + unique + "&event=" + eventName	
	urllib.urlopen(trackURL)
	
	# mc.ShowDialogOk("Analytics", trackURL)
					