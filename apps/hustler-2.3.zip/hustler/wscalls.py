#   Content:
#
#   WSInitLogin
#   WSGetFrontPage
#   WSGetMovieList
#   WSGetUserMovieList
#   WSGetItemList
#   WSGetMovieDetail
#   WSAction
#   WSUserAction
#   WSPay
#   WSGetSubscriptionDetail
#   WSGetSubscriptionStatus
#   WSPlayHeartbeat

import mc
from xml.dom import minidom
import urllib
import simplejson as json
import random

# VIEWSTER Librarys
import utilities
import frontPage
import movieDetails
import favorites
import options


PATH_WS = "http://hustler.viewster.tv/ws/viewster.asmx/";


#
# InitLogin Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSInitLogin(userEmail, password, translation, rememberMeControlID):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sUserEmail = urllib.quote(userEmail)
    sPassword = urllib.quote(password)
    sDeviceInfo = "devman:boxee|devtype:STB"
    bGetGUITr = translation
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sUserEmail=" + sUserEmail + "&sPassword=" + sPassword + "&sDeviceInfo=" + sDeviceInfo + "&bGetGUITr=" + bGetGUITr + "&sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "InitLogin"
    data = http.Post(path, params)
    
    #mc.HideDialogWait()
    
    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    # get previous countryCode
    countryCode = config.GetValue("countryCode")
    
    # save app language & countryCode & operationMode
    config.SetValue("language", str(dataXML.getElementsByTagName("sLanguage")[0].firstChild.nodeValue))
    config.SetValue("countryCode", str(dataXML.getElementsByTagName("sCountryCode")[0].firstChild.nodeValue))
    
    config.SetValue("operationMode", str(dataXML.getElementsByTagName("op")[0].firstChild.nodeValue))
    if(config.GetValue("operationMode") == "1"):
        config.SetValue("subscription_status", "t")
    
    # save SVOD value
    try:
        config.SetValue("init_svod", str(dataXML.getElementsByTagName("SVOD")[0].firstChild.nodeValue))
    except:
        config.SetValue("init_svod", "f")
    
    if (responseStatus.find("ok") != -1):
        
        # get subscription detail (subscription price & currency) at every successful initLogin call
        WSGetSubscriptionDetail()
        
        
        # GUI text translations requested
        if(bGetGUITr == "true"):
            
            # save locally the GUI XML
            tempDir = mc.GetTempDir()
            
            if(utilities.isViewster()):
                location = str(tempDir + "/viewster_v2_widget_gui.xml")
            elif(utilities.isHustler()):
                location = str(tempDir + "/hustler_v2_widget_gui.xml")
            
            #urllib.urlretrieve(PATH_WS + "InitLogin?" + params, location)
            
            f = open(location, "w")
            f.write(data)
            f.close()
            
            # first initLogin on app start
            if(config.GetValue("frontPageLoaded") != "already"):
                
                # get front page
                if(utilities.isViewster()):
                    WSGetFrontPage()
                
                # get subscription & voucher status
                if(config.GetValue("authenticatedUser") == "True"):
                    WSGetSubscriptionStatus("all")
                    WSUserAction(userEmail, password, "voucherget")
        
        
        # login
        else:
            widgetGuiXML = utilities.loadGuiXML()
            
            config.SetValue("authenticatedUser", "True")
            config.SetValue("emailAddress", userEmail)
            config.SetValue("password", password)
            
            checkBoxImg = mc.GetActiveWindow().GetList(rememberMeControlID).GetItem(0).GetProperty("checkBoxImg")
            if((utilities.isViewster() and checkBoxImg == "checkBox_active.png") or (utilities.isHustler() and checkBoxImg == "h_checkBox_active.png")):
                config.SetValue("rememberMe", "True")
            else:
                config.SetValue("rememberMe", "False")
            
            WSUserAction(userEmail, password, "voucherget")
            
            # options-login / favorites-login / options-myMovies / options-subscribe
            if(rememberMeControlID == 1309 or rememberMeControlID == 1910):
                
                txt_login_success = utilities.getGuiTagContent(widgetGuiXML, "txt_login_success")
                mc.ShowDialogOk(appName, txt_login_success)
                
                WSGetSubscriptionStatus("all")
                
                #if(rememberMeControlID == 1309):
                loginMaskType = mc.GetActiveWindow().GetList(1315).GetItem(0).GetProperty("loginMaskType")
               
                #elif(rememberMeControlID == 1910):
                #    loginMaskType = "registerAccount"
                
                if(loginMaskType == "Favorites"):
                    config.SetValue("previousScreenContent", "grid")
                    favorites.loadFavoritesContent()
                
                elif(loginMaskType == "MyMovies"):
                    config.SetValue("previousScreenContent", "grid")
                    if(utilities.isViewster()):
                        options.optionsItemOnClick(4)
                    elif(utilities.isHustler()):
                        options.optionsItemOnClick(3)
                
                elif(loginMaskType == "Subscribe"):
                    
                    ## countryCode not changed
                    #if(countryCode == config.GetValue("countryCode")):
                    #    price = config.GetValue("subscription_price")
                    #    currency = config.GetValue("subscription_currency")
                    #    WSPay("subscribe", "web", "", price, currency)
                    ## countryCode CHANGED
                    #else:
                        ## display the new price currency / availability for subscription
                        #price = config.GetValue("subscription_price")
                        #currency = config.GetValue("subscription_currency")
                        #txt_subscription_availability = utilities.getGuiTagContent(widgetGuiXML, "txt_subscription_availability")
                        #txt_subscribe_info = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe_info").replace("|br|", "\n").replace("|PRICE|", price).replace("|CURRENCY|", currency).replace("|AVAILABILITY|", txt_subscription_availability)
                        #mc.GetActiveWindow().GetList(1316).GetItem(0).SetLabel(txt_subscribe_info)
                        
                        ## display popup: price may have changed..
                        #txt_review_content = utilities.getGuiTagContent(widgetGuiXML, "txt_review_content")
                        #mc.ShowDialogOk(appName, txt_review_content)
                    
                    mc.GetActiveWindow().GetControl(1300).SetVisible(False)
                    mc.GetActiveWindow().GetControl(1900).SetVisible(False)
                    
                    options.loadPaymentConfirmation("subscribe")
                
                elif(loginMaskType == "MyVoucher"):
                    mc.GetActiveWindow().GetControl(1300).SetVisible(False)
                    mc.GetActiveWindow().GetControl(1900).SetVisible(False)
                    
                    options.loadMyVoucherContent()
                
                elif(loginMaskType == "info"):
                    mc.GetActiveWindow().GetControl(1900).SetVisible(False)
                    mc.GetActiveWindow().PopState(False)
                    options.loadHelpContent()
            
            
            # movie details/login
            elif(rememberMeControlID == 549 or rememberMeControlID == 581):
                txt_login_success = utilities.getGuiTagContent(widgetGuiXML, "txt_login_success")
                mc.ShowDialogOk(appName, txt_login_success)
                
                #if(rememberMeControlID == 549):
                loginMaskType = mc.GetActiveWindow().GetList(556).GetItem(0).GetProperty("loginMaskType")
                #elif(rememberMeControlID == 581):
                #    loginMaskType = "registerAccount"
                
                movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
                WSGetSubscriptionStatus(movieID)
                WSUserAction(config.GetValue("emailAddress"), config.GetValue("password"), "favg:" + movieID)
                movieDetails.setFavoriteButtonLabel(config.GetValue("movieFavoriteStatus"))
                if(mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("svod") == "t"):
                    mdButtonIndex = movieDetails.getMDButtonIndex("subscribe")
                    movieDetails.tryToGrayOutMDButton(mdButtonIndex, "subscribe")
                
                # countryCode not changed
                if(countryCode == config.GetValue("countryCode")):
                    
                    if(loginMaskType == "payAndWatch"):
                        watchButtonIndex = mc.GetActiveWindow().GetList(534).GetFocusedItem()
                        focusedWatchButtonType = mc.GetActiveWindow().GetList(534).GetItem(watchButtonIndex).GetProperty("buttonType")
                        
                        # rent - already rented movie
                        inSubscription = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("inSubscription")
                        if(focusedWatchButtonType == "rent" and ((config.GetValue("movie_subscription_status") == "t") or (config.GetValue("subscription_status") == "t" and inSubscription == "t"))):
                            price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
                            currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
                            WSPay("movierent", "web", movieID, price, currency)
                        
                        # subscribe - already subscribed
                        elif(focusedWatchButtonType == "subscribe" and config.GetValue("subscription_status") == "t"):
                            txt_already_subscribed = utilities.getGuiTagContent(widgetGuiXML, "txt_already_subscribed").replace("|br||br|"," ")#.replace("|br||br|","\n")
                            mc.ShowDialogOk(appName, txt_already_subscribed)
                            movieDetails.closeMDPopup("watchMovie", True)
                        
                        # payment confirmation
                        else:
                            # hide current popup content
                            movieDetails.hideLoginPopup()
                            movieDetails.hideRegisterPopup()
                            
                            # display payment confirmation popup
                            movieDetails.loadPaymentConfirmationPopup(False)
                    
                    elif(loginMaskType == "subscribe"):
                        # if not subscribed
                        if(config.GetValue("subscription_status") == "f"):
                            # hide login popup content
                            movieDetails.hideLoginPopup()
                            movieDetails.hideRegisterPopup()
                            
                            # display payment confirmation popup
                            movieDetails.loadPaymentConfirmationPopup(True)
                        # already subscribed
                        elif(config.GetValue("subscription_status") == "t"):
                            txt_already_subscribed = utilities.getGuiTagContent(widgetGuiXML, "txt_already_subscribed").replace("|br||br|"," ")#.replace("|br||br|","\n")
                            mc.ShowDialogOk(appName, txt_already_subscribed)
                            
                            movieDetails.closeMDPopup("subscribe", True)
                    
                    elif(loginMaskType == "favorites"):
                        # hide login popup content
                        movieDetails.hideLoginPopup()
                        movieDetails.hideRegisterPopup()
                        
                        movieDetails.loadAddRemoveFavoritePopupContent()
                
                # countryCode CHANGED
                else:
                    if(loginMaskType == "payAndWatch"):
                        # get movie detail
                        md_json_object = WSGetMovieDetail(movieID)
                        # movie in feed => display popup: price may have changed..
                        if(str(md_json_object["data"]["pr"]["p"]) != "-1"):
                            # update price values in main.xml & display the new values in Pay & Watch popup
                            movieDetails.updatePriceValues(md_json_object)
                            
                            watchButtonIndex = mc.GetActiveWindow().GetList(534).GetFocusedItem()
                            focusedWatchButtonType = mc.GetActiveWindow().GetList(534).GetItem(watchButtonIndex).GetProperty("buttonType")
                            
                            # rent - already rented movie
                            inSubscription = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("inSubscription")
                            if(focusedWatchButtonType == "rent" and ((config.GetValue("movie_subscription_status") == "t") or (config.GetValue("subscription_status") == "t" and inSubscription == "t"))):
                                price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
                                currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
                                WSPay("movierent", "web", movieID, price, currency)
                            
                            # subscribe - already subscribed
                            elif(focusedWatchButtonType == "subscribe" and config.GetValue("subscription_status") == "t"):
                                txt_already_subscribed = utilities.getGuiTagContent(widgetGuiXML, "txt_already_subscribed").replace("|br||br|"," ")#.replace("|br||br|","\n")
                                mc.ShowDialogOk(appName, txt_already_subscribed)
                                movieDetails.closeMDPopup("watchMovie", True)
                            
                            else:
                                txt_review_content = utilities.getGuiTagContent(widgetGuiXML, "txt_review_content")
                                mc.ShowDialogOk(appName, txt_review_content)
                                
                                # hide current popup content
                                movieDetails.hideLoginPopup()
                                movieDetails.hideRegisterPopup()
                                
                                # display payment confirmation popup
                                movieDetails.loadPaymentConfirmationPopup(False)
                        # movie not in feed => display explanatory popup
                        else:
                            txt_movie_not_available = utilities.getGuiTagContent(widgetGuiXML, "txt_movie_not_available")
                            mc.ShowDialogOk(appName, txt_movie_not_available)
                    
                    elif(loginMaskType == "subscribe"):
                        # if not subscribed
                        if(config.GetValue("subscription_status") == "f"):
                            # hide current popup content
                            movieDetails.hideLoginPopup()
                            movieDetails.hideRegisterPopup()
                            
                            movieDetails.loadPaymentConfirmationPopup(True)
                        # already subscribed
                        elif(config.GetValue("subscription_status") == "t"):
                            txt_already_subscribed = utilities.getGuiTagContent(widgetGuiXML, "txt_already_subscribed").replace("|br||br|"," ")#.replace("|br||br|","\n")
                            mc.ShowDialogOk(appName, txt_already_subscribed)
                            
                            movieDetails.closeMDPopup("subscribe", True)
                    
                    elif(loginMaskType == "favorites"):
                        # get movie detail
                        md_json_object = WSGetMovieDetail(movieID)
                        # movie not in feed => display explanatory popup
                        if(str(md_json_object["data"]["pr"]["p"]) == "-1"):
                            txt_movie_not_available = utilities.getGuiTagContent(widgetGuiXML, "txt_movie_not_available")
                            mc.ShowDialogOk(appName, txt_movie_not_available)
                        else:
                            movieDetails.hideLoginPopup()
                            movieDetails.hideRegisterPopup()
                            
                            movieDetails.loadAddRemoveFavoritePopupContent()
                    
                    #elif(loginMaskType == "registerAccount"):
                    #    # get movie detail
                    #    md_json_object = WSGetMovieDetail(movieID)
                    #    # movie not in feed => display explanatory popup
                    #    if(str(md_json_object["data"]["pr"]["p"]) == "-1"):
                    #        txt_movie_not_available = utilities.getGuiTagContent(widgetGuiXML, "txt_movie_not_available")
                    #        mc.ShowDialogOk(appName, txt_movie_not_available)
        
        #if(config.GetValue("authenticatedUser") == "True"):
        #    WSUserAction(userEmail, password, "voucherget")
        
        return True
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        if (responseStatus.find("INVALID_LOGIN") != -1):
            config.SetValue("rememberMe", "False")
            config.SetValue("authenticatedUser", "False")
            config.SetValue("emailAddress", "")
            config.SetValue("password", "")
            
            # GUI text translations requested
            if(bGetGUITr == "true"):
                
                # save locally the GUI XML
                tempDir = mc.GetTempDir()
                
                if(utilities.isViewster()):
                    location = str(tempDir + "/viewster_v2_widget_gui.xml")
                elif(utilities.isHustler()):
                    location = str(tempDir + "/hustler_v2_widget_gui.xml")
                
                #urllib.urlretrieve(PATH_WS + "InitLogin?" + params, location)
                
                f = open(location, "w")
                f.write(data)
                f.close()
                
                # first initLogin on app start
                if(config.GetValue("frontPageLoaded") != "already"):
                    
                    # get front page
                    if(utilities.isViewster()):
                        WSGetFrontPage()
        
        return False


#
# GetFrontPage Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSGetFrontPage():
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "GetFrontPage"
    data = http.Post(path, params)
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        frontPage.loadFrontPage(json_object)
        
        return True
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        return False


#
# GetMovieList Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSGetMovieList(criteria, offsetRow, maxRow):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    config.SetValue("callBackRecieved", "False")
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    if(config.GetValue("activePC") == "True" and config.GetValue("confirmed_pc_pin") == "False"):
        pc_filter = config.GetValue("pc_filter")
        criteria = criteria + "|pc:" + pc_filter
    
    sCriteria = urllib.quote(criteria)
    sDeviceInfo = "devman:boxee|devtype:STB"
    sFormat = "json"
    sOffsetRow = offsetRow
    sMaxRow = maxRow
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sCriteria=" + sCriteria + "&sDeviceInfo=" + sDeviceInfo + "&sFormat=" + sFormat + "&sOffsetRow=" + sOffsetRow + "&sMaxRow=" + sMaxRow + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "GetMovieList"
    data = http.Post(path, params)
    
    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    #mc.HideDialogWait()
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        
        # save the total no of movies
        if(offsetRow == "0"):
            mc.GetActiveWindow().GetList(404).GetItem(0).SetLabel(str(json_object["data"]["t"]))
        
        config.SetValue("callBackRecieved", "True")
        
        return json_object
        
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        config.SetValue("callBackRecieved", "True")
        
        return False
    

#
# GetUserMovieList Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSGetUserMovieList(criteria, offsetRow, maxRow):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    config.SetValue("callBackRecieved", "False")
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    if(config.GetValue("activePC") == "True" and config.GetValue("confirmed_pc_pin") == "False"):
        pc_filter = config.GetValue("pc_filter")
        criteria = criteria + "|pc:" + pc_filter
    
    sUserEmail = urllib.quote(config.GetValue("emailAddress"))
    sPassword = urllib.quote(config.GetValue("password"))
    sCriteria = criteria
    sDeviceInfo = "devman:boxee|devtype:STB"
    sFormat = "json"
    sOffsetRow = offsetRow
    sMaxRow = maxRow
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sUserEmail=" + sUserEmail + "&sPassword=" + sPassword + "&sCriteria=" + sCriteria + "&sDeviceInfo=" + sDeviceInfo + "&sFormat=" + sFormat + "&sOffsetRow=" + sOffsetRow + "&sMaxRow=" + sMaxRow + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "GetUserMovieList"
    data = http.Post(path, params)
    
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        
        # save the total no of movies
        if(offsetRow == "0"):
            if(sCriteria[:3] == "fav"):
                #mc.GetActiveWindow().GetLabel(602).SetLabel(str(json_object["data"]["t"]))
                mc.GetActiveWindow().GetList(602).GetItem(0).SetLabel(str(json_object["data"]["t"]))
            elif(sCriteria[:2] == "my"):
                mc.GetActiveWindow().GetList(404).GetItem(0).SetLabel(str(json_object["data"]["t"]))
        
        config.SetValue("callBackRecieved", "True")
        
        return json_object
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        if (responseStatus.find("INVALID_LOGIN") != -1):
            config.SetValue("rememberMe", "False")
            config.SetValue("authenticatedUser", "False")
            config.SetValue("emailAddress", "")
            config.SetValue("password", "")
        
        config.SetValue("callBackRecieved", "True")
        
        return False


#
# GetItemList Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSGetItemList(criteria, offsetRow, maxRow):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    config.SetValue("callBackRecieved", "False")
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    if(config.GetValue("activePC") == "True" and config.GetValue("confirmed_pc_pin") == "False"):
        pc_filter = config.GetValue("pc_filter")
        criteria = criteria + "|pc:" + pc_filter
    
    sCriteria = criteria
    sDeviceInfo = "devman:boxee|devtype:STB"
    sFormat = "json"
    sOffsetRow = offsetRow
    sMaxRow = maxRow
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sCriteria=" + sCriteria + "&sDeviceInfo=" + sDeviceInfo + "&sFormat=" + sFormat + "&sOffsetRow=" + sOffsetRow + "&sMaxRow=" + sMaxRow + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
   
    path = PATH_WS + "GetItemList"
    data = http.Post(path, params)
    
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        
        # save the total no of items
        if(offsetRow == "0"):
            mc.GetActiveWindow().GetList(404).GetItem(0).SetLabel(str(json_object["data"]["t"]))
        
        config.SetValue("callBackRecieved", "True")
        
        return json_object
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        config.SetValue("callBackRecieved", "True")
        
        return False


#
# GetMovieDetail Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSGetMovieDetail(movieID):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sMovieId = movieID
    sDeviceInfo = "devman:boxee|devtype:STB"
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sMovieId=" + sMovieId + "&sDeviceInfo=" + sDeviceInfo + "&sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "GetMovieDetail"
    data = http.Post(path, params)
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        
        return json_object
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        return False
    

#
# Action Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSAction(action, parameter):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sAction = action
    sParameter = parameter
    sDeviceInfo = "devman:boxee|devtype:STB"
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
   
    params = "sAction=" + sAction + "&sParameter=" + sParameter + "&sDeviceInfo=" + sDeviceInfo + "&sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "Action"
    data = http.Post(path, params)
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        
        if(sAction == "duid"):
            config.SetValue("deviceUniqueID", str(json_object["data"]["duid"]))
        
        elif(sAction == "trailersecurelink"):
            videoLanguage = config.GetValue("videoLanguage")
            videoLanguageList = mc.GetActiveWindow().GetList(509)
            for index in range(len(videoLanguageList.GetItems())):
                if(videoLanguage == videoLanguageList.GetItem(index).GetLabel()):
                    mc.GetActiveWindow().GetList(593).GetItem(index).SetProperty("trailerURL", str(json_object["data"]["trailersecurelink"]))
        #if(sAction == "trailerplay"):
        #    pass
        
        return True
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        return False


#
# User Action Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSUserAction(userEmail, password, criteria):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sUserEmail = urllib.quote(userEmail)
    sPassword = urllib.quote(password)
    sCriteria = criteria
    sDeviceInfo = "devman:boxee|devtype:STB"
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
   
    params = "sUserEmail=" + sUserEmail + "&sPassword=" + sPassword + "&sCriteria=" + sCriteria + "&sDeviceInfo=" + sDeviceInfo + "&sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "UserAction"
    data = http.Post(path, params)
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        
        # forgot account password, forgot parental Pin
        if(sCriteria == "fpwd" or sCriteria[:4] == "fpcp"):
            mc.ShowDialogOk(appName, utilities.cleanString(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        # get favorite status of a movie
        elif(sCriteria[:4] == "favg"):
            favoriteMovieStatus = utilities.cleanString(dataXML.getElementsByTagName("data")[0].getElementsByTagName("fav")[0].firstChild.nodeValue)
            config.SetValue("movieFavoriteStatus", favoriteMovieStatus)
            movieDetails.setFavoriteButtonLabel(favoriteMovieStatus)
        
        # add movie to favorites, remove movie from favorites
        elif(sCriteria[:4] == "fava" or sCriteria[:4] == "favr"):
            if(sCriteria[:4] == "fava"):
                config.SetValue("movieFavoriteStatus", "t")
            else:
                config.SetValue("movieFavoriteStatus", "f")
            # change popup message & md button label
            movieDetails.setFavoriteButtonLabel(config.GetValue("movieFavoriteStatus"))
            movieDetails.setFavoritePopupTextLabel(config.GetValue("movieFavoriteStatus"))
            
            mc.ShowDialogOk(appName, utilities.cleanString(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        # get info on the user voucher
        elif(sCriteria == "voucherget"):
            jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
            jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
            json_object = json.loads(jsonContent)
            
            voucherValidity = str(json_object["data"]["valid"])
            config.SetValue("voucherValidity", voucherValidity)
            
            config.SetValue("availableVoucherCredits", "")
            config.SetValue("remainingVoucherCredits", "")
            config.SetValue("voucherValidityDate", "")
            
            if(voucherValidity == "t"):
                availableVoucherCredits = str(json_object["data"]["va"])
                config.SetValue("availableVoucherCredits", availableVoucherCredits)
                remainingVoucherCredits = str(json_object["data"]["vr"])
                config.SetValue("remainingVoucherCredits", remainingVoucherCredits)
                voucherValidityDate = str(json_object["data"]["vd"])
                config.SetValue("voucherValidityDate", voucherValidityDate)
                
        
        # register account
        elif(sCriteria == "registeraccount"):
            if(mc.GetActiveWindow().GetControl(570).IsVisible()):
                WSInitLogin(userEmail, password, "false", 581)
            elif(mc.GetActiveWindow().GetControl(1900).IsVisible()):
                WSInitLogin(userEmail, password, "false", 1910)
        
        # voucherget
        elif(sCriteria[:10] == "voucherset"):
            mc.ShowDialogOk(appName, utilities.cleanString(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
            
            WSUserAction(userEmail, password, "voucherget")
        
        return True
    
    else:
        mc.ShowDialogOk(appName, utilities.cleanString(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        if (responseStatus.find("INVALID_LOGIN") != -1):
            config.SetValue("rememberMe", "False")
            config.SetValue("authenticatedUser", "False")
            config.SetValue("emailAddress", "")
            config.SetValue("password", "")
        
        return False


#
# Pay Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSPay(payAction, payMethod, itemID, itemPrice, itemCurrency):
    #mc.ShowDialogWait()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sUserEmail = urllib.quote(config.GetValue("emailAddress"))
    sPassword = urllib.quote(config.GetValue("password"))
    sAction = payAction
    sPayMethod = payMethod
    sDeviceType = "stb"
    sDeviceManufacturer = "Boxee"
    sDeviceModel = "Boxee Box"
    sDeviceId = config.GetValue("deviceUniqueID")
    sItemId = itemID
    sItemPrice = itemPrice 
    sItemCurrency = itemCurrency
    sVideoLanguage = config.GetValue("videoLanguage")
    sSubtitleLanguage = config.GetValue("subtitleLanguage")
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
   
    params = "sUserEmail=" + sUserEmail + "&sPassword=" + sPassword + "&sAction=" + sAction + "&sPayMethod=" + sPayMethod + "&sDeviceType=" + sDeviceType + "&sDeviceManufacturer=" + sDeviceManufacturer + "&sDeviceModel=" + sDeviceModel + "&sDeviceId=" + sDeviceId + "&sItemId=" + sItemId + "&sItemPrice=" + sItemPrice + "&sItemCurrency=" + sItemCurrency + "&sVideoLanguage=" + sVideoLanguage + "&sSubtitleLanguage=" + sSubtitleLanguage + "&sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage

    path = PATH_WS + "Pay"
    data = http.Post(path, params)
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        
        if((sAction == "movierent") or (sAction == "movievoucher")):
            
            if(sAction == "movievoucher"):
                WSUserAction(config.GetValue("emailAddress"), config.GetValue("password"), "voucherget")
            
            jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
            jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
            json_object = json.loads(jsonContent)
            
            if(payMethod == "adv"):
                if(str(json_object["data"]["avod"]["marketer"]) == "smartclip"):
                    config.SetValue("preRolls", str(json_object["data"]["avod"]["pre"]))
                    config.SetValue("midRolls", str(json_object["data"]["avod"]["mid"]))
                    config.SetValue("postRolls", str(json_object["data"]["avod"]["pos"]))
                    config.SetValue("midRollInterval", str(json_object["data"]["avod"]["midt"]))
                    
                    #adCallPath = str(json_object["data"]["avod"]["adcall"])
                    adCallPath = "http://ad.doubleclick.net/ad/testadvertiser.smartclip/ms;sz=400x320;dcmt=text/xml;ord=[random]?".replace("[random]", str(random.randint(10000000, 99999999)))
                    
                    config.SetValue("adCallPath", adCallPath)
                    GetAd(adCallPath)
            
            movieURL = str(json_object["data"]["vurl"])
            config.SetValue("movieStart", "") 
            config.SetValue("resume_time", str(json_object["data"]["rt"]))
            try:
                resume_time = float(config.GetValue("resume_time"))
            except ValueError:
                resume_time = 0
            
            movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
            txt_movie_rent_success = utilities.getGuiTagContent(widgetGuiXML, "txt_movie_rent_success").replace("|MOVIE_TITLE|", movieTitle).replace("|br|", "\n") 
            mc.ShowDialogOk(appName, txt_movie_rent_success)
            
            if(config.GetValue("authenticatedUser") == "True"):
                WSGetSubscriptionStatus(itemID)
            
            if(resume_time > 0):
                txt_restart_q = utilities.getGuiTagContent(widgetGuiXML, "txt_restart_q")
                txt_restart = utilities.getGuiTagContent(widgetGuiXML, "txt_restart")
                txt_resume = utilities.getGuiTagContent(widgetGuiXML, "txt_resume")
                response = mc.ShowDialogConfirm(appName, txt_restart_q, txt_resume, txt_restart)
                if response:
                    config.SetValue("movieStart", "restart") 
                else:
                    config.SetValue("movieStart", "resume")
            
            movieDetails.playVideo(movieURL, "Movie", payMethod)
        
        elif(sAction == "subscribe"):
            mc.ShowDialogOk(appName, utilities.cleanString(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
            WSGetSubscriptionStatus("all")
        
        return True
     
    else:
        mc.ShowDialogOk(appName, utilities.cleanString(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        if (responseStatus.find("INVALID_LOGIN") != -1):
            config.SetValue("rememberMe", "False")
            config.SetValue("authenticatedUser", "False")
            config.SetValue("emailAddress", "")
            config.SetValue("password", "")
        
        return False



class Ad:
    def __init__(self, ad_XML):
        self.adUrl = str(ad_XML.getElementsByTagName("ad_details")[0].getAttribute('imageUrl'))
        #mc.ShowDialogOk("", str(self.adUrl))
        if(self.adUrl == ""):
            #mc.ShowDialogNotification("!!! hardCoded ad url")
            self.adUrl = "http://cdn1.eyewonder.com/200125/761215/1218993/Kuckuck_baseline.mp4" # !!! for test
        
        self.progressList = []
        self.reportUrlList = []
        self.previousReportPosition = -1
        
        for index in range(ad_XML.getElementsByTagName("agencyTracker").length):
            self.progressList.append(str(ad_XML.getElementsByTagName("agencyTracker").item(index).getAttribute('progress')))
            self.reportUrlList.append(str(ad_XML.getElementsByTagName("agencyTracker").item(index).getAttribute('url')))
        
        if(len(self.progressList) < 3):
            self.progressList = ['0', '0', '0', '20', '40', '60', '80', '100', '0']# !!! for test
            self.reportUrlList = ['http://cdn1.eyewonder.com/200125/761215/1218989/ewtrack.gif?ewadid=90969&ewbust=225808436', 'http://dev.smartclip.net/redirect/302.php', 'http://cdn1.eyewonder.com/200125/EWTRACK_NEW_V?ewadid=90969&ewbust=225808436&eid=1218989&file=video-600.flv&bw=600&vlen=20&per=0&time=0', 'http://cdn1.eyewonder.com/200125/EWTRACK_NEW_V?ewadid=90969&ewbust=225808436&eid=1218989&file=video-600.flv&bw=600&vlen=20&per=20&time=4', 'http://cdn1.eyewonder.com/200125/EWTRACK_NEW_V?ewadid=90969&ewbust=225808436&eid=1218989&file=video-600.flv&bw=600&vlen=20&per=40&time=8', 'http://cdn1.eyewonder.com/200125/EWTRACK_NEW_V?ewadid=90969&ewbust=225808436&eid=1218989&file=video-600.flv&bw=600&vlen=20&per=60&time=12', 'http://cdn1.eyewonder.com/200125/EWTRACK_NEW_V?ewadid=90969&ewbust=225808436&eid=1218989&file=video-600.flv&bw=600&vlen=20&per=80&time=16', 'http://cdn1.eyewonder.com/200125/EWTRACK_NEW_V?ewadid=90969&ewbust=225808436&eid=1218989&file=video-600.flv&bw=600&vlen=20&per=100&time=20', 'http://stats.smartclip.net/stats/beacon?269;11043;400x320;155348;865281;0;1366352694'] # !!! for test
            #mc.ShowDialogNotification("!!! hardCoded ad progressList & reportUrlList")
        self.progressRate = int(self.progressList[3])
    
    def reportAdPlay(self, reportPosition):
        
        def reportCall(reportPos):
            http = mc.Http()
            
            for index in range(len(self.progressList)):
                if(self.progressList[index] == str(reportPos)):
                    path = self.reportUrlList[index]
                    data = http.Get(path)
                    #mc.ShowDialogOk("call", str(reportPos))
            
            return True
        
        def report(reportPosition):
            if(reportPosition == 0):
                if(self.previousReportPosition < reportPosition):
                    self.previousReportPosition = reportPosition
                    reportCall(reportPosition)
                    #mc.ShowDialogOk(str(reportPosition), str(self.previousReportPosition))
            
            else:
                if(self.previousReportPosition < reportPosition and self.previousReportPosition < reportPosition - self.progressRate):
                    report(reportPosition - self.progressRate)
                    report(reportPosition)
                else:
                    if(self.previousReportPosition < reportPosition):
                        self.previousReportPosition = reportPosition
                        reportCall(reportPosition)
        
        if(reportPosition < 100):
            for index in range(100 / self.progressRate):
                if(reportPosition < (index + 1) * self.progressRate):
                    reportPosition = index * self.progressRate
                    break
        else:
            reportPosition = 100
        
        report(reportPosition)
    
    
MyAd = [] #{}


#
# GetAd
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def GetAd(adCallPath):
    config = mc.GetApp().GetLocalConfig()
    
    http = mc.Http()
    path = adCallPath
    #data = http.Post(path, "")
    data = http.Get(path)
    
    dataXML = minidom.parseString(data)
    
    #mc.ShowDialogOk("ad url from smartclip call", str(dataXML.getElementsByTagName("ad_details")[0].getAttribute('imageUrl')))
    #mc.GetWindow(14000).GetLabel(99).SetLabel(str(data))
    
    global MyAd
    #MyAd = Ad(dataXML)
    MyAd.append(Ad(dataXML))
    
    return True


#
# GetSubscriptionDetail Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSGetSubscriptionDetail():
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sDeviceInfo = "devman:boxee|devtype:STB"
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sDeviceInfo=" + sDeviceInfo + "&sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "GetSubscriptionDetail"
    data = http.Post(path, params)
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        
        config.SetValue("subscription_currency", str(json_object["data"]["its"]["it"][0]["c"]))
        config.SetValue("subscription_price", str(json_object["data"]["its"]["it"][0]["p"]))
        
        return True
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        return False


#
# GetSubscriptionStatus Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSGetSubscriptionStatus(itemId):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sUserEmail = urllib.quote(config.GetValue("emailAddress"))
    sPassword = urllib.quote(config.GetValue("password"))
    sItemId = itemId
    sFormat = "json"
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sUserEmail=" + sUserEmail + "&sPassword=" + sPassword + "&sItemId=" + sItemId + "&sFormat=" + sFormat + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "GetSubscriptionStatus"
    data = http.Post(path, params)
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        jsonLength = int(dataXML.getElementsByTagName("data")[0].firstChild.length)
        jsonContent = utilities.cleanString(dataXML.getElementsByTagName("data")[0].firstChild.substringData(0, jsonLength))
        json_object = json.loads(jsonContent)
        
        if(itemId != "all"):
            config.SetValue("movie_subscription_status", str(json_object["data"]["i"]["s"]))
        
        config.SetValue("subscription_status", str(json_object["data"]["s"]["s"]))
        
        return True
    
    else:
        mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        if (responseStatus.find("INVALID_LOGIN") != -1):
            config.SetValue("rememberMe", "False")
            config.SetValue("authenticatedUser", "False")
            config.SetValue("emailAddress", "")
            config.SetValue("password", "")
        
        return False


#
# PlayHeartbeat Call
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def WSPlayHeartbeat(playPosition, displayErrorPopup):
    #mc.ShowDialogWait()
    
    config = mc.GetApp().GetLocalConfig()
    
    appName = config.GetValue("appName")
    
    http = mc.Http()
    
    sUserEmail = urllib.quote(config.GetValue("emailAddress"))
    sPassword = urllib.quote(config.GetValue("password"))
    sMovieId = config.GetValue("playMovieID")
    sVideoLanguage = config.GetValue("videoLanguage")
    sPlayPosition = playPosition
    sDeviceManufacturer = "Boxee"
    sDeviceType = "stb"
    sDeviceId = config.GetValue("deviceUniqueID")
    sCountryCode = config.GetValue("countryCode")
    sLanguage = config.GetValue("language")
    
    params = "sUserEmail=" + sUserEmail + "&sPassword=" + sPassword + "&sMovieId=" + sMovieId + "&sVideoLanguage=" + sVideoLanguage + "&sPlayPosition=" + sPlayPosition + "&sDeviceManufacturer=" + sDeviceManufacturer + "&sDeviceType=" + sDeviceType + "&sDeviceId=" + sDeviceId + "&sCountryCode=" + sCountryCode + "&sLanguage=" + sLanguage
    
    path = PATH_WS + "PlayHeartbeat"
    data = http.Post(path, params)
    
    #mc.HideDialogWait()

    dataXML = minidom.parseString(data)
    responseStatus = dataXML.getElementsByTagName("status")[0].firstChild.nodeValue
    
    if (responseStatus.find("ok") != -1):
        config.SetValue("stopMovie", "False")
        
        return True
    
    else:
        if(displayErrorPopup == "True"):
            config.SetValue("stopMovie", "True")
            mc.ShowDialogOk(appName, str(dataXML.getElementsByTagName("message")[0].firstChild.nodeValue))
        
        if (responseStatus.find("INVALID_LOGIN") != -1):
            config.SetValue("rememberMe", "False")
            config.SetValue("authenticatedUser", "False")
            config.SetValue("emailAddress", "")
            config.SetValue("password", "")
        
        return False