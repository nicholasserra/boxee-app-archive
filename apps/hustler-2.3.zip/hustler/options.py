import mc

# VIEWSTER Librarys
import utilities
import wscalls
import menu
import grid


#
# OPTIONS ITEM   - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def optionsItemOnClick(optionsItemIndex):
    config = mc.GetApp().GetLocalConfig()
    
    config.SetValue("previousScreenContent", "grid")
    
    
    # HELP
    if(optionsItemIndex == 0):
        utilities.hideAllContent()
        loadHelpContent()
    
    
    # LANGUAGE
    elif(optionsItemIndex == 1):
        utilities.hideAllContent()
        loadLanguageContent()
    
    
    # LOGIN
    elif(optionsItemIndex == 2):
        utilities.hideAllContent()
        loadLoginContent("Login")
    
    
    # PARENTAL CONTROL (VIEWSTER APP) / MY MOVIES (HUSTLER APP)
    elif(optionsItemIndex == 3):
        if(utilities.isViewster()):
            if(config.GetValue("activePC") == "True"):
                loadInputPopup("pin_options")
            else:
                utilities.hideAllContent()
                loadParentalControlContent()
        elif(utilities.isHustler()):
            utilities.hideAllContent()
            
            authenticatedUser = config.GetValue("authenticatedUser")
            if(authenticatedUser == "True"):
                # hide login mask
                mc.GetActiveWindow().GetControl(1300).SetVisible(False)
                config.SetValue("currentMovieListContent", "MyMovies")
                grid.loadMovieGrid("my", "0", "18")
            else:
                loadLoginContent("MyMovies")
    
    
    # MY MOVIES (VIEWSTER APP) / SUBSCRIBE/INFO (HUSTLER APP)
    elif(optionsItemIndex == 4):
        if(utilities.isViewster()):
            utilities.hideAllContent()
            
            authenticatedUser = config.GetValue("authenticatedUser")
            if(authenticatedUser == "True"):
                ## hide login mask
                #mc.GetActiveWindow().GetControl(1300).SetVisible(False)
                config.SetValue("currentMovieListContent", "MyMovies")
                grid.loadMovieGrid("my", "0", "18")
            else:
                loadLoginContent("MyMovies")
        
        elif(utilities.isHustler()):
            utilities.hideAllContent()
            
            if(config.GetValue("init_svod") == "t"):
                if(config.GetValue("authenticatedUser") == "False"):
                    loadLoginContent("Subscribe")
                else:
                    loadPaymentConfirmation("subscribe")
            else:
                loadInfoContent()
        
    
    
    # SUBSCRIBE/INFO (VIEWSTER APP) / INFO/MY VOUCHER (HUSTLER APP)
    elif(optionsItemIndex == 5):
        
        if(utilities.isViewster()):
            utilities.hideAllContent()
            
            if(config.GetValue("init_svod") == "t"):
                if(config.GetValue("authenticatedUser") == "False"):
                    loadLoginContent("Subscribe")
                else:
                    loadPaymentConfirmation("subscribe")
            else:
                loadInfoContent()
        
        elif(utilities.isHustler()):
            utilities.hideAllContent()
            
            if(config.GetValue("init_svod") == "t"):
                loadInfoContent()
            else:
                if(config.GetValue("authenticatedUser") == "True"):
                    loadMyVoucherContent()
                else:
                    loadLoginContent("MyVoucher")
    
    
    # INFO/MY VOUCHER (VIEWSTER APP)
    elif(optionsItemIndex == 6):
        
        if(utilities.isViewster()):
            utilities.hideAllContent()
            
            if(config.GetValue("init_svod") == "t"):
                loadInfoContent()
            else:
                if(config.GetValue("authenticatedUser") == "True"):
                    loadMyVoucherContent()
                else:
                    loadLoginContent("MyVoucher")
        
        elif(utilities.isHustler()):
            if(config.GetValue("init_svod") == "t"):
                utilities.hideAllContent()
                
                if(config.GetValue("authenticatedUser") == "True"):
                    loadMyVoucherContent()
                else:
                    loadLoginContent("MyVoucher")
            
    
    # MY VOUCHER (VIEWSTER APP)
    elif(optionsItemIndex == 7):
        if(utilities.isViewster()):
            utilities.hideAllContent()
            
            if(config.GetValue("authenticatedUser") == "True"):        
                loadMyVoucherContent()
            else:
                loadLoginContent("MyVoucher")
    
    return True


#
# LOAD HELP CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadHelpContent():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # 1.
    no_1 = "1."
    no_1_List = mc.ListItems()
    for index in range(1):
        no_1_Item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        no_1_Item.SetLabel(no_1)
        no_1_List.append(no_1_Item)
    mc.GetActiveWindow().GetList(1103).SetItems(no_1_List)
    
    # First step - First label
    txt_h1 = utilities.getGuiTagContent(widgetGuiXML, "txt_help_s_0")
    firstStep = txt_h1.split("|br|", 1)
    
    if(len(firstStep) != 2):
        firstStep.append("")
    else:
        if(utilities.isViewster()):
            firstStep[1] = firstStep[1].replace("http://www.viewster.com", "[COLOR FFF8AC00]http://www.viewster.com[/COLOR]")
        elif(utilities.isHustler()):
            firstStep[1] = firstStep[1].replace("http://hustler.viewster.tv", "[COLOR FFE13993]http://hustler.viewster.tv[/COLOR]")
    
    if(firstStep[1].find("|button|") != -1):
        firstStep[1] = firstStep[1].replace("|button|", "")
        mc.GetActiveWindow().GetControl(1107).SetVisible(True)
    else:
        mc.GetActiveWindow().GetControl(1107).SetVisible(False)
    
    firstStep_1_List = mc.ListItems()
    for index in range(1):
        firstStep_1_Item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        firstStep_1_Item.SetLabel(str(firstStep[0]))
        firstStep_1_List.append(firstStep_1_Item)
    mc.GetActiveWindow().GetList(1105).SetItems(firstStep_1_List)
    
    # Create Account Button
    txt_create_acount = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount")
    createAcountButtonsList = mc.ListItems()
    for index in range(1):
        createAcountButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        createAcountButtonItem.SetLabel(txt_create_acount)
        createAcountButtonsList.append(createAcountButtonItem)
    mc.GetActiveWindow().GetList(1107).SetItems(createAcountButtonsList)
    
    # First step - Second label
    firstStep_2_List = mc.ListItems()
    for index in range(1):
        firstStep_2_Item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        firstStep_2_Item.SetLabel(str(firstStep[1]))
        firstStep_2_List.append(firstStep_2_Item)
    mc.GetActiveWindow().GetList(1108).SetItems(firstStep_2_List)
    
    # Steps
    stepsList = mc.ListItems()
    for index in range(3):
        stepItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        stepItem.SetProperty("stepNo", str(index+2) + ".")
        if(utilities.isViewster()):
            stepText = utilities.getGuiTagContent(widgetGuiXML, "txt_help_s_" + str(index+1)).replace("www.viewster.com", "[COLOR FFF8AC00]www.viewster.com[/COLOR]")
        elif(utilities.isHustler()):
            stepText = utilities.getGuiTagContent(widgetGuiXML, "txt_help_s_" + str(index+1)).replace("hustler.viewster.tv", "[COLOR FFE13993]hustler.viewster.tv[/COLOR]")
        stepItem.SetLabel(stepText)
        stepsList.append(stepItem)
    mc.GetActiveWindow().GetList(1109).SetItems(stepsList)
    
    
    # test for back
    if(utilities.isCleanScreen()):
        ## set focus on option menu button
        #nextlist = mc.GetActiveWindow().GetList(200)
        #nextlist.SetFocus()
        #if(utilities.isViewster()):
        #    nextlist.SetFocusedItem(6)
        #elif(utilities.isHustler()):
        #    nextlist.SetFocusedItem(4)
        
        # set focus on Create account button
        nextlist = mc.GetActiveWindow().GetList(1107)
        nextlist.SetFocus()
        nextlist.SetFocusedItem(0)
        
        mc.GetActiveWindow().GetControl(1100).SetVisible(True)
    
    return True


#
# LOAD LANGUAGE CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadLanguageContent():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # Choose Language Label
    txt_choose_lang = utilities.getGuiTagContent(widgetGuiXML, "txt_choose_lang")
    chooseLangLabelList = mc.ListItems()
    for index in range(1):
        chooseLangLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        chooseLangLabelItem.SetLabel(txt_choose_lang)
        chooseLangLabelList.append(chooseLangLabelItem)
    mc.GetActiveWindow().GetList(1202).SetItems(chooseLangLabelList)
    
    # get available languages
    languagesJsonObject = wscalls.WSGetItemList("l", "0", "18")
    
    # set language list
    txt_language = utilities.getGuiTagContent(widgetGuiXML, "txt_language")
    languageList = mc.ListItems()
    for index in range(len(languagesJsonObject["data"]["its"]["it"])):
        languageItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        
        language = utilities.cleanString(languagesJsonObject["data"]["its"]["it"][index]["t"])
        languageItem.SetLabel(language)
        languageCode = utilities.cleanString(languagesJsonObject["data"]["its"]["it"][index]["i"])
        languageItem.SetProperty("languageCode", languageCode)
        languageItem.SetProperty("breadCrumb", txt_language + " | " + language)
        
        if(languageCode == config.GetValue("language")):
            if(utilities.isViewster()):
                languageItem.SetProperty("checkBoxImg", "checkBox_active.png")
            elif(utilities.isHustler()):
                languageItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
        else:
            languageItem.SetProperty("checkBoxImg", "checkBox.png")
        
        languageList.append(languageItem)
    mc.GetActiveWindow().GetList(1203).SetItems(languageList)
    
    # Apply Button
    txt_apply = utilities.getGuiTagContent(widgetGuiXML, "txt_apply")
    applyButtonsList = mc.ListItems()
    for index in range(1):
        applyButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        applyButtonItem.SetLabel(txt_apply)
        applyButtonItem.SetProperty("breadCrumb", txt_language)
        applyButtonsList.append(applyButtonItem)
    mc.GetActiveWindow().GetList(1204).SetItems(applyButtonsList)
    
    # test for back
    if(utilities.isCleanScreen()):
        # set focus on first language button
        if(config.GetValue("previousScreenContent") == "grid"):
            languagelist = mc.GetActiveWindow().GetList(1203)
            languagelist.SetFocus()
            languagelist.SetFocusedItem(0)
        
        mc.GetActiveWindow().GetControl(1200).SetVisible(True)
    
    return True


#
# LOAD LOGIN CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadLoginContent(loginMaskType):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # Email Address Label
    txt_email_add = utilities.getGuiTagContent(widgetGuiXML, "txt_email_add")
    emailAddressLabelList = mc.ListItems()
    for index in range(1):
        emailAddressLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        emailAddressLabelItem.SetLabel(txt_email_add)
        emailAddressLabelList.append(emailAddressLabelItem)
    mc.GetActiveWindow().GetList(1303).SetItems(emailAddressLabelList)
    
    # Password Label
    txt_pass = utilities.getGuiTagContent(widgetGuiXML, "txt_pass")
    passLabelList = mc.ListItems()
    for index in range(1):
        passLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        passLabelItem.SetLabel(txt_pass)
        passLabelList.append(passLabelItem)
    mc.GetActiveWindow().GetList(1306).SetItems(passLabelList)
    
    # Login/Subscribe Button
    loginButtonsList = mc.ListItems()
    for index in range(1):
        loginButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        txt_login = utilities.getGuiTagContent(widgetGuiXML, "txt_login")
        loginButtonItem.SetLabel(txt_login)
        loginButtonsList.append(loginButtonItem)
    mc.GetActiveWindow().GetList(1308).SetItems(loginButtonsList)
    
    # Remember me Button
    txt_remember = utilities.getGuiTagContent(widgetGuiXML, "txt_remember")
    rememberMeButtonList = mc.ListItems()
    for index in range(1):
        rememberMeButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        rememberMeButtonItem.SetLabel(txt_remember)
        if(config.GetValue("rememberMe") == "False"):
            rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox.png")
        elif(config.GetValue("rememberMe") == "True"):
            if(utilities.isViewster()):
                rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox_active.png")
            elif(utilities.isHustler()):
                rememberMeButtonItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
        rememberMeButtonList.append(rememberMeButtonItem)
    mc.GetActiveWindow().GetList(1309).SetItems(rememberMeButtonList)
    
    # Forgot your password label
    txt_forgot_q = utilities.getGuiTagContent(widgetGuiXML, "txt_forgot_q")
    forgotPassList = mc.ListItems()
    for index in range(1):
        forgotPassItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        forgotPassItem.SetLabel(txt_forgot_q)
        forgotPassList.append(forgotPassItem)
    mc.GetActiveWindow().GetList(1310).SetItems(forgotPassList)
    
    # Don't have an account label
    txt_have_account_q = utilities.getGuiTagContent(widgetGuiXML, "txt_have_account_q")
    haveAccountList = mc.ListItems()
    for index in range(1):
        haveAccountItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        haveAccountItem.SetLabel(txt_have_account_q)
        haveAccountList.append(haveAccountItem)
    mc.GetActiveWindow().GetList(1311).SetItems(haveAccountList)
    
    # Create account Button
    txt_create_acount = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount")
    createButtonsList = mc.ListItems()
    for index in range(1):
        createButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        createButtonItem.SetLabel(txt_create_acount)
        createButtonsList.append(createButtonItem)
    mc.GetActiveWindow().GetList(1312).SetItems(createButtonsList)
    
    # Or create an account at.. label
    txt_create_acount_web = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount_web")
    if(utilities.isViewster()):
        txt_create_acount_web = txt_create_acount_web.replace("www.viewster.com", "[COLOR FFF8AC00]www.viewster.com[/COLOR]")
    elif(utilities.isHustler()):
        txt_create_acount_web = txt_create_acount_web.replace("http://hustler.viewster.tv", "[COLOR FFE13993]http://hustler.viewster.tv[/COLOR]")
    createAccountList = mc.ListItems()
    for index in range(1):
        createAccountItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        createAccountItem.SetLabel(txt_create_acount_web)
        createAccountList.append(createAccountItem)
    mc.GetActiveWindow().GetList(1313).SetItems(createAccountList)
    
    if(config.GetValue("authenticatedUser") == "True"):
        mc.GetActiveWindow().GetEdit(1304).SetText(config.GetValue("emailAddress"))
        mc.GetActiveWindow().GetEdit(1307).SetText(config.GetValue("password"))
        #mc.GetActiveWindow().GetEdit(1313).SetText(config.GetValue("emailAddress"))
    else:
        mc.GetActiveWindow().GetEdit(1304).SetText("")
        mc.GetActiveWindow().GetEdit(1307).SetText("")
        #mc.GetActiveWindow().GetEdit(1313).SetText("")
    
    if(loginMaskType == "Subscribe"):
        breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_sbs_viewster")
    else:
        breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_login")
    
    loginTypeList = mc.ListItems()
    for index in range(1):
        loginTypeItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        loginTypeItem.SetProperty("loginMaskType", loginMaskType)
        loginTypeItem.SetLabel(breadCrumb)
        loginTypeList.append(loginTypeItem)
    mc.GetActiveWindow().GetList(1315).SetItems(loginTypeList)
    
    # test for back
    if(utilities.isCleanScreen()):
        if(config.GetValue("previousScreenContent") == "grid"):
            # set focus on email input
            mc.GetActiveWindow().GetControl(1304).SetFocus()
        
        mc.GetActiveWindow().GetControl(1300).SetVisible(True)
    
    return True


#
# LOAD PAYMENT CONFIRMATION Screen CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadPaymentConfirmation(paymentType):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    alreadySubscribed = False
    
    if(paymentType == "subscribe"):
        if(config.GetValue("subscription_status") == "t"):
            alreadySubscribed = True
        
        if(alreadySubscribed):
            txt_label = utilities.getGuiTagContent(widgetGuiXML, "txt_already_subscribed").replace("|br|", "\n")
            if(utilities.isViewster()):
                txt_label = txt_label.replace("www.viewster.com", "[COLOR FFF8AC00]www.viewster.com[/COLOR]")
            elif(utilities.isHustler()):
                txt_label = txt_label.replace("hustler.viewster.tv", "[COLOR FFE13993]hustler.viewster.tv[/COLOR]")
        else:
            price = config.GetValue("subscription_price")
            currency = config.GetValue("subscription_currency")
            txt_subscription_availability = utilities.getGuiTagContent(widgetGuiXML, "txt_subscription_availability")
            
            txt_subscribe_info = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe_info")
            txt_label = txt_subscribe_info.replace("|br|", "\n").replace("|PRICE|", price).replace("|CURRENCY|", currency).replace("|AVAILABILITY|", txt_subscription_availability)
    
    paymentLabelList = mc.ListItems()
    for index in range(1):
        paymentLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        paymentLabelItem.SetLabel(txt_label)
        paymentLabelList.append(paymentLabelItem)
    mc.GetActiveWindow().GetList(1801).SetItems(paymentLabelList)
    
    if(alreadySubscribed):
        mc.GetActiveWindow().GetControl(1802).SetVisible(False)
        
        # set focus on options menu button
        nextlist = mc.GetActiveWindow().GetList(200)
        nextlist.SetFocus()
        if(utilities.isViewster()):
            nextlist.SetFocusedItem(6)
        elif(utilities.isHustler()):
            nextlist.SetFocusedItem(4)
    
    else:
        # Payment Confirmation button
        if(paymentType == "subscribe"):
            txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
            txt_breadcrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_sbs_viewster")
        
        paymentButtonList = mc.ListItems()
        for index in range(1):
            paymentButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            paymentButtonItem.SetLabel(txt_button)
            paymentButtonItem.SetProperty("buttonType", paymentType)
            paymentButtonItem.SetProperty("breadCrumb", txt_breadcrumb)
            paymentButtonList.append(paymentButtonItem)
        mc.GetActiveWindow().GetList(1802).SetItems(paymentButtonList)
        
        mc.GetActiveWindow().GetControl(1802).SetVisible(True)
        
        # set focus on payment confirmation button
        focusList = mc.GetActiveWindow().GetList(1802)
        focusList.SetFocus()
        focusList.SetFocusedItem(0)
    
    mc.GetActiveWindow().GetControl(1800).SetVisible(True)
    
    return True


#
# LOAD REGISTER Screen CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadRegisterPopup():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # hide login mask
    mc.GetActiveWindow().GetControl(1300).SetVisible(False)
    
    # Email Address Label
    txt_email_add = utilities.getGuiTagContent(widgetGuiXML, "txt_email_add")
    emailAddressLabelList = mc.ListItems()
    for index in range(1):
        emailAddressLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        emailAddressLabelItem.SetLabel(txt_email_add)
        emailAddressLabelList.append(emailAddressLabelItem)
    mc.GetActiveWindow().GetList(1902).SetItems(emailAddressLabelList)
    
    # Password Label
    txt_pass = utilities.getGuiTagContent(widgetGuiXML, "txt_pass")
    passwordLabelList = mc.ListItems()
    for index in range(1):
        passwordLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        passwordLabelItem.SetLabel(txt_pass)
        passwordLabelList.append(passwordLabelItem)
    mc.GetActiveWindow().GetList(1905).SetItems(passwordLabelList)
    
    # Repeat password Label
    txt_retype_pass = utilities.getGuiTagContent(widgetGuiXML, "txt_retype_pass")
    repeatPassLabelList = mc.ListItems()
    for index in range(1):
        repeatPassLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        repeatPassLabelItem.SetLabel(txt_retype_pass)
        repeatPassLabelList.append(repeatPassLabelItem)
    mc.GetActiveWindow().GetList(1908).SetItems(repeatPassLabelList)
    
    # Create Acount Button
    txt_create_acount = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount")
    createAccountList = mc.ListItems()
    for index in range(1):
        createAccountItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        createAccountItem.SetLabel(txt_create_acount)
        createAccountList.append(createAccountItem)
    mc.GetActiveWindow().GetList(1911).SetItems(createAccountList)
    
    # set breadCrumb text
    #txt_create_acount = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount")
    breadCrumbList = mc.ListItems()
    for index in range(1):
        breadCrumbItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        breadCrumbItem.SetLabel(txt_create_acount)
        breadCrumbList.append(breadCrumbItem)
    mc.GetActiveWindow().GetList(1912).SetItems(breadCrumbList)
    
    # Remember me Button
    txt_remember = utilities.getGuiTagContent(widgetGuiXML, "txt_remember")
    rememberMeButtonList = mc.ListItems()
    for index in range(1):
        rememberMeButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        rememberMeButtonItem.SetLabel(txt_remember)
        if(config.GetValue("rememberMe") == "False"):
            rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox.png")
        elif(config.GetValue("rememberMe") == "True"):
            rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox_active.png")
        rememberMeButtonList.append(rememberMeButtonItem)
    mc.GetActiveWindow().GetList(1910).SetItems(rememberMeButtonList)
    
    # set focus on email input
    mc.GetActiveWindow().GetControl(1903).SetFocus()
    
    mc.GetActiveWindow().GetControl(1900).SetVisible(True)
    
    return True







#
# LOAD PARENTAL CONTROL CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadParentalControlContent():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # Current Settings Label
    txt_pc_settings = utilities.getGuiTagContent(widgetGuiXML, "txt_pc_settings")
    currentSettingsList = mc.ListItems()
    for index in range(1):
        currentSettingsLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        currentSettingsLabelItem.SetLabel(txt_pc_settings)
        currentSettingsList.append(currentSettingsLabelItem)
    mc.GetActiveWindow().GetList(1402).SetItems(currentSettingsList)
    
    # Parental Control: status Label
    txt_parental_control = utilities.getGuiTagContent(widgetGuiXML, "txt_parental_control")
    if(config.GetValue("activePC") == "False"):
        status = utilities.getGuiTagContent(widgetGuiXML, "txt_inactive")
    else:
        status = utilities.getGuiTagContent(widgetGuiXML, "txt_active")
    parentalControlStatusList = mc.ListItems()
    for index in range(1):
        parentalControlStatusItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        parentalControlStatusItem.SetLabel(txt_parental_control + ": " + status)
        parentalControlStatusList.append(parentalControlStatusItem)
    mc.GetActiveWindow().GetList(1403).SetItems(parentalControlStatusList)
    
    # Filter: rating filter value
    txt_pc_filter = utilities.getGuiTagContent(widgetGuiXML, "txt_pc_filter")
    filterList = mc.ListItems()
    if(config.GetValue("activePC") == "False"):
        mc.GetActiveWindow().GetControl(1404).SetVisible(False)
        mc.GetActiveWindow().GetControl(1405).SetVisible(False)
        
        for index in range(1):
            filterItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            filterItem.SetLabel("")
            filterList.append(filterItem)
    else:
        mc.GetActiveWindow().GetControl(1404).SetVisible(True)
        mc.GetActiveWindow().GetControl(1405).SetVisible(True)
        
        ratingValue = config.GetValue("pc_filter")
        for index in range(1):
            filterItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            filterItem.SetLabel(txt_pc_filter + ": " + ratingValue)
            filterList.append(filterItem)
    mc.GetActiveWindow().GetList(1404).SetItems(filterList)
    
    # Deactivate Button
    txt_deactivate = utilities.getGuiTagContent(widgetGuiXML, "txt_deactivate")
    deactivateButtonList = mc.ListItems()
    for index in range(1):
        deactivateButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        deactivateButtonItem.SetLabel(txt_deactivate)
        deactivateButtonList.append(deactivateButtonItem)
    mc.GetActiveWindow().GetList(1405).SetItems(deactivateButtonList)
    
    # Steps description Label
    txt_pc_instructions = utilities.getGuiTagContent(widgetGuiXML, "txt_pc_instructions").replace("|br|","\n")
    stepsList = mc.ListItems()
    for index in range(1):
        stepsItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        stepsItem.SetLabel(txt_pc_instructions)
        stepsList.append(stepsItem)
    mc.GetActiveWindow().GetList(1406).SetItems(stepsList)
    
    # 1.
    stepOneList = mc.ListItems()
    for index in range(1):
        stepOneItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        stepOneItem.SetLabel("1.")
        stepOneList.append(stepOneItem)
    mc.GetActiveWindow().GetList(1408).SetItems(stepOneList)
    
    # Set rating filter button
    ratingFilterList = mc.ListItems()
    for index in range(1):
        ratingFilterItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        ratingFilterItem.SetLabel("")
        ratingFilterList.append(ratingFilterItem)
    mc.GetActiveWindow().GetList(1409).SetItems(ratingFilterList)
    
    # Set rating filter Label
    txt_set_filter = utilities.getGuiTagContent(widgetGuiXML, "txt_set_filter")
    setFilterList = mc.ListItems()
    for index in range(1):
        setFilterItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        setFilterItem.SetLabel(txt_set_filter)
        setFilterList.append(setFilterItem)
    mc.GetActiveWindow().GetList(1410).SetItems(setFilterList)
    
    # 2.
    stepTwoList = mc.ListItems()
    for index in range(1):
        stepTwoItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        stepTwoItem.SetLabel("2.")
        stepTwoList.append(stepTwoItem)
    mc.GetActiveWindow().GetList(1412).SetItems(stepTwoList)
    
    mc.GetActiveWindow().GetEdit(1413).SetText("")
    
    # Enter PIN Code Label
    txt_enter_pin = utilities.getGuiTagContent(widgetGuiXML, "txt_enter_pin")
    enterPinList = mc.ListItems()
    for index in range(1):
        enterPinItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        enterPinItem.SetLabel(txt_enter_pin)
        enterPinList.append(enterPinItem)
    mc.GetActiveWindow().GetList(1414).SetItems(enterPinList)
    
    # Activate Button
    txt_activate = utilities.getGuiTagContent(widgetGuiXML, "txt_activate")
    activateButtonList = mc.ListItems()
    for index in range(1):
        activateButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        activateButtonItem.SetLabel(txt_activate)
        activateButtonList.append(activateButtonItem)
    mc.GetActiveWindow().GetList(1415).SetItems(activateButtonList)
    
    # breadCrumb
    txt_parental_control = utilities.getGuiTagContent(widgetGuiXML, "txt_parental_control")
    mc.GetActiveWindow().GetLabel(1416).SetLabel(txt_parental_control)
    
    # test for back
    if(utilities.isCleanScreen()):
        if(config.GetValue("activePC") == "False"):
            nextList = mc.GetActiveWindow().GetList(1409)
            nextList.SetFocus()
            nextList.SetFocusedItem(0)
        else:
            nextList = mc.GetActiveWindow().GetList(1405)
            nextList.SetFocus()
            nextList.SetFocusedItem(0)
        
        mc.GetActiveWindow().GetControl(1400).SetVisible(True)
    
    return True


#
# LOAD SELECT RATING FILTER POPUP
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def loadSelectRatingFilterPopup():
    widgetGuiXML = utilities.loadGuiXML()
    
    # Select rating filter Label
    txt_sel_rating = utilities.getGuiTagContent(widgetGuiXML, "txt_sel_rating")
    selectFilterList = mc.ListItems()
    for index in range(1):
        selectFilterItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        selectFilterItem.SetLabel(txt_sel_rating)
        selectFilterList.append(selectFilterItem)
    mc.GetActiveWindow().GetList(1423).SetItems(selectFilterList)
    
    # get available rating filters
    ratingFilterJsonObject = wscalls.WSGetItemList("ars", "0", "18")
    ratingFilterList = mc.ListItems()
    for index in range(len(ratingFilterJsonObject["data"]["its"]["it"])):
        ratingFilterItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        ratingFilterItem.SetProperty("checkBoxImg", "checkBox.png")
        ratingFilter = utilities.cleanString(ratingFilterJsonObject["data"]["its"]["it"][index]["v"])
        ratingFilterItem.SetLabel(ratingFilter)
        ratingFilterList.append(ratingFilterItem)
    mc.GetActiveWindow().GetList(1424).SetItems(ratingFilterList)
    
    # Ok Button
    txt_ok = utilities.getGuiTagContent(widgetGuiXML, "txt_ok")
    okButtonList = mc.ListItems()
    for index in range(1):
        okButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        okButtonItem.SetLabel(txt_ok)
        okButtonList.append(okButtonItem)
    mc.GetActiveWindow().GetList(1425).SetItems(okButtonList)
    
    # set focus on Ok button
    nextList = mc.GetActiveWindow().GetList(1425)
    nextList.SetFocus()
    nextList.SetFocusedItem(0)
    
    mc.GetActiveWindow().GetControl(1420).SetVisible(True)
    
    return True


#
# ACTIVATE PARENTAL CONTROL
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def activateParentalControl():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    config.SetValue("activePC", "True")
    config.SetValue("confirmed_pc_pin", "False")
    
    filterList = mc.GetActiveWindow().GetList(1424)
    for index in range(len(filterList.GetItems())):
        if(filterList.GetItem(index).GetProperty("checkBoxImg") == "checkBox_active.png"):
            ratingFilter = filterList.GetItem(index).GetLabel()
    config.SetValue("pc_filter", ratingFilter)
    
    pinCode = mc.GetActiveWindow().GetEdit(1413).GetText()
    config.SetValue("pc_pin", pinCode)
    
    # set Parental Control: status label
    txt_parental_control = utilities.getGuiTagContent(widgetGuiXML, "txt_parental_control")
    txt_active = utilities.getGuiTagContent(widgetGuiXML, "txt_active")
    mc.GetActiveWindow().GetList(1403).GetItem(0).SetLabel(txt_parental_control + ": " + txt_active)
    
    # set & display Filter: filter value label
    txt_pc_filter = utilities.getGuiTagContent(widgetGuiXML, "txt_pc_filter")
    ratingValue = config.GetValue("pc_filter")
    mc.GetActiveWindow().GetList(1404).GetItem(0).SetLabel(txt_pc_filter + ": " + ratingValue)
    mc.GetActiveWindow().GetControl(1404).SetVisible(True)
    
    # display Deactivate button
    mc.GetActiveWindow().GetList(1405).SetVisible(True)
    
    return True


#
# DEACTIVATE PARENTAL CONTROL
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def deactivateParentalControl():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    config.SetValue("activePC", "False")
    config.SetValue("pc_pin", "")
    config.SetValue("pc_filter", "")
    
    # set Parental Control: status label
    txt_parental_control = utilities.getGuiTagContent(widgetGuiXML, "txt_parental_control")
    txt_inactive = utilities.getGuiTagContent(widgetGuiXML, "txt_inactive")
    mc.GetActiveWindow().GetList(1403).GetItem(0).SetLabel(txt_parental_control + ": " + txt_inactive)
    
    # hide Filter: filter value label
    mc.GetActiveWindow().GetControl(1404).SetVisible(False)
    
    return True


#
# LOAD ENTER PARENTAL PIN CODE POPUP
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadInputPopup(popupType):
    widgetGuiXML = utilities.loadGuiXML()
    
    # set popup type
    mc.GetActiveWindow().GetLabel(1703).SetLabel(popupType)
    
    # popup title : Enter PIN Code / Notification email
    if(popupType == "pin_options" or popupType == "pin_startpage"):
        popup_title = utilities.getGuiTagContent(widgetGuiXML, "txt_enter_pin")
    elif(popupType == "fpwd_moviedetails"):
        popup_title = utilities.getGuiTagContent(widgetGuiXML, "txt_notification_email")
    popupTitleList = mc.ListItems()
    for index in range(1):
        popupTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        popupTitleItem.SetLabel(popup_title)
        popupTitleList.append(popupTitleItem)
    mc.GetActiveWindow().GetList(1704).SetItems(popupTitleList)
    
    mc.GetActiveWindow().GetEdit(1705).SetText("")
    mc.GetActiveWindow().GetEdit(1706).SetText("")
    
    if(popupType == "pin_options" or popupType == "pin_startpage"):
        mc.GetActiveWindow().GetEdit(1706).SetVisible(False)
        mc.GetActiveWindow().GetEdit(1705).SetVisible(True)
    elif(popupType == "fpwd_moviedetails"):
        mc.GetActiveWindow().GetEdit(1705).SetVisible(False)
        mc.GetActiveWindow().GetEdit(1706).SetVisible(True)
    
    # error message
    errorList = mc.ListItems()
    for index in range(1):
        errorItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        errorItem.SetLabel("")
        errorList.append(errorItem)
    mc.GetActiveWindow().GetList(1708).SetItems(errorList)
    
    # Popup Buttons:
    # parental_pin: OK, Cancel, Forgot PIN
    # forgot_password: OK, Cancel
    if(popupType == "pin_options" or popupType == "pin_startpage"):
        buttonsNo = 3
        txt_btn_0 = utilities.getGuiTagContent(widgetGuiXML, "txt_ok")
        txt_btn_2 = utilities.getGuiTagContent(widgetGuiXML, "txt_forgot_pin")
    elif(popupType == "fpwd_moviedetails"):
        buttonsNo = 2
        txt_btn_0 = utilities.getGuiTagContent(widgetGuiXML, "txt_send")
    
    txt_btn_1 = utilities.getGuiTagContent(widgetGuiXML, "txt_cancel")
    
    buttonsList = mc.ListItems()
    for index in range(buttonsNo):
        buttonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        if(index == 0):
            buttonItem.SetLabel(txt_btn_0)
        elif(index == 1):
            buttonItem.SetLabel(txt_btn_1)
        elif(index == 2):
            buttonItem.SetLabel(txt_btn_2)
        buttonsList.append(buttonItem)
    mc.GetActiveWindow().GetList(1707).SetItems(buttonsList)
    
    # set focus on first button
    nextList = mc.GetActiveWindow().GetList(1707)
    nextList.SetFocus()
    nextList.SetFocusedItem(0)
    
    mc.GetActiveWindow().GetControl(1700).SetVisible(True)
    
    return True


#
# ENTER PARENTAL PIN POPUP - Forgot PIN / Enter PIN code button ON CLICK
# # # # # # # # # # # # # # # # # # # # # # # # # # # # 
def pinPopupThirdButtonOnClick():
    widgetGuiXML = utilities.loadGuiXML()
    
    # Pin code input visible
    if(mc.GetActiveWindow().GetControl(1705).IsVisible()):
        # set popup title
        txt_email_add = utilities.getGuiTagContent(widgetGuiXML, "txt_email_add")
        mc.GetActiveWindow().GetList(1704).GetItem(0).SetLabel(txt_email_add)
        # hide pin input & display email address input
        mc.GetActiveWindow().GetControl(1706).SetVisible(True)
        mc.GetActiveWindow().GetControl(1705).SetVisible(False)
        # reset error message
        mc.GetActiveWindow().GetList(1708).GetItem(0).SetLabel("")
        # set 3rd button's label: Enter PIN code
        txt_enter_pin = utilities.getGuiTagContent(widgetGuiXML, "txt_enter_pin")
        mc.GetActiveWindow().GetList(1707).GetItem(2).SetLabel(txt_enter_pin)
    # Email Adress input visible
    elif(mc.GetActiveWindow().GetControl(1706).IsVisible()):
        # set popup title
        txt_enter_pin = utilities.getGuiTagContent(widgetGuiXML, "txt_enter_pin")
        mc.GetActiveWindow().GetList(1704).GetItem(0).SetLabel(txt_enter_pin)
        # display pin input & hide email address input
        mc.GetActiveWindow().GetControl(1705).SetVisible(True)
        mc.GetActiveWindow().GetControl(1706).SetVisible(False)
        # set 3rd button's label: Forgot PIN
        txt_forgot_pin = utilities.getGuiTagContent(widgetGuiXML, "txt_forgot_pin")
        mc.GetActiveWindow().GetList(1707).GetItem(2).SetLabel(txt_forgot_pin)
    
    return True


#
# INPUT POPUP BUTTONS ON CLICK
# # # # # # # # # # # # # # # # # # # # # # # # # # # #  
def inputPopupButtonOnClick():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    buttonslist = mc.GetActiveWindow().GetList(1707)
    focusedItemIndex = buttonslist.GetFocusedItem()
    
    def firstButtonOnClick():
        errorList = mc.GetActiveWindow().GetList(1708)
        errorList.GetItem(0).SetLabel("")
        
        popupType = mc.GetActiveWindow().GetLabel(1703).GetLabel()
        
        # password type input visible (Pin code)
        if(mc.GetActiveWindow().GetControl(1705).IsVisible()):
            pinCode = mc.GetActiveWindow().GetEdit(1705).GetText()
            if(len(pinCode) < 4 or len(pinCode) > 10):
                txt_px_pin_err = utilities.getGuiTagContent(widgetGuiXML, "txt_px_pin_err").replace("|MIN|", "4").replace("|MAX|", "10")
                errorList = mc.GetActiveWindow().GetList(1708)
                errorList.GetItem(0).SetLabel(txt_px_pin_err)
            elif(pinCode != config.GetValue("pc_pin")):
                txt_invalid = utilities.getGuiTagContent(widgetGuiXML, "txt_invalid")
                errorList = mc.GetActiveWindow().GetList(1708)
                errorList.GetItem(0).SetLabel(txt_invalid)
            else:
                if(popupType == "pin_options"):
                    utilities.hideAllContent()
                    loadParentalControlContent()
                elif(popupType == "pin_startpage"):
                    config.SetValue("confirmed_pc_pin", "True")
                    #hide popup
                    mc.GetActiveWindow().GetControl(1700).SetVisible(False)
                    # set focus on first box button
                    nextlist = mc.GetActiveWindow().GetList(301)
                    nextlist.SetFocus()
                    nextlist.SetFocusedItem(0)
        
        # clear text input visible (email address / notification email)
        elif(mc.GetActiveWindow().GetControl(1706).IsVisible()):
            username = mc.GetActiveWindow().GetEdit(1706).GetText()
            if(username == ""):
                txt_email_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_email_not_set")
                errorList = mc.GetActiveWindow().GetList(1708)
                errorList.GetItem(0).SetLabel(txt_email_not_set)
            else:    
                if(popupType == "pin_options" or popupType == "pin_startpage"):
                    wscalls.WSUserAction(username, "", "fpcp:" + config.GetValue("pc_pin"))
                elif(popupType == "fpwd_moviedetails"):
                    wscalls.WSUserAction(username, "", "fpwd")
        
    
    # grid visible => options visible 
    if(mc.GetActiveWindow().GetControl(400).IsVisible()):
        if(focusedItemIndex == 0):
            # OK button
            firstButtonOnClick()
        
        elif(focusedItemIndex == 1):
            # Cancel button
            mc.GetActiveWindow().PopState(False)
            
            mc.GetActiveWindow().GetControl(1700).SetVisible(False)
            nextlist = mc.GetActiveWindow().GetList(401)
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(int(focusedItem))
        
        # Forgot PIN / Enter PIN code
        elif(focusedItemIndex == 2):
            pinPopupThirdButtonOnClick()
    
    # start page visible
    elif(mc.GetActiveWindow().GetControl(300).IsVisible()):
        if(focusedItemIndex == 0):
            # OK button
            firstButtonOnClick()
        
        elif(focusedItemIndex == 1):
            # Cancel button
            mc.GetActiveWindow().PopState(False)
            config.SetValue("confirmed_pc_pin", "False")
            
            mc.GetActiveWindow().GetControl(1700).SetVisible(False)
            nextlist = mc.GetActiveWindow().GetList(301)
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(int(focusedItem))
        
        # Forgot PIN / Enter PIN code
        elif(focusedItemIndex == 2):
            pinPopupThirdButtonOnClick()
    
    # movie details visible
    elif(mc.GetActiveWindow().GetControl(500).IsVisible()):
        if(focusedItemIndex == 0):
            # Send button
            firstButtonOnClick()
        
        elif(focusedItemIndex == 1):
            # Cancel button
            mc.GetActiveWindow().PopState(False)
            
            mc.GetActiveWindow().GetControl(1700).SetVisible(False)
            nextlist = mc.GetActiveWindow().GetList(550)
            nextlist.SetFocus()
            nextlist.SetFocusedItem(0)
    
    # full login screen visible
    else:
        if(focusedItemIndex == 0):
            # Send button
            firstButtonOnClick()
        
        elif(focusedItemIndex == 1):
            # Cancel button
            mc.GetActiveWindow().PopState(False)
            
            mc.GetActiveWindow().GetControl(1700).SetVisible(False)
            nextlist = mc.GetActiveWindow().GetList(1310)
            nextlist.SetFocus()
            nextlist.SetFocusedItem(0)
    
    return True


#
# LOAD INFO CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadInfoContent():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # Info Label
    txt_op_info = utilities.getGuiTagContent(widgetGuiXML, "txt_op_info").replace("|br|", "\n")
    

    infoList = mc.ListItems()
    for index in range(1):
        infoItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        infoItem.SetLabel(txt_op_info)
        infoList.append(infoItem)
    mc.GetActiveWindow().GetList(1501).SetItems(infoList)
    
     # test for back
    if(utilities.isCleanScreen()):
        mc.GetActiveWindow().GetControl(1500).SetVisible(True)
        
        # set focus on option menu button
        nextlist = mc.GetActiveWindow().GetList(200)
        nextlist.SetFocus()
        if(utilities.isViewster()):
            nextlist.SetFocusedItem(6)
        elif(utilities.isHustler()):
            nextlist.SetFocusedItem(4)
    
    return True


#
# LOAD MY VOUCHER CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadMyVoucherContent():
    widgetGuiXML = utilities.loadGuiXML()
    
    config = mc.GetApp().GetLocalConfig()
    
    # Voucher details
    txt_voucher_credits = utilities.getGuiTagContent(widgetGuiXML, "txt_voucher_credits")
    txt_voucher_validity = utilities.getGuiTagContent(widgetGuiXML, "txt_voucher_credits")
    if(config.GetValue("voucherValidity") == "t"):
        txt_label = txt_voucher_credits + " " + config.GetValue("remainingVoucherCredits") + "/" + config.GetValue("availableVoucherCredits") + "\n" + txt_voucher_validity + " " + config.GetValue("voucherValidityDate")
    else:
        txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
        txt_label = txt_voucher_credits + " " + txt_no_file_name_avilable + "\n" + txt_voucher_validity + " " + txt_no_file_name_avilable
    
    voucherDetailsList = mc.ListItems()
    for index in range(1):
        voucherDetailsItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        voucherDetailsItem.SetLabel(txt_label)
        voucherDetailsList.append(voucherDetailsItem)
    mc.GetActiveWindow().GetList(2001).SetItems(voucherDetailsList)
    
    # Voucher Code Label
    txt_voucher_code = utilities.getGuiTagContent(widgetGuiXML, "txt_voucher_code")
    voucherCodeList = mc.ListItems()
    for index in range(1):
        voucherCodeItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        voucherCodeItem.SetLabel(txt_voucher_code)
        voucherCodeList.append(voucherCodeItem)
    mc.GetActiveWindow().GetList(2003).SetItems(voucherCodeList)
    
    # Redeem Voucher Button
    txt_redeem_voucher = utilities.getGuiTagContent(widgetGuiXML, "txt_redeem_voucher")
    redeemVoucherList = mc.ListItems()
    for index in range(1):
        redeemVoucherItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        redeemVoucherItem.SetLabel(txt_redeem_voucher)
        redeemVoucherList.append(redeemVoucherItem)
    mc.GetActiveWindow().GetList(2005).SetItems(redeemVoucherList)
    
    mc.GetActiveWindow().GetControl(2000).SetVisible(True)
    
    # set focus on input
    mc.GetActiveWindow().GetControl(2004).SetFocus()
    
    return True


#
# OPTIONS       - ON UP -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def options_OnUp(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    #
    # Help
    #
    
    # Create account button
    if(control_ID == 1107):
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # Language
    #
    
    # language buttons
    elif(control_ID == 1203):
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    # apply button
    elif(control_ID == 1204):
        nextlist = mc.GetActiveWindow().GetList(1203)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # Login
    #
    
    # email input, login button
    elif((control_ID == 1304) or (control_ID == 1308)):
        config.SetValue("returnToLoginContent", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # Parental Control
    #
    
    # deactivate button
    elif(control_ID == 1405):
        config.SetValue("returnToParentalControlContent", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    # set rating filter button 
    elif(control_ID == 1409):
        # deactivate button visible
        if(mc.GetActiveWindow().GetControl(1405).IsVisible()):
            nextList = mc.GetActiveWindow().GetList(1405)
            nextList.SetFocus()
            nextList.SetFocusedItem(0)
        else:
            config.SetValue("returnToParentalControlContent", str(control_ID))
            nextlist = mc.GetActiveWindow().GetList(200)
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(int(focusedItem))
    # Pin Code Input
    elif(control_ID == 1413):
        nextList = mc.GetActiveWindow().GetList(1409)
        nextList.SetFocus()
        nextList.SetFocusedItem(0)
    
    # Select rating filter popup
    
    # OK button
    elif(control_ID == 1425):
        nextlist = mc.GetActiveWindow().GetList(1424)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    # Enter Parental Pin Code Popup
    elif(control_ID == 1707):
        if(mc.GetActiveWindow().GetControl(1705).IsVisible()):
            mc.GetActiveWindow().GetControl(1705).SetFocus()
        elif(mc.GetActiveWindow().GetControl(1706).IsVisible()):
            mc.GetActiveWindow().GetControl(1706).SetFocus()
    
    #
    # Payment Confirmation Screen
    #
    elif(control_ID == 1802):
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # Register Screen
    #
    elif(control_ID == 1903):
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # My Voucher
    #
    
    # voucher code input / redeem voucher button
    elif(control_ID == 2004 or control_ID == 2005):
        nextlist = mc.GetActiveWindow().GetList(200)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    return True


#
# OPTIONS       - ON DOWN -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def options_OnDown(control_ID):
    
    #
    # Parental Control
    #
    
    # Deactivate button
    if(control_ID == 1405):
        nextList = mc.GetActiveWindow().GetList(1409)
        nextList.SetFocus()
        nextList.SetFocusedItem(0)
    # Pin Code input
    elif(control_ID == 1413):
        nextList = mc.GetActiveWindow().GetList(1415)
        nextList.SetFocus()
        nextList.SetFocusedItem(0)
    
    # Enter Parental Pin Code Popup
    elif(control_ID == 1705 or control_ID == 1706):
        nextlist = mc.GetActiveWindow().GetList(1707)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    return True


#
# OPTIONS       - ON RIGHT -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def options_OnRight(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    # email input / password input / remember me button / forgot your password / create account
    if((control_ID == 1304) or (control_ID == 1307) or (control_ID == 1309) or (control_ID == 1310) or (control_ID == 1312)):
        config.SetValue("returnToInput", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(1308)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
        
    return True


#
# OPTIONS       - ON LEFT -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def options_OnLeft(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    # login button
    if(control_ID == 1308):
        control_ID = config.GetValue("returnToInput")
        if(control_ID != ""):
            mc.GetActiveWindow().GetControl(int(control_ID)).SetFocus()
        else:
            mc.GetActiveWindow().GetControl(1304).SetFocus()
    
    return True


#
# OPTIONS       - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def options_OnClick(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    appName = config.GetValue("appName")
    
    #
    # Help
    #
    
    # Create account button
    if(control_ID == 1107):
        # workaround - because Create account is not in a login popup
        loginTypeList = mc.ListItems()
        for index in range(1):
            loginTypeItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            loginTypeItem.SetProperty("loginMaskType", "info")
            loginTypeList.append(loginTypeItem)
        mc.GetActiveWindow().GetList(1315).SetItems(loginTypeList)
        # end workaround
        
        # hide help content
        mc.GetActiveWindow().GetControl(1100).SetVisible(False)
        loadRegisterPopup()
    
    #
    # Language
    #
    
    # language button
    elif(control_ID == 1203):
        languageList = mc.GetActiveWindow().GetList(1203)
        focusedlanguageIndex = languageList.GetFocusedItem()
        focusedLanguageItem = languageList.GetItem(focusedlanguageIndex)
        
        for index in range(len(languageList.GetItems())):
            if(index != focusedlanguageIndex):
                languageList.GetItem(index).SetProperty("checkBoxImg", "checkBox.png")
        else:
            if(utilities.isViewster()):
                focusedLanguageItem.SetProperty("checkBoxImg", "checkBox_active.png")
            elif(utilities.isHustler()):
                focusedLanguageItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
    
    # apply button
    elif(control_ID == 1204):
        languageList = mc.GetActiveWindow().GetList(1203)
        for index in range(len(languageList.GetItems())):
            if((utilities.isViewster() and languageList.GetItem(index).GetProperty("checkBoxImg") == "checkBox_active.png") or (utilities.isHustler() and languageList.GetItem(index).GetProperty("checkBoxImg") == "h_checkBox_active.png")):
                languageCode = languageList.GetItem(index).GetProperty("languageCode")
                config.SetValue("language", languageCode)
                
                # get translation feed
                sUserEmail = config.GetValue("emailAddress")
                sPassword = config.GetValue("password")
                wscalls.WSInitLogin(sUserEmail, sPassword, "true", "")
                
                # reload menu
                menu.loadMenu()
                menu.setMenuButtonSelected(6)
                
                # reload language page
                # previousScreenContent is set to menu - to avoid focusing the first language button
                config.SetValue("previousScreenContent", "menu")    
                loadLanguageContent()
                
                # set focus on Apply button
                applyButtonlist = mc.GetActiveWindow().GetList(1204)
                applyButtonlist.SetFocus()
                applyButtonlist.SetFocusedItem(0)

    #
    # Login
    #
    
    # login button
    elif(control_ID == 1308):
        username = mc.GetActiveWindow().GetEdit(1304).GetText()
        password = mc.GetActiveWindow().GetEdit(1307).GetText()
        if(len(username) == 0):
            txt_email_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_email_not_set")
            mc.ShowDialogOk(appName, txt_email_not_set)
        elif(len(password) == 0):
            txt_pass_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_pass_not_set")
            mc.ShowDialogOk(appName, txt_pass_not_set)
        else:
            wscalls.WSInitLogin(username, password, "false", 1309)
        
    # remember me button
    elif(control_ID == 1309):
        focusedItemIndex = mc.GetActiveWindow().GetList(1309).GetFocusedItem()
        checkBoxImg = mc.GetActiveWindow().GetList(1309).GetItem(focusedItemIndex).GetProperty("checkBoxImg")
        if(checkBoxImg == "checkBox.png"):
            if(utilities.isViewster()):
                mc.GetActiveWindow().GetList(1309).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "checkBox_active.png")
            elif(utilities.isHustler()):
                mc.GetActiveWindow().GetList(1309).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "h_checkBox_active.png")
        else:
            mc.GetActiveWindow().GetList(1309).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "checkBox.png")
    
    # forgot your password button
    elif(control_ID == 1310):
        loadInputPopup("fpwd_moviedetails")
    
    # create account button
    elif(control_ID == 1312):
        loadRegisterPopup()
    
    #
    # Parental Control
    #
    
    # deactivate button
    elif(control_ID == 1405):
        deactivateParentalControl()
    # select rating filter button
    elif(control_ID == 1409):
        loadSelectRatingFilterPopup()
    # Activate button
    elif(control_ID == 1415):
        if(mc.GetActiveWindow().GetList(1409).GetItem(0).GetLabel() == ""):
            txt_pc_filter_err = utilities.getGuiTagContent(widgetGuiXML, "txt_pc_filter_err")
            mc.ShowDialogOk(appName, txt_pc_filter_err)
        elif(len(mc.GetActiveWindow().GetEdit(1413).GetText()) < 4 or len(mc.GetActiveWindow().GetEdit(1413).GetText()) > 10):
            txt_px_pin_err = utilities.getGuiTagContent(widgetGuiXML, "txt_px_pin_err").replace("|MIN|", "4").replace("|MAX|", "10")
            mc.ShowDialogOk(appName, txt_px_pin_err)
        else:
            activateParentalControl()
    
    # Select rating filter popup
    
    # Rating Filter button
    elif(control_ID == 1424):
        filterList = mc.GetActiveWindow().GetList(control_ID)
        focusedFilterIndex = filterList.GetFocusedItem()
        focusedFilterItem = filterList.GetItem(focusedFilterIndex)
        
        for index in range(len(filterList.GetItems())):
            if(index != focusedFilterIndex):
                filterList.GetItem(index).SetProperty("checkBoxImg", "checkBox.png")
            else:
                focusedFilterItem.SetProperty("checkBoxImg", "checkBox_active.png")
    # OK button
    elif(control_ID == 1425):
        filterList = mc.GetActiveWindow().GetList(1424)
        for index in range(len(filterList.GetItems())):
            if(filterList.GetItem(index).GetProperty("checkBoxImg") == "checkBox_active.png"):
                ratingFilter = filterList.GetItem(index).GetLabel()
                setFilterButtonList = mc.GetActiveWindow().GetList(1409)
                setFilterButtonList.GetItem(0).SetLabel(str(ratingFilter))
        mc.GetActiveWindow().GetControl(1420).SetVisible(False)
        nextList = mc.GetActiveWindow().GetList(1409)
        nextList.SetFocus()
        nextList.SetFocusedItem(0)
    
    # Enter Parental Pin Code Popup
    
    # popup buttons
    elif(control_ID == 1707):
        inputPopupButtonOnClick()
    
    #
    # Payment Confirmation(Big) screen
    #
    
    # Subscribe button
    elif(control_ID == 1802):
        price = config.GetValue("subscription_price")
        currency = config.GetValue("subscription_currency")
        wscalls.WSPay("subscribe", "web", "", price, currency)
    
    #
    # Register (Big) Screen
    #
    
    elif(control_ID == 1910):
        focusedItemIndex = mc.GetActiveWindow().GetList(control_ID).GetFocusedItem()
        checkBoxImg = mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).GetProperty("checkBoxImg")
        if(checkBoxImg == "checkBox.png"):
            if(utilities.isViewster()):
                mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "checkBox_active.png")
            elif(utilities.isHustler()):
                mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "h_checkBox_active.png")
        else:
            mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "checkBox.png")
    
    elif(control_ID == 1911):
        username = str(mc.GetActiveWindow().GetEdit(1903).GetText())
        password_1 = str(mc.GetActiveWindow().GetEdit(1906).GetText())
        password_2 = str(mc.GetActiveWindow().GetEdit(1909).GetText())
        
        if(username == ""):
            txt_email_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_email_not_set")
            mc.ShowDialogOk(appName, txt_email_not_set)
        elif(password_1 == "" or password_2 == ""):
            txt_pass_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_pass_not_set")
            mc.ShowDialogOk(appName, txt_pass_not_set)
        elif(password_1 != password_2):
            txt_pass_not_match = utilities.getGuiTagContent(widgetGuiXML, "txt_pass_not_match")
            mc.ShowDialogOk(appName, txt_pass_not_match)
        else:
            wscalls.WSUserAction(username, password_1, "registeraccount")
    
    #
    # My Voucher
    #
    
    # Redeem voucher button
    elif(control_ID == 2005):
        userEmail = config.GetValue("emailAddress")
        password = config.GetValue("password")
        voucher_code = mc.GetActiveWindow().GetEdit(2004).GetText()
        wscalls.WSUserAction(userEmail, password, "voucherset:" + voucher_code)
        
        # Voucher details
        txt_voucher_credits = utilities.getGuiTagContent(widgetGuiXML, "txt_voucher_credits")
        txt_voucher_validity = utilities.getGuiTagContent(widgetGuiXML, "txt_voucher_credits")
        txt_label = txt_voucher_credits + " " + config.GetValue("remainingVoucherCredits") + "/" + config.GetValue("availableVoucherCredits") + "\n" + txt_voucher_validity + " " + config.GetValue("voucherValidityDate")
        
        detailsList = mc.GetActiveWindow().GetList(2001)
        detailsItem = detailsList.GetItem(0)
        detailsItem.SetLabel(txt_label)
    
    return True