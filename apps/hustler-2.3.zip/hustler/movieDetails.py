import mc
#import xbmc

# VIEWSTER Librarys
import grid
import wscalls
import utilities
import options


#
# Set Video Language Code ( & flag if needed) (movie/trailer language/subtitle)
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def setVideoLanguage(langDict, control_id, setFlag, artworkBaseUrl):
    widgetGuiXML = utilities.loadGuiXML()
    
    txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
    
    mc.GetActiveWindow().GetList(control_id).SetVisible(True)
    if(control_id == 508):
        mc.GetActiveWindow().GetList(520).SetVisible(False)
    elif(control_id == 512):
        mc.GetActiveWindow().GetList(528).SetVisible(False)
    
    if(langDict == None):
        languagesList = mc.ListItems()
        noneList = mc.ListItems()
        
        for index in range(1):
            languageItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            languageItem.SetLabel(txt_no_file_name_avilable)
            languagesList.append(languageItem)
            
            noneItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            noneItem.SetLabel(txt_no_file_name_avilable)
            noneList.append(noneItem)
        
        mc.GetActiveWindow().GetList(control_id).SetItems(languagesList)
        
        # movie language
        if(control_id == 508):
            mc.GetActiveWindow().GetList(520).SetItems(noneList)
            mc.GetActiveWindow().GetList(control_id).SetVisible(False)
            mc.GetActiveWindow().GetList(520).SetVisible(True)
        # movie subtitle lang
        elif(control_id == 512):
            mc.GetActiveWindow().GetList(528).SetItems(noneList)
            mc.GetActiveWindow().GetList(control_id).SetVisible(False)
            mc.GetActiveWindow().GetList(528).SetVisible(True)
    else:
        langNo = len(langDict["it"])
        languagesList = mc.ListItems()
        for index in range(langNo):
            languageItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            languageItem.SetLabel(str(langDict["it"][index]["l"]))
            if(setFlag):
                #if(langDict["it"][index]["l"] == "de" or
                #   langDict["it"][index]["l"] == "en" or
                #   langDict["it"][index]["l"] == "fr" or
                #   langDict["it"][index]["l"] == "nl" or
                #   langDict["it"][index]["l"] == "it" or
                #   langDict["it"][index]["l"] == "ru" or
                #   langDict["it"][index]["l"] == "sv" or
                #   langDict["it"][index]["l"] == "es"):
                #    if(control_id == 512 or control_id == 513):
                #        languageItem.SetProperty("subtitleLangFlag", "flag_" + str(langDict["it"][index]["l"]) + ".png")
                #    else:
                #        languageItem.SetProperty("videoLangFlag", "flag_" + str(langDict["it"][index]["l"]) + ".png")
                
                if(control_id == 512 or control_id == 513):
                    languageItem.SetProperty("subtitleLangFlag", artworkBaseUrl + "flag_" + str(langDict["it"][index]["l"]) + ".png")
                else:
                    languageItem.SetProperty("videoLangFlag", artworkBaseUrl + "flag_" + str(langDict["it"][index]["l"]) + ".png")
                
            languagesList.append(languageItem)
        
        mc.GetActiveWindow().GetList(control_id).SetItems(languagesList)
    
    return True


#
# LOAD Movie Details
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
def loadMovieDetails(id):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    md_json_object = wscalls.WSGetMovieDetail(id)
    
    # hide popups
    #hideChooseLanguagePopup()
    #hideLoginPopup()
    #hideAddFatoritesPopup()
    hide_MD_Popup_Content()
    # hide popup bg
    mc.GetActiveWindow().GetControl(525).SetVisible(False)
    
    # hide previous similar movies
    mc.GetActiveWindow().GetControl(524).SetVisible(False)
    
    #
    # save undisplayed data from json
    #
    
    # save "share url web"
    suw = str(md_json_object["data"]["suw"]).replace("[mid]", id)
    config.SetValue("share_url_web", suw)
    
    # save movie id, price related data, subscription status, episode status
    mdList = mc.ListItems()
    for index in range(1):
        mdItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        mdItem.SetProperty("movieID", str(md_json_object["data"]["md"]["i"]))       # movieID
        mdItem.SetProperty("price", str(md_json_object["data"]["pr"]["p"]))         # price
        mdItem.SetProperty("currency", str(md_json_object["data"]["pr"]["c"]))      # currency
        mdItem.SetProperty("availability", str(md_json_object["data"]["pr"]["a"]))  # availability
        mdItem.SetProperty("inSubscription", str(md_json_object["data"]["is"]))     # inSubscription
        mdItem.SetProperty("hasEpisodes", str(md_json_object["data"]["md"]["e"]))   # hasEpisodes
        mdItem.SetProperty("baseUrl", str(md_json_object["data"]["ab"]))            # base url
        mdList.append(mdItem)
    mc.GetActiveWindow().GetList(591).SetItems(mdList)
    
    # save avod / fvod / tvod / svod
    vodList = mc.ListItems()
    for index in range(1):
        vodItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        vodItem.SetProperty("avod", str(md_json_object["data"]["avod"]))
        vodItem.SetProperty("fvod", str(md_json_object["data"]["fvod"]))
        vodItem.SetProperty("tvod", str(md_json_object["data"]["tvod"]))
        vodItem.SetProperty("svod", str(md_json_object["data"]["svod"]))
        vodList.append(vodItem)
    mc.GetActiveWindow().GetList(592).SetItems(vodList)
    
    # used for artworks
    language = config.GetValue("language")
    if(utilities.isViewster()):
        if(language != "en" and language != "de" and language != "fr"):
            language = "en"
    elif(utilities.isHustler()):
        language = "en"
    
    # movie artwork
    artworkURL = str(md_json_object["data"]["ar"].replace("[ab]", md_json_object["data"]["ab"]).replace("[mid]", id).replace("[LANG]", language.upper()))
    movieArtworkList = mc.ListItems()
    for index in range(1):
        movieArtworkItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        movieArtworkItem.SetImage(0, artworkURL)
        movieArtworkList.append(movieArtworkItem)
    mc.GetActiveWindow().GetList(501).SetItems(movieArtworkList)
    
    # rating stars
    userRating = int(md_json_object["data"]["md"]["ur"])
    ratingStarsList = mc.ListItems()
    for index in range(5):
        ratingStarItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        if(index < userRating):
            ratingStarItem.SetProperty("starImg", "fullStar.png")
        else:
            ratingStarItem.SetProperty("starImg", "emptyStar.png")
        ratingStarsList.append(ratingStarItem)
    mc.GetActiveWindow().GetList(503).SetItems(ratingStarsList)
    
    # title
    title = utilities.cleanString(md_json_object["data"]["md"]["t"])
    movieTitleList = mc.ListItems()
    for index in range(1):
        movieTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        movieTitleItem.SetProperty("movieTitle", title)
        movieTitleList.append(movieTitleItem)
    mc.GetActiveWindow().GetList(504).SetItems(movieTitleList)
    
    # informations
    txt_min = utilities.getGuiTagContent(widgetGuiXML, "txt_min")
    txt_rated = utilities.getGuiTagContent(widgetGuiXML, "txt_rated")
    infos = str(md_json_object["data"]["md"]["c"]) + " | " + str(md_json_object["data"]["md"]["rd"]) + " | " + str(md_json_object["data"]["md"]["rt"]) + txt_min + " | " + txt_rated + ": " + str(md_json_object["data"]["md"]["r"])
    movieInfosList = mc.ListItems()
    for index in range(1):
        movieInfosItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        movieInfosItem.SetProperty("movieInfos", infos)
        movieInfosList.append(movieInfosItem)
    mc.GetActiveWindow().GetList(505).SetItems(movieInfosList)
    
    # video languages
    txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
    txt_available_lang = utilities.getGuiTagContent(widgetGuiXML, "txt_available_lang")
    langLabelList = mc.ListItems()
    for index in range(1):
        langLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        langLabelItem.SetLabel(txt_available_lang + ":")
        langLabelList.append(langLabelItem)
    mc.GetActiveWindow().GetList(507).SetItems(langLabelList)
    
    # movie video languageCode
    setVideoLanguage(md_json_object["data"]["mv"]["its"], 508, True, str(md_json_object["data"]["ab"]))
    # trailer video languages
    setVideoLanguage(md_json_object["data"]["tr"]["its"], 509, False, str(md_json_object["data"]["ab"]))
    
    # subtitle languages
    txt_subtitle = utilities.getGuiTagContent(widgetGuiXML, "txt_subtitle")
    srtLabelList = mc.ListItems()
    for index in range(1):
        srtLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        srtLabelItem.SetLabel(txt_subtitle + ":")
        srtLabelList.append(srtLabelItem)
    mc.GetActiveWindow().GetList(511).SetItems(srtLabelList)
    # movie subtitle languages
    setVideoLanguage(md_json_object["data"]["mvst"]["its"], 512, True, str(md_json_object["data"]["ab"]))
    # trailer subtitle languages
    setVideoLanguage(md_json_object["data"]["trst"]["its"], 513, False, str(md_json_object["data"]["ab"]))
    
    # Genre
    txt_genre = utilities.getGuiTagContent(widgetGuiXML, "txt_genre")
    genre = utilities.cleanString(md_json_object["data"]["md"]["g"])
    genreList = mc.ListItems()
    for index in range(1):
        genreItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        genreItem.SetLabel(txt_genre + ": " + genre)
        genreList.append(genreItem)
    mc.GetActiveWindow().GetList(514).SetItems(genreList)
    
    # Original Title 
    txt_original_title = utilities.getGuiTagContent(widgetGuiXML, "txt_original_title")
    originalTitleList = mc.ListItems()
    for index in range(1):
        originalTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        originalTitleItem.SetLabel(txt_original_title + ": " + title)
        originalTitleList.append(originalTitleItem)
    mc.GetActiveWindow().GetList(515).SetItems(originalTitleList)
    
    # Director
    txt_director = utilities.getGuiTagContent(widgetGuiXML, "txt_director")
    director = utilities.cleanString(md_json_object["data"]["md"]["d"])
    directorList = mc.ListItems()
    for index in range(1):
        directorItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        directorItem.SetLabel(txt_director + ": " + director)
        directorList.append(directorItem)
    mc.GetActiveWindow().GetList(516).SetItems(directorList)
    
    # Actor
    txt_actor = utilities.getGuiTagContent(widgetGuiXML, "txt_actor")
    actor = utilities.cleanString(md_json_object["data"]["md"]["a"])
    actorsList = mc.ListItems()
    for index in range(1):
        actorItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        actorItem.SetLabel(txt_actor + ": " + actor)
        actorsList.append(actorItem)
    mc.GetActiveWindow().GetList(517).SetItems(actorsList)
    
    # Synopsis 
    synopsis = utilities.cleanString(md_json_object["data"]["md"]["sl"])
    synopsisList = mc.ListItems()
    for index in range(1):
        synopsisItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        synopsisItem.SetDescription(synopsis, False)
        synopsisList.append(synopsisItem)
    mc.GetActiveWindow().GetList(518).SetItems(synopsisList)
    
    # MD buttons
    txt_watch_trailer = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_trailer")
    txt_watch_movie = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_movie")
    txt_watch_episodes = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_episodes")
    txt_watch_episode = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_episode")
    txt_subscribe = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
    txt_add_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav")
    
    txt_watch = utilities.getGuiTagContent(widgetGuiXML, "txt_watch")
    txt_sbs_viewster = utilities.getGuiTagContent(widgetGuiXML, "txt_sbs_viewster")
    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    txt_add_fav_q = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav_q").replace("|MOVIE_TITLE|", movieTitle)
    
    svod = mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("svod")
    
    mdButtonsList = mc.ListItems()
    
    if(utilities.isViewster()):
        if(svod == "f" or (config.GetValue("init_svod") == "f")):
            buttonsNo = 3   # Watch Trailer / Watch Movie / Add-Remove Favorites
        else:
            buttonsNo = 4   # Watch Trailer / Watch Movie / Subscribe / Add-Remove Favorites
    elif(utilities.isHustler()):
        if(svod == "f" or (config.GetValue("init_svod") == "f")):
            buttonsNo = 2   # Watch Trailer / Watch Movie
        else:
            buttonsNo = 3   # Watch Trailer / Watch Movie / Subscribe
    
    for index in range(buttonsNo):
        mdButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        if(utilities.isViewster()):
            mdButtonItem.SetProperty("mdButtonBg", "mdYellowButton.png")
        elif(utilities.isHustler()):
            mdButtonItem.SetProperty("mdButtonBg", "mdPinkButton.png")
        
        # Watch Trailer
        if(index == 0):
            mdButtonItem.SetLabel(txt_watch_trailer)
            if(utilities.isViewster()):
                mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_1.png")
            elif(utilities.isHustler()):
                mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_1_pink.png")
            mdButtonItem.SetProperty("breadCrumb", txt_watch_trailer + " \"" + movieTitle + "\"")
            mdButtonItem.SetProperty("buttonType", "watchTrailer")
        
        # Watch Movie
        elif(index == 1):
            hasEpisodes = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("hasEpisodes")
            if(utilities.isViewster()):
                mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_1.png")
            elif(utilities.isHustler()):
                mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_1_pink.png")
            if(hasEpisodes == "0"):
                if(config.GetValue("currentMovieListContent") == "Episodes"):
                    mdButtonItem.SetLabel(txt_watch_episode)
                    mdButtonItem.SetProperty("breadCrumb", txt_watch_episode)
                else:
                    mdButtonItem.SetLabel(txt_watch_movie)
                    mdButtonItem.SetProperty("breadCrumb", txt_watch + " \"" + movieTitle + "\"")
            else:
                mdButtonItem.SetLabel(txt_watch_episodes)
                mdButtonItem.SetProperty("breadCrumb", txt_watch_episodes)
            mdButtonItem.SetProperty("buttonType", "watchMovie")
        
        # Subscribe / Add-Remove Favorites
        elif(index == 2):
            # Subscribe
            if(svod == "t" and (config.GetValue("init_svod") == "t")):
                mdButtonItem.SetLabel(txt_subscribe)
                if(utilities.isViewster()):
                    mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_2.png")
                elif(utilities.isHustler()):
                    mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_2_pink.png")
                mdButtonItem.SetProperty("breadCrumb", txt_sbs_viewster)
                mdButtonItem.SetProperty("buttonType", "subscribe")
            # Add / Remove Favorites
            else:
                if(config.GetValue("authenticatedUser") == "True"):
                    mdButtonItem.SetLabel("")
                else:
                    mdButtonItem.SetLabel(txt_add_fav)
                    mdButtonItem.SetProperty("breadCrumb", txt_add_fav_q)
                mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_3.png")
                mdButtonItem.SetProperty("buttonType", "addFavorites")
        
        # Add / Remove Favorites
        elif(index == 3):
            if(config.GetValue("authenticatedUser") == "True"):
                mdButtonItem.SetLabel("")
            else:
                mdButtonItem.SetLabel(txt_add_fav)
                mdButtonItem.SetProperty("breadCrumb", txt_add_fav_q)
            mdButtonItem.SetProperty("mdButtonIcon", "btnIcon_3.png")
            mdButtonItem.SetProperty("buttonType", "addFavorites")
        
        mdButtonItem.SetProperty("buttonSelected", "False")
        mdButtonsList.append(mdButtonItem)
    mc.GetActiveWindow().GetList(521).SetItems(mdButtonsList)
    
    if(utilities.isCleanScreen()):
        mc.GetActiveWindow().GetControl(500).SetVisible(True)
        
        # set focus on first MD button ( Watch Trailer )
        mc.GetActiveWindow().GetList(521).SetFocus()
        mc.GetActiveWindow().GetList(521).SetFocusedItem(0)
        
        # set add/remove favorite button label
        # this will not work if ws call made before SetItems
        if(config.GetValue("authenticatedUser") == "True"):
            username = config.GetValue("emailAddress")
            password = config.GetValue("password")
            if(utilities.isViewster()):        
                wscalls.WSUserAction(username, password, "favg:" + id)
            wscalls.WSGetSubscriptionStatus(id)
            # gray out subscribe button
            mdButtonIndex = getMDButtonIndex("subscribe")
            tryToGrayOutMDButton(mdButtonIndex, "subscribe")
        
        loadSimilarMovies(id)
        
        # save trailer URL
        if(md_json_object["data"]["tr"]["its"] != None):
            trailerURLList = mc.ListItems()
            for index in range(len(md_json_object["data"]["tr"]["its"]["it"])):
                trailerURLItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                trailerURLItem.SetProperty("trailerURL", str(md_json_object["data"]["tr"]["ur"].replace("[bu]", md_json_object["data"]["tr"]["its"]["it"][index]["bu"]).replace("[fn]", md_json_object["data"]["tr"]["its"]["it"][index]["fn"])))
                trailerURLList.append(trailerURLItem)
            mc.GetActiveWindow().GetList(593).SetItems(trailerURLList)
    
    return True


#
# LOAD SIMILAR MOVIES
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def loadSimilarMovies(movieID):
    widgetGuiXML = utilities.loadGuiXML()
    
    config = mc.GetApp().GetLocalConfig()
    
    # language for artworks
    language = config.GetValue("language")
    if(utilities.isViewster()):
        if(language != "en" and language != "de" and language != "fr"):
            language = "en"
    elif(utilities.isHustler()):
        language = "en"
    
    # "Similar movies" label
    txt_similar_movies = utilities.getGuiTagContent(widgetGuiXML, "txt_similar_movies")
    mc.GetActiveWindow().GetLabel(523).SetLabel(txt_similar_movies)
    
    # movies
    similarMoviesJsonObject = wscalls.WSGetMovieList("sim:" + movieID, "0", "3")
    similarMoviesList = mc.ListItems()
    
    if(similarMoviesJsonObject["data"]["its"] is not None):
        txt_min = utilities.getGuiTagContent(widgetGuiXML, "txt_min")
        similarMovies = similarMoviesJsonObject["data"]["its"]["it"]
        
        # VIEWSTER APP
        if(utilities.isViewster()):
            separator = " | "
        # HUSTLER APP
        elif(utilities.isHustler()):
            separator = ""
        
        for index in range(len(similarMovies)):
            movieItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            artworkURL = str(similarMoviesJsonObject["data"]["ar"]).replace("[ab]", similarMoviesJsonObject["data"]["ab"]).replace("[mid]", similarMovies[index]["i"]).replace("[LANG]", language.upper())
            movieItem.SetImage(0, str(artworkURL))
            movieItem.SetLabel(utilities.cleanString(similarMovies[index]["t"]))
            movieItem.SetProperty("id", utilities.cleanString(similarMovies[index]["i"]))
            movieItem.SetProperty("breadCrumb", utilities.cleanString(similarMovies[index]["t"]) + " | " + utilities.cleanString(similarMovies[index]["g"]) + " | " + utilities.cleanString(similarMovies[index]["c"]) + " | " + utilities.cleanString(similarMovies[index]["rd"]) + " | " + utilities.cleanString(similarMovies[index]["r"]) + txt_min)
            movieItem.SetProperty("userRating", utilities.cleanString(similarMovies[index]["ur"]))
            
            similarMoviesList.append(movieItem)
    mc.GetActiveWindow().GetList(524).SetItems(similarMoviesList)
    
    mc.GetActiveWindow().GetControl(524).SetVisible(True)
    
    return True


#
# GET MD BUTTON INDEX BASED ON BUTTON TYPE
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def getMDButtonIndex(buttonType):
    buttonIndex = -1
    
    mdButtonList = mc.GetActiveWindow().GetList(521)
    mdButtonsNo = len(mdButtonList.GetItems())
    
    for index in range(mdButtonsNo):
        if(mdButtonList.GetItem(index).GetProperty("buttonType") == buttonType):
            buttonIndex = index
    
    return buttonIndex


#
# GRAY OUT MOVIE DETAILS BUTTON
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def tryToGrayOutMDButton(mdButtonIndex, buttonType):
    # if button found in list
    if(mdButtonIndex != -1):
        widgetGuiXML = utilities.loadGuiXML()
        
        config = mc.GetApp().GetLocalConfig()
        
        # subbcribe button
        if(buttonType == "subscribe"):
            txt_subscribe = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
            subscription_status = config.GetValue("subscription_status")
            if(subscription_status == "t"):
                #closeMDPopup(buttonType, True)
                
                mdButton = mc.GetActiveWindow().GetList(521).GetItem(mdButtonIndex)
                mdButton.SetProperty("mdButtonBg", "mdGrayButton.png")
                mdButton.SetProperty("mdButtonIcon", "btnIcon_2_inactive.png")
                mdButton.SetLabel('[COLOR black]' + txt_subscribe + '[/COLOR]')
    
    return True


#
# SET ADD/REMOVE FAVORITE BUTTON LABEL - function called when user is authenticated
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def setFavoriteButtonLabel(favoriteStatus):
    widgetGuiXML = utilities.loadGuiXML()
    
    mdButtonsList = mc.GetActiveWindow().GetList(521)
    favButtonIndex = getMDButtonIndex("addFavorites")
    favButtunItem = mdButtonsList.GetItem(favButtonIndex)
    
    buttonSelected = favButtunItem.GetProperty("buttonSelected")
    
    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    txt_add_fav_q = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav_q").replace("|MOVIE_TITLE|", movieTitle)
    txt_remove_fav_q = utilities.getGuiTagContent(widgetGuiXML, "txt_remove_fav_q").replace("|MOVIE_TITLE|", movieTitle)
    
    if(favoriteStatus == "t"):
        txt_remove_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_remove_fav")
        if(buttonSelected == "True"):
            favButtunItem.SetLabel('[COLOR FFF8AC00]' + txt_remove_fav + '[/COLOR]')
        else:
            favButtunItem.SetLabel('[COLOR black]' + txt_remove_fav + '[/COLOR]')
        favButtunItem.SetProperty("breadCrumb", txt_remove_fav_q)
    else:
        txt_add_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav")
        if(buttonSelected == "True"):
            favButtunItem.SetLabel('[COLOR FFF8AC00]' + txt_add_fav + '[/COLOR]')
        else:
            favButtunItem.SetLabel('[COLOR black]' + txt_add_fav + '[/COLOR]')
        favButtunItem.SetProperty("breadCrumb", txt_add_fav_q)
    
    return True


#
# UPDATE PRICE RELATED DATA - function called when user country is changed due to login
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def updatePriceValues(md_json_object):
    widgetGuiXML = utilities.loadGuiXML()
    
    # update price values
    mdList = mc.ListItems()
    for index in range(1):
        mdItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        mdItem.SetProperty("movieID", str(md_json_object["data"]["md"]["i"]))       # movieID
        mdItem.SetProperty("price", str(md_json_object["data"]["pr"]["p"]))         # price
        mdItem.SetProperty("currency", str(md_json_object["data"]["pr"]["c"]))      # currency
        mdItem.SetProperty("availability", str(md_json_object["data"]["pr"]["a"]))  # availability
        mdItem.SetProperty("inSubscription", str(md_json_object["data"]["is"]))     # inSubscription
        mdItem.SetProperty("hasEpisodes", str(md_json_object["data"]["md"]["e"]))   # hasEpisodes
        mdItem.SetProperty("baseUrl", str(md_json_object["data"]["ab"]))            # base url
        mdList.append(mdItem)
    mc.GetActiveWindow().GetList(591).SetItems(mdList)
    
    ## display updated values in the pay & watch popup
    #movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    #price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
    #currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
    #availability = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("availability")
    
    #txt_rent_info = utilities.getGuiTagContent(widgetGuiXML, "txt_rent_info")
    #txt_rent_info = txt_rent_info.replace("|MOVIE_TITLE|", movieTitle).replace("|PRICE|", price).replace("|CURRENCY|", currency).replace("|AVAILABILITY|", availability).replace("|br|","\n")
    
    ## Login Popup Title
    #loginTitleList = mc.ListItems()
    #for index in range(1):
    #    loginTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    #    loginTitleItem.SetProperty("loginPopupTitle", txt_rent_info)
    #    loginTitleList.append(loginTitleItem)
    #mc.GetActiveWindow().GetList(541).SetItems(loginTitleList)
    
    return True


#
# SET SELECTED MOVIE DETAILS BUTTON
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def setSelectedMovieDetailsButton():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    txt_watch_trailer = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_trailer")
    txt_watch_movie = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_movie")
    txt_subscribe = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
    if(config.GetValue("authenticatedUser") == "True"):
        if(config.GetValue("movieFavoriteStatus") == "f"):
            txt_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav")
        else:
            txt_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_remove_fav")
    else:
        txt_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav")
    
    svod = mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("svod")
    if(svod == "t" and (config.GetValue("init_svod") == "t")):
        mdButtonsLabels = [txt_watch_trailer, txt_watch_movie, txt_subscribe, txt_fav]
    else:
        mdButtonsLabels = [txt_watch_trailer, txt_watch_movie, txt_fav]
    
    mdButtonsList = mc.GetActiveWindow().GetList(521)
    focusedButtonIndex = mdButtonsList.GetFocusedItem()
    focusedButtonItem = mdButtonsList.GetItem(focusedButtonIndex)

    for index in range(len(mdButtonsList.GetItems())):
        #subscribeButtonGrayedOut = (index == 2 and config.GetValue("authenticatedUser") == "True" and config.GetValue("subscription_status") == "t")
        subscribeButtonGrayedOut = (mdButtonsList.GetItem(index).GetProperty("buttonType") == "subscribe" and config.GetValue("authenticatedUser") == "True" and config.GetValue("subscription_status") == "t")
        
        if(index != focusedButtonIndex):
            mdButtonsList.GetItem(index).SetProperty("buttonSelected", "False")
            if(not subscribeButtonGrayedOut):
                if(utilities.isViewster()):
                    mdButtonsList.GetItem(index).SetProperty("mdButtonBg", "mdYellowButton.png")
                elif(utilities.isHustler()):
                    mdButtonsList.GetItem(index).SetProperty("mdButtonBg", "mdPinkButton.png")
                mdButtonsList.GetItem(index).SetLabel('[COLOR black]' + mdButtonsLabels[index] + '[/COLOR]')
        else:
            selectedMDButtonIndex = index
            focusedButtonItem.SetProperty("buttonSelected", "True")
            if(not subscribeButtonGrayedOut):
                focusedButtonItem.SetProperty("mdButtonBg", "mdSelectedButton.png")
                if(utilities.isViewster()):
                    focusedButtonItem.SetLabel('[COLOR FFF8AC00]' + mdButtonsLabels[index] + '[/COLOR]')
                elif(utilities.isHustler()):
                    focusedButtonItem.SetLabel('[COLOR FFE13993]' + mdButtonsLabels[index] + '[/COLOR]')
    
    return selectedMDButtonIndex


#
# UNSELECT MOVIE DETAILS BUTTON
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def unselectMovieDetailsButton(buttonIndex, mdButtonType):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    txt_watch_trailer = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_trailer")
    txt_watch_movie = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_movie")
    txt_subscribe = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
    if(config.GetValue("authenticatedUser") == "True"):
        if(config.GetValue("movieFavoriteStatus") == "t"):
            txt_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_remove_fav")
        else:
            txt_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav")
    else:
        txt_fav = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav")
    
    svod = mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("svod")
    if(svod == "t" and (config.GetValue("init_svod") == "t")):
        mdButtonsLabels = [txt_watch_trailer, txt_watch_movie, txt_subscribe, txt_fav]
    else:
        mdButtonsLabels = [txt_watch_trailer, txt_watch_movie, txt_fav]
    
    mdButtonsList = mc.GetActiveWindow().GetList(521)
    
    # subscribe button
    #if(buttonIndex == 2):
    if(mdButtonType == "subscribe"):
        if(config.GetValue("subscription_status") == "t"):
            mdButtonsList.GetItem(buttonIndex).SetProperty("mdButtonBg", "mdGrayButton.png")
        else:
            if(utilities.isViewster()):
                mdButtonsList.GetItem(buttonIndex).SetProperty("mdButtonBg", "mdYellowButton.png")
            elif(utilities.isHustler()):
                mdButtonsList.GetItem(buttonIndex).SetProperty("mdButtonBg", "mdPinkButton.png")
    else:
        if(utilities.isViewster()):
            mdButtonsList.GetItem(buttonIndex).SetProperty("mdButtonBg", "mdYellowButton.png")
        elif(utilities.isHustler()):
            mdButtonsList.GetItem(buttonIndex).SetProperty("mdButtonBg", "mdPinkButton.png")
    
    mdButtonItem = mdButtonsList.GetItem(buttonIndex)
    mdButtonItem.SetLabel('[COLOR black]' + mdButtonsLabels[buttonIndex] + '[/COLOR]')
    mdButtonItem.SetProperty("buttonSelected", "False")
    
    return True


#
# LOAD CHOOSE LANGUAGE POPUP CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadChooseLanguagePopupContent(videoType):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # reset md navigation return values
    config.SetValue("returnToChooseLangPopupContent", "")
    
    # Movie Title
    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    movieTitleList = mc.ListItems()
    for index in range(1):
        movieTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        movieTitleItem.SetProperty("movieTitle", movieTitle)
        movieTitleList.append(movieTitleItem)
    mc.GetActiveWindow().GetList(527).SetItems(movieTitleList)
    
    
    ## Choose language:
    # label
    txt_choose_lang = utilities.getGuiTagContent(widgetGuiXML, "txt_choose_lang")
    chooseLangList = mc.ListItems()
    for index in range(1):
        chooseLangItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        chooseLangItem.SetLabel(txt_choose_lang + ": ")
        chooseLangList.append(chooseLangItem)
    mc.GetActiveWindow().GetList(529).SetItems(chooseLangList)
    
    # flags/lang code/none
    txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
    
    if(videoType == "trailer"):
        languagesList = mc.GetActiveWindow().GetList(509)
    elif(videoType == "movie"):
        languagesList = mc.GetActiveWindow().GetList(508)
    languages = languagesList.GetItems()
    langList = mc.ListItems()
    
    mc.GetActiveWindow().GetList(530).SetVisible(True)
    mc.GetActiveWindow().GetList(536).SetVisible(False)
    
    for index in range(len(languages)):
        langItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        
        languageCode = languages[index].GetLabel()
        langItem.SetLabel(languageCode)
        
        if(languageCode != txt_no_file_name_avilable):
            baseUrl = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("baseUrl")
            langItem.SetProperty("videoLangFlag", baseUrl + "flag_" + languageCode + ".png")
            # select first language
            if(index == 0):
                if(utilities.isViewster()):
                    langItem.SetProperty("checkBoxImg", "checkBox_active.png")
                elif(utilities.isHustler()):
                    langItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
                config.SetValue("videoLanguage", languageCode)
            else:
                langItem.SetProperty("checkBoxImg", "checkBox.png")
            
            try:
                breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_" + languageCode)
                langItem.SetProperty("breadCrumb", breadCrumb)
            except:
                pass
        # no available language
        else:
            mc.GetActiveWindow().GetList(530).SetVisible(False)
            noneList = mc.ListItems()
            for index in range(1):
                noneItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                noneItem.SetLabel(txt_no_file_name_avilable)
                noneList.append(noneItem)
            mc.GetActiveWindow().GetList(536).SetItems(noneList)
            mc.GetActiveWindow().GetList(536).SetVisible(True)
        
        langList.append(langItem)
    mc.GetActiveWindow().GetList(530).SetItems(langList)
    
    
    ## Choose subtitles:
    # reset subtitle language
    config.SetValue("subtitleLanguage", "")
    
    # label
    txt_choose_subtitle = utilities.getGuiTagContent(widgetGuiXML, "txt_choose_subtitle")
    chooseLangList = mc.ListItems()
    for index in range(1):
        chooseLangItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        chooseLangItem.SetLabel(txt_choose_subtitle + ": ")
        chooseLangList.append(chooseLangItem)
    mc.GetActiveWindow().GetList(532).SetItems(chooseLangList)
    
    # flags/lang code/none
    if(videoType == "trailer"):
        subtitleLanguagesList = mc.GetActiveWindow().GetList(513)
    elif(videoType == "movie"):
        subtitleLanguagesList = mc.GetActiveWindow().GetList(512)
    subtitleLanguages = subtitleLanguagesList.GetItems()
    subtitleLangList = mc.ListItems()
    
    mc.GetActiveWindow().GetList(533).SetVisible(True)
    mc.GetActiveWindow().GetList(535).SetVisible(False)
    
    for index in range(len(subtitleLanguages)):
        subtitleLangItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        if(videoType == "trailer"):
            subtitleLanguageCode = subtitleLanguages[index].GetLabel()
            if(subtitleLanguageCode != txt_no_file_name_avilable):
                baseUrl = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("baseUrl")
                subtitleLangItem.SetProperty("subtitleLangFlag", baseUrl + "flag_" + subtitleLanguageCode + ".png")
                
                # select first language
                if(index == 0):
                    if(utilities.isViewster()):
                        subtitleLangItem.SetProperty("checkBoxImg", "checkBox_active.png")
                    elif(utilities.isHustler()):
                        subtitleLangItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
                    config.SetValue("subtitleLanguage", subtitleLanguageCode)
                else:
                    subtitleLangItem.SetProperty("checkBoxImg", "checkBox.png")
                
                try:
                    breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_" + subtitleLanguageCode)
                    subtitleLangItem.SetProperty("breadCrumb", breadCrumb)
                except:
                    pass
            subtitleLangItem.SetLabel(subtitleLanguageCode)
        elif(videoType == "movie"):
            subtitleLanguageCode = subtitleLanguages[index].GetLabel()
            if(subtitleLanguageCode != txt_no_file_name_avilable):
                subtitleLangItem.SetProperty("subtitleLangFlag", subtitleLanguages[index].GetProperty("subtitleLangFlag"))
                
                # select first language
                if(index == 0):
                    if(utilities.isViewster()):
                        subtitleLangItem.SetProperty("checkBoxImg", "checkBox_active.png")
                    elif(utilities.isHustler()):
                        subtitleLangItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
                    config.SetValue("subtitleLanguage", subtitleLanguageCode)
                else:
                    subtitleLangItem.SetProperty("checkBoxImg", "checkBox.png")
                
                try:
                    breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_" + subtitleLanguageCode)
                    subtitleLangItem.SetProperty("breadCrumb", breadCrumb)
                except:
                    pass
            subtitleLangItem.SetLabel(subtitleLanguages[index].GetLabel())
        subtitleLangList.append(subtitleLangItem)
        
        if(subtitleLanguages[index].GetLabel() == txt_no_file_name_avilable):
            mc.GetActiveWindow().GetList(533).SetVisible(False)
            noneList = mc.ListItems()
            for index in range(1):
                noneItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                noneItem.SetLabel(txt_no_file_name_avilable)
                noneList.append(noneItem)
            mc.GetActiveWindow().GetList(535).SetItems(noneList)
            mc.GetActiveWindow().GetList(535).SetVisible(True)
    mc.GetActiveWindow().GetList(533).SetItems(subtitleLangList)
    
    
    # Watch buttons
    watchButtonsList = mc.ListItems()
    descriptionList = mc.ListItems()
    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    
    if(videoType == "trailer"):
        txt_watch_trailer = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_trailer")
        for index in range(1):
            watchButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            if(utilities.isViewster()):
                watchButtonItem.SetProperty("iconImg", "btnIcon_1.png")
            elif(utilities.isHustler()):
                watchButtonItem.SetProperty("iconImg", "btnIcon_1_pink.png")
            watchButtonItem.SetLabel(txt_watch_trailer)
            watchButtonItem.SetProperty("breadCrumb", txt_watch_trailer + " \"" + movieTitle + "\"")
            watchButtonItem.SetProperty("buttonType", "trailer")
            watchButtonItem.SetProperty("buttonDescription", "")
            watchButtonsList.append(watchButtonItem)
    
    elif(videoType == "movie"):
        buttonsNo = 0
        
        avod = mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("avod")
        fvod = mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("fvod")
        tvod = mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("tvod")
        svod = mc.GetActiveWindow().GetList(592).GetItem(0).GetProperty("svod")
        
        buttonsList = []
        if(tvod == "t"):
            buttonsNo = buttonsNo + 1
            buttonsList.append("watchForPrice")
        if(avod == "t" or fvod == "t"):
            buttonsNo = buttonsNo + 1
            buttonsList.append("watchForFree")
        if(svod == "t"):
            if(((config.GetValue("authenticatedUser") == "True") and (config.GetValue("subscription_status") == "f")) or (config.GetValue("authenticatedUser") == "False")):
                buttonsNo = buttonsNo + 1
                buttonsList.append("subscribe")
        if(config.GetValue("authenticatedUser") == "True" and config.GetValue("voucherValidity") == "t"):
            if(int(config.GetValue("remainingVoucherCredits")) >= 1):
                buttonsNo = buttonsNo + 1
                buttonsList.append("voucher")
        
        # watch for price / watch button
        def setWatchForPriceButton():
            buttonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            
            txt_watch = utilities.getGuiTagContent(widgetGuiXML, "txt_watch")
            
            if(utilities.isViewster()):
                buttonItem.SetProperty("iconImg", "btnIcon_1.png")
            elif(utilities.isHustler()):
                buttonItem.SetProperty("iconImg", "btnIcon_1_pink.png")
            operationMode = config.GetValue("operationMode")
            inSubscription = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("inSubscription")
            # free period or (user is authenticated and movie subscribed) or (user is authenticated and has subscription and movie in subscription)
            if(operationMode == "1" or (config.GetValue("authenticatedUser") == "True" and config.GetValue("movie_subscription_status") == "t") or (config.GetValue("authenticatedUser") == "True" and config.GetValue("subscription_status") == "t" and inSubscription == "t")):
                buttonItem.SetLabel(txt_watch)
                txt_rent_details = ""
            else:
                price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
                currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
                availability = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("availability")
                buttonItem.SetLabel(txt_watch + " " + price + " " + currency + " / " + availability)
                txt_rent_details = utilities.getGuiTagContent(widgetGuiXML, "txt_rent_details").replace("|MOVIE_PRICE|", price).replace("|MOVIE_CURRENCY|", currency).replace("|MOVIE_AVAILABILITY|", availability)
            buttonItem.SetProperty("buttonType", "rent")
            buttonItem.SetProperty("buttonDescription", txt_rent_details)
            
            buttonItem.SetProperty("breadCrumb", txt_watch + " \"" + movieTitle + "\"")
            
            return buttonItem
        
        # watch for free button
        def setWatchForFreeButton():
            buttonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            
            txt_watch = utilities.getGuiTagContent(widgetGuiXML, "txt_watch")
            
            if(utilities.isViewster()):
                buttonItem.SetProperty("iconImg", "btnIcon_1.png")
            elif(utilities.isHustler()):
                buttonItem.SetProperty("iconImg", "btnIcon_1_pink.png")
            
            txt_watch_free_details = ""
            if(avod == "t"):
                txt_watch_free_details = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_free_details")
                buttonItem.SetProperty("buttonType", "ad")
                txt_watch_free = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_free_with_ads")
            else:
                buttonItem.SetProperty("buttonType", "free")
                txt_watch_free = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_free")
            buttonItem.SetLabel(txt_watch_free)
            buttonItem.SetProperty("buttonDescription", txt_watch_free_details)
            
            buttonItem.SetProperty("breadCrumb", txt_watch + " \"" + movieTitle + "\"")
            
            return buttonItem
        
        # subscribe button
        def setSubscribeButton():
            buttonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            
            txt_subscribe = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
            txt_sbs_viewster = utilities.getGuiTagContent(widgetGuiXML, "txt_sbs_viewster")
            
            if(utilities.isViewster()):
                buttonItem.SetProperty("iconImg", "btnIcon_2.png")
            elif(utilities.isHustler()):
                buttonItem.SetProperty("iconImg", "btnIcon_2_pink.png")
            buttonItem.SetLabel(txt_subscribe)
            
            price = config.GetValue("subscription_price")
            currency = config.GetValue("subscription_currency")
            availability = utilities.getGuiTagContent(widgetGuiXML, "txt_subscription_availability")
            txt_subscribe_details = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe_details").replace("|SUBSCRIPTION_PRICE|", price).replace("|SUBSCRIPTION_CURRENCY|", currency).replace("|SUSBCRIPTION_AVAILABILITY|", availability)
            buttonItem.SetProperty("buttonType", "subscribe")
            buttonItem.SetProperty("buttonDescription", txt_subscribe_details)
            
            buttonItem.SetProperty("breadCrumb", txt_sbs_viewster)
            
            return buttonItem
        
        # use voucher button
        def setUseVoucherButton():
            buttonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            
            txt_watch = utilities.getGuiTagContent(widgetGuiXML, "txt_watch")
            txt_use_voucher = utilities.getGuiTagContent(widgetGuiXML, "txt_use_voucher")
            
            if(utilities.isViewster()):
                buttonItem.SetProperty("iconImg", "btnIcon_1.png")
            elif(utilities.isHustler()):
                buttonItem.SetProperty("iconImg", "btnIcon_1_pink.png")
            buttonItem.SetLabel(txt_use_voucher)
            txt_use_voucher_details = ""
            buttonItem.SetProperty("buttonType", "voucher")
            buttonItem.SetProperty("buttonDescription", txt_use_voucher_details)
            
            buttonItem.SetProperty("breadCrumb", txt_watch + " \"" + movieTitle + "\"")
            
            return buttonItem
        
        setButton = {
            "watchForPrice" : setWatchForPriceButton(),
            "watchForFree"  : setWatchForFreeButton(),
            "subscribe"     : setSubscribeButton(),
            "voucher"       : setUseVoucherButton()
        }
        
        for index in range(buttonsNo):
            watchButtonItem = setButton[buttonsList[index]]
            watchButtonsList.append(watchButtonItem)
    
    mc.GetActiveWindow().GetList(534).SetItems(watchButtonsList)
    
    mc.GetActiveWindow().GetControl(526).SetVisible(True)
    
    return True


#
# HIDE LOGIN POPUP
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def hideLoginPopup():
    if(mc.GetActiveWindow().GetControl(540).IsVisible()):
        config = mc.GetApp().GetLocalConfig()
        
        config.SetValue("returnToLoginPopupContent", "")
        config.SetValue("returnToInput", "")
        mc.GetActiveWindow().GetControl(540).SetVisible(False)
    
    return True


#
# HIDE CHOOSE LANGUAGE POPUP
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def hideChooseLanguagePopup():
    if(mc.GetActiveWindow().GetControl(526).IsVisible()):
        config = mc.GetApp().GetLocalConfig()
        
        config.SetValue("returnToChooseLangPopupContent", "")
        mc.GetActiveWindow().GetControl(526).SetVisible(False)
    
    return True


#
# HIDE REGISTER POPUP
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def hideRegisterPopup():
    if(mc.GetActiveWindow().GetControl(570).IsVisible()):
        config = mc.GetApp().GetLocalConfig()
        
        config.SetValue("returnToRegisterPopupContent", "")
        mc.GetActiveWindow().GetControl(570).SetVisible(False)
    
    return True


#
# HIDE CONFIRM PAYMENT POPUP
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def hideConfirmPaymentPopup():
    mc.GetActiveWindow().GetControl(610).SetVisible(False)
    
    return True


#
# HIDE MD POPUP CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def hide_MD_Popup_Content():
    hideChooseLanguagePopup()
    hideLoginPopup()
    hideConfirmPaymentPopup()
    hideRegisterPopup()
    hideAddFatoritesPopup()
    
    return True


#
# CLOSE MD POPUP 
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def closeMDPopup(mdButtonType, setFocus):
    config = mc.GetApp().GetLocalConfig()
    
    mdButtonIndex = getMDButtonIndex(mdButtonType)
    
    # close Choose language for trailer
    if(mdButtonType == "watchTrailer"):
        hideChooseLanguagePopup()
    # close Choose language for movie / Login popup
    elif(mdButtonType == "watchMovie"):
        hideChooseLanguagePopup()
        hideLoginPopup()
        hideRegisterPopup()
        hideConfirmPaymentPopup()
    # close Subscribe
    elif(mdButtonType == "subscribe"):
        hideLoginPopup()
        hideRegisterPopup()
        hideConfirmPaymentPopup()
    # close Add/Remove favorites
    elif(mdButtonType == "addFavorites"):
        hideLoginPopup()
        hideRegisterPopup()
        hideAddFatoritesPopup()
    
    # hide popup bg
    mc.GetActiveWindow().GetControl(525).SetVisible(False)
    
    unselectMovieDetailsButton(mdButtonIndex, mdButtonType)
    
    if(setFocus == True):
        # needed on back from player
        mdButtonsList = mc.GetActiveWindow().GetList(521)
        mdButtonsList.SetFocus()
        mdButtonsList.SetFocusedItem(mdButtonIndex)
    
    return True


#
# CLOSE ACTIVE MD POPUP 
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def closeActiveMDPopup():
    mdButtonsList = mc.GetActiveWindow().GetList(521).GetItems()
    
    for index in range(len(mdButtonsList)):
        if(mc.GetActiveWindow().GetList(521).GetItem(index).GetProperty("buttonSelected") == "True"):
            mdButtonType = mc.GetActiveWindow().GetList(521).GetItem(index).GetProperty("buttonType")
            closeMDPopup(mdButtonType, False)
    
    return True


#
# LOAD SMALL LOGIN POPUP CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadLoginPopupContent(popupType):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    ## Pay & Watch
    #if(popupType == "payAndWatch"):
    #    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    #    price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
    #    currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
    #    availability = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("availability")
    #    
    #    txt_rent_info = utilities.getGuiTagContent(widgetGuiXML, "txt_rent_info")
    #    loginTitle = txt_rent_info.replace("|MOVIE_TITLE|", movieTitle).replace("|PRICE|", price).replace("|CURRENCY|", currency).replace("|AVAILABILITY|", availability).replace("|br|","\n")
    #    
    #    # Short Login Popup Title
    #    loginTitleList = mc.ListItems()
    #    for index in range(1):
    #        loginTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    #        loginTitleItem.SetProperty("loginPopupTitle", loginTitle)
    #        loginTitleList.append(loginTitleItem)
    #    mc.GetActiveWindow().GetList(541).SetItems(loginTitleList)
    #    
    #    mc.GetActiveWindow().GetControl(541).SetVisible(True)
    #    mc.GetActiveWindow().GetControl(555).SetVisible(False)
    ## Subscribe
    #elif(popupType == "subscribe"):
    #    price = config.GetValue("subscription_price")
    #    currency = config.GetValue("subscription_currency")
    #    txt_subscription_availability = utilities.getGuiTagContent(widgetGuiXML, "txt_subscription_availability")
    #    loginTitle = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe_info").replace("|br|", "\n").replace("|PRICE|", price).replace("|CURRENCY|", currency).replace("|AVAILABILITY|", txt_subscription_availability)
    #    
    #    # Long Login Popup Title
    #    longLoginTitleList = mc.ListItems()
    #    for index in range(1):
    #        longLoginTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    #        longLoginTitleItem.SetLabel(loginTitle)
    #        longLoginTitleList.append(longLoginTitleItem)
    #    mc.GetActiveWindow().GetList(555).SetItems(longLoginTitleList)
    #    
    #    mc.GetActiveWindow().GetControl(541).SetVisible(False)
    #    mc.GetActiveWindow().GetControl(555).SetVisible(True)
    ## Add / Remove favorites
    #elif(popupType == "favorites"):
    #    # Short Login Popup Title
    #    loginTitleList = mc.ListItems()
    #    for index in range(1):
    #        loginTitleItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    #        loginTitleItem.SetProperty("loginPopupTitle", "")
    #        loginTitleList.append(loginTitleItem)
    #    mc.GetActiveWindow().GetList(541).SetItems(loginTitleList)
    #    
    #    mc.GetActiveWindow().GetControl(541).SetVisible(True)
    #    mc.GetActiveWindow().GetControl(555).SetVisible(False)
    
    # Email Address Label
    txt_email_add = utilities.getGuiTagContent(widgetGuiXML, "txt_email_add")
    emailAddressLabelList = mc.ListItems()
    for index in range(1):
        emailAddressLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        emailAddressLabelItem.SetLabel(txt_email_add)
        emailAddressLabelList.append(emailAddressLabelItem)
    mc.GetActiveWindow().GetList(543).SetItems(emailAddressLabelList)

    # Password Label
    txt_pass = utilities.getGuiTagContent(widgetGuiXML, "txt_pass")
    passwordLabelList = mc.ListItems()
    for index in range(1):
        passwordLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        passwordLabelItem.SetLabel(txt_pass)
        passwordLabelList.append(passwordLabelItem)
    mc.GetActiveWindow().GetList(546).SetItems(passwordLabelList)

    # Login Button
    #if(popupType == "payAndWatch"):
    #    txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_pay_watch")
    #elif(popupType == "subscribe"):
    #    txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
    #elif(popupType == "favorites"):
    #    txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_login")
    txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_login")
    loginButtonsList = mc.ListItems()
    for index in range(1):
        loginButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        loginButtonItem.SetLabel(txt_button)
        loginButtonsList.append(loginButtonItem)
    mc.GetActiveWindow().GetList(548).SetItems(loginButtonsList)
    
    # Remember me Button
    txt_remember = utilities.getGuiTagContent(widgetGuiXML, "txt_remember")
    rememberMeButtonList = mc.ListItems()
    for index in range(1):
        rememberMeButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        rememberMeButtonItem.SetLabel(txt_remember)
        if(config.GetValue("rememberMe") == "False"):
            rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox.png")
        elif(config.GetValue("rememberMe") == "True"):
            rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox_active.png")
        rememberMeButtonList.append(rememberMeButtonItem)
    mc.GetActiveWindow().GetList(549).SetItems(rememberMeButtonList)
    
    # Forgot your password label
    txt_forgot_q = utilities.getGuiTagContent(widgetGuiXML, "txt_forgot_q")
    forgotPassList = mc.ListItems()
    for index in range(1):
        forgotPassItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        forgotPassItem.SetLabel(txt_forgot_q)
        forgotPassList.append(forgotPassItem)
    mc.GetActiveWindow().GetList(550).SetItems(forgotPassList)
    
    # Don't have an account label
    txt_have_account_q = utilities.getGuiTagContent(widgetGuiXML, "txt_have_account_q")
    haveAccountList = mc.ListItems()
    for index in range(1):
        haveAccountItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        haveAccountItem.SetLabel(txt_have_account_q)
        haveAccountList.append(haveAccountItem)
    mc.GetActiveWindow().GetList(551).SetItems(haveAccountList)
    
    # Create account Button
    txt_create_acount = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount")
    createButtonsList = mc.ListItems()
    for index in range(1):
        createButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        createButtonItem.SetLabel(txt_create_acount)
        createButtonsList.append(createButtonItem)
    mc.GetActiveWindow().GetList(552).SetItems(createButtonsList)
    
    # Or create an account at.. label
    txt_create_acount_web = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount_web")
    if(utilities.isViewster()):
        txt_create_acount_web = txt_create_acount_web.replace("www.viewster.com", "[COLOR FFF8AC00]www.viewster.com[/COLOR]")
    elif(utilities.isHustler()):
        txt_create_acount_web = txt_create_acount_web.replace("http://hustler.viewster.tv", "[COLOR FFE13993]http://hustler.viewster.tv[/COLOR]")
    createAccountList = mc.ListItems()
    for index in range(1):
        createAccountItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        createAccountItem.SetLabel(txt_create_acount_web)
        createAccountList.append(createAccountItem)
    mc.GetActiveWindow().GetList(553).SetItems(createAccountList)
    
    ## Notification email Label
    #txt_notification_email = utilities.getGuiTagContent(widgetGuiXML, "txt_notification_email")
    #notificationLabelList = mc.ListItems()
    #for index in range(1):
    #    notificationLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    #    notificationLabelItem.SetLabel(txt_notification_email)
    #    notificationLabelList.append(notificationLabelItem)
    #mc.GetActiveWindow().GetList(552).SetItems(notificationLabelList)
    
    if(config.GetValue("authenticatedUser") == "True"):
        mc.GetActiveWindow().GetEdit(544).SetText(config.GetValue("emailAddress"))
        mc.GetActiveWindow().GetEdit(547).SetText(config.GetValue("password"))
        #mc.GetActiveWindow().GetEdit(553).SetText(config.GetValue("emailAddress"))
    else:
        mc.GetActiveWindow().GetEdit(544).SetText("")
        mc.GetActiveWindow().GetEdit(547).SetText("")
        #mc.GetActiveWindow().GetEdit(553).SetText("")
    
    ## Send Button
    #txt_send = utilities.getGuiTagContent(widgetGuiXML, "txt_send")
    #sendButtonsList = mc.ListItems()
    #for index in range(1):
    #    sendButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
    #    sendButtonItem.SetLabel(txt_send)
    #    sendButtonsList.append(sendButtonItem)
    #mc.GetActiveWindow().GetList(554).SetItems(sendButtonsList)
    
    #if(popupType == "payAndWatch"):
    #    txt_watch = utilities.getGuiTagContent(widgetGuiXML, "txt_watch")
    #    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    #    breadCrumb = txt_watch + " \"" + movieTitle + "\""
    #elif(popupType == "subscribe"):
    #    breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_sbs_viewster")
    #elif(popupType == "favorites"):
    #    breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_login")
    breadCrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_login")
    
    loginTypeList = mc.ListItems()
    for index in range(1):
        loginTypeItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        loginTypeItem.SetProperty("loginMaskType", popupType)
        loginTypeItem.SetLabel(breadCrumb)
        loginTypeList.append(loginTypeItem)
    mc.GetActiveWindow().GetList(556).SetItems(loginTypeList)
    
    if(popupType == "payAndWatch"):
        # set focus on email input
        mc.GetActiveWindow().GetControl(544).SetFocus()
    
    mc.GetActiveWindow().GetControl(540).SetVisible(True)
    
    return True


#
# LOAD REGISTER POPUP CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadRegisterPopup():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # Email Address Label
    txt_email_add = utilities.getGuiTagContent(widgetGuiXML, "txt_email_add")
    emailAddressLabelList = mc.ListItems()
    for index in range(1):
        emailAddressLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        emailAddressLabelItem.SetLabel(txt_email_add)
        emailAddressLabelList.append(emailAddressLabelItem)
    mc.GetActiveWindow().GetList(572).SetItems(emailAddressLabelList)
    
    # Password Label
    txt_pass = utilities.getGuiTagContent(widgetGuiXML, "txt_pass")
    passwordLabelList = mc.ListItems()
    for index in range(1):
        passwordLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        passwordLabelItem.SetLabel(txt_pass)
        passwordLabelList.append(passwordLabelItem)
    mc.GetActiveWindow().GetList(575).SetItems(passwordLabelList)
    
    # Repeat password Label
    txt_retype_pass = utilities.getGuiTagContent(widgetGuiXML, "txt_retype_pass")
    repeatPassLabelList = mc.ListItems()
    for index in range(1):
        repeatPassLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        repeatPassLabelItem.SetLabel(txt_retype_pass)
        repeatPassLabelList.append(repeatPassLabelItem)
    mc.GetActiveWindow().GetList(578).SetItems(repeatPassLabelList)
    
    # Create Acount Button
    txt_create_acount = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount")
    createAccountList = mc.ListItems()
    for index in range(1):
        createAccountItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        createAccountItem.SetLabel(txt_create_acount)
        createAccountList.append(createAccountItem)
    mc.GetActiveWindow().GetList(580).SetItems(createAccountList)
    
    # set breadCrumb text
    #txt_create_acount = utilities.getGuiTagContent(widgetGuiXML, "txt_create_acount")
    breadCrumbList = mc.ListItems()
    for index in range(1):
        breadCrumbItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        breadCrumbItem.SetLabel(txt_create_acount)
        breadCrumbList.append(breadCrumbItem)
    mc.GetActiveWindow().GetList(582).SetItems(breadCrumbList)
    
    # Remember me Button
    txt_remember = utilities.getGuiTagContent(widgetGuiXML, "txt_remember")
    rememberMeButtonList = mc.ListItems()
    for index in range(1):
        rememberMeButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        rememberMeButtonItem.SetLabel(txt_remember)
        if(config.GetValue("rememberMe") == "False"):
            rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox.png")
        elif(config.GetValue("rememberMe") == "True"):
            rememberMeButtonItem.SetProperty("checkBoxImg", "checkBox_active.png")
        rememberMeButtonList.append(rememberMeButtonItem)
    mc.GetActiveWindow().GetList(581).SetItems(rememberMeButtonList)
    
    # set focus on email input
    mc.GetActiveWindow().GetControl(573).SetFocus()
    
    mc.GetActiveWindow().GetControl(570).SetVisible(True)
    
    return True


#
# LOAD PAYMENT CONFIRMATION POPUP CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadPaymentConfirmationPopup(subscribe_section):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    watchButtonIndex = mc.GetActiveWindow().GetList(534).GetFocusedItem()
    focusedWatchButtonType = mc.GetActiveWindow().GetList(534).GetItem(watchButtonIndex).GetProperty("buttonType")
    
    if(subscribe_section == True):
        focusedWatchButtonType = "subscribe"
    
    # set Label
    
    if(focusedWatchButtonType == "rent"):
        movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
        price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
        currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
        availability = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("availability")
        
        txt_rent_info = utilities.getGuiTagContent(widgetGuiXML, "txt_rent_info")
        txt_label = txt_rent_info.replace("|br|", "\n").replace("|MOVIE_TITLE|", movieTitle).replace("|PRICE|", price). replace("|CURRENCY|", currency).replace("|AVAILABILITY|", availability)
    
    elif(focusedWatchButtonType == "voucher"):
        txt_voucher_credits = utilities.getGuiTagContent(widgetGuiXML, "txt_voucher_credits")
        txt_voucher_validity = utilities.getGuiTagContent(widgetGuiXML, "txt_voucher_validity")
        txt_label = txt_voucher_credits + " " + config.GetValue("remainingVoucherCredits") + "/" + config.GetValue("availableVoucherCredits") + "\n" + txt_voucher_validity + " " + config.GetValue("voucherValidityDate")
    
    elif(focusedWatchButtonType == "subscribe"):
        price = config.GetValue("subscription_price")
        currency = config.GetValue("subscription_currency")
        txt_subscription_availability = utilities.getGuiTagContent(widgetGuiXML, "txt_subscription_availability")
        
        txt_subscribe_info = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe_info")
        txt_label = txt_subscribe_info.replace("|br|", "\n").replace("|PRICE|", price).replace("|CURRENCY|", currency).replace("|AVAILABILITY|", txt_subscription_availability)
    
    
    paymentLabelList = mc.ListItems()
    for index in range(1):
        paymentLabelItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        paymentLabelItem.SetLabel(txt_label)
        paymentLabelList.append(paymentLabelItem)
    mc.GetActiveWindow().GetList(611).SetItems(paymentLabelList)
    
    # Payment Confirmation button
    if(focusedWatchButtonType == "rent"):
        txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_pay_watch")
        
        txt_watch  = utilities.getGuiTagContent(widgetGuiXML, "txt_watch")
        movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
        txt_breadcrumb = txt_watch + " \"" + movieTitle + "\""
        
    elif(focusedWatchButtonType == "voucher"):
        txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_use_credit_watch")
        txt_breadcrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_watch_with_voucher")
        
    elif(focusedWatchButtonType == "subscribe"):
        txt_button = utilities.getGuiTagContent(widgetGuiXML, "txt_subscribe")
        txt_breadcrumb = utilities.getGuiTagContent(widgetGuiXML, "txt_sbs_viewster")
    
    paymentButtonList = mc.ListItems()
    for index in range(1):
        paymentButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        paymentButtonItem.SetLabel(txt_button)
        paymentButtonItem.SetProperty("buttonType", focusedWatchButtonType)
        paymentButtonItem.SetProperty("breadCrumb", txt_breadcrumb)
        paymentButtonList.append(paymentButtonItem)
    mc.GetActiveWindow().GetList(612).SetItems(paymentButtonList)
    
    # set focus on payment confirmation button
    focusList = mc.GetActiveWindow().GetList(612)
    focusList.SetFocus()
    focusList.SetFocusedItem(0)
    
    mc.GetActiveWindow().GetControl(610).SetVisible(True)
    
    return True


#
# LOAD ADD / REMOVE FAVORITES POPUP CONTENT
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def loadAddRemoveFavoritePopupContent():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # Add / Remove label
    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    if(config.GetValue("movieFavoriteStatus") == "f"):
        text = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav_q").replace("|MOVIE_TITLE|", movieTitle)
    else:
        text = utilities.getGuiTagContent(widgetGuiXML, "txt_remove_fav_q").replace("|MOVIE_TITLE|", movieTitle)
    textList = mc.ListItems()
    for index in range(1):
        textItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        textItem.SetLabel(text)
        textList.append(textItem)
    mc.GetActiveWindow().GetList(561).SetItems(textList)
    
    # OK button
    txt_ok = utilities.getGuiTagContent(widgetGuiXML, "txt_ok")
    okButtonsList = mc.ListItems()
    for index in range(1):
        okButtonItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        okButtonItem.SetLabel(txt_ok)
        okButtonsList.append(okButtonItem)
    mc.GetActiveWindow().GetList(562).SetItems(okButtonsList)
    
    # md button has no focus (coming from login popup )
    if(not mc.GetActiveWindow().GetControl(521).HasFocus()):
        # set focus on OK button
        okList = mc.GetActiveWindow().GetList(562)
        okList.SetFocus()
        okList.SetFocusedItem(0)
    
    mc.GetActiveWindow().GetControl(560).SetVisible(True)
    
    return True


#
# SET ADD/REMOVE FAVORITE POPUP LABEL
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def setFavoritePopupTextLabel(favoriteStatus):
    widgetGuiXML = utilities.loadGuiXML()
    
    textList = mc.GetActiveWindow().GetList(561)
    textItem = textList.GetItem(0)
    
    movieTitle = mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle")
    if(favoriteStatus == "t"):
        text = utilities.getGuiTagContent(widgetGuiXML, "txt_remove_fav_q").replace("|MOVIE_TITLE|", movieTitle)
    else:
        text = utilities.getGuiTagContent(widgetGuiXML, "txt_add_fav_q").replace("|MOVIE_TITLE|", movieTitle)
    
    textItem.SetLabel(text)
    
    return True


#
# HIDE ADD / REMOVE FAVORITES POPUP
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def hideAddFatoritesPopup():
    if(mc.GetActiveWindow().GetControl(560).IsVisible()):
        mc.GetActiveWindow().GetControl(560).SetVisible(False)
    
    return True


###
#####
### PLAYER
#####
###


def getPlayer():
    global _player
    try:
        if not _player :
            _player = ViewsterPlayer()
            #_player = mc.Player(True)
    except:
        _player = ViewsterPlayer()
        #_player = mc.Player(True)
    return _player
    

class ViewsterPlayer(mc.Player):
    
    def __init__(self):
        mc.Player.__init__(self, True)
        
        self.last = self.GetLastPlayerEvent() # Returns the last event that occured in the player. - int
        self.call = {
            self.EVENT_NEXT_ITEM    :   self.callbackNextItem,
            self.EVENT_STOPPED      :   self.callbackStopped, # 1
            self.EVENT_ENDED        :   self.callbackEnded,
            self.EVENT_STARTED      :   self.callbackStarted, # 3
            self.EVENT_NONE         :   self.callbackNone
            }
        self.videoStarted = False
        
        self.playType = ""
        self.currentAdTime = 0
        
        self.playlistPosition = -1
        self.adType = ""
        self.prerollIndex = -1
        self.midrollIndex = 0 # -1 
        self.postrollIndex = 0 # -1 
        self.adIndex = -1
    

    # Event Monitor    
    #def eventStart(self, playlist):
    def eventStart(self):
        import xbmc
        config = mc.GetApp().GetLocalConfig()
        
        while True:
            event = self.GetLastPlayerEvent()
            if event != self.last:
                if event in self.call.keys():
                    self.last = event
                    self.call[event]()
                    if event in [self.EVENT_ENDED, self.EVENT_STOPPED]:
                    #if event in [self.EVENT_STOPPED]:# !!! todo - check if ev ended and playlist ended to
                        break
            xbmc.sleep(1000)
            
            
            # BACK from DIALOG WAIT
            currentWindowId = utilities.getCurrentWindowId()
            if(currentWindowId == "14000"):                             # current windowid == 14000
            #if(mc.GetWindow(14000).GetControl(500).IsVisible()):# Movie Details content visible
                if(str(self.IsPlaying()) == "False"):                   # the video is not playing currently
                    if(self.videoStarted == False):                     # the video did not started to play yet
                        mc.GetWindow(14000).GetList(521).Refresh()
                        self.Stop()
                        break
            
            
            ## stop the player on back
            ## chek if playback started + CurrentControl is first md button + CurrentWindow is not Fullscreen video or Progress dialog
            ## if focus is o player menu currentWindow is "", the same happens when "Watch Trailer" is on focus
            #if(self.IsPlaying() or self.IsPaused() and event == 3):
            #    label = mc.GetInfoString("System.CurrentControl")
            #    currentWindow = mc.GetInfoString("System.CurrentWindow")
            #    if(label == config.GetValue("fistMDButtonLabel") and currentWindow != "Fullscreen video" and currentWindow != "Progress dialog"):
            #        self.Stop()
            
            # BACK from PLAYER
            if(self.videoStarted == True):                                      # the video did already started to play
                currentWindowId = utilities.getCurrentWindowId()
                #if(mc.GetWindow(14000).GetControl(500).IsVisible()):# Movie Details content visible
                if(currentWindowId == "14000"):                                 # current windowid == 14000   
                    self.Stop()
            
            
            # MOVIE
            if(config.GetValue("videoType") == "movie" and config.GetValue("authenticatedUser") == "True" and config.GetValue("playbackContent") == "movie"):
                # playback started and IsPlaying
                if(self.IsPlaying() and event == 3):
                    # stop playback if PlayHeartbeat status is stop
                    if(config.GetValue("stopMovie") == "True"):
                        self.Stop()
                    # report play position at every 60 secs
                    else:
                        import time
                        
                        currentTime = str(int(self.GetTime())*1000)
                        config.SetValue("movieCurrentTime", currentTime)
                        time = time.time()
                        
                        if(time > float(config.GetValue("realTime")) + 61):
                            #config.SetValue("movieReportTime", currentTime)
                            config.SetValue("realTime", str(time))
                            wscalls.WSPlayHeartbeat(currentTime, "True")
            
            elif(self.playType == "movie_with_ads" and config.GetValue("playbackContent") == "movie"):
                # check for available midrolls
                if(self.adIndex + 1 < int(config.GetValue("preRolls")) + int(config.GetValue("midRolls"))):
                    playlistSize = playlist.Size()
                    if(playlistSize == self.playlistPosition+1):
                        #mc.ShowDialogOk("","get mr")
                        adCallPath = config.GetValue("adCallPath")
                        wscalls.GetAd(adCallPath)
                        
                        adItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
                        adPath = wscalls.MyAd[self.adIndex + 1].adUrl
                        adItem.SetPath(adPath)
                        adItem.SetReportToServer(False)
                        #adItem.SetContentType("url")
                        adItem.SetContentType("video/mp4")
                        
                        playlist.Add(adItem)
                   
                    if(config.GetValue("realTime") != "0"):
                        import time
                        # check if time to play ad
                        time = time.time()
                        #mc.ShowDialogOk(str(time), str(float(config.GetValue("realTime"))) + "+" + str(int(config.GetValue("midRollInterval"))))
                        if(time > float(config.GetValue("realTime")) + int(config.GetValue("midRollInterval"))):
                            # save movie current time
                            currentTime = str(int(self.GetTime())*1000)
                            config.SetValue("movieCurrentTime", currentTime)
                            self.adType = "midroll"
                            self.PlayNext()
                            #mc.ShowDialogOk("after PlayNext","")
                            #mc.ShowDialogOk("","test here")
                            self.playlistPosition = self.playlistPosition + 1
                            config.SetValue("playbackContent", "ad")
                            
                            if(wscalls.MyAd[self.adIndex].previousReportPosition != 100):
                                wscalls.MyAd[self.adIndex].reportAdPlay(100)
                            
                            self.adIndex += 1
            
            # AD
            elif(self.playType == "movie_with_ads" and config.GetValue("playbackContent") == "ad"):
                #mc.GetPlayer().LockPlayerAction(mc.GetPlayer().XAPP_PLAYER_ACTION_STOP) # not working
                #mc.GetPlayer().LockPlayerAction(mc.GetPlayer().XAPP_PLAYER_ACTION_NEXT)
                #mc.GetPlayer().LockPlayerAction(mc.GetPlayer().XAPP_PLAYER_ACTION_PREV)
                
                if(self.IsPaused() or self.IsRewinding() or self.IsForwarding()): # not working
                    #mc.ShowDialogOk("IsPaused/IsRewinding/IsForwarding", "")
                    self.SeekTime(self.currentAdTime)
                
                if(self.IsPlaying() and event == 3):
                    # report ad play (to smartclip)
                    # movie
                    if(playlist.GetPosition() == int(config.GetValue("preRolls")) or playlist.GetPosition() == 4):
                        mc.ShowDialogOk("test#","test#")
                        pass
                    # ads
                    else:
                        try:
                            currentTime = self.GetTime()
                            self.currentAdTime = currentTime
                            totalTime = self.GetTotalTime()
                            adProgress = int((currentTime*100)/totalTime)
                            wscalls.MyAd[self.adIndex].reportAdPlay(adProgress)
                        except:
                            pass
                    
                    # preroll ad
                    if(self.adType == "preroll"):
                       
                        playlistSize = playlist.Size()
                        
                        # get new ad & add it to playlist
                        if(playlistSize < int(config.GetValue("preRolls"))):
                            adCallPath = config.GetValue("adCallPath")
                            wscalls.GetAd(adCallPath)
                            
                            adItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
                            adPath = wscalls.MyAd[self.adIndex + 1].adUrl
                            adItem.SetPath(adPath)
                            adItem.SetReportToServer(False)
                            #adItem.SetContentType("url")
                            adItem.SetContentType("video/mp4")
                            
                            playlist.Add(adItem)
                        
                        # add movie to playlist
                        elif(playlistSize == int(config.GetValue("preRolls"))):
                            playlist.Add(videoItem)
                    
                    elif(self.adType == "midroll"):
                        #mc.ShowDialogOk("midroll", "test")
                        playlist.Add(videoItem)
                    #elif(self.adType == "postroll"):
        
        return True
    
    
    def callbackNextItem(self):
        #mc.ShowDialogOk("", "callbackNextItem")
        pass
    
    
    def callbackStopped(self):
        #mc.ShowDialogOk("", "callbackStopped")
        
        # report movie Stop position
        config = mc.GetApp().GetLocalConfig()
        
        if(config.GetValue("videoType") == "movie" and config.GetValue("authenticatedUser") == "True" and config.GetValue("playbackContent") == "movie"):
            currentTime = config.GetValue("movieCurrentTime")
            wscalls.WSPlayHeartbeat(currentTime, "False")
        
        return True
    
    
    def callbackEnded(self):
        #import xbmc
        
        config = mc.GetApp().GetLocalConfig()
        if(config.GetValue("videoType") == "movie" and config.GetValue("playbackContent") == "ad"):
            if(self.playlistPosition + 1 >= int(config.GetValue("preRolls"))):
                config.SetValue("playbackContent", "movie")
                config.SetValue("realTime", "0")
        
        #if(config.GetValue("videoType") == "movie" and config.GetValue("playbackContent") == "ad"):
        #    self.playlistPosition = self.playlistPosition + 1
        #    #mc.ShowDialogOk("playlistPosition", str(self.playlistPosition))
        #    
        #    # ad
        #    if(self.playlistPosition + 1 <= int(config.GetValue("preRolls"))):
        #        #mc.ShowDialogOk("prerolls not finished","true")
        #        if(wscalls.MyAd[self.adIndex].previousReportPosition != 100):
        #            wscalls.MyAd[self.adIndex].reportAdPlay(100)
        #        
        #        self.adIndex += 1
        #        self.prerollIndex += 1
        #        #mc.ShowDialogOk("prep ad","finished")
        #        
        #    # movie
        #    elif(self.playlistPosition + 1 > int(config.GetValue("preRolls"))):
        #        #mc.ShowDialogOk("prerolls finished","true")
        #        if(wscalls.MyAd[self.adIndex].previousReportPosition != 100):
        #            wscalls.MyAd[self.adIndex].reportAdPlay(100)
        #        
        #        self.adType = "midroll"
        #        config.SetValue("playbackContent", "movie")
        #        #mc.ShowDialogOk("playbackContent", "movie")
        #        
        #    config.SetValue("realTime", "0") 
        
        #xbmc.sleep(3000)
        
        pass
    
    
    def callbackStarted(self):
        #mc.ShowDialogOk("", "callbackStarted")
        import time
        
        self.videoStarted = True
        
        config = mc.GetApp().GetLocalConfig()
        
        if(config.GetValue("videoType") == "trailer"):
            movieID = config.GetValue("playMovieID")
            # report trailer play
            wscalls.WSAction("trailerplay", str(movieID))
        
        #elif(config.GetValue("videoType") == "movie" and config.GetValue("authenticatedUser") == "True" and config.GetValue("playbackContent") == "movie"):
        elif(self.playType == "movie_play" and config.GetValue("authenticatedUser") == "True"):
            # resume if needed
            movieStart = config.GetValue("movieStart")
            #config.SetValue("movieReportTime", "0")
            if(movieStart == "resume"):
                resume_time = float(config.GetValue("resume_time"))/1000
                self.SeekTime(resume_time)
                resume_time = str(resume_time)
                #config.SetValue("movieReportTime", resume_time)
            
            # save start time
            time = time.time()
            config.SetValue("realTime", str(time))
        
        elif(self.playType == "movie_with_ads" and config.GetValue("playbackContent") == "movie"):
            mc.ShowDialogOk("start", "movie")
            
            # save start time
            time = time.time()
            config.SetValue("realTime", str(time))
            
            self.playlistPosition = self.playlistPosition + 1
            #if(wscalls.MyAd[self.adIndex].previousReportPosition != 100): # !!! uncomment & move this
            #    wscalls.MyAd[self.adIndex].reportAdPlay(100)
            
        
        elif(self.playType == "movie_with_ads" and config.GetValue("playbackContent") == "ad"):
            mc.ShowDialogOk("start", "ad")
            self.playlistPosition = self.playlistPosition + 1
            
            # ad
            if(self.playlistPosition + 1 <= int(config.GetValue("preRolls"))):
                #if(self.playlistPosition != 0): # !!! uncomment & move this
                #    if(wscalls.MyAd[self.adIndex].previousReportPosition != 100):
                #        wscalls.MyAd[self.adIndex].reportAdPlay(100)
                
                self.adIndex += 1
                self.prerollIndex += 1
        
        
        return True
    
    
    def callbackNone(self):
        #mc.ShowDialogOk("", "callbackNone")
        pass
    
    
    def isPlayingAd(self):
        if(self.playType == "movie_with_ads" and config.GetValue("playbackContent") == "ad"):
            return True
        else:
            return False
    
    
    def isPlayingMovie(self):
        if((self.playType == "movie_with_ads" or self.playType == "movie_play") and config.GetValue("playbackContent") == "movie"):
            return True
        else:
            return False


#class AdPlayer(mc.Player):    
#    playerState = 1
#    prevPlayerState = 1
#    PLAYER_STOPPED = 1
#    PLAYER_PLAYING = 2
#    PLAYER_PAUSED = 4
#    PLAYER_FORWARDING = 8
#    PLAYER_REWINDING = 16
#    PLAYER_SEEKING = 32
#    
#    def __init__(self):
#	mc.Player.__init__(self)
#    
#    def updatePlayerState(self):
#        while (self.__class__.playerState != 1 or (self.__class__.playerState == 1 and self.__class__.prevPlayerState == 1)):
#            prev_state = self.__class__.playerState
#            self.__class__.prevPlayerState = prev_state
#            
#            state = 0
#            
#            if self.IsPaused():
#                currentTime = self.GetTime()
#                state = self.__class__.PLAYER_PAUSED
#                mc.ShowDialogNotification("cheater " + str(currentTime))
#                self.SeekTime(currentTime)
#                
#            elif self.IsPlaying():
#                state = self.__class__.PLAYER_PLAYING
#            
#            #elif self.IsForwarding():                      # not fired at all, but ffw or rw = pause + play
#            #    state = self.__class__.PLAYER_FORWARDING
#            #elif self.IsRewinding():
#            #    state = self.__class__.PLAYER_REWINDING
#            
#            #elif self.IsCaching():                         # this is not working at all + but crashes the working ones
#            #    state = self.__class__.PLAYER_SEEKING
#            
#            else:
#                state = self.__class__.PLAYER_STOPPED
#            
#            #if(state != prev_state):
#            #    mc.ShowDialogOk("", str(state))
#            
#            self.__class__.playerState = state


#
# PLAY TRAILER
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def playTrailer(langListId):
    config = mc.GetApp().GetLocalConfig()
    
    config.SetValue("videoType", "trailer")
    
    videoLanguage = config.GetValue("videoLanguage")
    #videoLanguageList = mc.GetActiveWindow().GetList(530)
    #videoLanguageList = mc.GetActiveWindow().GetList(509)
    videoLanguageList = mc.GetActiveWindow().GetList(langListId)
    
    for index in range(len(videoLanguageList.GetItems())):
        if(videoLanguage == videoLanguageList.GetItem(index).GetLabel()):
            moviePath = mc.GetActiveWindow().GetList(593).GetItem(index).GetProperty("trailerURL")
            if(moviePath == "trailersecurelinktrailersecurelink"):
                # get trailer url
                movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
                response = wscalls.WSAction("trailersecurelink", str(videoLanguage) + "|" + str(movieID))
            else:
                response = True
    
    if(response == True):
        moviePath = mc.GetActiveWindow().GetList(593).GetItem(index).GetProperty("trailerURL")
        movieType = "Trailer"
        
        playVideo(moviePath, movieType, "")
    
    return True


#
# PLAY VIDEO
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def playVideo(moviePath, movieType, payMethod):
    config = mc.GetApp().GetLocalConfig()
    
    if(payMethod == "adv"):
        playWithAds = True
    else:
        playWithAds = False
    
    if(movieType == "Trailer"):
        videoItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_TRAILER)
        closeMDPopup("watchTrailer", True)
    
    elif(movieType == "Movie"):
        global videoItem
        videoItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_FEATURE_FILM)
        closeMDPopup("watchMovie", True)
        
        if(playWithAds == True):
            adItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
            #adPath = config.GetValue("ad_url")
            adPath = wscalls.MyAd[0].adUrl
            adItem.SetPath(adPath)
            adItem.SetReportToServer(False)
            adItem.SetContentType("video/mp4")
    
    #videoItem.SetReportToServer(False)
    videoItem.SetReportToServer(True)
    videoItem.SetAddToHistory(False)
    videoItem.SetEnableRecommend(True)
    videoItem.SetPath(moviePath)

    #synopsis = mc.GetActiveWindow().GetList(518).GetItem(0).GetDescription()
    #videoItem.SetDescription(synopsis, False)
    movieTitle = str(mc.GetActiveWindow().GetList(504).GetItem(0).GetProperty("movieTitle"))
    videoItem.SetLabel(movieTitle)
    
    videoItem.SetContentType("video/mp4")
    
    if(utilities.isViewster()):
        externalItem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
        watch_on_viewster = "Watch Free Movies on Viewster:"
        externalItem.SetTitle(watch_on_viewster + " " + movieTitle)
        externalItem.SetPath(config.GetValue("share_url_web"))
        videoItem.SetExternalItem(externalItem)
    
    global playlist
    playlist = mc.PlayList(mc.PlayList.PLAYLIST_VIDEO)
    playlist.Clear()
    
    movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
    config.SetValue("playMovieID", movieID)
    
    #config.SetValue("fistMDButtonLabel", mc.GetActiveWindow().GetList(521).GetItem(0).GetLabel())
    
    player = getPlayer()
    #player = MyPlayer()
    
    #player.LockPlayerAction(player.XAPP_PLAYER_ACTION_NONE)
    #player.LockPlayerAction(player.XAPP_PLAYER_ACTION_NEXT)
    #player.LockPlayerAction(player.XAPP_PLAYER_ACTION_PREV)
    #player.LockPlayerAction(player.XAPP_PLAYER_ACTION_STOP)
    
    
    #config.SetValue("playbackContent", "")
    #if(playWithAds == True and movieType == "Movie"):
    #    playlist.Add(adItem)
    #    config.SetValue("playbackContent", "ad")
    #    player.playlistPosition = -1
    #    player.adType = "preroll"
    #    player.prerollIndex = -1
    #    player.adIndex = -1
    #    player.playType = "movie_with_ads"
    #elif(playWithAds == False and movieType == "Movie"):
    #    config.SetValue("playbackContent", "movie")
    #    player.playType = "movie_play"
    ## !!! set playType for trailers
    
    config.SetValue("playbackContent", "movie")
    player.playType = "movie_play"
    
    #if(playWithAds == False):
    #    playlist.Add(videoItem)
    ##playlist.Add(adItem)
    
    playlist.Add(videoItem)
    
    #player.Play(playlist.GetItem(0))
    playlist.Play(0)
    
    #player.Play(videoItem)
    
    player.videoStarted = False
    #player.eventStart(playlist)
    player.eventStart()
    
    #adPlayer.Play(playlist.GetItem(0))
    #adPlayer.updatePlayerState()
    
    return True


#
# MOVIE DETAILS BUTTON   - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def movieDetailsButtonOnClick():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    appName = config.GetValue("appName")
    
    mdButtonsList = mc.GetActiveWindow().GetList(521)
    focusedButtonIndex = mdButtonsList.GetFocusedItem()
    focusedButtonItem = mdButtonsList.GetItem(focusedButtonIndex)
    
    if(focusedButtonItem.GetProperty("buttonSelected") == "True"):
        mdButtonType = mdButtonsList.GetItem(focusedButtonIndex).GetProperty("buttonType")
        closeMDPopup(mdButtonType, False)
    
    else:
        focusedButtonType = mdButtonsList.GetItem(focusedButtonIndex).GetProperty("buttonType")
        
        # Watch Trailer
        if(focusedButtonType == "watchTrailer"):
            utilities.resetVideoLanguages()
            
            #hideChooseLanguagePopup()
            #hideLoginPopup()
            #hideAddFatoritesPopup()
            
            hide_MD_Popup_Content()
            
            videoLanguagesList = mc.GetActiveWindow().GetList(509)
            videoLanguages = videoLanguagesList.GetItems()
            
            subtitleLanguagesList = mc.GetActiveWindow().GetList(513)
            subtitleLanguages = subtitleLanguagesList.GetItems()
            
            if(len(videoLanguages) == 1 and len(subtitleLanguages) == 1):
                closeActiveMDPopup()
                
                txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
                videoLanguageCode = videoLanguages[0].GetLabel()
                subtitleLanguageCode = subtitleLanguages[0].GetLabel()
                if(videoLanguageCode != txt_no_file_name_avilable):
                    config.SetValue("videoLanguage", videoLanguageCode)
                    if(subtitleLanguageCode != txt_no_file_name_avilable):
                        config.SetValue("subtitleLanguage", subtitleLanguageCode)
                    #playTrailer()
                    playTrailer(509)
                # else: no trailer available
            else:
                setSelectedMovieDetailsButton()
                mc.GetActiveWindow().GetControl(525).SetVisible(True)
                config.SetValue("videoType", "trailer")
                loadChooseLanguagePopupContent("trailer")
        
        
        # Watch Movie / Watch Episodes
        elif(focusedButtonType == "watchMovie"):
            utilities.resetVideoLanguages()
            
            hasEpisodes = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("hasEpisodes")
            
            # hide visible popups
            #hideChooseLanguagePopup()
            #hideLoginPopup()
            #hideAddFatoritesPopup()
            
            hide_MD_Popup_Content()
            mc.GetActiveWindow().GetControl(525).SetVisible(False)
            
            for index in range(len(mc.GetActiveWindow().GetList(521).GetItems())):
                buttonType = mc.GetActiveWindow().GetList(521).GetItem(index).GetProperty("buttonType")    
                #unselectMovieDetailsButton(index, focusedButtonType)
                unselectMovieDetailsButton(index, buttonType)
            
            # Watch Movie / Watch Episode
            if(hasEpisodes == "0"):
                #for index in range(len(mc.GetActiveWindow().GetList(521).GetItems())):
                #    buttonType = mc.GetActiveWindow().GetList(521).GetItem(index).GetProperty("buttonType")    
                #    #unselectMovieDetailsButton(index, focusedButtonType)
                #    unselectMovieDetailsButton(index, buttonType)
                
                user_authenticated = False  # 1.
                language_condition = False  # 2.
                
                # 1.
                if(config.GetValue("authenticatedUser") == "True"):
                    user_authenticated = True
                
                # 2.
                txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
                
                videoLanguages = mc.GetActiveWindow().GetList(508).GetItems()
                subtitleLanguages = mc.GetActiveWindow().GetList(512).GetItems()
                
                if(len(videoLanguages) == 1 and len(subtitleLanguages) == 1):
                    videoLanguageCode = videoLanguages[0].GetLabel()
                    subtitleLanguageCode = subtitleLanguages[0].GetLabel()
                    
                    if(videoLanguageCode != txt_no_file_name_avilable):
                        language_condition = True
                
                if(user_authenticated and language_condition):
                    config.SetValue("videoType", "movie")
                    inSubscription = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("inSubscription")
                    if((config.GetValue("movie_subscription_status") == "t") or ((config.GetValue("subscription_status") == "t" and inSubscription == "t"))):
                        config.SetValue("videoLanguage", videoLanguageCode)
                        if(subtitleLanguageCode != txt_no_file_name_avilable):
                            config.SetValue("subtitleLanguage", subtitleLanguageCode)
                        
                        movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
                        price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
                        currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
                        
                        wscalls.WSPay("movierent", "web", movieID, price, currency)
                    else:
                        setSelectedMovieDetailsButton()
                        mc.GetActiveWindow().GetControl(525).SetVisible(True)
                        loadChooseLanguagePopupContent("movie")
                        
                else:
                    setSelectedMovieDetailsButton()
                    mc.GetActiveWindow().GetControl(525).SetVisible(True)
                    config.SetValue("videoType", "movie")
                    loadChooseLanguagePopupContent("movie")
            
            # Watch Episodes
            else:
                #for index in range(len(mc.GetActiveWindow().GetList(521).GetItems())):
                #    buttonType = mc.GetActiveWindow().GetList(521).GetItem(index).GetProperty("buttonType")    
                #    #unselectMovieDetailsButton(index, focusedButtonType)
                #    unselectMovieDetailsButton(index, buttonType)
                
                mc.GetActiveWindow().PushState()
                utilities.hideAllContent()
                config.SetValue("currentMovieListContent", "Episodes")
                movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
                criteria = "e:" + movieID
                grid.loadMovieGrid(criteria, "0", "18")
        
        
        # Subscribe
        elif(focusedButtonType == "subscribe"):
            #hideChooseLanguagePopup()
            #hideLoginPopup()
            #hideAddFatoritesPopup()
            hide_MD_Popup_Content()
            
            #if(config.GetValue("authenticatedUser") == "False" or (config.GetValue("authenticatedUser") == "True" and config.GetValue("subscription_status") == "f")):
            if(config.GetValue("authenticatedUser") == "False"):    
                setSelectedMovieDetailsButton()
                mc.GetActiveWindow().GetControl(525).SetVisible(True)
                loadLoginPopupContent("subscribe")
            else:
                if (config.GetValue("subscription_status") == "f"):
                    setSelectedMovieDetailsButton()
                    mc.GetActiveWindow().GetControl(525).SetVisible(True)
                    loadPaymentConfirmationPopup(True)
                else:
                    for index in range(len(mc.GetActiveWindow().GetList(521).GetItems())):
                        buttonType = mc.GetActiveWindow().GetList(521).GetItem(index).GetProperty("buttonType")
                        if(buttonType != "subscribe"):
                            unselectMovieDetailsButton(index, buttonType)
                    
                    mc.GetActiveWindow().GetControl(525).SetVisible(False)
                    txt_already_subscribed = utilities.getGuiTagContent(widgetGuiXML, "txt_already_subscribed").replace("|br||br|"," ")#.replace("|br||br|","\n")
                    mc.ShowDialogOk(appName, txt_already_subscribed)
        
        
        # Add/Remove favorites
        else:
            #hideChooseLanguagePopup()
            #hideLoginPopup()
            #hideAddFatoritesPopup()
            hide_MD_Popup_Content()
            
            setSelectedMovieDetailsButton()
            mc.GetActiveWindow().GetControl(525).SetVisible(True)
            if(config.GetValue("authenticatedUser") == "False"):
                loadLoginPopupContent("favorites")
            else:
                loadAddRemoveFavoritePopupContent()
    
    return True


#
# MOVIE DETAILS     - ON DOWN -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def MD_OnDown(control_ID):
    widgetGuiXML = utilities.loadGuiXML()
    
    # MD Buttons
    if(control_ID == 521):
        nextlist = mc.GetActiveWindow().GetList(524)
        if(len(nextlist.GetItems()) > 0):
            nextlist.SetFocus()
            nextlist.SetFocusedItem(0)
    
    #
    # choose language popup
    #
    
    # video language button
    elif(control_ID == 530):
        txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
        
        # try to set focus on subtitle language button
        nextlist = mc.GetActiveWindow().GetList(533)
        if(nextlist.GetItem(0).GetLabel() != txt_no_file_name_avilable):
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(focusedItem)
        # set focus on watch button
        else:
            nextlist = mc.GetActiveWindow().GetList(534)
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(focusedItem)
    # subtitle language button
    elif(control_ID == 533):
        # set focus on watch button
        nextlist = mc.GetActiveWindow().GetList(534)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(focusedItem)
    
    #
    # login popup
    #
    
    ## login button
    #elif(control_ID == 548):
    #    nextlist = mc.GetActiveWindow().GetList(554)
    #    focusedItem = nextlist.GetFocusedItem()
    #    nextlist.SetFocus()
    #    nextlist.SetFocusedItem(int(focusedItem))
    
    # Forgot your password button
    elif(control_ID == 550):
        nextlist = mc.GetActiveWindow().GetList(552)
        nextlist.SetFocus()
        nextlist.SetFocusedItem(0)
    
    
    return True


#
# MOVIE DETAILS     - ON UP -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def MD_OnUp(control_ID):
    widgetGuiXML = utilities.loadGuiXML()
    
    #
    # choose language popup
    #
    
    # subtitle buttons
    if(control_ID == 533):
        txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
        # try to set focus on video language button
        nextlist = mc.GetActiveWindow().GetList(530)
        if(nextlist.GetItem(0).GetLabel() != txt_no_file_name_avilable):
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(focusedItem)
    # watch button
    elif(control_ID == 534):
        txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
        
        if(utilities.isViewster()):
            # try to set focus on first subtitle language button
            nextlist = mc.GetActiveWindow().GetList(533)
            if(nextlist.GetItem(0).GetLabel() != txt_no_file_name_avilable):
                focusedItem = nextlist.GetFocusedItem()
                nextlist.SetFocus()
                nextlist.SetFocusedItem(focusedItem)
            # try to set focus on first video language button
            else:
                nextlist = mc.GetActiveWindow().GetList(530)
                if(nextlist.GetItem(0).GetLabel() != txt_no_file_name_avilable):
                    focusedItem = nextlist.GetFocusedItem()
                    nextlist.SetFocus()
                    nextlist.SetFocusedItem(focusedItem)
    
    #
    # login popup
    #
    
    # forgot your password button
    elif(control_ID == 550):
        nextlist = mc.GetActiveWindow().GetList(549)
        nextlist.SetFocus()
        nextlist.SetFocusedItem(0)
    # Create account button
    elif(control_ID == 552):
        nextlist = mc.GetActiveWindow().GetList(550)
        nextlist.SetFocus()
        nextlist.SetFocusedItem(0)
    
    ## send button
    #elif(control_ID == 554):
    #    nextlist = mc.GetActiveWindow().GetList(548)
    #    focusedItem = nextlist.GetFocusedItem()
    #    nextlist.SetFocus()
    #    nextlist.SetFocusedItem(int(focusedItem))
    
    return True


#
# MOVIE DETAILS     - ON RIGHT -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def MD_OnRight(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    # synopsis
    if(control_ID == 518):
        list_ID = config.GetValue("returnToMdRightContent")
        if(list_ID != ""):
            nextlist = mc.GetActiveWindow().GetList(int(list_ID))
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(focusedItem)
        # set focus on first movie details button (mouse navigation)
        else:
            nextlist = mc.GetActiveWindow().GetList(521)
            nextlist.SetFocus()
            nextlist.SetFocusedItem(0)
    
    #
    # choose language popup
    #
    
    # video language button, subtitle language button, watch button
    elif((control_ID == 530) or (control_ID == 533) or (control_ID == 534)):
        config.SetValue("returnToChooseLangPopupContent", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(521)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # login popup
    #
    
    # email input / password input / remember me button / forgot your password button / create account button
    elif((control_ID == 544) or (control_ID == 547) or (control_ID == 549) or (control_ID == 550) or (control_ID == 552)):
        config.SetValue("returnToInput", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(548)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    ## notification email input
    #elif(control_ID == 553):
    #    config.SetValue("returnToInput", str(control_ID))
    #    nextlist = mc.GetActiveWindow().GetList(554)
    #    focusedItem = nextlist.GetFocusedItem()
    #    nextlist.SetFocus()
    #    nextlist.SetFocusedItem(int(focusedItem))
    # login button, send button
    elif((control_ID == 548)):# or (control_ID == 554)
        config.SetValue("returnToLoginPopupContent", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(521)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # add / remove favorites popup  AND  payment confirmation popup
    #
    
    # ok button
    elif((control_ID == 562) or (control_ID == 612)):
        nextlist = mc.GetActiveWindow().GetList(521)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    #
    # create account popup
    #
    
    # email input / password input / repeat password input / remember me button / create account
    elif((control_ID == 573) or (control_ID == 576) or (control_ID == 579) or (control_ID == 581) or (control_ID == 580)):
        config.SetValue("returnToRegisterPopupContent", str(control_ID))
        nextlist = mc.GetActiveWindow().GetList(521)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    
    return True


#
# MOVIE DETAILS     - ON LEFT -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def MD_OnLeft(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    # movie details button
    if(control_ID == 521):
        
        # login popup visible
        if(mc.GetActiveWindow().GetControl(540).IsVisible()):
            list_ID = config.GetValue("returnToLoginPopupContent")
            if(list_ID == ""):
                list_ID = 548
            nextlist = mc.GetActiveWindow().GetList(int(list_ID))
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(focusedItem)
        
        # choose language popup visible
        elif(mc.GetActiveWindow().GetControl(526).IsVisible()):
            list_ID = config.GetValue("returnToChooseLangPopupContent")
            if(list_ID == ""):
                txt_no_file_name_avilable = utilities.getGuiTagContent(widgetGuiXML, "txt_no_file_name_avilable")
                
                if(utilities.isViewster()):
                    # try to set focus on video language button
                    nextlist = mc.GetActiveWindow().GetList(530)
                    if(nextlist.GetItem(0).GetLabel() != txt_no_file_name_avilable):
                        list_ID = 530
                    else:
                        # try to set focus on subtitle language button
                        nextlist = mc.GetActiveWindow().GetList(533)
                        if(nextlist.GetItem(0).GetLabel() != txt_no_file_name_avilable):
                            list_ID = 533
                        else:
                            # set focus on watch button
                            list_ID = 534
                elif(utilities.isHustler()):
                    # set focus on watch button
                    list_ID = 534
            
            nextlist = mc.GetActiveWindow().GetList(int(list_ID))
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(focusedItem)
        
        # add / remove favorites popup visible
        elif(mc.GetActiveWindow().GetControl(560).IsVisible()):
            # set focus on OK button
            nextlist = mc.GetActiveWindow().GetList(562)
            nextlist.SetFocus()
            nextlist.SetFocusedItem(0)
        
        # register popup visible
        elif(mc.GetActiveWindow().GetControl(570).IsVisible()):
            list_ID = config.GetValue("returnToRegisterPopupContent")
            if(list_ID == ""):
                list_ID = 573
            mc.GetActiveWindow().GetControl(int(list_ID)).SetFocus()
        
        # payment confirmation popup visible
        elif(mc.GetActiveWindow().GetControl(610).IsVisible()):
            nextlist = mc.GetActiveWindow().GetList(612)
            nextlist.SetFocus()
            nextlist.SetFocusedItem(0)
        
        # no popup visible
        else:
            config.SetValue("returnToMdRightContent", str(control_ID))
            # synopsis
            mc.GetActiveWindow().GetControl(518).SetFocus()
    
    # similar movie button (focus goes to synopsis)
    elif(control_ID == 524):
        if((not mc.GetActiveWindow().GetControl(526).IsVisible()) and (not mc.GetActiveWindow().GetControl(540).IsVisible()) and (not mc.GetActiveWindow().GetControl(560).IsVisible())):
            config.SetValue("returnToMdRightContent", str(control_ID))
            mc.GetActiveWindow().GetControl(518).SetFocus()
    
    #
    # login popup
    #
    
    # login button
    elif(control_ID == 548):
        control_ID = config.GetValue("returnToInput")
        if(control_ID != ""):
            mc.GetActiveWindow().GetControl(int(control_ID)).SetFocus()
        else:
            mc.GetActiveWindow().GetControl(544).SetFocus()
    
    return True


#
# MOVIE DETAILS     - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #   
def MD_OnClick(control_ID):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    appName = config.GetValue("appName")
    
    
    # similar movies list
    if(control_ID == 524):
        mc.GetActiveWindow().GetControl(500).SetVisible(False)
        
        similarMovieList = mc.GetActiveWindow().GetList(524)
        similarMovieListItem = similarMovieList.GetItem(similarMovieList.GetFocusedItem())
        loadMovieDetails(similarMovieListItem.GetProperty("id"))
    
    
    #
    # choose language popup
    #
    
    # video language buttons
    elif(control_ID == 530):
        langList = mc.GetActiveWindow().GetList(control_ID)
        focusedLangIndex = langList.GetFocusedItem()
        focusedLangItem = langList.GetItem(focusedLangIndex)
        
        for index in range(len(langList.GetItems())):
            if(index != focusedLangIndex):
                langList.GetItem(index).SetProperty("checkBoxImg", "checkBox.png")
            else:
                if(utilities.isViewster()):
                    focusedLangItem.SetProperty("checkBoxImg", "checkBox_active.png")
                elif(utilities.isHustler()):
                    focusedLangItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
                languageCode = langList.GetItem(index).GetLabel()
                config.SetValue("videoLanguage", languageCode)
    
    # subtitle language buttons
    elif(control_ID == 533):
        langList = mc.GetActiveWindow().GetList(control_ID)
        focusedLangIndex = langList.GetFocusedItem()
        focusedLangItem = langList.GetItem(focusedLangIndex)
        
        for index in range(len(langList.GetItems())):
            if(index != focusedLangIndex):
                langList.GetItem(index).SetProperty("checkBoxImg", "checkBox.png")
            else:
                if(utilities.isViewster()):
                    focusedLangItem.SetProperty("checkBoxImg", "checkBox_active.png")
                elif(utilities.isHustler()):
                    focusedLangItem.SetProperty("checkBoxImg", "h_checkBox_active.png")
                languageCode = langList.GetItem(index).GetLabel()
                config.SetValue("subtitleLanguage", languageCode)
    
    # watch buttons list
    elif(control_ID == 534):
        focusedItemIndex = mc.GetActiveWindow().GetList(control_ID).GetFocusedItem()
        focusedButtonType = mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).GetProperty("buttonType")
        
        # trailer
        if(config.GetValue("videoType") == "trailer"):
            if(focusedButtonType == "trailer"):
                #playTrailer()
                playTrailer(530)
        # movie
        elif(config.GetValue("videoType") == "movie"):
            movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
            price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
            currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
            
            if(focusedButtonType == "rent"):
                authenticatedUser = config.GetValue("authenticatedUser")
                if(authenticatedUser == "True"):
                    # movie purchased
                    inSubscription = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("inSubscription")
                    if((config.GetValue("authenticatedUser") == "True" and config.GetValue("movie_subscription_status") == "t") or (config.GetValue("authenticatedUser") == "True" and config.GetValue("subscription_status") == "t" and inSubscription == "t")):
                        wscalls.WSPay("movierent", "web", movieID, price, currency)
                    # movie not purchased yet
                    else:
                        hideChooseLanguagePopup()
                        
                        loadPaymentConfirmationPopup(False)
                else:
                    hideChooseLanguagePopup()
                    loadLoginPopupContent("payAndWatch")
            
            elif(focusedButtonType == "ad"):
                # !!! TO DO !!!
                wscalls.WSPay("movierent", "adv", movieID, price, currency)
            
            elif(focusedButtonType == "free"):
                wscalls.WSPay("movierent", "fre", movieID, price, currency)
            
            elif(focusedButtonType == "subscribe"):
                authenticatedUser = config.GetValue("authenticatedUser")
                if(authenticatedUser == "True"):
                    hideChooseLanguagePopup()
                    
                    loadPaymentConfirmationPopup(False)
                else:
                    hideChooseLanguagePopup()
                    loadLoginPopupContent("payAndWatch")
            
            elif(focusedButtonType == "voucher"):
                hideChooseLanguagePopup()
                
                loadPaymentConfirmationPopup(False)
    
    
    #
    # login popup (& remember me button from register popup)
    #
    
    # login button
    elif(control_ID == 548):
        username = str(mc.GetActiveWindow().GetEdit(544).GetText())
        password = str(mc.GetActiveWindow().GetEdit(547).GetText())
        if(len(username) == 0):
            txt_email_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_email_not_set")
            mc.ShowDialogOk(appName, txt_email_not_set)
        elif(len(password) == 0):
            txt_pass_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_pass_not_set")
            mc.ShowDialogOk(appName, txt_pass_not_set)
        else:
            wscalls.WSInitLogin(username, password, "false", 549)
    
    # remember me button (from login popup or register popup)
    elif((control_ID == 549) or (control_ID == 581)):
        focusedItemIndex = mc.GetActiveWindow().GetList(control_ID).GetFocusedItem()
        checkBoxImg = mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).GetProperty("checkBoxImg")
        if(checkBoxImg == "checkBox.png"):
            if(utilities.isViewster()):
                mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "checkBox_active.png")
            elif(utilities.isHustler()):
                mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "h_checkBox_active.png")
        else:
            mc.GetActiveWindow().GetList(control_ID).GetItem(focusedItemIndex).SetProperty("checkBoxImg", "checkBox.png")
    
    # forgot your password button
    elif(control_ID == 550):
        options.loadInputPopup("fpwd_moviedetails")
    
    # create account button
    elif(control_ID == 552):
        hide_MD_Popup_Content()
        loadRegisterPopup()
        
    ## send button
    #elif(control_ID == 554):
    #    username = mc.GetActiveWindow().GetEdit(553).GetText()
    #    wscalls.WSUserAction(username, "", "fpwd")
    
    
    #
    # payment confirmation popup
    #
    
    # pay & watch button
    elif(control_ID == 612):
        movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
        price = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("price")
        currency = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("currency")
        
        buttonType = mc.GetActiveWindow().GetList(control_ID).GetItem(0).GetProperty("buttonType")
        
        if(buttonType == "rent"):
            wscalls.WSPay("movierent", "web", movieID, price, currency)
        elif(buttonType == "voucher"):
            wscalls.WSPay("movievoucher", "web", movieID, price, currency)
        elif(buttonType == "subscribe"):
            price = config.GetValue("subscription_price")
            currency = config.GetValue("subscription_currency")
            wscalls.WSPay("subscribe", "web", "", price, currency)
            
            if(config.GetValue("subscription_status") == "t"):
                # close popup
                hide_MD_Popup_Content()
                mc.GetActiveWindow().GetControl(525).SetVisible(False)
                for index in range(len(mc.GetActiveWindow().GetList(521).GetItems())):
                    buttonType = mc.GetActiveWindow().GetList(521).GetItem(index).GetProperty("buttonType")    
                    unselectMovieDetailsButton(index, buttonType)
                
                nextlist = mc.GetActiveWindow().GetList(521)
                focusedItem = nextlist.GetFocusedItem()
                nextlist.SetFocus()
                nextlist.SetFocusedItem(int(focusedItem))
                
                # grey out subscribe button
                mdButtonIndex = getMDButtonIndex("subscribe")
                tryToGrayOutMDButton(mdButtonIndex, "subscribe")
    
    #
    # register account popup
    #
    
    # create account button
    elif(control_ID == 580):
        username = str(mc.GetActiveWindow().GetEdit(573).GetText())
        password_1 = str(mc.GetActiveWindow().GetEdit(576).GetText())
        password_2 = str(mc.GetActiveWindow().GetEdit(579).GetText())
        
        if(username == ""):
            txt_email_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_email_not_set")
            mc.ShowDialogOk(appName, txt_email_not_set)
        elif(password_1 == "" or password_2 == ""):
            txt_pass_not_set = utilities.getGuiTagContent(widgetGuiXML, "txt_pass_not_set")
            mc.ShowDialogOk(appName, txt_pass_not_set)
        elif(password_1 != password_2):
            txt_pass_not_match = utilities.getGuiTagContent(widgetGuiXML, "txt_pass_not_match")
            mc.ShowDialogOk(appName, txt_pass_not_match)
        else:
            wscalls.WSUserAction(username, password_1, "registeraccount")
    
    
    #
    # add / remove favorite popup
    #
    
    # ok button
    elif(control_ID == 562):
        username = config.GetValue("emailAddress")
        password = config.GetValue("password")
        movieID = mc.GetActiveWindow().GetList(591).GetItem(0).GetProperty("movieID")
        if(config.GetValue("movieFavoriteStatus") == "t"):
            wscalls.WSUserAction(username, password, "favr:" + movieID)
        else:
            wscalls.WSUserAction(username, password, "fava:" + movieID)
    
    return True