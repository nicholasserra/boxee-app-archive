import mc

# VIEWSTER Librarys
import grid
import utilities
import search
import favorites


#
# LOAD MAIN MENU
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def loadMenu():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    menu0 = utilities.getGuiTagContent(widgetGuiXML, "txt_highlights")  
    menu1 = utilities.getGuiTagContent(widgetGuiXML, "txt_specials") 
    menu2 = utilities.getGuiTagContent(widgetGuiXML, "txt_genre")
    
    # VIEWSTER APP
    if(utilities.isViewster()):
        menu3 = utilities.getGuiTagContent(widgetGuiXML, "txt_favorites")
        menu4 = utilities.getGuiTagContent(widgetGuiXML, "txt_free") 
        menu5 = utilities.getGuiTagContent(widgetGuiXML, "txt_search") 
        menu6 = utilities.getGuiTagContent(widgetGuiXML, "txt_options")
        
        menuArray = [ menu0, menu1, menu2, menu3, menu4, menu5, menu6 ]
    
    # HUSTLER APP
    elif(utilities.isHustler()):
        menu3 = utilities.getGuiTagContent(widgetGuiXML, "txt_search") 
        menu4 = utilities.getGuiTagContent(widgetGuiXML, "txt_options")
        
        menuArray = [ menu0, menu1, menu2, menu3, menu4 ]
    
    menuList = mc.ListItems()
    
    for menuElem in menuArray:
        menuItem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        menuItem.SetLabel(str(menuElem))
        menuItem.SetProperty("breadCrumb", str(menuElem))
        menuList.append(menuItem)
    
    mc.GetActiveWindow().GetList(200).SetItems(menuList)
    
    mc.GetActiveWindow().GetControl(200).SetVisible(True)
    
    return True


#
# SET SELECTED MENU BUTTON
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def setSelectedMenuButton():
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    menuList = mc.GetActiveWindow().GetList(200)
    focusedItemIndex = menuList.GetFocusedItem()
    focusedMenuItem = menuList.GetItem(focusedItemIndex)

    for index in range(len(menuList.GetItems())):
        label = menuList.GetItem(index).GetProperty("breadCrumb")
        if(index != focusedItemIndex):
            menuList.GetItem(index).SetImage(0, "")
            menuList.GetItem(index).SetLabel('[COLOR white]' + label + '[/COLOR]')
        else:
            # VIEWSTER APP
            if(utilities.isViewster()):
                focusedMenuItem.SetImage(0, "menuButtonSelectedBg.png")
                focusedMenuItem.SetLabel('[COLOR FFF8AC00]' + label + '[/COLOR]')
            # HUSTLER APP
            elif(utilities.isHustler()):
                focusedMenuItem.SetImage(0, "h_menuButtonSelectedBg.png")
                focusedMenuItem.SetLabel('[COLOR FFE13993]' + label + '[/COLOR]')
    
    return True


#
# SET MENU BUTTON SELECTED
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def setMenuButtonSelected(buttonIndex):
    config = mc.GetApp().GetLocalConfig()
    
    widgetGuiXML = utilities.loadGuiXML()
    
    menuList = mc.GetActiveWindow().GetList(200)

    for index in range(len(menuList.GetItems())):
        label = menuList.GetItem(index).GetProperty("breadCrumb")
        if(index != buttonIndex):
            menuList.GetItem(index).SetImage(0, "")
            menuList.GetItem(index).SetLabel('[COLOR white]' + label + '[/COLOR]')
        else:
            # VIEWSTER APP
            if(utilities.isViewster()):
                menuList.GetItem(index).SetImage(0, "menuButtonSelectedBg.png")
                menuList.GetItem(index).SetLabel('[COLOR FFF8AC00]' + label + '[/COLOR]')
            # HUSTLER APP
            elif(utilities.isHustler()):
                menuList.GetItem(index).SetImage(0, "h_menuButtonSelectedBg.png")
                menuList.GetItem(index).SetLabel('[COLOR FFE13993]' + label + '[/COLOR]')
    return True


#
# MENU BUTTON - ON CLICK -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def menuButtonOnClick():
    config = mc.GetApp().GetLocalConfig()
    
    setSelectedMenuButton()
    
    menuList = mc.GetActiveWindow().GetList(200)
    focusedItemIndex = menuList.GetFocusedItem()
    
    utilities.hideAllContent()
    
    config.SetValue("previousScreenContent", "menu")
    
    # Highlights
    if(focusedItemIndex == 0):
        config.SetValue("currentMovieListContent", "Highlights")
        criteria = utilities.GetCriteria()
        grid.loadMovieGrid(criteria, "0", "18")
    
    # Specials
    elif(focusedItemIndex == 1):
        config.SetValue("currentMovieListContent", "Specials")
        criteria = utilities.GetCriteria()
        grid.loadMovieGrid(criteria, "0", "18")
    
    # Genre
    elif(focusedItemIndex == 2):
        config.SetValue("currentMovieListContent", "Genres")
        criteria = utilities.GetCriteria()
        grid.loadMovieGrid(criteria, "0", "18")
    
    # Favorites(VIEWSTER APP) / Search(HUSTLER APP)
    elif(focusedItemIndex == 3):
        if(utilities.isViewster()):
            favorites.loadFavoritesContent()
        elif(utilities.isHustler()):
            search.loadSearchContent()
    
    # Free(VIEWSTER APP) / Options(HUSTLER APP)
    elif(focusedItemIndex == 4):
        if(utilities.isViewster()):
            config.SetValue("currentMovieListContent", "Free")
            criteria = utilities.GetCriteria()
            grid.loadMovieGrid(criteria, "0", "18")
        elif(utilities.isHustler()):
            config.SetValue("currentMovieListContent", "Options")
            criteria = "Options"
            if(config.GetValue("init_svod") == "t"):
                optionsNo = "5"
            else:
                optionsNo = "4"
            grid.loadMovieGrid(criteria, "0", optionsNo)
    
    # Search(VIEWSTER APP)
    elif(focusedItemIndex == 5):
        if(utilities.isViewster()):
            search.loadSearchContent()
    
    # Options(VIEWSTER APP)
    elif(focusedItemIndex == 6):
        if(utilities.isViewster()):
            config.SetValue("currentMovieListContent", "Options")
            criteria = "Options"
            optionsNo = 8
            
            if(config.GetValue("init_svod") == "t"):
                pass
            elif(config.GetValue("init_svod") == "f"):
                optionsNo = optionsNo - 1
            
            grid.loadMovieGrid(criteria, "0", str(optionsNo))
    
    return True


#
# MAIN MENU BUTTON - ON DOWN -
# # # # # # # # # # # # # # # # # # # # # # # # # # # #
def menuButtonOnDown():
    config = mc.GetApp().GetLocalConfig()
    
    # FrontPage content visible
    if(mc.GetActiveWindow().GetControl(300).IsVisible()):
        nextlist = mc.GetActiveWindow().GetList(301)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    # Grid content visible
    elif(mc.GetActiveWindow().GetControl(400).IsVisible()):
        nextlist = mc.GetActiveWindow().GetList(401)
        if(len(nextlist.GetItems()) > 0):
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(int(focusedItem))
    # Movie Details content visible
    elif(mc.GetActiveWindow().GetControl(500).IsVisible()):
        nextlist = mc.GetActiveWindow().GetList(521)
        nextlist.SetFocus()
        nextlist.SetFocusedItem(0)
    # Favorites content visible
    elif(mc.GetActiveWindow().GetControl(600).IsVisible()):
        config.SetValue("previousScreenContent", "grid")
        nextlist = mc.GetActiveWindow().GetList(601)
        if(len(nextlist.GetItems()) > 0):
            focusedItem = nextlist.GetFocusedItem()
            nextlist.SetFocus()
            nextlist.SetFocusedItem(int(focusedItem))
    # Search content visible
    elif(mc.GetActiveWindow().GetControl(700).IsVisible()):
        control_ID = config.GetValue("returnToSearchContent")
        mc.GetActiveWindow().GetControl(int(control_ID)).SetFocus()
    # Help content visible
    elif(mc.GetActiveWindow().GetControl(1100).IsVisible()):
        nextlist = mc.GetActiveWindow().GetList(1107)
        nextlist.SetFocus()
        nextlist.SetFocusedItem(0)
    # Language content visible
    elif(mc.GetActiveWindow().GetControl(1200).IsVisible()):
        nextlist = mc.GetActiveWindow().GetList(1203)
        focusedItem = nextlist.GetFocusedItem()
        nextlist.SetFocus()
        nextlist.SetFocusedItem(int(focusedItem))
    # Login content visible
    elif(mc.GetActiveWindow().GetControl(1300).IsVisible()):
        control_ID = config.GetValue("returnToLoginContent")
        if(control_ID != ""):
            mc.GetActiveWindow().GetControl(int(control_ID)).SetFocus()
        else:
            mc.GetActiveWindow().GetControl(1304).SetFocus()
    # Parental Control content visible
    elif(mc.GetActiveWindow().GetControl(1400).IsVisible()):
        control_ID = config.GetValue("returnToParentalControlContent")
        #mc.GetActiveWindow().GetControl(int(control_ID)).SetFocus()
        nextlist = mc.GetActiveWindow().GetList(int(control_ID))
        nextlist.SetFocus()
        nextlist.SetFocusedItem(0)
    # Payment Confirmation(big) content visible
    elif(mc.GetActiveWindow().GetControl(1800).IsVisible()):
        if(mc.GetActiveWindow().GetControl(1802).IsVisible()):
            nextlist = mc.GetActiveWindow().GetList(int(1802))
            nextlist.SetFocus()
            nextlist.SetFocusedItem(0)
    # Register(big) content visible
    elif(mc.GetActiveWindow().GetControl(1900).IsVisible()):
        mc.GetActiveWindow().GetControl(1903).SetFocus()
    # My Voucher content visible
    elif(mc.GetActiveWindow().GetControl(2000).IsVisible()):
        mc.GetActiveWindow().GetControl(2002).SetFocus()
    
    return True