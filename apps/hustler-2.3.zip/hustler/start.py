import mc
from utilities import initAppVariables

# initialize App variables
initAppVariables()

# nedded on consecutive re/starts of Viewster app (without restarting boxee)
mc.GetWindow(14000).ClearStateStack(False)

params = mc.Parameters()
params["windowId"] = "14000"
mc.GetApp().ActivateWindow(14000, params)