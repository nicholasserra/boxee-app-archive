# definitions
# look-up table of control ids related to a pageview

DEFAULT = 0
SPLASH_ID = 14001
LOGIN_ID = 14000 
WINDOW_ID = 14002
NAV_SEARCH_ID = 300
NAV_QUEUE_ID = 304
SIDEBAR_ID = 6000
SIDEBAR_FILTER_ID = 6101
SEARCH_INPUT_ID = 8310
LIST_OPTIONS_ID = 5000
QUEUE_ID = 8430
SIDEBAR_CONTAINER = 6000

# player behavior
STREAM_RETRY_LIMIT = 3
STREAM_FAILURE_LIMIT = 10
STREAM_WAIT_CLOCK = 30
HIDDEN_QUEUE_ID = 10000
HIDDEN_CONTEXT_ID = 11000
HIDDEN_NORESULTS_INFO_ID = 12000
HIDDEN_PLAYLISTART_ID = 13000

USER_INFO = 8601

API_DELEGATE = 'https://api.grooveshark.com/boxee.php'

#  0 View = Control Group for page elements
#  1 Side = Sidebar
#  2 Ctrl   = Page Controls
#  3 List   = Main list that's getting populated for the page
#  4 Cont   = Content = Item that the focus should go to on the page
#  5 Ntab   = Navigation Tab
#  6 PCID   = ID of the page control that focus should land on
#  7 Desc   = Page Context
#  8 Sort   = ID of sort grouplist
#  9 Show   = ID that focus should land on when going from filter down
# 10 ShID   = Default 'Show' ID to be selected
# 11 SoID   = Default 'Sort' ID to be selected
# 12 Last   = Last ID on the list, so that going up from filter loops around
# 13 PLArt  = Playlist Art, the list used for showing the 4-albm thumb
# 14 AArt   = Album Art, the img ID for individual albums
# 15 ACList = Autocomplete List to be populated with autocompleteSearchResults
  
definitions = {              #(View, Side, Ctrl, List, Cont, Tab, PCID, Desc, Sort, Show, ShID, SoID, Last, PLArt, AArt, ACList)
  'Blank':                    (   0,    0,    0,    0,    0,   0,    0,    0,    0,    0,    0,    0,    0,     0,    0,    0),
  
  'Search':                   (8300,    0,    0,    0, 8310, 300,    0,    0,    0,    0,    0,    0,    0,     0,    0, 8320),
   
  'NowPlaying':               (8400,    0,    0, 8430,  851, 305,    0, 8429,    0,    0,    0,    0,    0,     0,    0,    0),
  'EmptyNowPlaying':          (8500,    0,    0,    0, 8520, 305,    0,    0,    0,    0,    0,    0,    0,     0,    0, 8530),
  
  
  'LibrarySongs':             (8000, 1100, 5100, 8010, 8010, 301,  161, 8001, 6710, 6610, 6611, 6711, 6714,     0,    0,    0),
  'LibraryAlbums':            (8000, 1100,    0, 8010, 8010, 301,    0, 8001, 7750, 6610, 6614, 7751, 7753,     0,    0,    0),
  'LibraryArtists':           (8100, 1100,    0, 8110, 8110, 301,    0, 8001, 6720, 6610, 6613, 6721, 6722,     0,    0,    0),
  'LibraryFavorites':         (8000, 1100, 5100, 8010, 8010, 301,  161, 8001, 6730, 6610, 6612, 6731, 6734,     0,    0,    0),
  'LibraryAlbumSongs':        (8700,    0, 5100, 8710, 8710, 301,  161, 8001,    0,    0,    0,    0,    0,     0, 8722,    0),
  
  'EmptyLibrary':             (8500,    0,    0,    0, 8520, 301,    0,    0, 6710, 6610,    0,    0, 6714,     0,    0, 8530),
  'EmptyLibraryFavorites':    (8500, 1100,    0,    0, 8520, 301,    0,    0, 6730, 6610,    0,    0, 6734,     0,    0, 8530),
  
  
  'SearchSongs':              (8000, 1600, 5100, 8010, 8010, 300,  161, 8001, 6790, 6660, 6661, 6791, 6794,     0,    0,    0),
  'SearchAlbums':             (8000, 1600,    0, 8010, 8010, 300,  161, 8001, 6760, 6660, 6662, 6761, 6763,     0,    0,    0),
  'SearchArtists':            (8100, 1600,    0, 8110, 8110, 300,    0, 8001, 6770, 6660, 6663, 6771, 6772,     0,    0,    0),
  'SearchPlaylists':          (8100, 1600,    0, 8110, 8110, 300,    0, 8001, 6780, 6660, 6664, 6781, 6782,     0,    0,    0),
  
  'EmptySearchSongs':         (8500, 1600,    0,    0, 8520, 300,    0,    0, 6790, 6660, 6661, 6791, 6794,     0,    0, 8530),
  'EmptySearchAlbums':        (8500, 1600,    0,    0, 8520, 300,    0,    0, 6760, 6660, 6662, 6761, 6763,     0,    0, 8530),
  'EmptySearchArtists':       (8500, 1600,    0,    0, 8520, 300,    0,    0, 6770, 6660, 6663, 6771, 6772,     0,    0, 8530),
  'EmptySearchPlaylists':     (8500, 1600,    0,    0, 8520, 300,    0,    0, 6770, 6660, 6664, 6781, 6782,     0,    0, 8530),
  
  'PopularToday':             (8000, 2200, 5100, 8010, 8010, 304,  161, 8001, 7720, 7620, 7621, 7721, 7724,     0,    0,    0),
  'PopularMonth':             (8000, 2200, 5100, 8010, 8010, 304,  161, 8001, 7720, 7620, 7622, 7721, 7724,     0,    0,    0),
  
  'AlbumSongs':               (8700,    0, 5100, 8710, 8710, 301,  161, 8001,    0,    0,    0,    0,    0,     0, 8722,    0),
  'LibraryArtistAlbums':      (8000, 1100,    0, 8010, 8010, 301,    0, 8001, 7750, 6610, 6614, 7751, 7753,     0,    0,    0),
  'ArtistAlbums':             (8000, 1400, 5100, 8010, 8010, 300,  161, 8001, 7740, 6640, 6641,    0, 7741,     0,    0,    0),
  'ArtistSongs':              (8000, 1400, 5100, 8010, 8010, 301,  161, 8001, 6740, 6640, 6642,    0, 6743,     0,    0,    0),
  
  'AllPlaylists':             (8100, 1500,    0, 8110, 8110, 302,    0, 8001, 6750, 6650, 6651, 6751, 6752,     0,    0,    0),
  'MyPlaylists':              (8100, 1500,    0, 8110, 8110, 302,    0, 8001, 6750, 6650, 6652, 6751, 6752,     0,    0,    0),
  'SubscribedPlaylists':      (8100, 1500,    0, 8110, 8110, 302,    0, 8001, 6750, 6650, 6653, 6751, 6752,     0,    0,    0),
  'UserPlaylistSongs':        (8200, 2500, 5200, 8210, 8210, 302,  261, 8001, 7540, 7540, 7541, 7541, 7544, 13000,    0,    0),  
  'MyPlaylistSongs':          (8200, 2500, 5400, 8210, 8210, 302,  461, 8001, 7540, 7540, 7541, 7541, 7544, 13000,    0,    0),
  
  'EmptyAllPlaylists':        (8500,    0,    0,    0, 8520, 302,    0,    0, 6750, 6650, 6651, 6751, 6752,     0,    0, 8530),
  'EmptyMyPlaylists':         (8500, 1500,    0,    0, 8520, 302,    0,    0, 6750, 6650, 6652, 6751, 6752,     0,    0, 8530),
  'EmptySubscribedPlaylists': (8500, 1500,    0,    0, 8520, 302,    0,    0, 6750, 6650, 6653, 6751, 6752,     0,    0, 8530),
  'EmptyMyPlaylistSongs':     (8500,    0, 5500,    0, 8520, 302,  561,    0,    0,    0,    0,    0,    0,     0,    0, 8530),
  'EmptyUserPlaylistSongs':   (8500,    0,    0,    0, 8520, 302,    0,    0,    0,    0,    0,    0,    0,     0,    0, 8530),
                             #(View, Side, Ctrl, List, Cont, Tab, PCID, Desc, Sort, Show, ShID, SoID, Last, PLArt, AArt, ACList)
  'Stations':                 (8100,    0,    0, 8110, 8110, 303,    0, 8001,    0,    0,    0,    0,    0,     0,    0,    0),
  
  'Settings':                 (8600,    0,    0,    0, 8610, 306,    0,    0,    0,    0,    0,    0,    0,     0,    0,    0)
}
