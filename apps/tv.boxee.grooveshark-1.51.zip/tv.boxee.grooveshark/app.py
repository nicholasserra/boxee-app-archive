# app
# safely start grooveshark

from mc import ActivateWindow, ShowDialogWait, HideDialogWait 
from cgi import parse_qs
from sys import argv

if __name__ == '__main__':
    from gs.grooveshark import getGrooveshark
    grooveshark = getGrooveshark()
    if argv[1]:
        args = parse_qs(argv[1])
        if args.has_key('songID'):
            songID = args['songID'][0]
            grooveshark.setReadySong(songID)
        elif args.has_key('playlistID'):
            playlistID = args['playlistID'][0]
            grooveshark.setReadyPlaylist(playlistID)
        elif args.has_key('albumID'):
            albumID = args['albumID'][0]
            grooveshark.setReadyAlbum(albumID)
    if grooveshark.isRunning():
        """ if running, re open the app safely. """
        ActivateWindow(14002) # main
        player = grooveshark.getPlayer()
        queue = player.getQueue() 
        """ check for external links: if app is running """
        readyPlaylistID = grooveshark.getReadyPlaylist()
        readySongID = grooveshark.getReadySong()
        readyAlbumID = grooveshark.getReadyAlbum()
        if readyPlaylistID > 0 or readySongID > 0 or readyAlbumID > 0:
            from gs import service
            songs = []
            if readyPlaylistID > 0:
                request = service.Request('getPlaylistSongs', \
                    {'playlistID': readyPlaylistID})
                if not request.hasError():
                    songs = request.getResult('songs')
                grooveshark.removeReadyPlaylist()
            if readySongID > 0:
                request = service.Request('getSongsInfo', {'songIDs': [readySongID]})
                if not request.hasError():
                    songs = request.getResult('songs')
                grooveshark.removeReadySong()
            if readyAlbumID > 0:
                request = service.Request('getAlbumSongs', {'albumID': readyAlbumID})
                if not request.hasError():
                    songs = request.getResult('songs')
                grooveshark.removeReadyAlbum()
            position = queue.insertNext(songs)
            if player.player.IsPlaying():
                position += 1
            position = queue.getPlaylistPosition(position)
            player.play(position)
        if queue.size() > 0:
            from page import nowplaying
            from page.ui import open
            open(nowplaying.NowPlaying())
        else:
            from page.ui import open
            from page.search import Search
            open(Search())
    else:
           """ app not running yet, initilize """
           """ check if user logged in """ 
           from gs.user import getUser
           user = getUser()
           grooveshark.setUser(user)
           user.recallUser()
           if not user.isLoggedIn():
               """ if not logged in, go to form """ 
               ActivateWindow(14007) # login
           else:
               """ logged in; check vip, trial status """
               user.syncUser()
               valid = user.isValid()
               trial = None
               if not valid:
                   """ user not vip, check trial status """
                   from gs.service import getTrial
                   trial = getTrial()
                   trial.syncServer()
                   if not trial.isStarted():
                       """ trial not started, request start """
                       ActivateWindow(14004) # start
                   elif not trial.isValid():
                       """ trial ended, cta to upgrade """ 
                       ActivateWindow(14005) # upgrade
                   else:
                       valid = True
               if valid:
                   """ vip or trial, start app """
                   grooveshark.setStart(True)
                   #mc.ActivateWindow(14002) # main
                   from util import replaceWindow
                   replaceWindow(14002)
                   ShowDialogWait()
                   user.startLoading()
                   import model.queue
                   import gs.player
                   if not grooveshark.getPlayer():
                       player = gs.player.getPlayer()
                       queue = model.queue.Queue()
                       player.setQueue(queue)
                       player.start()
                       grooveshark.setPlayer(player)
                   from page.ui import open
                   """ check for external links: if app is running """
                   readyPlaylistID = grooveshark.getReadyPlaylist()
                   readySongID = grooveshark.getReadySong()
                   readyAlbumID = grooveshark.getReadyAlbum()
                   if readyPlaylistID > 0 or readySongID > 0 or readyAlbumID > 0:
                       from gs import service
                       songs = []
                       if readyPlaylistID > 0:
                           request = service.Request('getPlaylistSongs', \
                               {'playlistID': readyPlaylistID})
                           if not request.hasError():
                               songs = request.getResult('songs')
                           grooveshark.removeReadyPlaylist()
                       if readySongID > 0:
                           request = service.Request('getSongsInfo', \
                               {'songIDs': [readySongID]})
                           if not request.hasError():
                               songs = request.getResult('songs')
                           grooveshark.removeReadySong()
                       if readyAlbumID > 0:
                           request = service.Request('getAlbumSongs', \
                               {'albumID': readyAlbumID})
                           if not request.hasError():
                               songs = request.getResult('songs')
                           grooveshark.removeReadyAlbum()
                       position = queue.insertNext(songs)
                       if player.player.IsPlaying():
                           position += 1
                       position = queue.getPlaylistPosition(position)
                       player.play(position)
                   if queue.size() > 0:
                       from page import nowplaying
                       from page.ui import open
                       open(nowplaying.NowPlaying())
                   else:
                       from page.ui import open
                       from page.search import Search
                       open(Search())
                   HideDialogWait()
                   if trial and trial.isValid() and not user.isValid():
                       """ if trial, show status """
                       trial.notifyStatus()
