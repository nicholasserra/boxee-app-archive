# page.nowplaying
# show queue

from sys import path
path.append(r'u:\apps\grooveshark\\')

from mc import GetWindow
import dialog, ui, search
from gs.player import getPlayer
from model.page import Page, SongPage, SearchPage

from definitions import *

import util
from gs import grooveshark

class NowPlaying(SongPage):
    def __init__(self):
        self.list = getPlayer().getQueue()
        Page.__init__(self)

    def prepare(self):
        pass

    def render(self):
        items = self.list.getListItems()
        queuePos = self.list.getQueuePosition()
        try: # prevents crash when trying to open NP with no songs in queue.  Not elegant but it works.
            nowplaying = items[queuePos]
        except:
            ui.open(EmptyNowPlaying())
        ui.updateNowPlaying(nowplaying)
        try:
            list = GetWindow(WINDOW_ID).GetList(8430)
            list.SetItems(items, getPlayer().getQueue().getQueuePosition())
            list.SetVisible(True)
        except:
            pass
            
        if self.list.isShuffle():
            util.setToggle(4012, True)
        if self.list.isRepeat():
            util.setToggle(4011, True)
        if self.list.isRadio():
            util.show(855)
            util.show(856)
            util.hide(4041)
            util.hide(4042)
            util.setToggle(4013, True)

    def getItems(self):
        return getPlayer().getQueue().getItems()
        
    def page(self):
        if self.list.size() == 0:
             ui.open(EmptyNowPlaying())
        else:
            queuePos = self.list.getQueuePosition()
            item = self.list.getItems()[queuePos]
            nowplaying = self.list.getListItemFromItem(item)
            ui.updateNowPlaying(nowplaying)

            queue = self.list
            
            # if queue.isShuffle():
            #     util.setToggle(4012, True)
            # if queue.isRepeat():
            #     util.setToggle(4011, True)
            # if queue.isRadio():
            #     util.show(855)
            #     util.show(856)
            #     util.hide(4041)
            #     util.hide(4042)
            #     util.setToggle(4013, True)

            # util.goto(851) # play button 
     
        def click(self):
            dialog.queue()   
        
class EmptyNowPlaying(SearchPage):
    def page(self):
        GetWindow(WINDOW_ID).GetEdit(8520).SetText('')
        self.drawEmptyPageMessages(header="You don't have any songs playing!",sub="Search for a song and click 'Play Now'.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(search.SearchSongs())
        ui.gotoContent()
