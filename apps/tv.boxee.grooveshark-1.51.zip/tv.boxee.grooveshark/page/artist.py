# page.artist
# view artist's albums, songs

from sys import path
path.append(r'u:\apps\grooveshark\\')

import album, dialog, ui
from gs import service
from model.page import AlbumPage, SongPage

class ArtistAlbums(AlbumPage):
    def getItems(self, item):
        artistID = item['ArtistID']
        self.list.setSortColumn('AlbumName')
        self.list.setSortOrder(False)
        request = service.Request('getArtistAlbums', {'artistID': artistID})
        albums = request.getResult('albums')
        return albums

    def page(self, item):
        if self.list.size() == 0:
            self.setContext("Oh snap!  We couldn't find any albums by %s" % (item['ArtistName']))
        else:
            self.setContext('%s - Albums' % (item['ArtistName']))

    def click(self):
        item = self.list.getSelected()
        ui.open(album.AlbumSongs(item))
        ui.gotoContent()

class ArtistSongs(SongPage):
    def getItems(self, item):
        artistID = item['ArtistID']
        self.list.setSortColumn('SongName')
        self.list.setSortOrder(False)
        request = service.Request('getArtistPopularSongs', {'artistID': artistID})
        return request.getResult('songs')

    def page(self, item):
        if self.list.size() == 0:
            self.setContext("Oh snap!  We couldn't find any songs by %s" % (item['ArtistName']))
        else:
            self.setContext('%s - Songs' % item['ArtistName'])
  
    def click(self):
        dialog.playSongs()
       
