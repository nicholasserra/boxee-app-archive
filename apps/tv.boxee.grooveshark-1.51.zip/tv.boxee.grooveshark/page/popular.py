# page.popular
# popular music on grooveshark

from sys import path
path.append(r'u:\apps\grooveshark\\')

from dialog import playSongs
from gs import service
from model.page import SongPage

class PopularToday(SongPage):

    def getItems(self):
        self.list.setSortColumn('Popularity')
        self.list.setSortOrder(False)
        request = service.Request('getPopularSongsToday')
        songs = request.getResult('songs')
        order = 1
        for song in songs:
            song['Popularity'] = order
            order += 1
        return songs

    def page(self):
        if self.list.size() == 0:
            self.setContext("Oh snap!  We've had a problem fetching today's popular songs! Try coming back later.")
        else:
            self.setContext('Popular Songs Today')
        

    def click(self):
        playSongs()

class PopularMonth(SongPage):

    def getItems(self):
        self.list.setSortColumn('Popularity')
        self.list.setSortOrder(False)
        request = service.Request('getPopularSongsMonth')
        songs = request.getResult('songs')
        order = 1
        for song in songs:
            song['Popularity'] = order
            order += 1
        return songs

    def page(self):
        if self.list.size() == 0:
            self.setContext("Oh snap!  We've had a problem fetching this month's popular songs!  Try coming back later.")
        else:
            self.setContext('Popular Songs This Month')

    def click(self):
        playSongs()
