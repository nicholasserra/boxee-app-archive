# page.ui
# utilities to be accessed from the skin

from mc import GetWindow, GetActiveWindow, ListItems

from sys import path
path.append(r'u:\apps\grooveshark\\')

from util import goto, safe_str, show, hide, setToggle
import manager
from definitions import *

import dialog as dlg

from gs import grooveshark, service

def clearSidebarSearch():
    GetWindow(WINDOW_ID).GetEdit(SIDEBAR_FILTER_ID).SetText('') 

def gotoContent():
    page = manager.getPageManager().getCurrent()
    goto(page.getContentID())

def gotoSidebar():
    page = manager.getPageManager().getCurrent()
    if page.isSidebarOpen() and page.isSidebarVisible():
        goto(SIDEBAR_FILTER_ID)

def goUp():
    page = manager.getPageManager().getCurrent()
    if page.getOptionsID() > 0 and GetActiveWindow().GetControl(LIST_OPTIONS_ID).IsVisible():
        goto(page.getOptionsID())
    else:
        goto(NAV_SEARCH_ID)

def gotoSidebarSort():
    page = manager.getPageManager().getCurrent()
    sortID = page.getSidebarSortID() + 1
    goto(sortID)
 
def gotoSidebarShow():
    page = manager.getPageManager().getCurrent()
    showID = page.getSidebarShowID() + 1
    goto(showID)

def sort(column=DEFAULT, reverse=False, sortID=0):
    page = manager.getPageManager().getCurrent()
    setToggle(sortID, selected=True)
    if page.getSidebarSortDefault() != sortID:
        setToggle(page.getSidebarSortDefault(), selected=False)
    page.setSidebarSortDefault(sortID)
    list = page.getList()
    list.setSortColumn(column)
    list.setSortOrder(reverse) 
    list.sort()  
    list.render()

def restore():
    page = manager.getPageManager().getCurrent()
    list = page.getList()
    list.restore()

def filter(query):
    page = manager.getPageManager().getCurrent()
    list = page.getList()
    list.filter(query)
    list.render()
    page.setContext(safe_str(query))
    if len(page.getList().getAll()) == 0:
        hide(page.getCtrlGroupID())
    else:
        show(page.getCtrlGroupID())

def getListID():
    page = manager.getPageManager().getCurrent()
    return page.getListID()

def getList():
    page = manager.getPageManager().getCurrent()
    return page.getList()

def getPage():
    return manager.getPageManager().getCurrent()

def clearCheckpoints():
    manager.getPageManager().clearCheckpoints()

def saveCheckpoint():
    manager.getPageManager().saveCheckpoint()
    
def gotoQueue():
    queue = grooveshark.getPlayer().getQueue()
    position = queue.getQueuePosition()
    GetWindow(WINDOW_ID).GetList(QUEUE_ID).SetFocusedItem(position)        
    if queue.isShuffle():
        setToggle(4012, True)
    if queue.isRepeat():
        setToggle(4011, True)
    if queue.isRadio():
        setToggle(4013, True)
    goto(QUEUE_ID)
    
def gotoSidebarLast():
    page = manager.getPageManager().getCurrent()
    goto(page.getSidebarLastID())

def updateNowPlaying(song):
    try:
        items = ListItems()
        items.push_back(song)
        if song.GetThumbnail() != '':
            GetWindow(WINDOW_ID).GetImage(11).SetTexture(song.GetThumbnail())
            GetWindow(WINDOW_ID).GetImage(8411).SetTexture(song.GetThumbnail())
        else:
            GetWindow(WINDOW_ID).GetImage(11).SetTexture('')
            GetWindow(WINDOW_ID).GetImage(8411).SetTexture('')
            
        list = GetWindow(WINDOW_ID).GetList(HIDDEN_QUEUE_ID)
        list.SetItems(items, 1)
        GetWindow(WINDOW_ID).GetControl(NAV_QUEUE_ID).SetVisible(state)
    except:
        pass # ignore. might not be on app (visualiser)
        
def open(page):
    manager.getPageManager().push(page)
    clearSidebarSearch()
    return page

def openDialog(dialog):
    dlg.getDialog().setCurrentDialog(dialog)
    # dialog.setup()
    dialog.draw()
    return dialog

def refresh():
    page = getPage()
    page.prepare()
    page.render()
