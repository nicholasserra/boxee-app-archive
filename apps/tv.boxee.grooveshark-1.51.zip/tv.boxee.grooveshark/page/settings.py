from mc import GetWindow

from sys import path
path.append(r'u:\apps\grooveshark\\')

from util import goto, safe_str, show, hide
from gs import service, grooveshark
from model.page import RegularPage
from definitions import *

class Settings(RegularPage):
    def page(self):
        goto(8610)
        user = grooveshark.getGrooveshark().getUser()
        GetWindow(WINDOW_ID).GetLabel(USER_INFO).SetLabel("Logged in as %s" % safe_str(user.getUsername()))
        trial = service.getTrial()
        if trial.isStarted() and trial.isValid() and not user.isValid():
            show(8613) # show trial info only if theres a trial 
        else:
            hide(8613)
