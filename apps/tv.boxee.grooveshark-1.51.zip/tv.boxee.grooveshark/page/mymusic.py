# page.mymusic
# grooveshark library

from sys import path
path.append(r'u:\apps\grooveshark\\')

from mc import ShowDialogWait, HideDialogWait, GetWindow
import dialog, search
from ui import open, gotoContent
from gs.user import getUser
from model.page import SongPage, AlbumPage, ArtistPage, PlaylistPage, SearchPage
from definitions import *

class LibrarySongs(SongPage):
    def getItems(self):
        self.list.setSortColumn('TSAdded')
        self.list.setSortOrder(True)
        library = getUser().getLibrarySongs()
        return library

    def page(self):
        if not getUser().isLoaded():
            self.setContext('Fetching your library. One moment please...', nocount=True)
            ShowDialogWait()
            import time
            while not getUser().isLoaded():
                time.sleep(1)
            HideDialogWait()
            self.prepare()
            self.render()
        elif self.list.size() == 0:
            open(EmptyLibrary())
        else:
            self.setContext('My Music')

    def click(self):
        dialog.playSongs()
        

class LibraryArtists(ArtistPage):
    def getItems(self):
        self.list.setSortColumn('ArtistName')
        self.list.setSortOrder(False)
        return getUser().getLibraryArtists()

    def page(self):
        if self.list.size() == 0:
            open(SearchPage())
        else:
            self.setContext('My Music - Artists')

    def click(self): 
        item = self.list.getSelected()
        open(LibraryArtistAlbums(item))
        gotoContent()

class LibraryArtistAlbums(AlbumPage):
    def getItems(self, item):
        artistID = item['ArtistID']
        self.list.setSortColumn('TSAdded')
        self.list.setSortOrder(True)
        return getUser().getLibraryAlbums(artistID)

    def page(self, item):
        artistID = item['ArtistID']
        self.setContext('My Music - %s - Albums' % item['ArtistName'])

    def click(self):
        item = self.list.getSelected()
        open(LibraryAlbumSongs(item))
        gotoContent()

def LibraryArtistSongs(SongPage):
    """ this class isnt used because its written retardedly.
        please fix before progressing. """

    def getItems(self, item):
        artistID = item['ArtistID']
        return service.getArtistSongs(artistID)
    
    def click(self):
        dialog.playSong()

class LibraryAlbums(AlbumPage):
    def getItems(self, item=None):
        if not item:
            artistID = 0
        else:
            artistID = item['ArtistID']
        self.list.setSortColumn('TSAdded')
        self.list.setSortOrder(True)
        return getUser().getLibraryAlbums(artistID)

    def page(self, item=None):
        self.setContext('My Music - Albums')

    def click(self):
        item = self.list.getSelected()
        open(LibraryAlbumSongs(item))
        gotoContent()

class LibraryAlbumSongs(SongPage):
    def getItems(self, item):
        albumID = item['AlbumID']
        self.list.setSortColumn('TSAdded')
        self.list.setSortOrder(True)
        return getUser().getLibrarySongs(albumID)

    def page(self, item):
        albumID = item['AlbumID']
        self.setContext('My Music - %s - %s' % (item['ArtistName'], item['AlbumName']))
        self.setAlbumArt()

    def click(self):
        dialog.playSongs()

class LibraryFavorites(SongPage):
    def getItems(self):
        self.list.setSortColumn('TSFavorited')
        self.list.setSortOrder(True)
        return getUser().getFavorites()

    def page(self):
        if self.list.size() == 0:
            open(EmptyLibraryFavorites())
        else:
            self.setContext('My Favorites')
    
    def click(self):
        dialog.playSongs()
        
class EmptyLibrary(SearchPage):
    def page(self):
        GetWindow(WINDOW_ID).GetEdit(8520).SetText('')
        self.drawEmptyPageMessages(header="Your library is empty!",sub="Search for your favorites and add them to your collection.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        open(search.SearchSongs())
        gotoContent()

class EmptyLibraryFavorites(SearchPage):
    def page(self):
        GetWindow(WINDOW_ID).GetEdit(8520).SetText('')
        self.drawEmptyPageMessages(header="You don't have any favorites saved!",sub="Search for a few of your favorite songs below.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        open(search.SearchSongs())
        gotoContent()
