# page.playlist
# see playlists and their songs

from sys import path
path.append(r'u:\apps\grooveshark\\')

from mc import GetWindow
from util import show, safe_str
import dialog, ui, search
from gs import service, user, grooveshark
from model.page import PlaylistPage, SongPage, SearchPage
from definitions import *

class AllPlaylists(PlaylistPage):
    def getItems(self):
        self.list.setSortColumn('TSAdded')
        self.list.setSortOrder(True)
        myPlaylists = grooveshark.getUser().getMyPlaylists()
        subPlaylists = grooveshark.getUser().getSubPlaylists()
        for sub in subPlaylists:
            sub['TSAdded'] = sub['TSFavorited']
        allPlaylists = myPlaylists + subPlaylists
        return allPlaylists
        
    def page(self):
        if self.list.size() == 0:
             ui.open(EmptyAllPlaylists())
        else:
            self.setContext('All Playlists')

    def click(self):
        item = self.list.getSelected()
        if item.has_key('UserID'):
            ui.open(UserPlaylistSongs(item))
        else:
            ui.open(MyPlaylistSongs(item))
        ui.gotoContent()

class MyPlaylists(PlaylistPage):
    def getItems(self):
        self.list.setSortColumn('TSAdded')
        self.list.setSortOrder(True)
        return grooveshark.getUser().getMyPlaylists()
        
    def page(self):
        if self.list.size() == 0:
           ui.open(EmptyMyPlaylists())
        else:
            self.setContext('My Playlists')

    def click(self):
        item = self.list.getSelected()
        ui.open(MyPlaylistSongs(item))
        ui.gotoContent()

class SubscribedPlaylists(PlaylistPage):
    def getItems(self):
        self.list.setSortOrder(True)
        subPlaylists = grooveshark.getUser().getSubPlaylists()
        for sub in subPlaylists:
            sub['TSAdded'] = sub['TSFavorited']
        return subPlaylists
        
    def page(self):
        if self.list.size() == 0:
            ui.open(EmptySubscribedPlaylists())
        else:
            self.setContext('Subscribed Playlists')
   
    def click(self):
        item = self.list.getSelected()
        ui.open(UserPlaylistSongs(item))
        ui.gotoContent()

class MyPlaylistSongs(SongPage):
    def getItems(self, item):
        playlistID = item['PlaylistID']
        request = service.Request('getPlaylistSongs', {'playlistID': playlistID})
        print request.getResult('songs')
        return request.getResult('songs')
        
    def page(self, item):
        playlistID = item['PlaylistID']
        if self.list.size() == 0:
            ui.open(EmptyMyPlaylistSongs())
        else:
            self.setContext(item['PlaylistName'])
            # if self.list.size() > 3:
            #     self.generatePlaylistThumb()
            show(8220)
            show(8221)

    def click(self):
        dialog.playSongs()
        
class UserPlaylistSongs(SongPage):
    def getItems(self, item):
        playlistID = item['PlaylistID']
        request = service.Request('getPlaylistSongs', {'playlistID': playlistID})
        return request.getResult('songs')
        
    def page(self, item):
        playlistID = item['PlaylistID']
        if grooveshark.getUser().isSubscribedPlaylist(playlistID):
            GetWindow(WINDOW_ID).GetControl(5202).SetVisible(True)
        if self.list.size() == 0:
           ui.open(EmptyUserPlaylistSongs())
        else:
            self.setContext(item['PlaylistName'])
            # if self.list.size() > 3:
            #     self.generatePlaylistThumb()
            show(8220)
            show(8221)
        
    def click(self):
        dialog.playSongs()
        
        
class EmptyAllPlaylists(SearchPage):

    def page(self):
        self.drawEmptyPageMessages(header="You don't have any playlists!",sub="Search for playlists now.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(search.SearchPlaylists())
        ui.gotoContent()

class EmptyMyPlaylists(SearchPage):

    def page(self):
        self.drawEmptyPageMessages(header="You don't have any playlists!",sub="Create one at grooveshark.com and start adding songs to it.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(search.SearchSongs())
        ui.gotoContent()
        
class EmptySubscribedPlaylists(SearchPage):

    def page(self, item):
        self.drawEmptyPageMessages(header="You aren't subscribed to any playlists!",sub="Search for one now.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(search.SearchPlaylists())
        ui.gotoContent()

class EmptyMyPlaylistSongs(SearchPage):

    def page(self):
        self.drawEmptyPageMessages(header="This playlist is empty!",sub="Search for your favorite songs to add to it.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(search.SearchSongs())
        ui.gotoContent()
        
class EmptyUserPlaylistSongs(SearchPage):

    def page(self, item):
        self.drawEmptyPageMessages(header="What's-his-name forgot to add any songs to %s!" % item['PlaylistName'],sub="Search for other playlists.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(search.SearchPlaylists())
        ui.gotoContent()


