# page.search
# search stuff on grooveshark

from mc import GetWindow

from sys import path
path.append(r'u:\apps\grooveshark\\')

from util import getCountryCode, goto, safe_str, show
import dialog, ui, artist, album, playlist, search
from gs import service
from model.page import SongPage, AlbumPage, ArtistPage, PlaylistPage, RegularPage, SearchPage
from definitions import *

SEARCH_INPUT_ID = 8310
NORESULTS_INPUT_ID = 8520

countryCode = getCountryCode()

class Search(SearchPage):
    def page(self):
        clearQuery()
        self.autocompleteResult = {}
        self.setAutocompleteItems()
        goto(SEARCH_INPUT_ID)

class SearchSongs(SongPage):
    def getItems(self):
        self.list.setSortColumn('Popularity')
        self.list.setSortOrder(False)
        request = service.Request('getSongSearchResults', {'query': getQuery(), 'limit': 200, 'country': countryCode })
        songs = request.getResult('songs')
        order = 1
        for song in songs:
            song['Popularity'] = order
            order += 1
        return songs

    def page(self):
        if self.list.size() == 0:
            ui.open(EmptySearchSongs())
        else:
            self.setContext("Song results for '%s'" % getQuery())

    def click(self):
        dialog.playSongs()

class SearchAlbums(AlbumPage):
    def getItems(self):
        self.list.setSortColumn('Popularity')
        self.list.setSortOrder(False)
        request = service.Request('getAlbumSearchResults', {'query': getQuery(), 'limit': 200, 'country': countryCode })
        albums = request.getResult('albums')
        order = 1
        for album in albums:
            album['Popularity'] = order
            order += 1
        return albums
    
    def page(self):
        if self.list.size() == 0:
            ui.open(EmptySearchAlbums())   
        else:
            self.setContext("Album results for '%s'" % getQuery())

    def click(self):
        item = self.list.getSelected()
        ui.open(album.AlbumSongs(item))
        ui.gotoContent()

class SearchArtists(ArtistPage):
    def getItems(self):
       self.list.setSortColumn('Popularity')
       self.list.setSortOrder(False)
       request = service.Request('getArtistSearchResults', {'query': getQuery(), 'limit': 200, 'country': countryCode })
       artists = request.getResult('artists')
       order = 1
       for artist in artists:
           artist['Popularity'] = order
           order += 1
       return artists

    def page(self):
        if self.list.size() == 0:
            ui.open(EmptySearchArtists())
        else:
            self.setContext("Artist results for '%s'" % getQuery())
    
    def click(self):
        item = self.list.getSelected()
        ui.open(artist.ArtistAlbums(item))
        ui.gotoContent()
         
class SearchPlaylists(PlaylistPage):
    def getItems(self):
        self.list.setSortColumn('Popularity')
        self.list.setSortOrder(False)
        request = service.Request('getPlaylistSearchResults', {'query': getQuery(), 'limit': 200, 'country': countryCode })
        playlists = request.getResult('playlists')
        order = 1
        for playlist in playlists:
            playlist['Popularity'] = order
            order += 1
        return playlists
    
    def page(self):
        if self.list.size() == 0:
            ui.open(EmptySearchPlaylists())
        else:
            self.setContext("Playlist results for '%s'" % getQuery())
    
    def click(self):
        item = self.list.getSelected()
        ui.open(playlist.UserPlaylistSongs(item))
        ui.gotoContent()
        
       
################# Empty Pages
        
class EmptySearchSongs(SearchPage):

    def page(self):
        self.drawEmptyPageMessages(header="We couldn't find any songs by that name!", sub="Check your spelling and try a new search.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(SearchSongs())
        ui.gotoContent()

        
class EmptySearchAlbums(SearchPage):

    def page(self):
        self.drawEmptyPageMessages(header="Oh snap!  We couldn't find any albums by that name!", sub="Check your spelling and try a new search.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(SearchAlbums())
        ui.gotoContent()

            
class EmptySearchArtists(SearchPage):

    def page(self):
        self.drawEmptyPageMessages(header="Oh snap!  We couldn't find any albums by that name!", sub="Check your spelling and try a new search.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(SearchArtists())
        ui.gotoContent()

            
class EmptySearchPlaylists(SearchPage):

    def page(self):
        self.drawEmptyPageMessages(header="Oh snap!  We couldn't find any albums by that name!", sub="Check your spelling and try a new search.")
            
    def click(self):
        query = GetWindow(WINDOW_ID).GetEdit(8520).GetText()
        search.setQuery(query)
        ui.open(SearchPlaylists())
        ui.gotoContent()
        
#
# utilities
#

DEFAULT = ''
query = ''

def setQuery(q = DEFAULT):
    global query
    if q != DEFAULT:
        query = q

def getQuery():
    global query
    return query

def clearQuery():
    global query
    query = ''
    setEditText(SEARCH_INPUT_ID, '')
    
def setEditText(edit, query=''):
    GetWindow(WINDOW_ID).GetEdit(edit).SetText(query)

