# page.stations
# see radio stations

from sys import path
path.append(r'u:\apps\grooveshark\\')

from mc import GetWindow
from util import show, safe_str
import dialog, ui, nowplaying
from gs import service, grooveshark
from model.page import StationPage
from definitions import *

class Stations(StationPage):
    def getItems(self):
        self.list.setSortColumn('StationName')
        self.list.setSortOrder(False)
        request = service.Request('getAutoplayTags')
        if not request.hasError():
            stations = []
            for key, value in request.getResult().iteritems():
                stationName = safe_str(value)
                stationName = stationName.replace('_', ' ')
                stationName = stationName.capitalize()
                if stationName == "Rnb":
                    stationName = "R'n'B"
                station = {
                    "StationName" : stationName, \
                    "StationID" : key \
                }
                stations.append(station)
        return stations
        
    def page(self):
        if self.list.size() == 0:
            self.setContext("Oh snap!  We've had a problem fetching radio stations. Try coming back later.")
        else:
            self.setContext('All Stations')

    def click(self):
        if grooveshark.getPlayer().getQueue().size() == 0:
            station = dialog.getDialog().getItems()[0]
            tagID = station['StationID']
            grooveshark.getPlayer().startAutoplay(tagID)
            ui.open(nowplaying.NowPlaying())
            ui.gotoContent()
        else:
            ui.openDialog(dialog.StartStationConfirm())
