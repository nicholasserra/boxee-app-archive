# page.album
# view album's songs

from sys import path
path.append(r'u:\apps\grooveshark\\')

from dialog import playSongs
from gs.service import Request
from model.page import SongPage

class AlbumSongs(SongPage):
    def getItems(self, item, isVerified=True):
        albumID = item['AlbumID']
        self.list.setSortColumn('SongName')
        self.list.setSortOrder(False)
        request = Request('getAlbumSongs', {'albumID': albumID})
        songs = request.getResult('songs')
        if isVerified:
            verifiedSongs = []
            for song in songs:
                if song['IsVerified']:
                    verifiedSongs.append(song)
            songs = verifiedSongs
        return songs

    def page(self, item):
        albumID = item['AlbumID']
        if self.list.size() == 0:
            self.setContext('There are no songs in %s' % (item['AlbumName']))
        else:
            self.setContext('%s -  %s' % (item['ArtistName'], item['AlbumName']))
            self.setAlbumArt()

    def click(self):
        #playsongs() = dialog.playSongs()
        playSongs()
        
