# dialogs

from mc import ActivateWindow, GetWindow
from util import safe_str, notify
from gs import user
from xbmc import executebuiltin
from gs import grooveshark
import ui


def playSongs():
    ActivateWindow(14021)

def addToPlaylist():
    ActivateWindow(14023)

def addSong():
    ActivateWindow(14024)
    
def queue():
    ActivateWindow(14026)
    
def logout():
    ActivateWindow(14030)
    
def trialInfo():
    ActivateWindow(14040)
    
def helpDialog():
    ActivateWindow(14041)

def clearQueue():
    ActivateWindow(14031)

def replaceQueue():
    ActivateWindow(14032)
    
def createPlaylist():
    ActivateWindow(14060)

def playlistOptions():
    ActivateWindow(14070)

def getDialog():
    global _dialog
    try:
        if not _dialog:
            _dialog = Dialog()
    except:
        _dialog = Dialog()
    return _dialog

class Dialog(object):
    """ Mediates interactions with the DialogCache """
    def setCurrentDialog(self, dialog):
        self.currentDialog = dialog

    def getCurrentDialog(self):
        return self.currentDialog
        
    def setItems(self, items):
        getDialogCache().cacheItems(items)
           
    def getItems(self):
        return getDialogCache().getItems()
        
    def setIndices(self, index):
        getDialogCache().cacheIndices(index)
            
    def getIndex(self):
        print ('dialog.getIndex', getDialogCache().getIndex())
        return getDialogCache().getIndex()


def getDialogCache():
    global _dialogCache
    try:
        if not _dialogCache:
            _dialogCache = DialogCache()
    except:
        _dialogCache = DialogCache()
    return _dialogCache

class DialogCache(object):
    """ A storage locker for data accessible by the dialogs. """
    def __init__(self, *args, **kwargs):
        self.items = []
        self.index = []

    def cacheItems(self, items):
        self.items = []
        if type(items) == list:
            for item in items:
                self.items.append(item)
        else:
            self.items.append(items)
        print ('printing items', self.items)
        return True

    def getItems(self):
        return self.items

    def cacheIndices(self, index):
        self.index = []
        if type(index) == list:
            for i in index:
               self.index.append(i)
        else:
            self.index.append(index)

    def getIndex(self):
        return self.index[0]


## Generic Confirmation and Namer classes
class ConfirmDialog(Dialog):
    def __init__(self, *args, **kwargs):
        Dialog.__init__(self, *args, **kwargs)
        self.windowID = 14031

    def setDescription(self, description):
        GetWindow(self.windowID).GetLabel(10).SetLabel(safe_str(description))

    def setup(self):
        ActivateWindow(self.windowID)

    def setActionLabel(self, action):
        GetWindow(self.windowID).GetButton(602).SetLabel(safe_str(action))

    def close(self):
        executebuiltin("Dialog.Close(14031)")

class NameDialog(Dialog):
    def __init__(self, *args, **kwargs):
        Dialog.__init__(self, *args, **kwargs)
        self.windowID = 14060

    def setDescription(self, description):
        GetWindow(self.windowID).GetLabel(10).SetLabel(safe_str(description))

    def setSubmit(self, label):
        GetWindow(self.windowID).GetButton(3).SetLabel(safe_str(label))

    def setup(self):
        ActivateWindow(self.windowID)


## Confirmers
class LogoutConfirm(ConfirmDialog):
    """ Every Dialog has to implement draw and click """

    def draw(self): # Overriding normal functions to use different xml since label is only one line
        ActivateWindow(14030)
        GetWindow(14030).GetLabel(10).SetLabel(safe_str('Are you sure you want to logout?'))
        GetWindow(14030).GetButton(602).SetLabel(safe_str('  Logout'))

    def click(self):
        from gs import grooveshark
        import search
        ui.open(search.Search())
        grooveshark.getGrooveshark().logout()
        
    def setup(self):
        pass        

class ClearQueueConfirm(ConfirmDialog):
    def draw(self):
        self.setup()
        self.setDescription('Are you sure you want to clear your currently playing songs?')
        self.setActionLabel('  Clear Current Songs')

    def click(self):
        from mc import GetPlayer
        import nowplaying
        player = grooveshark.getPlayer()
        if player.getQueue().isRadio():
            player.stopAutoplay()
        self.close()
        player.getQueue().clear()
        ui.getList().clear()
        GetPlayer().Stop()
        ui.open(nowplaying.EmptyNowPlaying())
        ui.gotoContent()
        

class ReplaceQueueConfirm(ConfirmDialog):
    def draw(self):
        self.setup()
        self.setDescription('Are you sure you want to replace your currently playing songs?')
        self.setActionLabel('  Replace Current Songs')

    def click(self):
        from mc import GetPlayer
        import nowplaying
        player = grooveshark.getPlayer()
        player.getQueue().clear()
        GetPlayer().Stop()
        player.getQueue().insertNext(self.getItems())
        player.play()
        ui.open(nowplaying.NowPlaying())
        executebuiltin("Dialog.Close(14021)")
        self.close()

class DeletePlaylistConfirm(ConfirmDialog):
    def draw(self):
        self.setup()
        self.setDescription('Are you sure you want to delete this playlist?')
        self.setActionLabel('  Delete')

    def click(self):
        import playlist
        playlistID = ui.getPage().getPageItem()['PlaylistID']
        user.getUser().deletePlaylist(playlistID)
        self.close()
        executebuiltin("Dialog.Close(14070)")
        notify("Deleted Playlist", "icon_playlist_unsub.png")
        ui.open(playlist.AllPlaylists())

class RemoveFromPlaylistConfirm(ConfirmDialog):
    def draw(self):
        self.setup()
        self.setDescription("Are you sure you want to remove this song from the playlist?")
        self.setActionLabel('  Remove Song')

    def click(self):
        items = ui.getList().getAll()
        songID = self.getItems()[0]['SongID']
        newItems = []
        for i in items:
            if i['SongID'] != songID:
                newItems.append(i)
        if user.getUser().updatePlaylist(ui.getPage().getPageItem()['PlaylistID'], newItems, overwrite=True):
            notify("Removed song from playlist!", "icon_x.png")
            ui.refresh()
            self.close()

class StartStationConfirm(ConfirmDialog):
    def draw(self):
        self.setup()
        self.setDescription("Are you sure you want replace your current songs?")
        self.setActionLabel('  Start Station')

    def click(self):
        self.close()
        import nowplaying
        station = self.getItems()[0]
        print station
        tagID = station['StationID']
        grooveshark.getPlayer().startAutoplay(tagID)
        ui.open(nowplaying.NowPlaying())
        ui.gotoContent()

## Namers
class CreatePlaylist(NameDialog):
    """ Creates and names a new playlist """
    def draw(self):
        self.setup()
        self.setDescription('Create New Playlist:')
        self.setSubmit('Create Playlist')

    def click(self):
        playlistName = GetWindow(14060).GetEdit(1).GetText()
        items = self.getItems()
        if playlistName is not "":
            print ('printing items', items)
            user.getUser().createPlaylist(playlistName, items)
            numSongs = len(items)
            if numSongs > 1:
                s = 's'
            else:
                s = ''
            notify("Created '%s' with %s song%s!" % (playlistName, numSongs, s), "icon_playlist_subscribe.png")
            executebuiltin("Dialog.Close(14060)")
            executebuiltin("Dialog.Close(14023)")
        else:
            notify("Please enter a name for your playlist!")  


class RenamePlaylist(NameDialog):
    """ Renames an existing playlist """

    def draw(self):
        self.setup()
        print self.getItems()
        self.setDescription("Rename '%s':" % ui.getPage().getPageItem()['PlaylistName'])
        self.setSubmit('Rename')

    def click(self):
        oldName = ui.getPage().getPageItem()['PlaylistName']
        newName = GetWindow(14060).GetEdit(1).GetText()
        if newName is not "":
            playlistID = ui.getPage().getPageItem()['PlaylistID']
            if user.getUser().renamePlaylist(playlistID, newName):
                executebuiltin("Dialog.Close(14060)")
                executebuiltin("Dialog.Close(14070)")
                ui.getPage().setContext(newName)
                notify("Playlist renamed to '%s'!" % newName, "icon_edit.png")
                ui.getPage().setPageItemProperty('PlaylistName', newName)
        else:
            notify("Please enter a new name!")


