# page.manager
# track instantiated pages

from mc import GetWindow, ShowDialogWait, HideDialogWait

from sys import path
path.append(r'u:\apps\grooveshark\\')

from util import setToggle, hide, show
from model.page import Page
from definitions import *

_page_manager = None

def getPageManager():
    global _page_manager
    if not _page_manager:
        _page_manager = PageManager()
    return _page_manager

class PageManager(object):
    """ An obnoxious system to support drill down pages on a single xml sheet
        with dynamically generated lists. """
    def __init__(self):
        self.checkpoints = []
        self.last = Page()
        self.current = Page()

    def getCurrent(self):
        """ get real current page. slow but necessary b/c of popstate. """ 
        checkpoints = [c for c in self.checkpoints] # copy
        checkpoints.append(self.current)
        checkpoints.reverse()
        isVis = lambda c: GetWindow(WINDOW_ID).GetControl(c).IsVisible()
        for checkpoint in checkpoints:
            if checkpoint.getListID() > 0 and GetWindow(WINDOW_ID).GetControl(checkpoint.getViewID()).IsVisible():
                list = GetWindow(WINDOW_ID).GetList(checkpoint.getListID())
                test = list.GetItem(0)
                if checkpoint.name == test.GetProperty('Context'):
                   self.current = checkpoint
                   return checkpoint
        return self.current # fallback

    def saveCheckpoint(self): 
        self.checkpoints.append(self.current)
        GetWindow(WINDOW_ID).PushState()

    def getNumCheckpoints(self):
        return len(self.checkpoints)

    def getCheckpoint(self, index):
        index = int(index) 
        try:
            return self.checkpoints[index]
        except Exception, e:
            return self.current

    def clearCheckpoints(self, index=0):
        index = int(index) 
        if index == 0:
            checkpoints = []
            if len(self.checkpoints) > 0:
                checkpoints.append(self.checkpoints[0])
                GetWindow(WINDOW_ID).PopToState(1) # always a prev page
            else:
                GetWindow(WINDOW_ID).PopToState(0)
            self.checkpoints = checkpoints
            return True
        checkpoints = []
        for checkpoint in self.checkpoints:
            if checkpoint.order <= index:
                checkpoints.append(checkpoint)
        changed = len(checkpoints) == len(self.checkpoints)
        GetWindow(WINDOW_ID).PopToState(len(self.checkpoints))
        self.checkpoints = checkpoints
        return changed

    def closeCheckpoints(self):
        if self.checkpoints:
            for checkpoint in self.checkpoints:
                if checkpoint.name != self.current.name and checkpoint.name != self.last.name:
                    checkpoint.close()

    def push(self, pg):
        self.last = self.current
        self.current = pg
        self.current.setOrder(self.getNumCheckpoints())

        # show page transition
        ShowDialogWait()

        # close previous checkpoints, for safety
        self.closeCheckpoints()

        # swap tabs
        if self.current.getNavigationID() == 0:
            self.current.setNavigationID(self.last.getNavigationID())
        setToggle(self.current.getNavigationID(), selected=True)
        if self.current.getNavigationID() != self.last.getNavigationID():
            setToggle(self.last.getNavigationID(), selected=False)

        # hide previous page's content
        self.last.hideContent()
        
        # swap sidebars
        setToggle(self.last.getSidebarDefaults(), selected=False) # show, sort
        if self.current.isSidebarOpen():
            if not GetWindow(WINDOW_ID).GetControl(SIDEBAR_ID).IsVisible():
                show(SIDEBAR_ID)
            self.current.showSidebar()
            if self.current.getSidebarID() != self.last.getSidebarID():
                hide(self.last.getSidebarID())
            if self.current.getSidebarSortID() != self.last.getSidebarSortID():
                hide(self.last.getSidebarSortID())
            if self.current.getSidebarShowID() != self.last.getSidebarShowID():
                hide(self.last.getSidebarShowID())
            setToggle(self.current.getSidebarDefaults(), selected=True)
        else:
            hide(SIDEBAR_ID, self.last.getSidebarID(), self.last.getSidebarShowID(), self.last.getSidebarSortID())

        self.last.close()

        self.current.prepare()
        self.current.render()
        self.current.showContent()

        # finish transition
        HideDialogWait()
 
