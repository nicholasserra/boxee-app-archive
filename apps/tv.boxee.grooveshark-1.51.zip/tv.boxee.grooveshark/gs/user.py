# gs.user
# grooveshark session user

from md5 import new
from threading import Thread
from urllib import urlencode
from urllib2 import Request as req, urlopen
from simplejson import loads
from binascii import hexlify, unhexlify as unhex

from sys import path
path.append(r'u:\apps\grooveshark\\')

import util
from pydes import triple_des
from gs import service
from definitions import * 

def getUser():
    global _user
    try:
        if not _user:
            _user = User()
    except:
        _user = User()
    return _user

class User(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.loaded = False
        # User Info
        self.userID = 0
        self.username = ''
        self.token = ''
        self.loggedIn = False
        self.isAnywhere = False
        self.isTrial = False
        self.library = []    
        self.librarySongIDs = []
        self.favorites = []
        self.favoritesSongIDs = []
        self.myPlaylists = []
        self.myPlaylistsCached = False
        self.subPlaylists = []
        self.subPlaylistsCached = False
        self.subscribedPlaylistIDs = []

        # API & Session
        self.host = ''
        self.endpoint = ''
        self.wskey = ''
        self.secret = '' 
        self.salt = ''
        self.error = 0
        self.sessionID = ''

    def hasError(self):
        return self.error > 0

    ##
    # API & Session 
    def authenticate(self):
        try:
            params = urlencode({"key": "boxee", "login": self.username, \
                "password": self.token})
            #req() = urllib2.Request()    
            request = req(API_DELEGATE, data=params, \
                 headers={"X-Boxee-App": "Boxee"})
              
            response = urlopen(request).read()
            decoded = loads(response)
            self.salt = util.safe_str(decoded['salt'])
            self.host = util.safe_str(decoded['host'])
            self.wskey = util.safe_str(decoded['wskey'])
            self.secret = util.safe_str(decoded['secret'])
            self.endpoint = util.safe_str(decoded['endpoint'])
            user = decoded['user']
            if user['UserID'] > 0:
                self.setSessionID(decoded['sessionID'])
                self.setUserID(user['UserID'])
                self.loggedIn = True
                self.setAnywhere(user['IsAnywhere'])
                self.storeUser()
                self.storeAPIKey()
                #self.requestCountryCode()
                return True
            else:
                self.error = 1
                return False
        except Exception, e: # no connection?
            self.error = 2
            return False

    def logout(self):
        self.storeLibraryIDs()
        self.clearCredentials()
        self.library = []
        self.favorites = []
	self.librarySongIDs = []
        self.favoritesSongIDs = []
        self.loaded = False
        self.myPlaylistsCached = False
        self.subPlaylistsCached = False

    def storeAPIKey(self):
        key = triple_des(unhex(self.salt))
        host = key.encrypt(self.host, '*')
        host = hexlify(host)
        wskey = key.encrypt(self.wskey, '*')
        wskey = hexlify(wskey)
        secret = key.encrypt(self.secret, '*')
        secret = hexlify(secret)
        endpoint = key.encrypt(self.endpoint, '*')
        endpoint = hexlify(endpoint)
        encoded = '%s;%s;%s;%s;%s' % (self.salt, host, endpoint, wskey, secret)
        key = triple_des(unhex(self.sessionID))
        encrypted = key.encrypt(encoded, '*')
        encrypted = hexlify(encrypted)
        util.store('SessionInfo', encrypted)
        pass

    def recallAPIKey(self):
        try:
            info = util.recall('SessionInfo')
            info = unhex(info)
            key = triple_des(unhex(self.sessionID))
            info = key.decrypt(info, '*').split(';')
            (salt, host, endpoint, wskey, secret) = info
            key = triple_des(unhex(salt))
            self.salt = salt
            self.host = key.decrypt(unhex(host), '*')
            self.wskey = key.decrypt(unhex(wskey), '*')
            self.secret = key.decrypt(unhex(secret), '*')
            self.endpoint = key.decrypt(unhex(endpoint), '*')
        except Exception, e:
            pass

    def clearAPIKey(self):
        util.store('SessionInfo', '')

    def requestSession(self):
        request = service.SecureRequest('startSession')
        if not request.hasError():
            sessionID = request.getResult('sessionID')
            self.setSessionID(sessionID)
            self.storeUser()

    def getSessionID(self):
        return self.sessionID

    def hasSessionID(self):
        return self.sessionID != ''

    def setSessionID(self, session):
        self.sessionID = session

    def generateCountryCode(self):
        request = service.Request('getCountry')
        if not request.hasError():
            countryCode = request.getResult()
            util.storeJSON('CountryCode', countryCode)
            return countryCode
        return {}
   
    def getHost(self):
        return self.host

    def getEndpoint(self):
        return self.endpoint

    def getWSKey(self):
        return self.wskey

    def getSecret(self):
        return self.secret

    ##
    # User specific
    def recallUser(self):
        user = util.recallJSON('UserInfo', {})
        if user != {}:
            self.sessionID = user['SessionID']
            userID = user['LoginUserID']
            if userID:
                self.userID = int(userID)
            else:
                self.userID = 0
            self.username = user['LoginUsername']
            self.token = user['LoginToken']
            self.isAnywhere = user['LoginAnywhere']
            self.loggedIn = self.userID > 0
        if self.isLoggedIn():
            self.recallAPIKey()
        #self.recallCountryCode()

    def syncUser(self): 
        request = service.Request('getUserInfo')
        userInfo = request.getResult()
        self.userID  = userInfo['UserID']
        self.isAnywhere = userInfo['IsAnywhere']

    def storeUser(self):
        user = {'SessionID': self.sessionID, 'LoginUserID': self.userID, \
                'LoginUsername': self.username, 'LoginToken': self.token, \
                'LoginAnywhere': self.isAnywhere}
        util.storeJSON('UserInfo', user)

    def reauthenticate(self):
        request = service.SecureRequest('authenticateUser', {'login': self.username, 'password': self.token})
        if not request.hasError():
            userID = int(request.getResult('UserID'))
            self.setUserID(userID)
            self.loggedIn = userID > 0
            if self.isLoggedIn():
                self.storeAPIKey()
                #self.requestCountryCode()
                self.setAnywhere(user['IsAnywhere'])
                self.storeUser()
        return self.loggedIn

    def isLoggedIn(self):
        return self.loggedIn

    def isValid(self): 
        return self.isAnywhere or self.isTrial

    def setAnywhere(self, anywhere):
        self.isAnywhere = anywhere

    def getUsername(self):
        return self.username 

    def setUserID(self, userID):
        self.userID = userID

    def setUsername(self, username):
        self.username = username

    def setPassword(self, password):
        #md5.new()
        token = new(password).hexdigest()
        self.setToken(token)

    def setToken(self, token):
        self.token = token

    def clearCredentials(self):
        self.setUsername('')
        self.setToken('')
        self.setUserID('')
        #self.setCountryCode({})
        #self.setSessionID('')
        self.setAnywhere(False)
        #self.clearAPIKey()
        util.storeJSON('LibraryIDs', [])
        util.storeJSON('FavoriteIDs', [])
        self.storeUser()

    ##
    # User's music

    def loadLibrary(self):
        request = service.Request('getUserLibrarySongs')
        if not request.hasError():
            self.library = request.getResult('songs')
            for song in self.library:
                self.librarySongIDs.append(int(song['SongID']))

    def isLibrary(self, songID):
        songID = int(songID)
        return songID in self.librarySongIDs

    def addToLibrary(self, items):
        if type(items) != list:
            items = [items]
        songIDs = []
        albumIDs = []
        artistIDs = []
        for item in items:
            songID = int(item['SongID'])
            if songID not in self.librarySongIDs:
                songIDs.append(songID)
                albumIDs.append(item['AlbumID'])
                artistIDs.append(item['ArtistID'])
                item['TSAdded'] = util.generateTimeStamp()
                self.library.append(item)
                self.librarySongIDs.append(songID)
        if len(songIDs) > 0: 
            request = service.Request('addUserLibrarySongs', \
                {'songIDs': songIDs, 'artistIDs': artistIDs, 'albumIDs': albumIDs})
            return request.getResult('success')
        return False
    
    def removeFromLibrary(self, items):
        if type(items) != list:
            items = [items]
        songIDs = []
        albumIDs = []
        artistIDs = []
        index = 0
        indexesToRemove = []
        for item in items:
            songID = int(item['SongID'])
            songIDs.append(songID)
            albumIDs.append(item['AlbumID'])
            artistIDs.append(item['ArtistID'])
            if self.isFavorite(item['SongID']):
                self.removeFromFavorites(item)
            self.librarySongIDs.remove(songID)
            index = 0
            for i in self.library:
                if int(i['SongID']) == songID:
                    indexesToRemove.append(index)
                index += 1
        request = service.Request('removeUserLibrarySongs', \
            {'songIDs': songIDs, 'artistIDs': artistIDs, 'albumIDs': albumIDs})
        indexesToRemove.reverse()
        for i in indexesToRemove:
            self.library.pop(i)
        return request.getResult('success')

    def getLibrarySongs(self, albumID=0, artistID=0):
        albumID = int(albumID)
        artistID = int(artistID)
        if (albumID, artistID) == (0, 0):
            seenIDs = []
            uniqueLibrary = []
            for song in self.library:
                seenIDs.append(song['SongID'])
                uniqueLibrary.append(song)
            for song in self.favorites:
                if song['SongID'] not in seenIDs:
                    uniqueLibrary.append(song)
            return uniqueLibrary
        elif albumID > 0 or artistID > 0:
            songs = []
            for song in self.library:
                if (albumID, artistID) == (int(song['AlbumID']), 0) or (albumID, artistID) == (0, int(song['ArtistID'])):
                    songs.append(song)
            return songs

    def getLibraryArtists(self):
        artists = []
        dupes = []
        for song in self.library:
            if util.safe_str(song['ArtistName']).strip() == '': continue
            artist = {'ArtistID': song['ArtistID'], 'ArtistName': util.safe_str(song['ArtistName']), 'TSAdded': song['TSAdded']}
            if song['ArtistID'] not in dupes:
                dupes.append(song['ArtistID'])
                artists.append(artist)
        return artists

    def getLibraryAlbums(self, artistID = 0):
        artistID = int(artistID)
        albums = []
        dupes = []
        for song in self.library:
            if util.safe_str(song['AlbumName']).strip() in ['', 'Unknown Album']:
                continue
            album = {'AlbumID': song['AlbumID'], 
                     'AlbumName': util.safe_str(song['AlbumName']), 
                     'ArtistID': song['ArtistID'], 
                     'ArtistName': util.safe_str(song['ArtistName']), 
                     'TSAdded': song['TSAdded'] }
            if song['AlbumID'] not in dupes and artistID in [0, int(song['ArtistID'])]:
                dupes.append(song['AlbumID'])
                albums.append(album)
        return albums

    def loadFavorites(self):
        request = service.Request('getUserFavoriteSongs')
        if not request.hasError():
            for song in request.getResult('songs'):
                song['TSAdded'] = song['TSFavorited']
                self.favorites.append(song)
                self.favoritesSongIDs.append(int(song['SongID']))

    def isFavorite(self, songID):
        songID = int(songID)
        return songID in self.favoritesSongIDs

    def getFavorites(self):
        return self.favorites

    def addToFavorites(self, item):
        songID = int(item['SongID'])
        if songID in self.favoritesSongIDs:
            return False
        if not self.isLibrary(songID):
            self.addToLibrary(item)
        item['TSFavorited'] = util.generateTimeStamp()
        self.favorites.append(item)
        self.favoritesSongIDs.append(songID)
        request = service.Request('addUserFavoriteSong', {'songID': songID})
        return request.getResult('success')
    
    def removeFromFavorites(self, item):
        songID = int(item['SongID'])
        self.favoritesSongIDs.remove(songID)
        index = 0
        indexesToRemove = []
        for i in self.favorites:
            if int(i['SongID']) == songID:
                indexesToRemove.append(index) 
            index += 1
        request = service.Request('removeUserFavoriteSongs', {'songIDs': [songID]})
        indexesToRemove.reverse()
        for i in indexesToRemove:
            self.favorites.pop(i)
        index = 0
        return request.getResult('success')

    def subscribePlaylist(self, playlistID):
        request = service.Request('subscribePlaylist', {'playlistID': playlistID})
        self.subscribedPlaylistIDs.append(playlistID)
        return request.getResult('success')
        
    def unsubscribePlaylist(self, playlistID):
        request = service.Request('unsubscribePlaylist', {'playlistID': playlistID})
        self.subscribedPlaylistIDs.remove(playlistID)
        return request.getResult('success')
        
    def updatePlaylist(self, playlistID, items, overwrite=False):
        # Overwrite forces the current songs in the playlist to be overwritten with whatever is given
        # ie, when removing a song it prevents the new playlist being appended to the old one
        if overwrite:
            songIDs = []
            for item in items:
                songIDs.append(int(item['SongID']))
        else:
            r = service.Request('getPlaylistSongs', {'playlistID': playlistID})
            if type(items) != list:
                items = [items]
            songs = r.getResult('songs')
            for i in items:
                songs.append(i)
            songIDs = []
            for song in songs:
                songIDs.append(int(song['SongID']))
        request = service.Request('setPlaylistSongs', {'playlistID': playlistID, 'songIDs': songIDs} )
        return request.getResult('success')
        
    def createPlaylist(self, playlistName, items):
        songIDs = []
        for item in items:
            songIDs.append(int(item['SongID']))
        requestCreatePlaylist = service.Request('createPlaylist', {'name': playlistName, 'songIDs': songIDs})
        playlistID = requestCreatePlaylist.getResult('playlistID')
        playlistObject = {'TSAdded': str(util.generateTimeStamp), 'PlaylistName': playlistName, 'PlaylistID': playlistID}
        self.myPlaylists.append(playlistObject)
        return requestCreatePlaylist.getResult('success')

    def deletePlaylist(self, playlistID):
        requestDeletePlaylist = service.Request('deletePlaylist', {'playlistID': playlistID})
        if requestDeletePlaylist.getResult('success'):
            self.resetMyPlaylistsCache()
            return True
        # return False

    def renamePlaylist(self, playlistID, name):
        request = service.Request('renamePlaylist', {'playlistID': playlistID, 'name': name})
        if request.getResult('success'):
            self.resetMyPlaylistsCache()
            return True

    def resetMyPlaylistsCache(self):
        self.myPlaylistsCached = False
    
    def requestMyPlaylists(self):
        request = service.Request('getUserPlaylists')
        # if request.getResult('success'):
        self.myPlaylists = request.getResult('playlists') 
        return True

    def getMyPlaylists(self):
        if not self.myPlaylistsCached:
            if self.requestMyPlaylists():
                self.myPlaylistsCached = True
        return self.myPlaylists

    def resetSubPlaylists(self):
        self.subPlaylistsCached = False

    def requestSubPlaylists(self):
        request = service.Request('getUserPlaylistsSubscribed')
        #if request.getResult('success'):
        self.subPlaylists = request.getResult('playlists')
        for s in self.subPlaylists:
            self.subscribedPlaylistIDs.append(int(s['PlaylistID']))
        return True
        #return False
 
    def getSubPlaylists(self):
        if not self.subPlaylistsCached:
            if self.requestSubPlaylists():
                self.subPlaylistsCached = True
        return self.subPlaylists
        
    def isSubscribedPlaylist(self, playlistID):
        playlistID = int(playlistID)
        return playlistID in self.subscribedPlaylistIDs

    def recallLibraryIDs(self):
        reducedLibraryIDs = util.recallJSON('LibraryIDs')
        if not reducedLibraryIDs:
            reducedLibraryIDs = []
        self.favoritesSongIDs = util.recallJSON('FavoriteIDs')
        if not self.favoritesSongIDs:
            self.favoritesSongIDs = []
        self.librarySongIDs = reducedLibraryIDs + self.favoritesSongIDs
        for id in self.librarySongIDs:
            id = int(id)
        for id in self.favoritesSongIDs:
            id = int(id)
        # first remove all duplicates.
        self.librarySongIDs = list(set(self.librarySongIDs))
        self.favoritesSongIDs = list(set(self.favoritesSongIDs))

    def storeLibraryIDs(self):
        # first remove all duplicates.
        self.librarySongIDs = list(set(self.librarySongIDs))
        self.favoritesSongIDs = list(set(self.favoritesSongIDs))
        reducedLibraryIDs = list(set(self.librarySongIDs) ^ set(self.favoritesSongIDs))
        util.storeJSON('LibraryIDs', reducedLibraryIDs)
        util.storeJSON('FavoriteIDs', self.favoritesSongIDs)

    def startLoading(self):
        self.start()

    def isLoaded(self):
        return self.loaded

    def run(self):
        """ Load user's library and favorites in the background. """
        self.storeUser()
        self.recallLibraryIDs()
        country = util.recallJSON('CountryCode')
        if country == {}:
            country = self.generateCountryCode()
        util.setCountryCode(country)
        self.loadLibrary()
        self.loadFavorites()
        self.loaded = True
        self.storeLibraryIDs()
        if not self.myPlaylistsCached:
            self.requestMyPlaylists()
            self.myPlaylistsCached = True
        if not self.subPlaylistsCached: 
            self.requestSubPlaylists()
            self.subPlaylistsCached = True

    def cacheBust(self):
        self.library = []    
        self.librarySongIDs = []
        self.favorites = []
        self.favoritesSongIDs = []
        self.myPlaylists = []
        self.resetMyPlaylistsCache()
        self.resetSubPlaylists()
        self.run()
