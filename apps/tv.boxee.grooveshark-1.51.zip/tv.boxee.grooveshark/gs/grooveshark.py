from mc import CloseWindow
from sys import path
path.append(r'u:\apps\grooveshark\\')
from util import recall, store, replaceWindow

def getGrooveshark():
    global _gs
    try:
        if not _gs:
            _gs = Grooveshark()
    except:
        _gs = Grooveshark()
    return _gs

def getUser():
    return getGrooveshark().getUser()

def getPlayer():
    return getGrooveshark().getPlayer()

class Grooveshark(object):
    def __init__(self):
        self.started = False 
        self.error = False
        self.player = None
        self.user = None

    def isFirstTime(self): 
        return recall('IsWelcomed') != 'True'

    def setFirstTime(self, value):
        store('IsWelcomed', value)

    def isRunning(self):
        return self.started

    def setError(self, error):
        self.error = error

    def hasError(self):
        return self.error > 0

    def getError(self):
        return self.error

    def setStart(self, start):
        self.started = start

    def getUser(self):
        return self.user

    def setUser(self, user):
        self.user = user

    def getPlayer(self):
        return self.player
    
    def setPlayer(self, player):
        self.player = player

    def logout(self):
        CloseWindow()
        replaceWindow(14000)
        self.user.logout()
        del self.user
        self.started = False

    def hasReadyPlaylist(self):
        playlistID = self.getReadyPlaylist()
        return playlistID > 0

    def getReadyPlaylist(self):
        playlistID = recall('ReadyPlaylist')
        try:
            return int(playlistID)
        except:
            return 0
    
    def setReadyPlaylist(self, playlistID):
        store('ReadyPlaylist', str(playlistID))

    def removeReadyPlaylist(self):
        self.setReadyPlaylist(0)

    def hasReadySong(self):
        songID = self.getReadySong()
        return songID > 0

    def getReadySong(self):
        songID = recall('ReadySong')
        try:
            return int(songID)
        except:
            return 0

    def setReadySong(self, songID):
        store('ReadySong', str(songID))

    def removeReadySong(self):
        self.setReadySong(0)
        
    def hasReadyAlbum(self):
        albumID = self.getReadyAlbum()
        return albumID > 0

    def getReadyAlbum(self):
        albumID = recall('ReadyAlbum')
        try:
            return int(albumID)
        except:
            return 0

    def setReadyAlbum(self, albumID):
        store('ReadyAlbum', str(albumID))

    def removeReadyAlbum(self):
        self.setReadyAlbum(0)
