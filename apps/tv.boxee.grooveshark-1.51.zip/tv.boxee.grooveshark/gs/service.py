# gs.service
# access point to grooveshark's api

from hmac import new
from mc import ActivateWindow, ShowDialogOk, GetActiveWindow
import simplejson as json
from urllib2 import Request as req, urlopen
from time import time

from sys import path
path.append(r'u:\apps\grooveshark\\')

import util
from gs.grooveshark import getGrooveshark
from definitions import *

class Request(object):
    def __init__(self, method, params={}, autoRequest=True):
        self.user = getGrooveshark().getUser()
        self.PROTOCOL = 'http'
        self.HOST = self.user.getHost()
        self.ENDPOINT = self.user.getEndpoint()
        self.WSKEY = self.user.getWSKey()
        self.TOKEN = self.user.getSecret()

        self.response = ''
        self.decoded = ''
        self.message = ''
        self.code = 0

        self.method = method
        self.params = params
        self.header = {'wsKey': self.WSKEY}

        if self.user.hasSessionID():
            self.refreshHeader()
 
        if autoRequest:
            self.sendRequest()

    def refreshHeader(self):
        """ has to be dynamic in case the session changes """
        if self.user.hasSessionID():
            self.header['sessionID'] = self.user.getSessionID()

    def getSignature(self):
        # hmac.new
        return new(self.TOKEN, self.getRequest()).hexdigest()

    def getRequest(self):
        self.refreshHeader()
        return json.dumps({'method': self.method, 'header': self.header, 'parameters': self.params})

    def sendRequest(self):
        url = '%s://%s/%s?sig=%s' % (self.PROTOCOL, self.HOST, self.ENDPOINT, self.getSignature())
        try:
            #req() is urllib2.Request()
            request = req(url, self.getRequest())
            self.response = urlopen(request)
        except Exception, e:
            ShowDialogOk("Boxee Error!", "Something awful happened. Please restart Grooveshark.")
            #mc.GetApp().Close()
        try: 
            self.decoded = json.loads(self.response.read())
        except:
            self.error = 9000
            self.message = 'malformed response'
            return
        if self.decoded.has_key('errors'):
            self.code = self.decoded['errors'][0]['code']
            self.message = self.decoded['errors'][0]['message']
            if self.code == 300: # session is stale
                self.user.requestSession()
                if self.user.reauthenticate():
                    self.request()
                else:
                    GetActiveWindow().PopState(False)
                    getGrooveshark().logout()
                    ShowDialogOk("Session Expired", "Your session has expired and your login credentials have since changed. Please re-enter your credentials.")
                    return 
            elif self.code in [104, 105]: 
                trial = getTrial()
                trial.setEnded(True)
                trial.showTrialEnded()
                from mc import GetPlayer, PlayList
                GetPlayer().Stop()
                PlayList().Clear()
            elif self.code in [102, 103, 104]:
                trial = getTrial()
                if not trial.isStarted():
                    trial.showTrialNotStarted()
                else:
                    self.setEnded(True)
                    trial.showTrialEnded()
            elif self.code == 11:
                notify("Too many streams have failed! Let's chill out for a bit.")
                from mc import GetPlayer
                GetPlayer().Stop()
                getGrooveshark().getPlayer().getQueue().generatePlaylist()

    def hasError(self):
        """ Returns if error occurred. """
        return int(self.code) > 0

    def getCode(self):
        """ Return error code. """
        return self.code

    def getMessage(self):
        """ Return error message. """
        return self.message

    def getRaw(self):
        """ Get raw service return. """
        return self.response

    def getResult(self, key=None):
        """ Get decoded service return. """
        if self.hasError():
            return None
        try:
            if not key:
                return self.decoded['result']
            else:
               return self.decoded['result'].get(key, '')
        except:
            return None

class SecureRequest(Request):
    def __init__(self, method, params={}, autoRequest=True):
        Request.__init__(self, method, params, False)
        self.PROTOCOL = 'https'

        if autoRequest:
            self.sendRequest()

def getTrial():
    global _trial
    try:
        if not _trial:
            _trial = Trial()
    except:
        _trial = Trial()
    return _trial

class Trial(object):
    def __init__(self):
        self.numDays = 0
        self.numSongs = 0
        try:
            self.started = util.recall('HasTrial') == 'True'
        except:
            self.started = False
        self.ended = False
        self.initStart = False

    def start(self):
        uniqueID = util.getBoxeeID()
        request = SecureRequest('createTrial', {'uniqueID': uniqueID})
        self.started = True
        self.numSongs = 50
        self.numDays = 14
        util.store('HasTrial', 'True')
        self.initStart = True

    def isStarted(self):
        return self.started

    def isValid(self):
        return self.started and not self.ended

    def getDaysLeft(self):
        return self.numDays
 
    def getSongsLeft(self):
        return self.numSongs

    def syncServer(self):
        uniqueID = util.getBoxeeID()
        request = SecureRequest('getTrialInfo', {'uniqueID': uniqueID})
        self.started = request.getResult('success')
        if self.started:
            info = request.getResult('trial')
            self.numDays = int((time() - info['StartTime']) / (3600 * 24) + 1)
            self.numSongs = info['NumPlaysLimit'] - info['NumPlays']
            if self.numDays == 15 or self.numSongs == 0 or info['EndTime'] <= time():
                self.ended = True

    def songPlayed(self): 
        self.numSongs -= 1
        if self.numSongs % 10 == 0 or self.numSongs == 5:
            self.notifyStatus()

    def notifyStatus(self):
        if self.initStart:
            firstTimeMsg = "Thanks for giving Grooveshark a whirl!" 
        else:
            firstTimeMsg = ''
        if self.numSongs > 1:
            util.notify("%s You're on day %s of your trial and have %s songs left to play." % (firstTimeMsg, self.numDays, self.numSongs))
        elif self.numSongs == 1:
            util.notify("You're on day %s of your trial and have 1 song left to play. Make it count!" % (self.numDays, self.numSongs))

    def setEnded(self, ended):
        self.ended = ended
        if ended:
            gs = getGrooveshark()
            gs.setStart(False)

    def showTrialEnded(self):
        util.replaceWindow(14005)

    def showTrialNotStarted(self):
        util.replaceWindow(14004)
        