# play
# handle play requests

from mc import PlayList, GetPlayer
from sys import path
path.append(r'u:\apps\grooveshark\\')

from gs.stream import Stream

if __name__ == '__main__':
    try:
        playlist = PlayList(mc.PlayList.PLAYLIST_MUSIC)
        position = playlist.GetPosition()
        item = playlist.GetItem(position)
        song = Stream(item)
        if song.getSongID() > 0:
            song.fetchStream()
            GetPlayer().PlaySelected(position)
    except Exception, e:
        pass
        
