# model.list
# Formats data properly

from mc import ListItems, GetWindow, ListItem, GetApp
from operator import itemgetter

from sys import path
path.append(r'u:\apps\grooveshark\\')

import util
from gs import user
from definitions import *

DEFAULT_ALBUM_ART = 'http://static.a.gs-cdn.net/webincludes/images/default/album_250.png'
DEFAULT_ARTIST_ART = 'http://static.a.gs-cdn.net/webincludes/images/default/artist_250.png'

class List(object):
    def __init__(self):
        self.primary = ''
        self.items = []
        self.original = []
        self.listitems = ListItems()
        self.dirty = False
        self.lastFilterLen = 0
        self.sortCol = DEFAULT
        self.sortOrder = DEFAULT
        self.windowID = WINDOW_ID
        self.listID = DEFAULT
        self.flags = {}

    def setListID(self, listID):
        self.listID = listID

    def setWindowID(self, windowID):
        self.windowID = windowID

    def setFlag(self, key, value):
        key = util.safe_str(key)
        value = util.safe_str(value)
        self.flags[key] = value
        self.dirty = True

    def setSortColumn(self, column=DEFAULT):
        if column == DEFAULT:
            column = self.primary
        self.sortCol = column

    def setSortOrder(self, order=DEFAULT):
        if order == DEFAULT:
            order = False
        self.sortOrder = order

    def setItems(self, items):
        """ Import python list items, to be converted. """
        self.items = items
        self.original = items
        self.dirty = True

    def insert(self, items, index):
        """ insert songs into list at index """
        if not isinstance(items, list):
            items = [items]
        for item in items:
            self.items.insert(index, item)
            index += 1
        self.setItems(self.items)

    def append(self, items):
        """ append songs to the end of the queue. """
        if not isinstance(items, list):
            items = [items]
        self.items += items
        self.setItems(self.items)

    def removeByIndex(self, index):
        """ remove item from list with an index. """
        item = self.items.pop(index)
        self.setItems(self.items)  # in case an extended class has to act
        return item

    def getFocusedIndex(self):
        try:
            return GetWindow(self.windowID).GetList(self.listID).GetFocusedItem()
        except:
            return 0

    def setFocusedIndex(self, index):
        GetWindow(self.windowID).GetList(self.listID).SetFocusedItem(index)

    def getSelected(self):
        """ Get selected item. """
        index = self.getFocusedIndex()
        return self.getItem(index)

    def getItem(self, index):
        return self.items[index]

    def getListItem(self, index):
        if self.dirty:
            item = self.getItem(index)
            listItem = self.getListItemFromItem(item)
            return listItem
        return self.listitems.GetItem(int(index))
 
    def getItems(self):
        """ Get all items. """
        return self.items

    def getAll(self):
        """ Alias for backwards compatibility """
        return self.items

    def getListItems(self):
        """ Get all items as mc.ListItems """
        if self.dirty:
            self.generateListItems()
        return self.listitems

    def generateListItems(self):
        """ Generate & cache mc.ListItems of items """
        self.listitems = ListItems()
        for item in self.items:
            listitem = self.getListItemFromItem(item)
            self.listitems.push_back(listitem)
        self.dirty = False

    def size(self):
        try:
            return len(self.items)
        except:
            return 0

    def clear(self):
        self.setItems([])
        if self.listID > 0:
            self.render()

    def restore(self):
        self.setItems(self.original)

    def sort(self):
        if self.sortCol != DEFAULT:
            self.dirty = True
            self.items = sorted(self.items, key=itemgetter(self.sortCol))
            if self.sortOrder:
                self.items.reverse()

    def filter(self, query):
        query = util.safe_str(query).lower()
        # on backspace: restore list, restore sort state; else work on alerady filtered items to reduce latency
        if self.lastFilterLen > len(query):
            self.restore()
            self.sort()
        relevant = []
        for item in self.items:
           for (key, value) in item.items():
               if query in util.safe_str(value).lower():
                   relevant.append(item)
                   break # move to next item
        self.items = relevant 
        self.lastFilterLen = len(query)
        self.dirty = True

    def render(self, force=False):
        """ populate a skin control with currently held list """
        if force:
            self.dirty = True
        index = self.getFocusedIndex() # keep the focused index the same.
        items = self.getListItems()
        list = GetWindow(self.windowID).GetList(self.listID)
        list.SetItems(items, len(items) - 1)
        list.SetVisible(True)
        list.SetFocusedItem(index)
         
class SongList(List):
    def __init__(self): 
        List.__init__(self)
        self.primary = 'SongName'

    def getListItemFromItem(self, item):
        listitem = ListItem(ListItem.MEDIA_AUDIO_MUSIC)
        listitem.SetLabel(util.safe_str(item['SongName']))
        caf = util.safe_str(item['CoverArtFilename'])
        if item.has_key('CoverArtFilename') and caf is not None and caf != '':
           listitem.SetThumbnail('http://beta.grooveshark.com/static/amazonart/m' + util.safe_str(item["CoverArtFilename"]))
        else:
           listitem.SetThumbnail(DEFAULT_ALBUM_ART) 
        listitem.SetContentType("audio/mpeg")
        listitem.SetTitle(util.safe_str(item["SongName"]))
        listitem.SetArtist(util.safe_str(item["ArtistName"]))
        listitem.SetAlbum(util.safe_str(item["AlbumName"]))
        listitem.SetPath('app://%s/play' % GetApp().GetId())
        listitem.SetProperty("SongID", util.safe_str(item['SongID']))
        listitem.SetProperty("IsSong", "True")
        if user.getUser().isLibrary(item['SongID']):
            listitem.SetProperty("IsLibrary", "True")
        if user.getUser().isFavorite(item['SongID']):
            listitem.SetProperty("IsFavorite", "True")
        for (key, value) in self.flags.items():
            listitem.SetProperty(key, value)
        return listitem

class ArtistList(List):
    def __init__(self): 
        List.__init__(self)
        self.primary = 'ArtistName'

    def getListItemFromItem(self, item):
        listitem = ListItem(ListItem.MEDIA_UNKNOWN)
        listitem.SetLabel(util.safe_str(item["ArtistName"]))
        listitem.SetArtist(util.safe_str(item["ArtistName"]))
        listitem.SetProperty("ArtistID", util.safe_str(item['ArtistID']))
        listitem.SetProperty("IsArtist", "True")
        if item.has_key('CoverArtFilename') and item['CoverArtFilename'] is not None:
            listitem.SetThumbnail('http://beta.grooveshark.com/static/amazonart/m' + util.safe_str(item["CoverArtFilename"]))
        else:
            listitem.SetThumbnail(DEFAULT_ARTIST_ART)
        for (key, value) in self.flags.items():
            listitem.SetProperty(key, value)
        return listitem

class AlbumList(List):
    def __init__(self): 
        List.__init__(self)
        self.primary = 'AlbumName'
 
    def getListItemFromItem(self, item):
        listitem = ListItem(ListItem.MEDIA_UNKNOWN)
        listitem.SetLabel(util.safe_str(item["AlbumName"]))
        listitem.SetAlbum(util.safe_str(item["AlbumName"]))
        listitem.SetArtist(util.safe_str(item["ArtistName"]))
        listitem.SetProperty("AlbumID", util.safe_str(item['AlbumID']))
        listitem.SetProperty("IsAlbum", "True")
        if item.has_key('CoverArtFilename') and item['CoverArtFilename'] is not None:
            listitem.SetThumbnail('http://beta.grooveshark.com/static/amazonart/m' + util.safe_str(item["CoverArtFilename"]))
        for (key, value) in self.flags.items():
            listitem.SetProperty(key, value)
        return listitem

class PlaylistList(List):
    def __init__(self): 
        List.__init__(self)
        self.primary = 'Name'

    def getListItemFromItem(self, item):
        listitem = ListItem(ListItem.MEDIA_UNKNOWN)
        listitem.SetLabel(util.safe_str(item["PlaylistName"]))
        listitem.SetProperty("PlaylistID", util.safe_str(item['PlaylistID']))
        listitem.SetProperty("IsPlaylist", "True")
        for (key, value) in self.flags.items():
            listitem.SetProperty(key, value)
        return listitem
        
class StationList(List):
    def __init__(self):
        List.__init__(self)
        self.primary = 'StationName'
        
    def getListItemFromItem(self, item):
        listitem = ListItem(ListItem.MEDIA_UNKNOWN)
        listitem.SetLabel(util.safe_str(item["StationName"]))
        listitem.SetProperty("StationID", util.safe_str(item["StationID"]))
        for (key, value) in self.flags.items():
            listitem.SetProperty(key, value)
        return listitem
