# model.queue
# extended song list, customized for playback

from mc import PlayList, GetPlayer, ListItems, ShowDialogWait, HideDialogWait
from random import shuffle

from sys import path
path.append(r'u:\apps\grooveshark\\')

from model.list import SongList

from gs import user

class Queue(SongList):
    def __init__(self):
        SongList.__init__(self)
        self.playlist = PlayList(PlayList.PLAYLIST_MUSIC)
        self.indices = []
        self.shuffle = False
        self.repeat = False

    def setItems(self, items):
        SongList.setItems(self, items)
        self.generatePlaylist()

    def clear(self): 
        SongList.clear(self)
        self.playlist.Clear()

    def isRadio(self):
        return False

    def setRepeat(self, repeat):
        self.repeat = repeat

    def isRepeat(self):
        return self.repeat

    def setShuffle(self, shuffle):
        self.shuffle = shuffle
        self.generatePlaylist()
        
    def isShuffle(self):
        return self.shuffle

    def getPlaylistItem(self, playlistPosition):
        try:
            return self.playlist.GetItem(playlistPosition)
        except:
            return None

    def getPlaylistPosition(self, queuePosition=-1):
        try:
            if queuePosition >= 0:
                return self.indices.index(queuePosition)
            return self.playlist.GetPosition()
        except:
            return 0

    def getQueuePosition(self):
        try:
            if self.size() > 0 and self.getPlaylistPosition() >= 0:
                return self.indices[self.getPlaylistPosition()]
            return 0
        except:
            return 0
    
    def generatePlaylist(self):
        """ Generate playlist for the given queue. """
        # rebuild indices. not pretty but it works
        print "calling queue.generatePlaylist"
        self.indices = range(self.size())
        if self.shuffle:
            shuffle(self.indices)
        self.playlist.Clear()
        print ('GEN PLAYLIST', 'indexes', self.indices, 'size', self.size())
        self.dirty = True
        for index in self.indices:
            song = self.getListItem(index)
            self.playlist.Add(song)
         
    def insertNext(self, items):
        position = self.getQueuePosition() + 1
        self.insert(items, position)
        return position - 1

    def isEmpty(self):
        if len(self.items) == 0:
            return True 
        else:
            return False

    def insertLast(self, items):
        """ handling this in queue so I can extend it in RadioQueue """
        self.append(items)

class RadioQueue(Queue):
    def __init__(self):
        Queue.__init__(self)
        self.autoplay = None
        self.voteStates = {} # songID => [-1, 0, 1]
        self.recSong = {}

    def setAutoplay(self, autoplay): 
        self.autoplay = autoplay
        print ('RadioQueue.setAutoplay', autoplay, autoplay.getState())
        #self.resetRecommendation()
 
    def getAutoplay(self):
        return self.autoplay

    def isRepeat(self):
        return False

    def isShuffle(self):
        return False

    def isRadio(self):
        return True

    def setItems(self, items):
        print ('RadioQueue.setItems', items)
        oldItems = {}
        for item in self.items:
            songID = int(item['SongID'])
            oldItems[songID] = item
        print ('SETTING NEW ITEMS...', items)
        for item in items:
            songID = int(item['SongID'])
            self.voteStates[songID] = self.voteStates.get(songID, 0)
        Queue.setItems(self, items)
        newItems = {}
        print ('RadioQueue.setItems', 'BEFORE ADDSONGS', self.autoplay.getState())
        for item in self.getItems():
           songID = int(item['SongID'])
           newItems[songID] = item
           # check if item was added
           if oldItems.has_key(songID):
               self.autoplay.addSongsToAutoplay(item)
        print ('RadioQueue.setItems', 'AFTER ADDSONGS', self.autoplay.getState())
        self.resetRecommendation()
        # self.resetRecommendedSong()

    def removeByIndex(self, index):
        item = Queue.removeByIndex(self, index)
        Queue.removeByIndex(self, len(self.items)-1)
        self.autoplay.removeSongFromAutoplay(item)
        self.generatePlaylist()

    # def insertNext(self, items):
    #     position = self.getQueuePosition() + 1
    #     self.insert(items, position)
    #     for i in items:
    #         self.autoplay.addSongToAutoplay(i)
    #     self.resetRecommendedSong()
    #     return position - 1

    def insert(self, items, index):
        """ extending to add vote state & replace rec'd song """
        ShowDialogWait()
        Queue.removeByIndex(self, len(self.items)-1)
        if not isinstance(items, list):
            items = [items]
        self.autoplay.addSongsToAutoplay(items)
        for item in items:
            self.items.insert(index, item)
            self.setVoteState(item['SongID'])
            index += 1
        self.setItems(self.items)
        HideDialogWait()

    def insertLast(self, items):
        """ need to reset rec'd song """
        ShowDialogWait()
        Queue.removeByIndex(self, len(self.items)-1)
        self.append(items)
        for item in items:
            self.setVoteState(item['SongID'])
        self.autoplay.addSongsToAutoplay(items)
        HideDialogWait()
         
    def voteUp(self, song, resetRec=True):
        songID = int(song['SongID'])
        # self.removeRecommendedSong()
        vote = self.voteStates.get(songID, 0)
        if vote == 0:
            self.voteStates[songID] = 1
            self.autoplay.voteUp(song)
        elif vote == -1:
            self.voteStates[songID] = song
            self.autoplay.removeVoteDown(songID)
            self.autoplay.voteUp(songID)
        elif vote == 1:
            self.voteStates[songID] = 0
            self.autoplay.removeVoteUp(song)
        self.dirty = True
        # self.resetRecommendation()
        if resetRec:
            self.resetRecommendedSong()
        else:
            self.resetRecommendation()

    def voteDown(self, song):
        songID = int(song['SongID'])
        # self.removeRecommendedSong()
        vote = self.voteStates.get(songID, 0)
        if vote == 0:
            self.voteStates[songID] = -1
            self.autoplay.voteDown(song)
        elif vote == -1:
            self.voteStates[songID] = 0
            self.autoplay.removeVoteDown(song)
        elif vote == 1:
            self.voteStates[songID] = -1
            self.autoplay.removeVoteUp(song)
            self.autoplay.voteDown(songsong)
        self.dirty = True
        # self.resetRecommendation()
        self.resetRecommendedSong()

    def getVoteState(self, songID):
        return self.voteStates[songID]

    def setVoteState(self, songID, voteState=1):
        """ set vote states for seeds (implicitly voted up) """
        self.voteStates[songID] = voteState

    def getListItemFromItem(self, item):
        """ Overriding SongList in order to add Vote state flags """
        voteKeys = {1: 'IsVoteUp', -1: 'IsVoteDown'}
        songID = int(item['SongID'])
        vote = self.voteStates.get(songID, 0)
        listitem = Queue.getListItemFromItem(self, item)
        if vote:
            voteKey = voteKeys[vote]
            listitem.SetProperty(voteKey, 'True')
        return listitem

    def generateListItems(self):
        """ Overiding SongList in order to add IsLast state flag for Rec'd Song """
        """ Abandon hope all ye who enter here """
        Queue.generateListItems(self)
        self.items.append(self.recSong)
        self.indices.append(len(self.indices))
        listitems = ListItems()
        for index, item in enumerate(self.items):
            listitem = self.getListItemFromItem(item)
            if index == len(self.items) - 1:
                listitem.SetProperty('IsLast', 'True')
                self.playlist.Add(listitem)
            listitems.append(listitem)
        self.listitems = listitems
        self.dirty = False
        

    def getRecommendation(self):
        if not self.recSong:
            self.resetRecommendation()
        return self.recSong

    def resetRecommendation(self):
        self.recSong = self.autoplay.getNextSong()

    def refreshRecommendation(self):
        self.recSong = self.getRecommendation()
        self.generateListItems()

    # helpers

    def resetRecommendedSong(self):
        """ Replaces the rec'd song.  Giving it a different name for backwards compatibility """
        if self.recSong:
            Queue.removeByIndex(self, len(self.items)-1)
        self.refreshRecommendation()

    
