# model.page
# page models for boxee's different views

from mc import GetWindow, ListItems, ListItem

from sys import path
path.append(r'u:\apps\grooveshark\\')

from util import show, hide, safe_str
import list
from definitions import *

# Using these for autocomplete
from threading import Timer
from gs.service import Request

# page model

class Page(object):
    def __init__(self, *args, **kwargs):
        self.name = self.__class__.__name__
        self.args = args
        self.kwargs = kwargs
        self.order = 0
        self.item = {}
        self.context = ''
        if len(self.args) > 0:
            self.pageItem = self.args[0]
        elif self.kwargs.has_key('item'):
            self.pageItem = kwargs['item']

    def setOrder(self, order):
        self.order = order

    def prepare(self):
        if self.hasList():
            self.list.setListID(self.getListID())
            self.list.setFlag('Context', self.name)
            self.list.setFlag('StateOrder', self.order)
            self.list.clear()
            self.list.setItems(self.getItems(*self.args, **self.kwargs))
            self.list.sort()

    def render(self):
        if self.hasList():
            self.list.render()
            if self.list.size() > 0:
                show(LIST_OPTIONS_ID)
            else:
                hide(LIST_OPTIONS_ID)
        self.page(*self.args, **self.kwargs)
 
    # skin control group ids
    def getSkinIDs(self):
        return definitions.get(self.name, definitions.get('Blank'))

    def getViewID(self):
        return self.getSkinIDs()[0]

    def getContentID(self):
        return self.getSkinIDs()[4]

    def getContextID(self):
        return self.getSkinIDs()[7]

    def getListID(self):
        return self.getSkinIDs()[3]

    def hasList(self):
        return self.getListID() > 0

    def getOptionsID(self):
        return self.getSkinIDs()[6]

    def getSidebarID(self):
        return self.getSkinIDs()[1]

    def getSidebarSortID(self):
        return self.getSkinIDs()[8]

    def getSidebarSortDefault(self):
        try:
            if self.sidebarSortDefault:
                return self.sidebarSortDefault
            else:
                return self.getSkinIDs()[11]
        except Exception, e:
            return self.getSkinIDs()[11]

    def setSidebarSortDefault(self, sortID):
        if sortID > 0:
            self.sidebarSortDefault = sortID

    def getSidebarShowID(self):
        return self.getSkinIDs()[9]

    def getSidebarDefaults(self):
        return self.getSkinIDs()[10], self.getSidebarSortDefault()

    def isSidebarOpen(self):
        return self.getSidebarID() > 0
        
    def isSidebarVisible(self):
        return GetWindow(14002).GetControl(self.getSidebarID()).IsVisible()
  
    def getNavigationID(self):
        try:
            return self.navigationID
        except:
            return self.getSkinIDs()[5]
 
    def setNavigationID(self, navID):
        self.navigationID = navID
        
    def getSidebarLastID(self):
        return self.getSkinIDs()[12]
        
    def getCtrlGroupID(self):
        return self.getSkinIDs()[2]

    # actions 
    def hideContent(self):
        """ Hides page's list, list control group, and options """
        hide(self.getSkinIDs()[0], self.getSkinIDs()[2], self.getSkinIDs()[3], self.getContentID(), self.getSkinIDs()[13])
        self.setContext(' ')

    def showContent(self):
        """ Shows page's list, list control group, and options """
        show(self.getSkinIDs()[0], self.getSkinIDs()[2], self.getContentID())
        #show(self.getSkinIDs()[0], self.getSkinIDs()[2], self.getSkinIDs()[3], self.getContentID())

    def showSidebar(self):
        show(self.getSkinIDs()[1], self.getSkinIDs()[8], self.getSkinIDs()[9])

    def close(self):
        self.hideContent()
        # hide(self.getSidebarID())
        # hide(self.getSidebarShowID())
        # hide(self.getSidebarSortID())
        self.context = ''

    # helpers
    def setContext(self, description, color='FFbbbbbb', nocount=False):
        description = description.strip()
        if not self.context:
            self.context = description
        if len(description) > 100:
            description = (description[:97] + '...')
        if description == '':
            context = ''
        elif len(description) > 0:
            if self.getList() and not nocount:
                count = self.getList().size() #Number of items in the list
                context = safe_str('%s [COLOR %s](%s)[/COLOR]' % (description, color, count))
            else:
                context = safe_str(description)
        else:
            context = ''
        try:
            itemlist = ListItems()
            item = ListItem(ListItem.MEDIA_UNKNOWN)
            item.SetLabel(context)
            item.SetPath('')
            itemlist.append(item)
            list = GetWindow(WINDOW_ID).GetList(HIDDEN_CONTEXT_ID)
            list.SetItems(itemlist, 0)
        except:
            pass


    def restoreContext(self):
        self.setContext(self.context)
               
    def getList(self):
        try:
            return self.list
        except:
            return None 

    def setList(self, list): # accepts List
        self.list = list
        self.list.setListID(self.getListID())
        
    def getPageItem(self):
        return self.pageItem

    def setPageItemProperty(self, key, value):
        self.pageItem[key] = value

    # every subpage must implement load and click 
    def getItems(self, *args, **kwargs):
        """ Python list of data that will be converted to mc.ListItems """
        pass

    def page(self, *args, **kwargs):
        """ Extraneous work to display info on a page, optional """
        pass
 
    def click(self):
        """ Click handler function when clicking on ListItem on page """
        pass

    def __str__(self):
        return '%s (%s)' % (self.name, self.order)

class AlbumPage(Page):
    def __init__(self, *args, **kwargs):
        self.list = list.AlbumList()
        Page.__init__(self, *args, **kwargs)

class ArtistPage(Page):
    def __init__(self, *args, **kwargs):
        self.list = list.ArtistList()
        Page.__init__(self, *args, **kwargs)

class PlaylistPage(Page):
    def __init__(self, *args, **kwargs):
        self.list = list.PlaylistList()
        Page.__init__(self, *args, **kwargs)
        
class StationPage(Page):
    def __init__(self, *args, **kwargs):
        self.list = list.StationList()
        Page.__init__(self, *args, **kwargs)

class SongPage(Page):
    def __init__(self, *args, **kwargs):
        self.list = list.SongList()
        Page.__init__(self, *args, **kwargs)

    def setAlbumArt(self):
        """ This fixes the default art being shown when scrolling through long albums """
        items = self.getList().getAll()
        filename = ''
        for item in items:
            if item['CoverArtFilename'] != '':
                filename = item['CoverArtFilename']
                break
        try:
            GetWindow(WINDOW_ID).GetImage(self.getSkinIDs()[14]).SetTexture('http://beta.grooveshark.com/static/amazonart/m' + safe_str(filename))
        except:
            pass

    def generatePlaylistThumb(self):
        """ Generates the 4-album thumbnail for playlists """
        albumDict = {}
        albumArr = []
        items = self.getList().getItems()
        if len(items) < 100: # generating the four album thumb is a MAJOR slowdown on the box for large playlists so limiting to 100
            for i in self.getList().getItems():
                albumID = str(i['AlbumID'])
                if not albumDict.has_key(albumID) and i['CoverArtFilename'] is not None:
                    albumDict[albumID] = {'CoverArtFileName':i['CoverArtFilename'], 'Weight':1}
                elif albumDict.has_key(albumID):
                    albumDict[albumID]['Weight'] += 1
        else:
            for i in self.getList().getItems()[:100]:
                albumID = str(i['AlbumID'])
                if not albumDict.has_key(albumID) and i['CoverArtFilename'] is not None:
                    albumDict[albumID] = {'CoverArtFileName':i['CoverArtFilename'], 'Weight':1}
                elif albumDict.has_key(albumID):
                    albumDict[albumID]['Weight'] += 1
        for key, value in albumDict.iteritems():
            e = [
                    value['Weight'],
                    value['CoverArtFileName']
                ]
            albumArr.append(e)
        if len(albumArr) < 4:
            pass
        else:
            albumArr.sort(key=lambda x: x[0], reverse=True) #sort album art arry by weight
            artArr = albumArr[:4] # Slice dat array
            show(13000)
            for i, val in enumerate(artArr):
                imgID = int(13001 + i)
                GetWindow(WINDOW_ID).GetImage(imgID).SetTexture('http://beta.grooveshark.com/static/amazonart/m' + safe_str(val[1]))

class RegularPage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        
######
# Rolling this into more generic SearchPage
######
# class EmptyPage(Page):
#     def __init__(self, *args, **kwargs):
#         Page.__init__(self, *args, **kwargs)
    # def drawEmptyPageMessages(self,header="",sub=""):
    #         try:
    #             itemlist = ListItems()
    #             item = ListItem(ListItem.MEDIA_UNKNOWN)
    #             item.SetLabel(safe_str(header))
    #             item.SetArtist(safe_str(sub))
    #             item.SetPath('')
    #             itemlist.append(item)
    #             list = GetWindow(WINDOW_ID).GetList(HIDDEN_NORESULTS_INFO_ID)
    #             list.SetItems(itemlist, 0)
    #         except:
    #             pass

    
            
class SearchPage(Page):     
    def __init__(self, *args, **kwargs):
        self.autocompleteDelay = .4 # Rate limit calls to getAutoplaySearchResults
        Page.__init__(self, *args, **kwargs)

    def page(self):
        """ hacky fix for autocomplete not getting cleared """
        hide(self.getSkinIDs()[15])

    def setTimer(self, timer):
        self.timer = timer
        self.timer.start()    

    def setAutocompleteTimer(self):
        """ Rate-limits autcomplete api calls """
        try:
            self.timer.cancel()
            self.setTimer(Timer(self.autocompleteDelay, self.autocomplete))
        except:
            self.setTimer(Timer(self.autocompleteDelay, self.autocomplete))

    def autocomplete(self):
        query = GetWindow(WINDOW_ID).GetEdit(self.getContentID()).GetText()
        if query != '':
            request = Request('getAutocompleteSearchResults', {'query': safe_str(query), 'type':'music', 'limit':'4'})
            self.autocompleteResult = request.getResult('words')
        else:
            self.autocompleteResult = {}
        self.setAutocompleteItems()

    def setAutocompleteItems(self):
        import mc
        listitems = mc.ListItems()
        for i in self.autocompleteResult:
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(safe_str(i))
            item.SetPath('')
            listitems.append(item)
        l = mc.GetWindow(WINDOW_ID).GetList(self.getSkinIDs()[15])
        l.SetItems(listitems, -1)

    def drawEmptyPageMessages(self, header="", sub=""):
        try:
            itemlist = ListItems()
            item = ListItem(ListItem.MEDIA_UNKNOWN)
            item.SetLabel(safe_str(header))
            item.SetArtist(safe_str(sub))
            item.SetPath('')
            itemlist.append(item)
            list = GetWindow(WINDOW_ID).GetList(HIDDEN_NORESULTS_INFO_ID)
            list.SetItems(itemlist, 0)
        except:
            pass

    def close(self):
        """ Extending the close method to clear autocomplete list """
        self.autocompleteResult = {}
        self.setAutocompleteItems()
