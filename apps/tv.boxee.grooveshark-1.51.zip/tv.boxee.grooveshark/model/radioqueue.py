from mc import Playlist
from gs import autoplay, service

from sys import path
path.append(r'u:\apps\grooveshark\\')

def startRadio():
    queue = RadioQueue()

class RadioQueue(Queue):
	def __init__(self):
        SongList.__init__(self)
        self.playlist = PlayList(PlayList.PLAYLIST_MUSIC)
        self.indices = []
        self.isAutoplay = True

    def getAutoplayState(self):
        return autoplay.getAutoplay().getState()

    def setAutoplayState(self, state):
        autoplay.getAutoplay().setState(state)

    def getAutoplaySong(self):
        state = self.getAutoplayState()
        request = service.Request('getAutoplaySong', {'autoplayState':state})
        self.setAutoplayState(request.getResult('getAutoplayState'))

    def addSongToAutoplay(self, songObj):
    	state = self.getAutoplayState()
        request = service.Request('addSongToAutoplay', {'autoplayState':state, 'song':songObj})
        self.setAutoplayState(request.getResult('getAutoplayState'))

    def removeSongFromAutoplay(self, songObj):
        state = self.getAutoplayState()
        request = service.Request('removeSongFromAutoplay', {'autoplayState':state, 'song':songObj})
        self.setAutoplayState(request.getResult('getAutoplayState'))
        