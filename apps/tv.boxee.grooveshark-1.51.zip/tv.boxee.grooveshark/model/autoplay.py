# model.autoplay
# data model for autoplay objects

from sys import path
path.append(r'u:\apps\grooveshark\\')
from gs import service

class Autoplay(object):
    def __init__(self, state={}):
        print ('INIT AUTOPLAY', state)
        self.state = state
        self.seedArtistWeightRange = [110, 130]
        self.weightModifierRange = [-9, 9]
        self.secondaryArtistWeightModifier = 0.9
        self.minDuration = 60
        self.maxDuration = 1500
        self.recentArtists = []
        self.frowns = []
        self.songIDsAlreadySeen = []
        self.queueSongs = []
        self.frowns = []

    def getState(self):
        return self.state

    def setState(self, state):
        self.state = state

    def voteUp(self, songObj):
        # request = service.Request('voteUpAutoplaySong', {'song': songObj,'autoplayState': self.getState()})
        # if not request.hasError():
        #     state = request.getResult()
        #     print ('Autoplay.voteUp', state)
        #     self.setState(state)
        print songObj
        songID = songObj['SongID']
        artistID = songObj['ArtistID']
        state = self.getState()
        state['seedArtists'][artistID] = 'p'
        if artistID in state['frowns']:
            frowns.remove(artistID)
        self.setState(state)

    def removeVoteUp(self, songObj):
        # request = service.Request('removeVoteUpAutoplaySong', {'song': songObj,'autoplayState': self.getState()})
        # if not request.hasError():
        #     state = request.getResult()
        #     print ('Autoplay.removeVoteUp', state)
        #     self.setState(state)
        songID = songObj['SongID']
        artistID = songObj['ArtistID']
        state = self.getState()
        state['seedArtists'][artistID] = 's'
        self.setState(state)

    def voteDown(self, songObj):
        # request = service.Request('voteDownAutoplaySong', {'song': songObj, 'autoplayState': self.getState()})
        # if not request.hasError():
        #     state = request.getResult()
        #     print ('Autoplay.voteDown', state)
        #     self.setState(state)
        print songObj
        songID = songObj['SongID']
        artistID = songObj['ArtistID']
        state = self.getState()
        frowns = state['frowns']
        print state
        seedartists = state['seedArtists']
        newSeedArtists = {}
        for k,v in seedartists.items():
            if k != artistID:
                newSeedArtists[k] = v
        state['seedArtists'] = newSeedArtists
        if artistID not in frowns:
            frowns.append(artistID)
        self.setState(state)

    def removeVoteDown(self, songObj):
        # request = service.Request('removeVoteDownAutoplaySong', {'song': songObj, 'autoplayState': self.getState()})
        # if not request.hasError():
        #     state = request.getResult()
        #     print ('Autoplay.removeVoteDown', state)
        #     self.setState(state) 
        songID = songObj['SongID']
        artistID = songObj['ArtistID']
        state = self.getState()
        state['seedArtists'][artistID] = 's'
        frowns.remove(artistID)
        self.setState(state)

    def getNextSong(self):
        print ('Autoplay.getNextSong', 'sending autoplay', self.getState())
        request = service.Request('getAutoplaySong', {'autoplayState': self.getState()})
        state = request.getResult('autoplayState')
        self.setState(state)
        print ('Autoplay.getNextSong', request.getResult('nextSong'))
        return request.getResult('nextSong')

    def addSongsToAutoplay(self, songs):
        state = self.getState()
        print ('ADD SONG TO AUTOPLAY', 'aUTOPLAY=', state)
        # request = service.Request('addSongToAutoplay', {'song': songObj, 'autoplayState': self.getState()})
        # if not request.hasError():
        #     #state = request.getResult('autoplayState')
        #     state = request.getResult()
        #     print ('ADD SONGS TO AUTOPLAY', 'RESPONSE=', request.getResult())
        #     self.setState(state) 
            # WE DO IT LIVE!
        if type(songs) != list:
            songs = [songs]
        for song in songs:
            songID = int(song['SongID'])
            state['songIDsAlreadySeen'].append(songID)
            state['queuedSongs'][songID] = song['ArtistID']
            state['seedArtists'][song['ArtistID']] = 'p'
        self.setState(state)
        print ('ADD SONGS TO AUTOPLAY', 'RESPONSE=', self.state)
    
    def removeSongFromAutoplay(self, songObj):
        print "running autoplay.removeSongFromAutoplay()"
        request = service.Request('removeSongFromAutoplay', {'song': songObj, 'autoplayState': self.getState()})
        if not request.hasError():
            state = request.getResult()
            self.setState(state)

