import mc
app = mc.GetApp()
config = app.GetLocalConfig()
#clean crap from previous versions
config.Reset('label')
config.Reset('title')
config.Reset('path')
config.Reset('url')

mc.ActivateWindow(14000)
