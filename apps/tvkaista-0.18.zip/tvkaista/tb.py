#boxee tvkaista.fi plugin
#
#Copyright (C) 2009-2011  Viljo Viitanen <viljo.viitanen@iki.fi>
#
#This program is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public License
#as published by the Free Software Foundation; either version 2
#of the License, or (at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

#muutoshistoria:
#6.12.2010 ensimmainen versio - perustuu pitkälle xbmc-pluginiin
#7.12.2010 päivämäärävalikko ei toiminut
# lisätty thumbnail ohjelmalistauksiin
# kaikki paitsi edellisen päivien ohjelmalistaukset käännetyssä järjestyksessä
# "now playing" pikkuvideo päälimmäiseksi
#10.1.2011 helpompi asetusruutu (settings.xml), lisätty tuki tvkaistan välimuistipalvelimille
#6.2.2011 muutettu parametrien välitystä eri paikoissa, pientä hienosäätöä skineissä
# lisätty ohjelman toistoon väliin popup, jossa valintana "toista" ja "hae samannimisiä"
#9.2.2011 lisää ja poista Listaan ja Sarjoihin
#20.2.2011 fiksaus: pushstate ennen "hae samannimisiä", estetään silti rekursiivinen pushstate
#11.3.2011 sortataan sarjat
#5.6.2011 asetukset yläpalkkiin
#10.11.2011 proxycookie pois
#11.11.2011 jsessionid-cookie talteen

import urllib, urllib2, re, time, cookielib
from string import split, replace, find
from xml.dom import minidom
import mc
import locale
locale.setlocale(locale.LC_ALL, 'C')

def load(window):
  app = mc.GetApp()
  windowparams = app.GetLaunchedWindowParameters()
  config = app.GetLocalConfig()
  n = mc.GetWindow(window).GetList(100).GetFocusedItem()
  item = mc.GetWindow(window).GetList(100).GetItem(n)
  path = item.GetPath()
  label = item.GetLabel()
  params = mc.Parameters()
  if path=="Kanavat - tänään":
    params['label']=label
    params['path']='channels'
    app.ActivateWindow(14002, params)
  elif path=="Sarjat":
    params['label']=label
    params['path']='seasonpasses'
    app.ActivateWindow(14002, params)
  elif path=="Lista":
    params['title']=label
    params['path']=''
    params['url']='http://www.tvkaista.fi/feed/playlist'
    app.ActivateWindow(14003, params)
  elif path=="Elokuvat":
    params['title']=label
    params['path']='elokuvat'
    params['url']='http://www.tvkaista.fi/feed/search/title/elokuva'
    app.ActivateWindow(14003, params)
  elif path=="Haku":
    response = mc.ShowDialogKeyboard("Hae", "", False)
    if response:
      params['title']='Haku: '+response
      params['path']='search'
      params['url']='http://www.tvkaista.fi/feed/search/title/%s' % urllib.quote_plus(response)
      app.ActivateWindow(14003, params)
  elif path=="Asetukset":
    mc.ActivateWindow(14001)
  else:
    #kanavat per päivämäärä
    if window==14000:
      params['label']=label
      params['path']=path
      app.ActivateWindow(14002, params)
    else:
      params['title']= windowparams["label"]+' - '+label
      params['path']=''
      params['url']=path
      app.ActivateWindow(14003, params)
  

def play():
  config = mc.GetApp().GetLocalConfig()
  n = mc.GetWindow(14003).GetList(100).GetFocusedItem()
  item = mc.GetWindow(14003).GetList(100).GetItem(n)
  url = item.GetPath()
  if item.GetLabel().find("TALLENNE PUUTTUU") != -1:
    mc.ShowDialogOk("Tallenne puuttuu", "Tallennetta ei ole vielä saatavilla tällä laadulla.")
    return
  try:
    mc.ShowDialogWait()
    cj = cookielib.CookieJar()
    if config.GetValue("session") != '':
      ck = cookielib.Cookie(version=0, name='JSESSIONID', value='1', port=None, port_specified=False, domain='www.tvkaista.fi', domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None})
      cj.set_cookie(ck)
    passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
    passman.add_password(None, "http://www.tvkaista.fi", config.GetValue("username"), config.GetValue("password"))
    opener = urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman),urllib2.HTTPCookieProcessor(cj))
    urllib2.install_opener(opener)
    req = urllib2.Request(url)
    u = urllib2.urlopen(req)
    new = u.geturl()
    u.close()
    for c in cj:
      if c.name=="JSESSIONID":
        if config.GetValue("session") != c.value:
          config.SetValue("session",c.value)
    item.SetPath(new)
    mc.HideDialogWait()
    if mc.GetPlayer().IsPlaying():
        mc.GetPlayer().Stop()
    mc.GetPlayer().Play(item)
  except Exception, e:
    mc.HideDialogWait()
    mc.ShowDialogOk("WWW-haku ei onnistunut", str(e))

def bitrate():
  config = mc.GetApp().GetLocalConfig()
  quality = config.GetValue("quality")
  if quality=="1":
    return "mp4"
  elif quality=="2":
    return "flv"
  elif quality=="3":
    return "h264"
  elif quality=="4":
    return "ts"
  else:
    return "h264"


def main():
  config = mc.GetApp().GetLocalConfig()
  username = config.GetValue("username")
  password = config.GetValue("password")

  list = mc.GetWindow(14000).GetList(100)
  itemList = mc.ListItems()
  
  if username=="":
    item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
    item.SetPath("Asetukset")
    item.SetLabel("Asetukset")
    itemList.append(item)
    list.SetItems(itemList)
    return

  for i in ("Kanavat - tänään","Sarjat","Lista","Elokuvat","Haku"):
    item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
    item.SetPath(i)
    item.SetLabel(i)
    itemList.append(item)

  vko=['Maanantai','Tiistai','Keskiviikko','Torstai','Perjantai','Lauantai','Sunnuntai']
  t=time.time()
  for i in range(1,29):
    tt=time.localtime(t-86400*i)
    title='%s %s' % (vko[tt[6]], (time.strftime("%d.%m",tt)))
    u="%d/%d/%d/" % (tt[0],tt[1],tt[2])
    item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
    item.SetPath(u)
    item.SetLabel(title)
    itemList.append(item)
  list.SetItems(itemList)
  
#params kaytetaan play.xml:ssa, ladataan ikkunan sisalto uudestaan
def listprograms(params=None):
  config = mc.GetApp().GetLocalConfig()
  if params==None:
    windowparams = mc.GetApp().GetLaunchedWindowParameters()
  else:
    windowparams = params
  username = config.GetValue("username")
  password = config.GetValue("password")
  path = windowparams["path"]
  title = windowparams["title"]
  #boxeen bugi: pushstaten jälkeen labelit ei palaa
  if params==None:
    mc.GetWindow(14003).GetLabel(9022).SetLabel(title)

  list = mc.GetWindow(14003).GetList(100)
  itemList = mc.ListItems()
  list.SetItems(itemList)

  url = windowparams["url"]
  passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
  passman.add_password(None, "http://www.tvkaista.fi", username, password)
  opener = urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman))
  urllib2.install_opener(opener)
  try:
    mc.ShowDialogWait()
    content = urllib2.urlopen(url+'/'+bitrate()+'.rss').read()
  except urllib2.HTTPError,e:
    mc.HideDialogWait()
    mc.ShowDialogOk("WWW-haku ei onnistunut", str(e)+" "+url)
    mc.CloseWindow()
    return
  dom = minidom.parseString(content)
  try:
    #haetaan aikaero GMT->lokaaliaika. Oletetaan, etta boxeen/pythonin aika on oikea lokaaliaika...
    otherdate=dom.getElementsByTagName('channel')[0].getElementsByTagName('lastBuildDate')[0].childNodes[0].nodeValue
    timediff=time.time()-time.mktime(time.strptime(otherdate,"%a, %d %b %Y %H:%M:%S +0000"))
  except:
    timediff=0

#  try:
  items = dom.getElementsByTagName('item')
  if len(items) == 0:
    mc.HideDialogWait()
    mc.ShowDialogOk("Haku ei palauttanut yhtään ohjelmaa","")
    mc.CloseWindow()
    return
  #käänteinen järjestys kaikkeen paitsi edellisten päivien listauksiin
  if url.count("/feed/archives/")==0:
    items.reverse()
  ret = []
  for i in items:
    ptit=i.getElementsByTagName('title')[0].childNodes[0].nodeValue
#    print "in "+ptit.encode("utf-8")
    try:
      pdes=i.getElementsByTagName('description')[0].childNodes[0].nodeValue
    except:
      pdes=""
    pdat=i.getElementsByTagName('pubDate')[0].childNodes[0].nodeValue
    pcha=i.getElementsByTagName('source')[0].childNodes[0].nodeValue
    plin=i.getElementsByTagName('link')[0].childNodes[0].nodeValue
    pid = re.compile(r"([0-9]+)", re.IGNORECASE).findall(plin)[0]
    try:
      purl=i.getElementsByTagName('enclosure')[0].attributes['url'].value
    except:
      purl=pid
      ptit=ptit+" [COLOR red](TALLENNE PUUTTUU)[/COLOR]"
    t=time.localtime(timediff+time.mktime(time.strptime(pdat,"%a, %d %b %Y %H:%M:%S +0000")))
    if url.count("/feed/seasonpasses/")!=0:
      tark=time.strftime(" (%d.%m.)",t)
    elif url.count("/feed/search/")!=0:
      tark=time.strftime(" (%d.%m. ",t)+pcha+')'
    else:
      tark=""
    label=ptit+tark
    vko=['Maanantai','Tiistai','Keskiviikko','Torstai','Perjantai','Lauantai','Sunnuntai']
    paiva=vko[t[6]]
    desc = '[B]%s[/B][CR]%s %s (%s)[CR]%s' % (ptit,paiva,time.strftime("%d.%m. klo %H:%M",t),pcha, pdes)
    listitem = mc.ListItem( mc.ListItem.MEDIA_VIDEO_CLIP )
    listitem.SetLabel(label.encode("utf-8"))
    listitem.SetTitle(time.strftime("%H:%M",t))
    listitem.SetPath(purl.encode("utf-8"))
    listitem.SetDescription(desc.encode("utf-8"))
    listitem.SetThumbnail("http://www.tvkaista.fi/resources/recordings/screengrabs/%s.jpg"%(pid.encode("utf-8")))
    #estetään play.xml:ssä rekursiivinen pushstate
    if params!=None:
      listitem.SetProperty("issubsearch","true")
    itemList.append(listitem)
  dom.unlink()
  list.SetItems(itemList)
  mc.HideDialogWait()

def listfeed():
  config = mc.GetApp().GetLocalConfig()
  windowparams = mc.GetApp().GetLaunchedWindowParameters()
  label = windowparams["label"]
  path = windowparams["path"]
  mc.GetWindow(14002).GetLabel(9022).SetLabel(label)
  list = mc.GetWindow(14002).GetList(100)
  itemList = mc.ListItems()
  list.SetItems(itemList)

  if path=="channels" or path!="seasonpasses":
    content = config.GetValue("channels")
  else:
    passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
    passman.add_password(None, "http://www.tvkaista.fi", config.GetValue("username"), config.GetValue("password"))
    opener = urllib2.build_opener(urllib2.HTTPBasicAuthHandler(passman))
    urllib2.install_opener(opener)
    mc.ShowDialogWait()
    try:
      content = urllib2.urlopen("http://www.tvkaista.fi/feed/seasonpasses/").read()
    except urllib2.HTTPError,e:
      mc.HideDialogWait()
      mc.ShowDialogOk("WWW-haku ei onnistunut", str(e))
      mc.CloseWindow()
      return
    mc.HideDialogWait()

  dom = minidom.parseString(content)
  items = dom.getElementsByTagName('item')
  if len(items) == 0:
    if path=="seasonpasses":
      mc.ShowDialogOk("Haku ei palauttanut yhtään ohjelmaa","Et ehkä ole lisännyt vielä yhtään sarjaa.")
    else:
      mc.ShowDialogOk("Haku ei palauttanut yhtään ohjelmaa","")
    mc.CloseWindow()
    return
  if path=="seasonpasses":
    items.sort(key=lambda i: i.getElementsByTagName('title')[0].childNodes[0].nodeValue)
  for i in items:
    ptit=i.getElementsByTagName('title')[0].childNodes[0].nodeValue
    plin=i.getElementsByTagName('link')[0].childNodes[0].nodeValue
    item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
    if path!="channels" and path!="seasonpasses":
      plin=re.sub(r'/feed/','/feed/archives/'+path,plin)
    #print(plin.encode("utf-8"))
    item.SetPath(plin.encode("utf-8"))
    item.SetLabel(ptit.encode("utf-8"))
    itemList.append(item)
  dom.unlink()
  list.SetItems(itemList)

def addremove(action,id,label):
  config = mc.GetApp().GetLocalConfig()
  username = config.GetValue("username")
  password = config.GetValue("password")
  opts = {'action': 'login', 'username': username, 'password': password, 'rememberme':'on'}
  cj = cookielib.CookieJar()
  opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
  mc.ShowDialogWait()
  r = opener.open('http://www.tvkaista.fi/login/', urllib.urlencode(opts))
  try:
    if action==1:
      r = opener.open("http://www.tvkaista.fi/recordings/?action=addtoplaylist&id=%s"%id)
      mc.HideDialogWait()
      mc.ShowDialogOk(label, 'Ohjelma lisätty listalle.')
    elif action==2:
      r = opener.open("http://www.tvkaista.fi/recordings/?action=removefromplaylist&id=%s"%id)
      mc.HideDialogWait()
      mc.ShowDialogOk(label, 'Ohjelma poistettu listalta.')
    elif action==3:
      r = opener.open("http://www.tvkaista.fi/recordings/?action=addseasonpass&id=%s"%id)
      mc.HideDialogWait()
      mc.ShowDialogOk(label, 'Ohjelma lisätty sarjoihin')
    elif action==4:
      r = opener.open("http://www.tvkaista.fi/recordings/?action=removeseasonpass&spid=%s"%id)
      mc.HideDialogWait()
      mc.ShowDialogOk(label, 'Ohjelma poistettu sarjoista.')
    else:
      mc.HideDialogWait()
      mc.ShowDialogOk(label, 'Ohjelmavirhe! (addremove)')
  except Error:
      mc.HideDialogWait()
      mc.ShowDialogOk(label, 'Toiminto ei onnistunut!')

