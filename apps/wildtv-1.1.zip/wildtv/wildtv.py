import mc
import md5
from xml.dom.minidom import parseString
from time import time
from urllib import urlencode, quote_plus

class WildTV(object):
    url_base = 'https://www.wildtv.ca/api/'
    categories = {}
    show = {}
    asset = {}
    cat_index = 'free'
    token = ''
    
    def __init__(self):
        # Call home right off the hop, get the feed URLs
        mc.ActivateWindow(14001)
        self.box_id = mc.GetUniqueId()
        self.get_service_info()
        if not self.check_affiliation():
            if mc.ShowDialogConfirm('Affiliate',
                                    'Would you like to affiliate your device with your WildTV Account?  If you do not yet have a wildtv.ca account, please visit http://www.wildtv.ca and subscribe today!',
                                    'Free Previews',
                                    'Affiliate'):
                if self.affiliate():
                    mc.ShowDialogNotification("Your device is affiliated, enjoy!")
                else:
                    mc.ShowDialogNotification('Free Previews')
            else:
                mc.ShowDialogNotification('Free Previews')
        mc.CloseWindow()
    
    def run(self):
        self.populate_categories()
        self.update_category_page(self.cat_index)
    
    # UI INTERACTIONS
    def populate_categories(self):
        catlist = mc.ListItems()
        # take care of free previews, allshows, etc.
        for cat_id in self.categories.keys():
            cat = self.categories[cat_id]
            category = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
            category.SetProperty('cat_id', str(cat_id))
            category.SetLabel(cat['title'])
            category.SetProperty('icon', cat['icon'])
            catlist.append(category)
        mc.GetWindow(14000).GetList(102).SetItems(catlist)
    
    def update_category_page(self, cat_id):
        mc.ShowDialogWait()
        category = self.get_category_info(cat_id)
        mc.GetWindow(14000).GetLabel(107).SetLabel(category['title'])
        showlist = mc.ListItems()
        for show in category['shows']:
            item = mc.ListItem(mc.ListItem.MEDIA_PICTURE)
            item.SetProperty('show_id', show['id'])
            item.SetProperty('bannerthumb', show['banner_thumb'])
            item.SetLabel(show['title'])
            showlist.append(item)
        mc.GetWindow(14000).GetList(104).SetItems(showlist)
        mc.HideDialogWait()
    
    def show_page(self, show_id):
        self.show = self.get_show_info(show_id)
        self.setup_show_page()
    
    def setup_show_page(self):
        if self.show:
            mc.GetWindow(14002).GetImage(203).SetTexture(self.show['banner_thumb'])
            mc.GetWindow(14002).GetLabel(202).SetLabel(self.show['title'])
            if self.show['preview_only']:
                mc.GetWindow(14002).GetLabel(205).SetVisible(True)
            else:
                mc.GetWindow(14002).GetLabel(205).SetVisible(False)
            assets = mc.ListItems()
            for show_asset in self.show['assets']:
                asset = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
                asset.SetLabel(show_asset['title'])
                asset.SetTitle(show_asset['title'])
                asset.SetTVShowTitle(self.show['title'])
                asset.SetDescription(show_asset['description'])
                asset.SetProperty('asset_id', show_asset['id'])
                asset.SetProperty('keyart', show_asset['keyart'])
                assets.append(asset)
            mc.GetWindow(14002).GetList(201).SetItems(assets)
    
    def asset_page(self, asset_id):
        self.asset = self.get_asset_info(asset_id)
        self.setup_asset_page()
    
    def setup_asset_page(self):
        if self.asset:
            mc.GetWindow(14003).GetLabel(301).SetLabel(self.asset['title'])
            mc.GetWindow(14003).GetImage(302).SetTexture(self.asset['keyart'])
            mc.GetWindow(14003).GetTextbox(303).SetText(self.asset['description'])
            if self.asset['preview_only']:
                mc.GetWindow(14003).GetLabel(305).SetVisible(True)
            else:
                mc.GetWindow(14003).GetLabel(305).SetVisible(False)
            profiles = mc.ListItems()
            for bitrate in sorted(self.asset['profiles'].keys(), key=int, reverse=True):
                asset_profile = self.asset['profiles'][bitrate]
                profile = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
                profile.SetProperty('quality', asset_profile)
                profile.SetTVShowTitle(self.asset['show_title'])
                profile.SetTitle(self.asset['title'])
                profile.SetDescription(self.asset['description'])
                profile.SetProperty('bitrate', bitrate)
                profile.SetProperty('asset_id', self.asset['id'])
                profiles.append(profile)
            mc.GetWindow(14003).GetList(304).SetItems(profiles)
    
    def authorize_asset(self, item):
        asset_id = item.GetProperty('asset_id')
        expires = int(time()) + 3600
        http = mc.Http()
        params = {'id' : asset_id, 'expires' : expires, 'token' : self.token }
        url = '?'.join((self.url_base+'authorize.xml', urlencode(params)))
        m = md5.new(url)
        signed_url = url + '&sig=' + m.hexdigest()
        data = http.Get(signed_url)
        resp = parseString(data)
        # FIXME - finish redone content auth
        xml_success = resp.getElementsByTagName('success')[0]
        success = xml_success.firstChild.nodeValue
        if success == 'true' or success == 'preview':
            for url in resp.getElementsByTagName('url'):
                if url.getAttribute('bitrate') == item.GetProperty('bitrate'):
                    playlink = url.firstChild.nodeValue.encode('ascii','replace')
                    item.SetPath(playlink)
            player = mc.GetPlayer()
            player.Play(item)
        else:
            mc.ShowDialogNotification("Error, unable to authenticate asset.")
    # GET META INFO
    def get_info(self, params):
        http = mc.Http()
        url = '?'.join((self.url_base+'getInfo.xml', urlencode(params)))
        data = http.Get(url)
        response = parseString(data)
        return response
        
    def get_service_info(self):
        resp = self.get_info({'type' : 'service'})
        categories = {}
        for xml_cat in resp.getElementsByTagName('category'):
            cat_id = xml_cat.getAttribute('id')
            xml_title = xml_cat.getElementsByTagName('title')[0]
            title = xml_title.firstChild.nodeValue.encode('ascii','replace')
            xml_icon = xml_cat.getElementsByTagName('icon')[0]
            icon = xml_icon.firstChild.nodeValue.encode('ascii','replace')
            categories[cat_id] = {'title': title, 'icon': icon}
        if resp.getElementsByTagName('default_category'):
            xml_default = resp.getElementsByTagName('default_category')[0]
            self.cat_index = xml_default.getAttribute('id')
        else:
            self.cat_index = '2'
        self.categories = categories
    
    def get_category_info(self, cat_id):
        params = { 'type' : 'category', 'id' : cat_id }
        resp = self.get_info(params)
        xml_cat = resp.getElementsByTagName('category')[0]
        xml_title = xml_cat.getElementsByTagName('title')[0]
        title = xml_title.firstChild.nodeValue.encode('ascii','replace')
        shows = []
        for xml_show in xml_cat.getElementsByTagName('show'):
            show = {}
            show_id = str(xml_show.getAttribute('id'))
            xml_show_title = xml_show.getElementsByTagName('title')[0]
            show_title = xml_show_title.firstChild.nodeValue.encode('ascii','replace')
            show_banner_thumb = ''
            for banner in xml_show.getElementsByTagName('banner'):
                if banner.getAttribute('type') == 'thumb':
                    show_banner_thumb = str(banner.firstChild.nodeValue)
            show['title'] = show_title
            show['banner_thumb'] = show_banner_thumb
            show['id'] = show_id
            shows.append(show)
            
        return { 'title' : title, 'shows' : shows }
    
    def get_show_info(self, show_id):
        show = {'id' : show_id}
        params = {'type' : 'show', 'id' : show_id}
        resp = self.get_info(params)
        xml_show = resp.getElementsByTagName('show')[0]
        xml_show_title = xml_show.getElementsByTagName('title')[0]
        show_title = xml_show_title.firstChild.nodeValue.encode('ascii','replace')
        show['title'] = show_title
        show_banner_thumb = ''
        if xml_show.getElementsByTagName('preview_only'):
            show['preview_only'] = True
        else:
            show['preview_only'] = False

        for xml_banner in xml_show.getElementsByTagName('banner'):
            if xml_banner.getAttribute('type') == 'thumb':
                show_banner_thumb = xml_banner.firstChild.nodeValue.encode('ascii','replace')
        show['banner_thumb'] = show_banner_thumb
        assets = []
        for xml_asset in xml_show.getElementsByTagName('asset'):
            asset = {'id' : str(xml_asset.getAttribute('id'))}
            xml_asset_title = xml_asset.getElementsByTagName('title')[0]
            asset_title = xml_asset_title.firstChild.nodeValue.encode('ascii','replace')
            asset['title'] = asset_title
            
            xml_asset_desc = xml_asset.getElementsByTagName('description')[0]
            asset_desc = xml_asset_desc.firstChild.nodeValue.encode('ascii','replace')
            asset['description'] = asset_desc
            
            asset_keyart = ''
            for xml_image in xml_asset.getElementsByTagName('image'):
                if xml_image.getAttribute('type') == 'hd':
                    asset_keyart = xml_image.firstChild.nodeValue.encode('ascii','replace')
            asset['keyart'] = asset_keyart
            assets.append(asset)
        show['assets'] = assets
        return show
    
    def get_asset_info(self, asset_id):
        asset = {'id' : asset_id}
        params = {'type' : 'asset', 'id' : asset_id}
        resp = self.get_info(params)
        xml_asset = resp.getElementsByTagName('asset')[0]
        xml_asset_title = xml_asset.getElementsByTagName('title')[0]
        asset_title = xml_asset_title.firstChild.nodeValue.encode('ascii','replace')
        asset['title'] = asset_title
        
        if xml_asset.getElementsByTagName('show_title'):
            xml_show_title = xml_asset.getElementsByTagName('show_title')[0]
            show_title = xml_show_title.firstChild.nodeValue.encode('ascii','replace')
        else:
            show_title = self.show['title']
        asset['show_title'] = show_title
        xml_asset_desc = xml_asset.getElementsByTagName('description')[0]
        asset_desc = xml_asset_desc.firstChild.nodeValue.encode('ascii','replace')
        asset['description'] = asset_desc
        
        if xml_asset.getElementsByTagName('preview_only'):
            asset['preview_only'] = True
        else:
            asset['preview_only'] = False
        asset_keyart = ''
        for xml_image in xml_asset.getElementsByTagName('image'):
            if xml_image.getAttribute('type') == 'hd':
                asset_keyart = xml_image.firstChild.nodeValue.encode('ascii','replace')
        asset['keyart'] = asset_keyart
        
        profiles = {}
        for xml_profile in xml_asset.getElementsByTagName('profile'):
            bitrate = str(xml_profile.getAttribute('bitrate'))
            title = xml_profile.firstChild.nodeValue.encode('ascii','replace')
            profiles[bitrate] = title
        asset['profiles'] = profiles
        return asset
    # USER AFFILIATION
    # FIXME : This has to be reworked in a cross-platform manner
    def check_affiliation(self):
        http = mc.Http()
        params = {'deviceid' : self.box_id, 'devicetype' : 'boxee'}
        url = '?'.join((self.url_base+'affiliate.xml', urlencode(params)))
        data = http.Get(url)
        resp = parseString(data)
        xml_success = resp.getElementsByTagName('success')[0]
        success = str(xml_success.firstChild.nodeValue)
        if success == 'true':
            affiliated = True
            xml_token = resp.getElementsByTagName('token')[0]
            self.token = xml_token.firstChild.nodeValue
        else:
            affiliated = False
        return affiliated
    
    #FIXME : make process smoother + rework in cross-platform manner
    def affiliate(self):
        uname = mc.ShowDialogKeyboard("Enter your wildtv.ca Username/Email", "", False)
        pword = mc.ShowDialogKeyboard("Enter your wildtv.ca Password", "", True)
        if uname and pword:
            http = mc.Http()
            params = { 'type': 'login', 'username' : uname, 'password' : pword, 'deviceid' : self.box_id, 'devicetype' : 'boxee'}
            url = self.url_base + "affiliate.xml"
            data = http.Post(url, urlencode(params))
            resp = parseString(data)
            xml_success = resp.getElementsByTagName('success')[0]
            success = xml_success.firstChild.nodeValue
            if success == 'true':
                xml_affiliation = resp.getElementsByTagName('affiliation')[0]
                xml_token = xml_affiliation.getElementsByTagName('token')[0]
                self.token = xml_token.firstChild.nodeValue
                return True
            else:
                if 'affiliation' in resp.childNodes:
                    xml_affiliation = resp.getElementsByTagName('affiliation')[0]
                    xml_reason = xml_affiliation.getElementsByTagName('reason')[0]
                    reason = xml_reason.firstChild.nodeValue
                    if reason == 'badpw':
                        if mc.ShowDialogConfirm('Password',
                                            'The password does not match our records.',
                                            'Free Previews',
                                            'Try Again'):
                            return self.affiliate()
                        else:
                            return False
                    else:
                        return False
                else:
                    if mc.ShowDialogConfirm('Username',
                                            'There is no user with this username, please visit http://www.wildtv.ca/ to sign up.',
                                            'Free Previews',
                                            'Try Again'):
                        return self.affiliate()
                    else:
                        return False