import mc
import wildtv

mc.ActivateWindow(14000) # Load the category (main) window
w = wildtv.WildTV()
w.run()