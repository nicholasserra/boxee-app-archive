'''
Created on 29 May 2010

@author: tom
'''
import unittest
from ContextSpecification import ContextSpecification
import Infrastructure.Api

class KnownCustomer(object):
	def __init__(self):
		self.ValidUsername = "tom@greatboxee.com"
		self.ValidPassword = "Turn1p5"
		self.FirstName = "Tom"
		self.LastName = "Philip"
		self.CustomerId = "5773B6CC0cbf20862ANly2118E65"
		self.FeedId = "f44ec220e6db305a53db1bc1dccb024c50a628bd7ae189342a2ca55e0e37011a"

class when_signing_in_with_valid_credentials(ContextSpecification):

	def EstablishContext(self):
		self.api = Infrastructure.Api.AuthenticationApi()

	def When(self):
		self.result = self.api.SignIn(KnownCustomer().ValidUsername, KnownCustomer().ValidPassword)
		pass

	def test_should_authenticate_successfully(self):
		self.assertTrue(self.result.Successful)
		
	def test_should_get_the_customers_first_name(self):
		self.assertEquals(self.result.Customer.FirstName, KnownCustomer().FirstName)

	def test_should_get_the_customers_lastname(self):
		self.assertEquals(self.result.Customer.LastName, KnownCustomer().LastName)

	def test_should_get_the_customers_id(self):
		self.assertEquals(self.result.Customer.Id, KnownCustomer().CustomerId)
		
	def test_should_get_the_customers_feed_id(self):
		self.assertEquals(self.result.Customer.FeedId, KnownCustomer().FeedId)
		
class when_signing_in_with_invalid_credentials(ContextSpecification):

	def EstablishContext(self):
		self.api = Infrastructure.Api.AuthenticationApi()

	def When(self):
		self.result = self.api.SignIn("surely_i_dont_exist", "bob")
		pass

	def test_should_not_authenticate(self):
		self.assertFalse(self.result.Successful)

class when_building_the_sign_in_url(ContextSpecification):

	def EstablishContext(self):
		self.api = Infrastructure.Api.AuthenticationApi()

	def When(self):
		self.result = self.api._authenticationUrl % {'uid': 'test', 'pwd': 'test'}
		pass

	def test_should_not_contain_spaces(self):
		self.assertEquals(self.result, "http://api.nodplatform.com/boxee/auth.xml?username=test&password=test&token=F7CCA699389E350AE2E6D0ED531A06349EFDC1861D6BCAF62D97DAB26099ECB3")

if __name__ == "__main__":
	#import sys;sys.argv = ['', 'Test.test_']
	unittest.main()