# To change this template, choose Tools | Templates
# and open the template in the editor.

import unittest

class  ContextSpecification(unittest.TestCase):
    def setUp(self):
        self.EstablishContext()
        self.When()