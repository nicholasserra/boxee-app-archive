import mc, sys, os, cgi, urllib, urllib2, time, re

# GET
def _get(id):
	config = mc.GetApp().GetLocalConfig()
	return config.GetValue(id)

# SET
def _set(id, val):
	config = mc.GetApp().GetLocalConfig()

	if val == False:
		config.Reset(id)
	else:
		config.SetValue(id, str(val))

def launch(id, params):
	p = mc.Parameters()

	if (params != False):
		for i in params:
			p[i] = params[i]

	mc.GetApp().ActivateWindow(id, p)

# Post / Get
def call(url, params):
	mc.ShowDialogWait()
	enc = urllib.urlencode(params)
	#mc.Http().Post()
	rsp = mc.Http().Get(url + '?' + enc)
	mc.HideDialogWait()
	return rsp

def quickLaunch(id):
	mc.GetApp().ActivateWindow(id, mc.Parameters())

def sort(s, force_refresh):
	_set('searching', False)
	LAST_REFRESH = _get('last_feed_refresh')

	if force_refresh == True or not LAST_REFRESH:
		t = str(time.time())
		_set('last_feed_refresh', t)
		LAST_REFRESH = t

	list = mc.GetActiveWindow().GetList(51)

	items = False

	mc.ShowDialogWait()
#	if s == 'atoz':
	if True:
		_set('ui_sort_atoz', True)
		_set('ui_sort_date', False)

		_set('feed_sort', 'atoz')
		_set('sort_label', '')

		items = mc.GetDirectory('rss://app.boxee.tv/rssapi/userfeeds?sort=name&v=' + str(LAST_REFRESH))

	else:
		_set('ui_sort_atoz', False)
		_set('ui_sort_date', True)

		_set('feed_sort', 'date')
		_set('sort_label', 'Recently Added')

		items = mc.GetDirectory('rss://app.boxee.tv/rssapi/userfeeds?sort=date&v=' + str(LAST_REFRESH))

	mc.HideDialogWait()

	if len(items) == 0:
		control = mc.GetActiveWindow().GetControl(8000)
		control.SetFocus()

	list.SetItems(items)

def user_feed_search():
	search = mc.ShowDialogKeyboard("Search your feeds", "", False)

	if search != '':
		mc.GetActiveWindow().PopState()
		mc.GetActiveWindow().PushState()
		list = mc.GetActiveWindow().GetList(51)
		list.SetContentURL('rss://app.boxee.tv/rssapi/userfeeds?type=search&query=%s' % (search))
		_set('searching', search)

def add_new_feed():
	url = mc.ShowDialogKeyboard("Enter an RSS feed URL", "", False)
	rsp = subscribe_toggle(url, True)

	url = re.compile("<url>http://(.*?)<\/url>").findall(rsp)[0]

	if url:
		item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
		item.SetLabel(re.compile("<title>(.*?)<\/title>").findall(rsp)[0])
		item.SetPath('rss://' + url)
		item.SetThumbnail(re.compile("<thumbnail>(.*?)<\/thumbnail>").findall(rsp)[0])
		item.SetProperty('subscribed', '1')
		go_to_page('feed', item)

def subscribe_btn_click():
	params = mc.GetApp().GetLaunchedWindowParameters()
	btn = mc.GetActiveWindow().GetToggleButton(1001)

	if not _get('feed_subscribed'):
		subscribe_toggle(params['path'], True)
		btn.SetSelected(True)
		mc.ShowDialogNotification("Added to Favorites", "icons/icon_star.png")
	else:
		subscribe_toggle(params['path'], False)
		btn.SetSelected(False)
		mc.ShowDialogNotification("Removed from Favorites", "icons/icon_star.png")


def subscribe_toggle(url, subscribe):
	if subscribe == True:
		s = '1'
		_set('feed_subscribed', 1)
	else:
		s = '0'
		_set('feed_subscribed', False)

	_set('last_feed_refresh', False)

	return call('http://app.boxee.tv/rssapi/subscribe', { 'url': url, 'subscribe': s })

def directory_search():
	search = mc.ShowDialogKeyboard("Search Directory for RSS Feeds", "", False)
	_set('dir_cur_label', 'MiroSearch')
	_set('dir_search', search)
	_set('dir_cur_page', 0)
	directory_paginate()
	_set('searching', search)
	_set('category', False)
	#call('http://app.boxee.tv/rssapi/directory', { 'url': url, 'subscribe': '1' })

def directory_click():
    win  = mc.GetActiveWindow()
    list = win.GetList(1002)

    for i in list.GetItems():
        i.SetProperty('selected', '')

    item = list.GetItem(list.GetFocusedItem())
    item.SetProperty('selected', 'true')
    _set('dir_cur_label', item.GetLabel())
    _set('category', item.GetLabel())
    _set('dir_search', '')
    _set('dir_cur_page',  1)
    show_directory(item)

def directory_feed_click():
    _set('searching', False)
    list = mc.GetActiveWindow().GetList(2001)
    item = list.GetItem(list.GetFocusedItem())
    go_to_page('feed', item)

def show_directory(item):
    _set('searching', False)
    list = mc.GetActiveWindow().GetList(2001)
    list.SetContentURL(item.GetPath())
    list.SetFocus()

def directory_paginate():
    if not _get('loading'):
        list = mc.GetActiveWindow().GetList(2001)
        items = list.GetItems()

        if _get('dir_cur_page'):
            page = int(_get('dir_cur_page')) + 1
            items = list.GetItems()
        else:
            page = 1
            items = mc.ListItems()

        _set('dir_cur_page', page)

        params = {
            'type': _get('dir_cur_label'),
            'page': page,
            'search': _get('dir_search')
        }

        _set('loading', True)
        result = call('http://app.boxee.tv/rssapi/directory', params)
        rss_items = re.compile("<item>((.|\s)*?)<\/item>").findall(result)

        for i in rss_items:
            try:
                title = re.compile("<title><!\[CDATA\[(.*?)\]\]><\/title>").findall(i[0])[0]
                desc  = re.compile("<description><!\[CDATA\[(.*?)\]\]><\/description>").findall(i[0])[0]
                thumb = re.compile("<boxee:image>(.*?)<\/boxee:image>").findall(i[0])[0]
                link = re.compile("<link>(.*?)<\/link>").findall(i[0])[0]

                item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                item.SetLabel(title)
                item.SetThumbnail(thumb)
                item.SetDescription(desc)
                item.SetPath(link)

                items.append(item)
            except:
                pass

        list.SetItems(items)
        list.SetFocusedItem((int(page) - 1) * 10)
        list.SetFocus()
        list.SetFocusedItem((int(page) - 1) * 10)

        _set('loading', False)


def on_menu_level1():
    items = mc.ListItems()
    directory = ['Favorites', 'Directory']
    for i in directory:
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(i)
            item.SetPath("load_%s" % i)
            items.append(item)

    list = mc.GetActiveWindow().GetList(47)
    list.SetItems(items)
    list.SetFocusedItem(0)

def on_directory_load():
	items = mc.ListItems()

	directory = ['Most Popular', 'Top Rated', 'New Shows', 'HD Shows', 'Activism', 'Animals', 'Animation', 'Arts', 'Blogs', 'Business', 'Comedy', 'Courseware', 'Culture', 'Education', 'Environment', 'Family', 'Food', 'Government', 'Health', 'International', 'Kids', 'Linux & Free Software', 'Local', 'Mac', 'Movies & TV', 'Music', 'News', 'Politics', 'Public Broadcasting', 'Religion & Spirituality', 'Science', 'Sexuality', 'Sports', 'Technology', 'Transportation', 'Travel', 'Video Games']

	for i in directory:
		item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
		item.SetLabel(i)
		item.SetPath("rss://app.boxee.tv/rssapi/directory?type=%s&page=1" % urllib.quote(i))
		#item.SetThumbnail()
		#SetProperty
		if i == 'HD Shows':
			item.SetProperty('divider', 'true')

		items.append(item)

	list = mc.GetActiveWindow().GetList(1002)
	list.SetItems(items)
	list.SetFocusedItem(0)

	directory_click()


def feed_list_click():
	win  = mc.GetActiveWindow()
	list = win.GetList(51)

	item = list.GetItem(list.GetFocusedItem())
	item.SetProperty('subscribed', '1')

	go_to_page('feed', item)

def on_feed_load(params):
    list = mc.GetActiveWindow().GetList(51)

    mc.ShowDialogWait()
    items = mc.GetDirectory(params['path'])

    for i in items:
        try:
            feed = params['title']
            title = i.GetLabel()
            p = re.compile(re.escape(feed), re.IGNORECASE)
            title = p.sub('', title).strip(' :-')
            i.SetProperty('temptitle', title)
        except:
            i.SetProperty('temptitle', i.GetLabel())

    list.SetItems(items)

    mc.HideDialogWait()

    if len(items) == 0:
        response = mc.ShowDialogConfirm(params['title'] + " failed to load", "Looks like there's some issues with the " + params['title'] + " RSS feed. Would you like to return to the previous page?", "No", "Yes")
        if response:
            mc.CloseWindow()

    btn = mc.GetActiveWindow().GetToggleButton(1001)

    if params['subscribed'] == '1':
        _set('feed_subscribed', 1)
        btn.SetSelected(True)
    else:
        _set('feed_subscribed', False)
        btn.SetSelected(False)

def go_to_page(page, args):
	_set('ui_page_' + _get('cur_page'), False)
	_set('searching', False)

	if page == 'browse':
		_set('cur_page', 'browse')
		launch(14002, False)

	elif page == 'feed':
		_set('cur_page', 'feed')

		params = {
			"title":		args.GetLabel(),
			"thumbnail":	args.GetThumbnail(),
			"path":			args.GetPath(),
			"date":			args.GetDate(),
			"subscribed":   args.GetProperty('subscribed')
		}

		# on_feed_load
		launch(14001, params)

	else:
		_set('cur_page', 'myfeeds')
		sort(_get('feed_sort'), False)

	_set('ui_page_' + _get('cur_page'), True)

quickLaunch(14000)

# myfeeds, browse, feed
go_to_page('myfeeds', False)
