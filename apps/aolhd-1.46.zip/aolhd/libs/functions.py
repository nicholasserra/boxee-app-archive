from loader import *

import urllib2
import elementtree.ElementTree as ET


class ElementWrapper:
    def __init__(self, element):
        self._element = element
    def __getattr__(self, tag):
        if tag.startswith("__"):
            raise AttributeError(tag)
        return self._element.findtext(tag)

def getmasterfeed():
    path = "http://hd.aol.com/boxee_masterfeed.xml"
    request = urllib2.Request(path)
    try:
        r = urllib2.urlopen(request)
    except urllib2.HTTPError, e:
        mc.LogDebug("######################### UrlLib2 call Failed")

    xml = r.read()

    if xml:
        response = ET.fromstring(xml)
        info     = {}

        for category in ["techitem", "entitem", "homeitem", "engadgetitem", "moviefoneitem"]:

            info[category] = []
            for feeditem in response.findall(category):
                feedtitle = ElementWrapper(feeditem)
                mc.LogDebug("############### : show name = " + str(feedtitle.title))
                info[category].append({
                        'title': feedtitle.title,
                        'link' : feedtitle.link,
                })

        return info
    else:
        mc.LogDebug("######################### Failed")
        return False

def launchcdlp():
    CONFIG.SetValue("showtracks", "")
    CONFIG.SetValue("coverimage", "")
    mc.ActivateWindow(14001)

def showgrid(app, category):
    slots  = 20
    length = len(app.master[category]) -1

    storage_list = mc.ListItems()
    storage_item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)

    for i in xrange(slots):
        if i <= length:
            item = app.master[category][i]
            mc.GetWindow(14000).GetControl(600+i).SetVisible(True)
            storage_item.SetProperty(str(500+i), '[B]'+item['title']+'[/B]')
            mc.GetWindow(14000).GetList(100+i).SetContentURL(str(item['link']))
        else:
            mc.GetWindow(14000).GetControl(600+i).SetVisible(False)

    storage_list.append(storage_item)
    mc.GetWindow(14000).GetList(200).SetItems(storage_list)


def getgrid(app, feedpath):
    if 'listening' in feedpath:
        launchcdlp()
    elif 'tech' in feedpath:
        showgrid(app, "techitem",)
    elif 'entertainment' in feedpath:
        showgrid(app, "entitem")
    elif 'home' in feedpath:
        showgrid(app, "homeitem")
    elif 'engadget' in feedpath:
        showgrid(app, "engadgetitem")
    elif 'moviefone' in feedpath:
        showgrid(app, "moviefoneitem")