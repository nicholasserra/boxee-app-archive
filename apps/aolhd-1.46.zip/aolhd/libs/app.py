from loader import *

import functions
import music

class init:
    def __init__(self):
        self.master    = functions.getmasterfeed()
        self.poller    = music.pollaol()
        self.player    = mc.GetPlayer()
        self.categories= [
                        {   'id':'entertainment',
                            'url':'http://o.aolcdn.com/os/iptv/boxee/entertainment.png',
                            'desc':"Hear about the latest celebrity gossip and find out what's hot in movies, television and music."},
                        {   'id':'home',
                            'url':'http://o.aolcdn.com/os/iptv/boxee/home.png',
                            'desc':'Watch home and cooking tips from celebrities like Curtis Stone, Gail Simmons and Eric Stromer.'},
                        {   'id':'moviefone',
                            'url':'http://o.aolcdn.com/os/iptv/boxee/moviefone.png',
                            'desc':'Find all the info about the hottest movies, watch the trailers and exclusive behind the scene interviews.'},
                        {   'id':'engadget',
                            'url':'http://o.aolcdn.com/os/iptv/boxee/engadget.png',
                            'desc':'See the latest in gadgets and consumer electronics from the pros at Engadget.'},
                        {   'id':'listening',
                            'url':'http://o.aolcdn.com/os/iptv/boxee/cdlp_logo_within_aolhd.png',
                            'desc':'Listen to free, newly released albums from your favorite artists!'},
                        {   'id':'tech',
                            'url':'http://o.aolcdn.com/os/iptv/boxee/technology.png',
                            'desc':'Learn about the latest gadgets, cars and electronics from Engadget and Translogic.'},
        ]

        if not self.master:
            window = mc.GetActiveWindow()
            window.ClearStateStack(False)
            mc.CloseWindow()

        self.launch()

    def launch(self):
        mc.ShowDialogWait()
        mc.GetWindow(14000).GetControl(2000).SetVisible(True)
        mc.GetWindow(14000).GetControl(3000).SetVisible(False)

        #set category list
        items = mc.ListItems()
        for i in self.categories:
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(i['id'])
            item.SetPath(i['id'])
            item.SetThumbnail(i['url'])
            item.SetDescription(i['desc'])
            items.append(item)
        mc.GetWindow(14000).GetList(330).SetItems( items )
        
        params = mc.GetApp().GetLaunchedScriptParameters()
        if params.has_key('videourl'):
            mc.GetWindow(14000).PushState()
            item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
            item.SetLabel("AOLHD")
            item.SetContentType("video/mpeg")
            item.SetPath(params['videourl'])
            item.Dump()
            self.player.Play(item)

        elif params.has_key('sect'):
            mc.GetWindow(14000).PushState()
            functions.getgrid(self, params['sect'])

            focus = [index for index, item in enumerate(self.categories) if item['id'] == params['sect']]
            mc.GetWindow(14000).GetList(330).SetFocusedItem( focus[0] )

            mc.GetWindow(14000).GetControl(2000).SetVisible(False)
            mc.GetWindow(14000).GetControl(3000).SetVisible(True)
            mc.GetWindow(14000).GetControl(100).SetFocus()

        mc.HideDialogWait()

    def browse(self):
        mc.ShowDialogWait()
        
        list      = mc.GetWindow(14000).GetList(330)
        listitems = list.GetItems()
        listitem  = listitems[list.GetFocusedItem()]
        feedpath  = listitem.GetPath()

        mc.GetActiveWindow().PushState()
        functions.getgrid(self, feedpath)

        mc.GetWindow(14000).GetControl(2000).SetVisible(False)
        mc.GetWindow(14000).GetControl(3000).SetVisible(True)

        mc.GetWindow(14000).GetControl(100).SetFocus()
        mc.HideDialogWait()

    def music_carousel(self):
        mc.LogDebug("%s: loading carousel" % (APPID,) )

        # Poll for featured
        mc.ShowDialogWait()
        publisher = music.Publisher(14001,131)
        concerts  = self.poller.GetFeaturedItems()
        publisher.publishConcerts(concerts)

        mc.HideDialogWait()

        mc.GetActiveWindow().GetControl(131).SetFocus()

        # prevent Boxee from clearing away album info when returning from screensaver...
        coverimage = CONFIG.GetValue("coverimage")

        image = mc.GetWindow(14001).GetImage(301)
        image.SetTexture(coverimage)

    def music_concert(self):
        mc.ShowDialogWait()
        CONFIG.SetValue("showtracks","true")

        mc.GetActiveWindow().GetControl(100).SetVisible(True)

        mc.LogDebug("%s: Onclick play..." % (APPID,) )
        publisher = music.Publisher(14001,120)

        if self.player.IsPlaying():
                self.player.Stop()

        items = mc.GetActiveWindow().GetList(131).GetItems()
        n     = mc.GetActiveWindow().GetList(131).GetFocusedItem()
        item  = items[n]

        PlayConcertID = item.GetProperty("ConcertID")

        publisher.playConcert(PlayConcertID, "true", "false")

        mc.HideDialogWait()

    def play(self, window, listid):
        list      = mc.GetWindow(window).GetList(listid)
        listitems = list.GetItems()
        n         = list.GetFocusedItem()

        playlist = self.m3u(listitems, n)

        item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
        item.SetLabel("AOLHD")
        item.SetContentType("video/x-mpegurl")
        item.SetPath(playlist)
        self.player.Play(item)

    def m3u(self, playlist, n=0):
        data = ["#EXTM3U", ""]

        for item in playlist[n:]:
            data.append( "#EXTINF:0,"+ item.GetLabel())
            data.append( item.GetPath() )
            data.append( "" )

        raw   = "\n".join(data)
        fname = mc.GetTempDir() + os.sep +"playlist.m3u"
        fd    = open(fname,'w')
        fd.write(raw)
        fd.close()
        return fname