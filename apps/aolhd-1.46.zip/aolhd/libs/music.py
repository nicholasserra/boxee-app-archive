from loader import *

import functions
import urllib2
import elementtree.ElementTree as ET

globartist = "test"

class pollaol:
    def __init__(self):
        self.host = "http://concerts.aolsvault.com"
        self.namespace = "{http://aolsvault.com/webservices/}"

    def request(self, path):
        request = urllib2.Request(path)
        try:
            r = urllib2.urlopen(request)
        except urllib2.HTTPError, e:
            return False

        xml = r.read()
        return xml

    def auth(self, username, password):
        # path = self.host + "/ws/concert.asmx/CreateSession?login=" + username + "&password=" + password
        # path = "http://www.benchwarmersports.com/aol/IPTV/boxee_fakeauth.xml"
        # xml = self.request(path)

        xml = '<CVCustomerSessionLight xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://aolsvault.com/webservices/"><Status><Result xmlns="Account"><AuthenticationStatusID>0</AuthenticationStatusID><Name>OK</Name></Result></Status><Customer><IsWVIPMember>false</IsWVIPMember><IsDisabled>false</IsDisabled><ScreenName>anonymous669359064</ScreenName><Email>gouldimg@mac.com</Email><Login>gouldimg@mac.com</Login><LastName>User</LastName><FirstName>Boxee</FirstName><CustomerID>1710545</CustomerID></Customer><SessionID>03f49d90-6bf0-4d79-af17-e8e72695c4eb</SessionID><IsSessionValid>true</IsSessionValid></CVCustomerSessionLight>'

        if xml:
            response = ET.fromstring(xml)

            d = {
                'SessionID':        response.findtext( "".join([ self.namespace, "SessionID"]) ),
                'IsSessionValid':   response.findtext( "".join([ self.namespace, "IsSessionValid"]) ),
                'ScreenName':       response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "ScreenName"]) ),
                'Email':            response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "Email"]) ),
                'Login':            response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "Login"]) ),
                'LastName':         response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "LastName"]) ),
                'FirstName':        response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "FirstName"]) ),
                'CustomerID':       response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "CustomerID"]) ),
                'IsWVIPMember':     response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "IsWVIPMember"]) ),
                'IsDisabled':       response.findtext( "".join([ self.namespace, "Customer/", self.namespace, "IsDisabled"]) )
            }

            if d["IsSessionValid"] == "false":
                return "Invalid"
            elif d["IsDisabled"] == "true":
                return "Disabled"
            else:
                return d
        else:
            return "Failed"


    def GetConcert(self, ConcertID, SessionID, Hostname):

        path  = ConcertID.replace("/cdlp/", "/cdlp-xml/")
        path += "/audio:128.mp3?track1=stream&track2=boxee&track3=iptv"
        xml   = self.request(path)

        if xml:
            response = ET.fromstring(xml)
            mc.LogDebug("%s: Got a response! - %s" % (APPID, str(response),) )

            details = {
                'TrackCount':       response.findtext('count'),
                'Title':            response.findtext('cdlp/album_name'),
                'EventID':          response.findtext('cdlp/ch_id'),
                'ArtistID':         response.findtext('cdlp/ch_id'),
                'ConcertID':        response.findtext('cdlp/ch_id'),
                'LargeImage':       response.findtext('cdlp/album_thumbnail').replace("![CDATA[","").replace("]",""),
                'Description':      response.findtext('cdlp/description').replace("![CDATA[","").replace("]","")
            }

            artist = {
                'ArtistID':         response.findtext('cdlp/artist_name'),
                'ArtistFriendlyName': response.findtext('cdlp/artist_name').replace("![CDATA[","").replace("]",""),
                'ArtistName':       response.findtext('cdlp/artist_name'),
                'ArtistUrl':        response.findtext('cdlp/artist_name'),
                'FileName':         response.findtext('cdlp/artist_name')
            }

            tracks = []
            for track in response.findall("tracks/track"):
                wrappedtrack = functions.ElementWrapper(track)
                tracks.append({
                    'TrackNumber':  wrappedtrack.url,
                    'TrackID':      wrappedtrack.url,
                    'Duration':     wrappedtrack.duration,
                    'DurationInSeconds': wrappedtrack.duration,
                    'SongID':       wrappedtrack.url,
                    'Name':         wrappedtrack.title
                })

            related = []
            for concert in response.findall("cdlp"):
                concert = functions.ElementWrapper(concert)
                related.append({
                    'ConcertID':    response.findtext('album_name'),
                    'EventID':      response.findtext('album_name'),
                    'ArtistID':     response.findtext('album_name'),
                    'ArtistName':   response.findtext('album_name'),
                    'ArtistFriendlyName': response.findtext('album_name'),
                    'TrackCount':   response.findtext('count')
                })

            d = [details, artist, tracks, related]
            return d
        else:
            return "Failed"
   

    def GetFeaturedItems(self):
        # path = self.host + "/ws/concert.asmx/GetFeaturedItems?"
        # path = "http://www.benchwarmersports.com/aol/IPTV/boxee_cdlp.php"

        path = "http://api.castfire.com/rest/xml/?api_key=04567-37082-81709+&method=public.getFilteredSet&set_slug=cdlp"
        xml  = self.request(path)

        if xml:
            response = ET.fromstring(xml)
            d = []

            # for concert in response.findall("ConcertsOfTheWeekCollection/ConcertOfTheWeek/ConcertListing"):

            for concert in response.findall("set/items/item"):

                wrappedconcert = functions.ElementWrapper(concert)

                details = {
                    'TrackCount': "10",
                    'Title':        concert.findtext('metadata/cdlp/album_name'),
                    'ConcertID':    concert.findtext('value'),
                    'EventID':      concert.findtext('value'),
                    'ArtistID':     concert.findtext('value'),
                    'LargeImage':   concert.findtext('metadata/cdlp/album_thumbnail')
                }

                artist = {
                    'ArtistID':     concert.findtext('metadata/cdlp/artist_name'),
                    'ArtistFriendlyName': concert.findtext('metadata/cdlp/artist_name'),
                    'ArtistName':   concert.findtext('metadata/cdlp/artist_name'),
                    'ArtistUrl':    concert.findtext('metadata/cdlp/artist_name'),
                }

                tracks = {
                	'TrackNumber':  '1',
                	'TrackID':      'null',
                	'Duration':     '4:03',
                	'DurationInSeconds': '243.000',
                	'SongID':       '47470801',
                	'Name':         'test',
                }

                d.append([details, artist, tracks])

            return d
        else:
            return "Failed"




class Publisher:
    def __init__(self, WinID, ListID):
        self.WinID   = WinID
        self.ListID  = ListID
        self.host    = "http://concerts.aolsvault.com"
        self.webhost = "http://www.aolsvault.com"

    def publishConcerts(self, concerts):
        mc.LogDebug("%s: Publishing concerts..." % (APPID, ) )
        container = mc.ListItems()
        for concert in concerts:
            newitem = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            newitem.SetLabel(concert[0]["Title"])
            newitem.SetTitle( "".join([concert[1]["ArtistFriendlyName"], " - ", concert[0]["Title"]]) )
            newitem.SetThumbnail(concert[0]["LargeImage"])
            newitem.SetProperty("ArtistID", concert[0]["ArtistID"])
            newitem.SetProperty("EventID", concert[0]["EventID"])
            newitem.SetProperty("ConcertID", concert[0]["ConcertID"])
            newitem.SetProperty("Artist", concert[1]["ArtistFriendlyName"])
            newitem.SetProperty("TrackCount", concert[0]["TrackCount"])
            try:
                # newitem.SetProperty("ArtistImage", "http://images.aolsvault.com/artists/" + concert[1]["FileName"])
                newitem.SetProperty("ArtistImage", "http://www.benchwarmersports.com/aol/IPTV/Translogic_300x300.jpg")
            except KeyError:
                pass

            songlisting = ""
            n = 1
            for song in concert[2]:
                # songlisting = songlisting + str(n) + ". " + song["Name"] + "[CR]"
                n += 1
            # newitem.SetProperty("SongListing", songlisting)
            # newitem.SetPath(self.host + "/" + concert[0]["SeoUrlName"])
            container.append(newitem)

        mc.GetWindow(self.WinID).GetList(131).SetItems(container)

    def playConcert(self, ConcertID, SessionID, Membership):
        # mc.ShowDialogNotification("Here7!!")
        mc.LogDebug("%s: Publishing concert - %s" % (APPID, str(ConcertID),) )

        tempPoller = pollaol()
        params     = mc.Parameters()
        playlist   = mc.PlayList(mc.PlayList.PLAYLIST_MUSIC)
        container  = mc.ListItems()
        myPlayer   = mc.GetPlayer()

        concert = tempPoller.GetConcert(ConcertID, SessionID, "concerts.aolsvault.com")

        mc.LogDebug("%s: Queuing playlist..." % (APPID, ) )
        if myPlayer.IsPlaying():
            myPlayer.Stop()

        playlist.Clear()
        n = 1

        for item in concert[2]:
            duration = item["DurationInSeconds"].split(".")

            newitem = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            newitem.SetLabel( "".join([str(n), ". ", item["Name"]]) )
            newitem.SetTitle( "".join([str(n), ". ", item["Name"]]) )
            newitem.SetArtist(concert[1]["ArtistFriendlyName"])
            newitem.SetDuration(int(duration[0]))
            newitem.SetProperty("SongID", item["SongID"])
            newitem.SetProperty("TrackNumber", item["TrackNumber"])
            newitem.SetProperty("TrackCount", "".join(["Tracks: [B]", concert[0]["TrackCount"], "[/B]"]) )

            newitem.SetPath(str(item["TrackID"] + "&track1=stream&track2=boxee&track3=iptv"))

            path  = concert[0]["LargeImage"]
            image = mc.GetWindow(14001).GetImage(301)
            image.SetTexture(path)

            mc.GetApp().GetLocalConfig().SetValue("coverimage",path)
            myLabel = mc.GetActiveWindow().GetLabel(110)

            try:
		myLabel.SetLabel(concert[0]["Description"])
            except (RuntimeError, TypeError, NameError):
            	myLabel.SetLabel("")
                mc.LogDebug("%s: Bad Description" % (APPID, ) )

            # desc = str(concert[0]["Description"])
            # mc.LogDebug("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Description: " + str(desc))

            ext = mc.ListItem(mc.ListItem.MEDIA_AUDIO_MUSIC)
            ext.SetTitle(concert[1]["ArtistFriendlyName"] + " at ,  in @concertvault")
            ext.SetLabel(concert[1]["ArtistFriendlyName"] + " at ,  in @concertvault")
            ext.SetContentType("audio/mpeg")

            ext.SetProviderSource("AOL CD Listening Party")
            extparams = {
                'title':        concert[1]["ArtistFriendlyName"] + " at ,  in @concertvault",
                'alt-label':    concert[1]["ArtistFriendlyName"] + " at ,  in @concertvault",
                'ConcertID':    ConcertID,
                'description':  'null',
                'bx-ourl':      'null',
                'thumbnail':    '',
            }
            newitem.SetExternalItem(ext)

            container.append(newitem)
            playlist.Add(newitem)
            n = n + 1

        mc.LogDebug("%s: Switching to play window..." % (APPID, ) )
        params["artist"] = concert[1]["ArtistFriendlyName"]
        params["image"] = "http://www.benchwarmersports.com/aol/IPTV/Moviefone_300x300.jpg"
        params["membership"] = ""

        # mc.GetApp().ActivateWindow( 14001, params )
        mc.LogDebug("%s: Playing playlist..." % (APPID, ) )
        myPlayer.PlaySelected(0)
        mc.LogDebug("%s: Loading list container..." % (APPID, ) )
        mc.GetWindow(self.WinID).GetList(self.ListID).SetItems(container)

        mc.GetActiveWindow().GetControl(120).SetFocus()
        # mc.ShowDialogNotification("Set Focus!!")

