import mc
import os
import sys

# SET APP GLOBAL VARS
CWD    = os.getcwd().replace(";","")
APP    = ""
APPID  = mc.GetApp().GetId()
CONFIG = mc.GetApp().GetLocalConfig()

sys.path.append(os.path.join(CWD, 'libs'))

if ( __name__ == "__main__" ):
    import app
    mc.ActivateWindow(14000)
    APP = app.init()


    

