import mc


def checktoken():
    config = mc.GetApp().GetLocalConfig()
    token = config.GetValue("token")

    if token:
        data = mc.Http().Get('http://pubdhub.info/validatetoken.php?token=' + token)

        if 'valid' in data:
            return True
        else:
            config.Reset("token")
            return False
    else:
        return False
