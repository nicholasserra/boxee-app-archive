import mc


def login():
    uname = mc.ShowDialogKeyboard("Enter Username (online account)", "", False)
    pword = mc.ShowDialogKeyboard("Enter Password (online account)", "", True)
    device = mc.GetDeviceId()

    if uname and pword:
        params = "username=" + uname + "&password=" + pword + "&device=" + device
        data = mc.Http().Post('http://pubdhub.info/check_boxee.php', params)

        if 'yes' in data:
            config = mc.GetApp().GetLocalConfig()
            config.SetValue("username", uname)
            config.SetValue("password", pword)
            return True
        elif 'expired' in data:
            config = mc.GetApp().GetLocalConfig()
            config.SetValue("failure", "expired")
        elif 'full' in data:
            config = mc.GetApp().GetLocalConfig()
            config.SetValue("failure", "full")
        elif 'not subscribed' in data:
            config = mc.GetApp().GetLocalConfig()
            config.SetValue("failure", "not subscribed")
        else:
            return False
