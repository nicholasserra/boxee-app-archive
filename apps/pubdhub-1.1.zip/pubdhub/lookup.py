import mc


def lookup():
    config = mc.GetApp().GetLocalConfig()
    uname = config.GetValue("username")
    pword = config.GetValue("password")
    device = mc.GetDeviceId()

    if uname and pword:
        params = "username=" + uname + "&password=" + pword + "&device=" + device
        data = mc.Http().Post('http://pubdhub.info/check_boxee.php', params)

        if 'yes' in data:
            return True
        else:
            config.Reset("username")
            config.Reset("password")
            return False
    else:
        return False
