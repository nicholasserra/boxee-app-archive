import mc


def search():
    searchit = mc.ShowDialogKeyboard("Enter keyword to search", "", False)

    if searchit:
        params = "search=" + searchit
        data = mc.Http().Get('http://pubdhub.info/search_boxee.php?search=' + searchit)
        url = "http://pubdhub.info/search_boxee.php&search="+searchit

        if data:
	    if 'NO RESULTS' in data:
                return False
            else:
                return searchit
        else:
            return False
