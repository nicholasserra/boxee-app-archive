# utility functions for solvellc app

import string
import random
import thread
import time
import urllib,urllib2
import xml.dom.minidom
import mc
import ElementTree as et
import ElementPath
import urlparse
from urllib import quote_plus, urlencode

def gencode():
	"""generates 12-digit random alpha numeric code
	returns string"""
	aleph = string.uppercase + string.digits
	code = ""
	for i in range(12):
		code += random.choice(aleph)
	#return code
	boxId = mc.GetDeviceId()
	return boxId

def get_redir_url(url):
	r_url = urllib2.urlopen(url).geturl()
	params = { 'quality': 'A' }
	playlist_url = "playlist://%s?%s" % (quote_plus(r_url), urlencode(params))
	return playlist_url
	return r_url

def fetchurl(url, args):
	"""fetches data from url
	returns urllib object"""
	request = urllib2.Request(url)
	request.add_data(urllib.urlencode(args))
	request.add_header('EVTV','HHV56923KBETT')
	return urllib2.urlopen(request)

def fetchdata(xmlcode, tag):
	"""fetches data from xml code with tag"""
	return xmlcode.getElementsByTagName(tag)[0].childNodes[0].data
	
def set_banner_ad(image_url):	
	image = mc.GetActiveWindow().GetImage(101)
	image.SetTexture(image_url)
	image = mc.GetActiveWindow().GetImage(201)
	image.SetTexture(image_url)
	
def get_register_dialogue(channel):
	url = "https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/newdb/get_boxee_dialogue.php"
	args = {'channel':channel}
	urldata = fetchurl(url,args)
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	itemlist = rootElem.findall("item")
	for item in itemlist:
		name = item.find("name").text
		message = item.find("message").text
	returndata = {"name":name,"message":message}
	return returndata

def get_stream_url(channel):
	url = "https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/newdb/stream_url.php"
	args = {'channel':channel}
	urldata = fetchurl(url,args)
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	itemlist = rootElem.findall("item")
	for item in itemlist:
		url = item.find("url").text
	return url

def gettimesecs(timestring):
	"""docstring for gettimesecs"""
	if len(timestring) > 5:
		ts = time.strptime(timestring, "%H:%M:%S")
		seconds = ts.tm_hour * 360 + ts.tm_min * 60 + ts.tm_sec
	else:
		ts = time.strptime(timestring, "%M:%S")
		seconds = ts.tm_min * 60 + ts.tm_sec		
	return seconds
	
def formatdate(datestring):
	"""docstring for formatdate"""
	ts = time.strptime(datestring, "%a, %d %b %Y %H:%M:%S")
	formatteddate = time.strftime("%Y/%m/%d", ts)
	return formatteddate
	
def calcviewcount(countstring):
	"""docstring for calcviewcount"""
	vc = int(countstring.split(",")[0])*1000+int(countstring.split(",")[1])
	return vc

def getregcode(channel):
	"""get the register code
	returns register code as string if not registered or true"""
	code = mc.GetApp().GetLocalConfig().GetValue("code")
	args = {'id':code,'deviceID':code,'partner':'boxee','deviceTypeName':'boxee','channel':channel}
	urldata = fetchurl('https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/newdb/mregister.pl',args)
	answer = xml.dom.minidom.parse(urldata)
	status = fetchdata(answer,"status")
	regcode = fetchdata(answer,"regCode")
	if status == "false":
		return regcode
	else:
		return "true"
		
def pinentry(pin):
	"""enters user pin
	returns status as string"""
	code = mc.GetApp().GetLocalConfig().GetValue("code")
	args = {'id':code,'pin':pin,'partner':'boxee','deviceID':code,'deviceTypeName':'boxee'}
 	urldata= fetchurl('https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/pin.pl',args)
	answer = xml.dom.minidom.parse(urldata)
	status = fetchdata(answer,"status")
	return status

def get_banner_from_category(channel):
	#fetches xml for categories
	#code = mc.GetApp().GetLocalConfig().GetValue("code")
	args = {}
	url = "https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/"+ channel +"/categories_from_xml.pl"
	urldata = fetchurl(url,args)
	#bxlist = mc.ListItems()
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	catlist = rootElem.findall("banner_ad")
	for cat in catlist:
		vals = {}
		for name,value in cat.items():
			vals[name] = value
	img_url = vals['hd_img']
	return img_url
	
def get_listitems_from_category(channel):
	#fetches xml for categories
	code = mc.GetApp().GetLocalConfig().GetValue("code")
	args = {}
	url = "https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/"+ channel +"/categories_from_xml.pl"
	urldata = fetchurl(url,args)
	bxlist = mc.ListItems()
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	catlist = rootElem.findall("category")
	x = 1
	for cat in catlist:
		vals = {}
		for name,value in cat.items():
			vals[name] = value
		bxitem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		bxitem.SetReportToServer(False)
		bxitem.SetDescription(str(vals['description']))
		bxitem.SetThumbnail(str(vals['sd_img']))
		bxitem.SetLabel(str(vals['title']))
		bxitem.SetPath(str(vals['sd_img']))
		bxitem.SetViewCount(int('0'))
		bxitem.SetProperty("pubdate",'2011-03-20')
		bxitem.SetProperty("posnum",str(x))
		bxitem.SetProperty("source",'http://www.bollyverse.com')	
		bxlist.append(bxitem)
		x += 1
	return bxlist

def get_listitems_from_subcategory(channel,category):
	#fetches subcategories from xml
	url = "https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/" + channel + "/categories_from_xml.pl"
	args = {}	
	urldata = fetchurl(url,args)	
	bxlist = mc.ListItems()
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	catlist = rootElem.findall("category")
	x = 1
	for cat in catlist:
		vals = {}
		for name,value in cat.items():
			vals[name] = value
		if(vals['title'] == category):
			sublist = cat.findall("categoryLeaf")
			for sublistitem in sublist:
				subvals = {}
				for name,value in sublistitem.items():
					subvals[name] = value
				bxitem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
				bxitem.SetReportToServer(False)
				bxitem.SetDescription(str(subvals['title']))
				bxitem.SetThumbnail(str(vals['sd_img']))
				bxitem.SetLabel(str(subvals['title']))
				bxitem.SetPath(str(vals['sd_img']))
				bxitem.SetViewCount(int('0'))
				bxitem.SetProperty("pubdate",'2011-03-20')
				bxitem.SetProperty("feed",str(subvals['feed']))
				bxitem.SetProperty("posnum",str(x))
				#bxitem.SetProperty("source",'http://www.bollyverse.com')	
				bxlist.append(bxitem)
				x += 1
	return bxlist
		
def get_listitems_from_feed(url,channel):
	#fetches XML for videos based on category selection
	code = mc.GetApp().GetLocalConfig().GetValue("code")
	urlsplit = url.split("?")
	baseurl = urlsplit[0]
	argsplit = urlsplit[1].split("=")
	args = {'channame':channel,argsplit[0]:argsplit[1],'id':code}
	urldata = fetchurl(baseurl, args)
	boxeelist = mc.ListItems()
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	movielist = rootElem.findall("item")
	for movie in movielist:
		bxitem = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
		bxitem.SetReportToServer(False)
		bxitem.SetDescription(movie.find('synopsis').text.encode('utf-8','replace'))
		bxitem.SetProperty("durationformatted",str(movie.find('runtime').text))
		imgs = {}
		for name,value in movie.items():
			imgs[name] = value
		bxitem.SetThumbnail(str(imgs['sdImg']))
		bxitem.SetLabel(str(movie.find('title').text))
		bxitem.SetPath(str(movie.find('media/streamUrl').text))
		bxitem.SetProperty("source",str('www.bollyverse.com'))
		bxitem.SetProperty("contentId",str(movie.find('contentId').text))
		bxitem.SetReportToServer(False)
		bxitem.SetAddToHistory(False)
		boxeelist.append(bxitem)
	return boxeelist

def playcount(code,contentid):
	url = "https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/newdb/playcount.pl"
	vid = str(contentid+':'+code)
	args = {'vid':vid}
	urldata = fetchurl(url, args)

def isfree(vidurl):
	if(vidurl.find('mainredirect-free') != -1):
		return 'true'
	else:
		return 'false'
		
def fetchurl_ext(url, args):
	request = urllib2.Request(url)
	request.add_data(urllib.urlencode(args))
	return urllib2.urlopen(request)

def get_yume_url():
	url = "https://api1.eroticvision.tv/infini2/feeds/api/standardfeeds/newdb/get_boxee_yume.php"
	args = {}
	urldata = fetchurl(url,args)
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	itemlist = rootElem.findall("item")
	for item in itemlist:
		url = item.find("url").text
		domain = item.find("domain").text
		pubchannel = item.find("pubchannel").text
	data = {'url':url,'domain':domain,'pubchannel':pubchannel}
	return data
	
def get_yume_data(data):
	url = data['url']
	domain = data['domain']
	pubchannel = data['pubchannel']
	args = {'domain':domain,'pubchannel':pubchannel}
	urldata = fetchurl_ext(url,args)
	tree = et.parse(urldata)
	rootElem = tree.getroot()
	itemlist = rootElem.findall("Ad")
	if not itemlist:
		return 'false'
	else:
		for item in itemlist:
			duration = item.find("InLine/Creatives/Creative/Linear/Duration").text
			startevent = item.find("InLine/Impression").text
			tevents = item.findall("InLine/Creatives/Creative/Linear/TrackingEvents/Tracking")
			endevent = tevents[-1].text
			mediafiles = item.findall("InLine/Creatives/Creative/Linear/MediaFiles/MediaFile")
			for mf in mediafiles:
				if(mf.attrib['type'] == 'video/mp4' and mf.attrib['bitrate'] == '840'):
					video_url = mf.text
		timesplit = duration.split(':')
		length = int(timesplit[-1]) + int(timesplit[-2]*60) + int(timesplit[-3]*60*60)
		#print length
		data = {'starturl':startevent,'endurl':endevent,'video_url':video_url,'length':length}
		return data