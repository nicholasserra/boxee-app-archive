import mc
import urllib
from xml.dom.minidom import parse, parseString

def log(s):
   print '@koldcast: '+str(s)

def grabpreroll(url):
   try:
      f = urllib.urlopen(url)
      data = f.read()
      xml = parseString(data)

      result = {
         'file': str(xml.getElementsByTagName('MediaFile')[0].firstChild.data),
         'impression': str(xml.getElementsByTagName('Impression')[0].firstChild.data),
         'title': str(xml.getElementsByTagName('AdTitle')[0].firstChild.data),
      }

      duration = xml.getElementsByTagName('Duration')[0].firstChild.data

      result['duration'] = int(duration[0:2])*3600+int(duration[3:5])*60+int(duration[6:8])
      return result

   except:
      pass

def playvid(item):
   log('playing requested video')

   # Hit the URL to track the view count for the desired episode
   try:
      view_url = item.GetProperty("tracking")
      mc.Http().Get(view_url)
   except:
      pass

   # Create the playlist
   playlist = mc.PlayList(mc.PlayList.PLAYLIST_VIDEO)
   playlist.Clear()

   try:
      log('grabbing preroll')
      # Grab the preroll ad
      ad_url = item.GetProperty("preroll")
      result = grabpreroll(ad_url)
      log(result)

      # Create the preroll ad item
      ad_item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)
      ad_item.SetLabel('Ad: %s' % str(result['title']))
      ad_item.SetPath(str(result['file']))
      ad_item.SetDuration(result['duration'])
      log('adding preroll video to playlist')
      playlist.Add(ad_item)
      log('hitting impression url')
      mc.Http().Get(str(result['impression']))
   except:
      pass

   playlist.Add(item)

   # Play the playlist
   mc.GetPlayer().PlaySelected(0, mc.PlayList.PLAYLIST_VIDEO)
