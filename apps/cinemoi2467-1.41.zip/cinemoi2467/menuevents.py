import mediafly as mf
import mc
import bxutils as bx
import showevents

def setTitle(text):
	activeWindow = mc.GetActiveWindow()
	
	titleItem = mc.ListItem()
	titleItem.SetLabel(text)

	titleItems = mc.ListItems()
	titleItems.append(titleItem)

	activeWindow.GetList(8900).SetItems(titleItems)

def title_onload():
	params = mc.GetApp().GetLaunchedWindowParameters()
	title  = params['title']
	setTitle(title)
	
def mychannels_onClick(onShowPage = False):
	title = "My Channels"
	if mf.requires_binding():
		mc.ShowDialogWait()
		if onShowPage:
			episodes, channels= mf.get_channels(mf.config.GetValue('user_context'))
			showevents.fillContent(channels, episodes, True)
			setTitle(title)
		else:
			bx.launch_window(14001, 'mine', {'title':title})
		mc.HideDialogWait()

def popularchannels_onClick(onShowPage = False):
	title = "Popular Channels"
	mc.ShowDialogWait()
	if onShowPage:
		episodes, channels = mf.get_channels()
		showevents.fillContent(channels, episodes, True)
		setTitle(title)
	else:
		bx.launch_window(14001, 'popular', {'title':title})
	mc.HideDialogWait()

def mediaplugins_onClick():
	if mf.requires_binding():
		mc.ShowDialogWait()
		bx.launch_window(14002,'',{'title':'Media Plugins'})
		mc.HideDialogWait()

def login_onClick():
	mf.bind_user()
	if mf.user_is_bound():
		bx.launch_window(14001, 'mine', {'title':'Popular Channels'})

def login_onAltClick():
	mf.unbind_user()
	bx.launch_window(14001, 'popular', {'title':'Popular Channels'})

def handle_search(query, onShowWindow=False):
	mc.ShowDialogWait()
	config = mc.GetApp().GetLocalConfig()
	if query.startswith('add mcode '):
		if mf.requires_binding():
			mcode=query.replace('add mcode ','')
			if mf.add_source(mcode, config.GetValue('user_context')):
				mc.ShowDialogNotification("%s mcode has been added." % mcode)
				config.SetValue('hasmcode','True')
				bx.launch_window(14002)
			else:
				mc.ShowDialogNotification("%s mcode could not be added." % mcode)
		else:
			mc.ShowDialogNotification("You must be logged in to add a mcode")
	else:
		bx.log_message('Searching query: ' + query)
		if onShowWindow == True:
			activeWindow = mc.GetWindow(14001)
			contentList = activeWindow.GetList(200)
			contentList.SetFocus()
			activeWindow.PushState()

			episodes, shows = mf.search(query)
			setTitle("Search: %s" % query)
			contentList.SetItems(episodes)
		else:
			mc.GetActiveWindow().GetControl(200).SetFocus()
			bx.launch_window(14001, 'search', {"query": query, 'title': 'Search : %s' % query})

	mc.HideDialogWait()

def settings_onClick():
	'''
	Occurs when the setting gear is clicked
	'''
	window = mc.GetActiveWindow()
	config = mc.GetApp().GetLocalConfig()
	if config.GetValue('isderivativeapp') == 'True':
		window.GetControl(8002).SetFocus()
	else:
		window.GetControl(8001).SetFocus()

def nowPlaying_onClick():
	'''
	Occurs when user clicks now playing
	'''
	if mc.GetPlayer().IsPlayingAudio():
		mc.ActivateWindow(12006)
	elif mc.GetPlayer().IsPlayingVideo():
		mc.ActivateWindow(12005)
	else:
		mc.ShowDialogNotification("Error switching to current item")