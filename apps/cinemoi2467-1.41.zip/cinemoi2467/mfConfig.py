###############################################################################
#[ APP SPECIFIC VARIABLES ]####################################################
#	update descriptor.xml
#		- change id, name, description, thumbnail
#	update mfConfig.py
#		- change mCode
#		- change title
#		- change isDerivative
###############################################################################
mCode = "cinemoi2467"
title = "Cinemoi Cannes Film Festival 2011"
isDerivativeApp = True