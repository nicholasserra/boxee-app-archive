import mc
import mediafly as mf
import bxutils as bx
import menuevents

rating=0

def fillContent(channels, episodes, pushState = False):
	currentWindow = mc.GetWindow(14001)
	contentList = currentWindow.GetList(200)

	# push state if needed
	if pushState: currentWindow.PushState()

	# Add items to content list. #
	contentListItems = mc.ListItems()

	if channels:
		for item in channels:
			contentListItems.append(item)

	if episodes:
		for item in episodes:
			contentListItems.append(item)
	
	contentList.SetItems(contentListItems)
	contentList.Refresh()
	mc.GetWindow(14001).GetControl(200).SetFocus()

def playbutton_click():
	currentWindow = mc.GetWindow(14001)
	contentList = currentWindow.GetList(200)
	selectedItem = contentList.GetItem(contentList.GetFocusedItem())
	
	mf.play_item(selectedItem, True)

def moreEpisodes_click():
	'''
	Occurs when more episodes is clicked on the info panel
	'''
	mc.ShowDialogWait()

	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())
	
	# Reset focus before pushing state.
	mc.GetWindow(14001).GetControl(200).SetFocus()

	# Like Salt 'n Pepa, Push it.
	mc.GetWindow(14001).PushState()

	contentList.SetItems(mc.ListItems())
	contentList.Refresh()

	bx.log_message('Channel name: ' + item.GetLabel())
	bx.log_message('Channel slug: ' + item.GetProperty('slug'))

	menuevents.setTitle(item.GetProperty('showTitle'))
	episodeList = mf.get_show(item.GetProperty('showSlug'), 100)

	contentList.SetItems(episodeList)
	contentList.Refresh()

	mc.HideDialogWait()

def episodeFavorite_click():
	'''
	Occurs when user selects add episode to favorites
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.add_episode_favorite(item.GetProperty("slug"), item.GetTitle()):
		item.SetProperty("isEpisodeFavorite", "true")
	mc.HideDialogWait()

def episodeFavorite_altclick():
	'''
	Occurs when user selects remove episode from favorites
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.remove_episode_favorite(item.GetProperty("slug"), item.GetTitle()):
		item.SetProperty("isEpisodeFavorite","")
	mc.HideDialogWait()

def showFavorite_click():
	'''
	Occurs when user selects add show to favorites
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.add_show_favorite(item.GetProperty("showSlug"), item.GetTitle()):
		item.SetProperty("isShowFavorite", "true")
	mc.HideDialogWait()

def showFavorite_altclick():
	'''
	Occurs when user selects remove show from favorites
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.remove_show_favorite(item.GetProperty("showSlug"), item.GetTitle()):
		item.SetProperty("isShowFavorite", "")
	mc.HideDialogWait()

def episodeSubscribe_click():
	'''
	Occurs when user selects subscribe to episode
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.subscribe(item.GetProperty("slug"), item.GetTitle(), False):
		item.SetProperty("isEpisodeSubscription", "true")
	mc.HideDialogWait()

def episodeSubscribe_altclick():
	'''
	Occurs when user selects unsubscribe to episode
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.unsubscribe(item.GetProperty("slug"), item.GetTitle(), False):
		item.SetProperty("isEpisodeSubscription", "")
	mc.HideDialogWait()

def showSubscribe_click():
	'''
	Occurs when user selects subscribe to show
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.subscribe(item.GetProperty("showSlug"), item.GetTitle()):
		item.SetProperty("isShowSubscription", "true")
	mc.HideDialogWait()

def showSubscribe_altclick():
	'''
	Occurs when user selects unsubscribe to show
	'''
	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	mc.ShowDialogWait()
	if mf.unsubscribe(item.GetProperty("showSlug"), item.GetTitle()):
		item.SetProperty("isShowSubscription", "")
	mc.HideDialogWait()

def rateSeries_change(amt):
	'''
	Occurs when left or right is used on rate series from info panel
	'''
	_changeRating(5001,amt)

def rateSeries_onfocus():
	'''
	Occurs when rate series is focused on info panel
	'''
	_changeRating(5001, -5) # reset to 0 on focus

def	rateSeries_onClick():
	'''
	Occurs when rate series is selected from info panel
	'''
	global rating

	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())
	
	if rating>0:
		if mf.rate_item(item.GetProperty('showSlug'), rating, True):
			item.SetProperty(item.SetProperty('userShowRating', str(rating)))
	else:
		if mf.remove_rating(item.GetProperty('showSlug'), item.GetProperty('showTitle'), True):
			item.SetProperty('userShowRating', '')

def rateEpisode_change(amt):
	'''
	Occurs when left or right is used on rate episode from info panel
	'''
	_changeRating(5003, amt)

def rateEpisode_onfocus():
	'''
	Occurs when rate episode is focused on info panel
	'''
	_changeRating(5003, -5) # reset to 0 on focus

def	rateEpisode_onClick():
	'''
	Occurs when rate episode is selected from info panel
	'''
	global rating

	contentList = mc.GetWindow(14001).GetList(200)
	item = contentList.GetItem(contentList.GetFocusedItem())

	if rating>0:
		if mf.rate_item(item.GetProperty('slug'), rating, False):
			item.SetProperty(item.SetProperty('userRating', str(rating)))
	else:
		if mf.remove_rating(item.GetProperty('slug'), item.GetTitle(), False):
			item.SetProperty('userRating', '')

def _changeRating(id, amt):
	'''
	Changes rating by amt and then updates id with the correct image
	'''
	global rating

	rating+=amt
	if(rating>5): rating = 5
	if(rating<0): rating = 0
	mc.GetWindow(14001).GetImage(id).SetTexture(mc.GetApp().GetAppMediaDir() + "/media/rating_star_%s.png" % rating)

def audioAndVideo_onDown():
	'''
	Occurs when down is pressed on the audio and video button
	'''
	window = mc.GetWindow(14001)
	config = mc.GetApp().GetLocalConfig()
	if config.GetValue('isderivativeapp') == 'True':
		window.GetControl(200).SetFocus()
	else:
		window.GetControl(8005).SetFocus()

def items_onUp():
	'''
	Occurs when up is pressed on the item list
	'''
	window = mc.GetWindow(14001)
	bar = window.GetControl(9000)
	nowplaying = window.GetControl(6000)
	if bar.IsVisible():
		bar.SetFocus()
	else:
		if nowplaying.IsVisible(): nowplaying.SetFocus()
