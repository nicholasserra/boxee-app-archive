__module__ = "Mediafly API"
__author__ = "Neil Layne and Mike McMullin"
__url__ = "http://codeorangelabs.com/"
__version__ = "1.41"

from xml.dom import minidom
import urllib, time, datetime, math
from threading import Thread
import bxutils as bx
import mc

# Medifly API URLs #
apiURL = 'http://api.mediafly.com/api/rest/2.0/'
apiSecURL = 'https://api.mediafly.com/api/rest/2.0/'

# Default attibute set to request from API. #
episodeAttributes = 'title,description,imageUrl,url,published,showTitle,showSlug,mediaType,duration,averageRating,userRating,showRating,subscriptionType,favoriteType,bookmark,webSiteUrl'

# Mediafly API key #
#appID = 'f1a3ec75573242b38c87b79ae7361a11'
appID = 'd4cf391e9b7940ba8757c3febd236d19'

# Third Party ID (use Boxee profile name.) #
boxeeID = mc.GetInfoString('System.ProfileName').replace(' ', '')

# Where to store XML responses for debugging. Do not use in production app, #
# as storing the XML of any call slows app to a crawl #
tempXML = mc.GetTempDir() + 'mf-bx.xml'

# Local user's confiuration information for app. #
config = mc.GetApp().GetLocalConfig()

# MF defaults. #
defaultSlug = '__all__'
rootSlug = '__root__'
appContext = 'app_context_system'

token = ''
tokenID = ''

# Get token from Mediafly #
def get_token():
	
	global token
	global tokenID
	
	'''
	if _check_token():
		token = config.GetValue('token')
		tokenID = config.GetValue('tokenID')
		return
	'''
	
	bx.log_message('Requesting new token')
	bx.log_message('Boxee Profile Name (third party ID): '  + boxeeID)
	
	# Build API URL #
	url = '%sMediafly.Authentication.GetToken?app_id=%s&thirdPartyUserID=%s' % (apiURL, appID, boxeeID)
	
	xml = _get_api_url(url, 'set_token()')
	
	if xml:
		# Get a new token, save it to local config. #		
		token =  xml.getElementsByTagName('token')[0].firstChild.data
		tokenID = xml.getElementsByTagName('token')[0].getAttribute('id')
		
		bx.log_message('Token is: ' + token)
		bx.log_message('Token ID is: ' + tokenID )
		
		config.SetValue('haveToken', 'True')
		config.SetValue('token', str(token))
		config.SetValue('tokenID', str(tokenID))
		
		
		# Get token expiry time. #
		url = '%sMediafly.Authentication.GetTokenInfo?app_id=%s&&token=%s' % (apiURL, appID, token)
	
		xml = _get_api_url(url, 'set_token() (token info)')
		
		if xml:
			# Get token expiry, save it to local config. #
			expiry = xml.getElementsByTagName('tokeninfo')[0].getAttribute('expires')
			bx.log_message('Token expires at: ' + str(expiry))
			
			config.SetValue('expiry', str(expiry))
			
			return True
		
		else:
			config.Reset('expiry')
			return False
		
	# If we get a failed response from the API, reset token vars. #
	else:
		config.SetValue('haveToken', 'False')
		config.Reset('token')
		config.Reset('tokenID')
		return False


# Get channels based on user context. #
def get_channels(userContext = 'app_context_system'):
	
	# Pass call to get channel.  Leaving this method for alais methond simplicity. #
	episodes, channels = get_channel(rootSlug, 50, True, False, userContext)
	
	return episodes, channels
	
	

# Get episodes from a given channel based on slug and user context. #
def get_channel(channelSlug, limit = 50, returnChannels = False, source = False, userContext = 'app_context_system'):
	
	# Build API URL #
	url = '%sMediafly.Channels.GetChannel?app_id=%s&token=%s&channelSlug=%s&includeAttributes=%s&includeShow=yes&limit=%s&user_context=%s' %  (
		apiURL, appID, token, channelSlug, episodeAttributes, limit, userContext)
		
	if source:
		url = '%s&source=%s' % (url, source)
	
	xml = _get_api_url(url, 'get_channel()')
	
	if xml:
		# Get channel count. #
		channelNode = xml.getElementsByTagName('channel')[0]
		channelCount = channelNode.getAttribute('channelCount')
				
		# Convert episodes to Boxee Item List. #

		episodes = _nodes_to_listitems(channelNode.childNodes, userContext)
		
		# Convert sub-channels to Boxee Item List. #
		channels = _channels_to_listitems(xml.getElementsByTagName('channel'), userContext)
		
		# This is one of the silliest things I have ever written.
		# See, MF returns both the channel you're in AND sub-channels
		# using the root <channel> tag.
		# If we don't remove the first channel, it will show-up as a sub-channel.
		# Meanwhile, Boxee for it's part does not support .pop correctly,
		# or .remove at all.  Even thought the API says it does.
		if len(channels) > int(channelCount) and len(channels) > 0:
			#channels.remove(channels[0]) #Does not work
			#channels.pop(0) #Does not work
			itemList = mc.ListItems()
			count = 0
			for channel in channels:
				if count != 0:
					itemList.append(channel)
				count = (count + 1)
				
			channels = itemList
		
		
		# Return with episode count, if requested. #
		if returnChannels:
			return episodes, channels
		else:
			return episodes


# Get episodes of a given show based on show slug and user context. #
def get_show(showSlug, limit = 50, returnShows = False, userContext = 'app_context_system'):
	# Build API URL #
	url = '%sMediafly.Shows.GetShowInfo?app_id=%s&token=%s&showSlug=%s&recentEpisodes=%s&user_context=%s' % (
		apiURL, appID, token, showSlug, limit, userContext)
	
	xml = _get_api_url(url, 'get_show()')
	showNode = xml.getElementsByTagName('show')[0]

	if xml:
		# Convert episodes to Boxee Item List. #
		episodes = _nodes_to_listitems(showNode.childNodes, userContext)

		# Convert shows to Boxee Item List. #
		shows = _shows_to_listitems(xml.getElementsByTagName('show'), userContext)


		# Return with show count, if requested. #
		if returnShows:
			return episodes, shows
		else:
			return episodes



def browse_content_sources(userContext = 'app_context_system'):
	
	# Build API URL #
	url = '%sMediafly.ContentSources.Browse?app_id=%s&token=%s&user_context=%s' % (apiURL, appID, token, userContext)
	
	xml = _get_api_url(url, 'browse_content_sources()')
	
	if xml:
		# Convert sources to Boxee Item List. #
		sources = _content_sources_to_listitems(xml.getElementsByTagName('contentSource'), userContext)
		
		return sources

	

# Get episode details based on episode slug. # 
def get_episode_info(episodeSlug):
	
	# Build API URL #
	url = '%sMediafly.Episodes.GetEpisodeInfo?app_id=%s&token=%s&episodeSlug=%s' % (apiURL, appID, token, episodeSlug)
	
	xml = _get_api_url(url, 'get_episode_info()')
	
	if xml:
		# Not in use, yet #
		return

# Search a give query, return shows and episodes. #
def search(query, userContext = 'app_context_system'):
	# Clean query string. #
	query = urllib.quote(query)
	
	# Build API URL #
	url = '%sMediafly.Search.Query?app_id=%s&token=%s&term=%s&searchtype=show,episode&includeShow=yes&limit=100' %	(apiURL, appID, token, query)
	
	xml = _get_api_url(url, 'search()')
	searchResultsNode = xml.getElementsByTagName('searchResults')[0]
	
	if xml:
		# Convert episodes to Boxee Item List. #
		episodes = _nodes_to_listitems(searchResultsNode.childNodes, userContext)
		
		# Convert shows to Boxee Item List. #
		shows = _shows_to_listitems(xml.getElementsByTagName('show'), userContext)
		
		return episodes, shows


# Subscribe user to a given show or episode based on slug. #
def subscribe(slug, title, show = True):
	
	# Build API URL #
	url = '%sMediafly.Subscriptions.Subscribe?app_id=%s&token=%s&slug=%s' % (apiURL, appID, token, slug)
	
	# Default is show, only change if episode.
	if not show:
		url += '&subscriptionType=Episode'

	xml = _get_api_url(url, 'subscribe()')
	
	if xml:
		mc.ShowDialogNotification('You have subscribed to: %s' % title)
		return True
		
	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed subscribing to: %s' % title)
		return False


# Unubscribe user from a given show or episode based on slug. #
def unsubscribe(slug, title, show = True):
	
	# Build API URL #
	url = '%sMediafly.Subscriptions.Unsubscribe?app_id=%s&token=%s&slug=%s'  % (apiURL, appID, token, slug)
	
	# Default is show, only change if episode. #
	if not show:
		url += '&subscriptionType=Episode'

	xml = _get_api_url(url, 'unsubscribe()')
	
	if xml:			
		mc.ShowDialogNotification('You have unsubscribed to: %s' % title)
		return True
		
	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed unsubscribing to: %s' % title)
		return False


# Add an episode to the users favorite based on slug. #
def add_episode_favorite(slug, title):
	
	# Build API URL #
	url = '%sMediafly.Episodes.AddFavoriteEpisode?app_id=%s&token=%s&episodeSlug=%s' % (apiURL, appID, token, slug)

	xml = _get_api_url(url, 'add_episode_favorite()')
	
	if xml:	
		mc.ShowDialogNotification('Added %s to favorites.' % title)
		return True
		
	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed adding %s to favorites.' % title)
		return False


# Remove an episode from the users favorite based on slug. #
def remove_episode_favorite(slug, title):
	
	# Build API URL #
	url = '%sMediafly.Episodes.RemoveFavoriteEpisode?app_id=%s&token=%s&episodeSlug=%s' % (apiURL, appID, token, slug)

	xml = _get_api_url(url, 'remove_episode_favorite()')
	
	if xml:			
		mc.ShowDialogNotification('Removed %s from favorites.' % title)
		return True
		
	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed removing %s from favorites.' % title)
		return False


# Add a show to the users favorite based on slug. #
def add_show_favorite(slug, title):

	# Build API URL #
	url = '%sMediafly.Shows.AddFavoriteShow?app_id=%s&token=%s&showSlug=%s' % (apiURL, appID, token, slug)

	xml = _get_api_url(url, 'add_show_favorite()')

	if xml:
		mc.ShowDialogNotification('Added %s to favorites.' % title)
		return True

	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed adding %s to favorites.' % title)
		return False

# Add a show to the users favorite based on slug. #
def remove_show_favorite(slug, title):

	# Build API URL #
	url = '%sMediafly.Shows.RemoveFavoriteShow?app_id=%s&token=%s&showSlug=%s' % (apiURL, appID, token, slug)

	xml = _get_api_url(url, 'remove_show_favorite()')

	if xml:
		mc.ShowDialogNotification('Removed %s to favorites.' % title)
		return True

	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed adding %s to favorites.' % title)
		return False

# Rate a given show or episode based on slug. #
def rate_item(slug, rating, show = True):
	
	# Build API URL #
	if show:
		url = '%sMediafly.Shows.AddShowRating?app_id=%s&token=%s&showSlug=%s&rating=%s' % (apiURL, appID, token, slug, rating)
	else:
		url = '%sMediafly.Episodes.AddEpisodeRating?app_id=%s&token=%s&episodeSlug=%s&rating=%s' % (apiURL, appID, token, slug, rating)
	
	xml = _get_api_url(url, 'rate_item()')
	
	if xml:		
		mc.ShowDialogNotification('Set rating to: %s' % rating)
		return True
		
	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed rating item')
		return False

def remove_rating(slug, title, show = True):
	# Build API URL #
	if show:
		url = '%sMediafly.Shows.RemoveShowRating?app_id=%s&token=%s&showSlug=%s' % (apiURL, appID, token, slug)
	else:
		url = '%sMediafly.Episodes.RemoveEpisodeRating?app_id=%s&token=%s&episodeSlug=%s' % (apiURL, appID, token, slug)

	xml = _get_api_url(url, 'remove_rating()')

	if xml:
		mc.ShowDialogNotification('Removed rating from %s' % title)
		return True

	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed to remove rating from %s' % title)
		return False

# Post playback to MF #
def post_action(item, action, position):
	if user_is_bound():
		#Build API URL #
		url = '%sMediafly.Experience.PostAction?app_id=%s&token=%s&slug=%s&source=__mediafly__&type=%s&action=%s&position=%s' % (
			apiURL, appID, token, item.GetProperty('slug'), item.GetProperty('type'), action, position)
		
		# Call MF api, get XML results for parsing. #
		xml = _get_api_url(url, 'post_action()')
	

# Report banners ect to Mediafly #
def post_impression(sourceStart, sourceAtImpression, url, slug=None):
	url = '%sMediafly.Experience.PostImpression?app_id=%s&token=%s&sourceAtStart=%s&sourceAtImpression=%s&url=%s' % (
		apiURL, appID, token, sourceStart, sourceAtImpression, url)
	# Call MF api, get XML results for parsing. #
	xml = _get_api_url(url, 'post_impression()')

# Bind Boxee user to MF account. (login) #
def bind_user():
	
	# Request MF username and password. #
	user = mc.ShowDialogKeyboard("Enter Username", "", False)
	pswd = mc.ShowDialogKeyboard("Enter Password", "", True)
		
		
	# Make sure we have valid strings for user anr pswd. #
	if user and pswd:
		mc.ShowDialogWait()
		# Build API URL (use SSL) #
		url = '%sMediafly.Authentication.BindMFUser?app_id=%s&token=%s&accountName=%s&password=%s' %  (apiSecURL, appID, token, user, pswd)
		
		# Call MF api, get XML results for parsing. #
		xml = _get_api_url(url, 'bind_user()', True)
		
		if xml:
			# If this is the first binding, inform user of seccuss. #
			if not user_is_bound:
				mc.ShowDialogNotification('Bound user: ' + user)
			
			# Set local config with binding info #
			config.SetValue('bound', 'True')
			get_bound_users()
			mc.HideDialogWait()
			return True
			
		else:
			# If anything failed, reset bound var, inform user. #
			config.SetValue('bound', 'False')
			mc.ShowDialogNotification('Invalid user and/or password.')
			bx.log_message('Invalid user and/or password.', True)
			mc.HideDialogWait()
			return False
	
	# Either the saved user and pass is invalid, or the keyboard input was bad. #	
	else:
		config.SetValue('bound', 'False')
		return False


# Bind Boxee user to content source. #
def add_source(mcode, userContext = 'app_context_system'):		
	
	sourceSlug = False
		
	# Build API URL. #
	url = '%sMediafly.ContentSources.AddContentSource?app_id=%s&token=%s&code=%s&user_context=%s' % (apiURL, appID, token, mcode, userContext)
	
	# Call MF api, get XML results for parsing. #
	xml = _get_api_url(url, 'add_source()')
	
	if xml:
		'''
		createAccountUrl = bx.clean_string(source.getAttribute('createAccountUrl'))
		linkAccountUrl = bx.clean_string(source.getAttribute('linkAccountUrl'))
		requiresAuthentication = bx.clean_string(source.getAttribute('requiresAuthentication'))
		allowsUnboundUsers = bx.clean_string(source.getAttribute('allowsUnboundUsers'))
		'''
		
		source = xml.getElementsByTagName('contentSource')[0] #there should only be one.
		supportsUserBindings = source.getAttribute('supportsUserBindings')
		if source.getAttribute('postImpressions')=='true': config.SetValue('usePostImpressions', "True")
		sourceSlug = source.getAttribute('slug')
		
		# Should we bind? #
		if supportsUserBindings == 'true':
			provider = bx.clean_string(source.getAttribute('provider'))
			bindingMethod = source.getElementsByTagName('bindingMethod')[0].getAttribute('type')
			
			if bindingMethod == 'UsernamePassword':
				user = mc.ShowDialogKeyboard("Please enter your %s user name." % provider, "", False)
				pswd = mc.ShowDialogKeyboard("Please enter your %s password." % provider, "", True)
				
				if user and pswd:
					url = '%sMediafly.ContentSources.BindUser?app_id=%s&token=%s&source=%s&accountName=%s&password=%s&user_context=%s' % (
						apiURL, appID, token, sourceSlug, user, pswd, userContext)
				else:
					remove_source(sourceSlug)
					return False
				
			elif bindingMethod == 'UsernamePasswordPin':
				user = mc.ShowDialogKeyboard("Please enter your %s user name.", "", False)
				pswd = mc.ShowDialogKeyboard("Please enter your %s password.", "", True)
				pin = mc.ShowDialogKeyboard("Please enter a PIN", "", False)
				
				if user and pswd and pin:
					url = '%sMediafly.ContentSources.BindUser?app_id=%s&token=%s&source=%s&accountName=%s&password=%s&pin=%s&user_context=%s' % (
						apiURL, appID, token, sourceSlug, user, pswd, pin, userContext)
				else:
					remove_source(sourceSlug)
					return False
			
			# Unknown binding method. #
			else:
				return False
				
			xml = _get_api_url(url, 'add_source() (binding call)')
			
			# Binding worked. #
			if xml:
				return str(sourceSlug)
				
			# Binding failed. #
			else:
				return False
			
		# No binding required. #
		else:
			return str(sourceSlug)
		
	# Adding plugin failed from API call. #
	else:
		return False


# Bind Boxee user to content source. #
def remove_source(source, userContext = 'app_context_system'):
	
		
	# Build API URL. #
	url = '%sMediafly.ContentSources.RemoveContentSource?app_id=%s&token=%s&source=%s&user_context=%s' % (apiURL, appID, token, source, userContext)
	
	# Call MF api, get XML results for parsing. #
	xml = _get_api_url(url, 'remove_source()')
	
	# Add logging. #
	if xml:
		return True
	else:
		return False


# Bind get accounts bound to Boxee user (should only be one). #
def get_content_sources(userContext = 'app_context_system'):
	
	# Build API URL #
	url = '%sMediafly.ContentSources.GetContentSources?app_id=%s&token=%s&user_context=%s' % (apiURL, appID, token, userContext)
	
	# Call MF api, get XML results for parsing. #
	xml = _get_api_url(url, 'get_content_sources()')
	
	if xml:
		# Convert sources to Boxee Item List. #
		sources = _content_sources_to_listitems(xml.getElementsByTagName('contentSource'), userContext)
		
		return sources
		
	else:
		return False

# Bind get accounts bound to Boxee user (should only be one). #
def get_bound_users():
	
	# Default is true, unless we have an issue. #
	bound = True
	config.Reset('hasmcode') # default is hide media sources
	
	# Build API URL #
	url = '%sMediafly.Authentication.GetBoundMFUsers?app_id=%s&token=%s' % (apiURL, appID, token)
	
	# Call MF api, get XML results for parsing. #
	xml = _get_api_url(url, 'get_bound_users()')
	
	if xml:
		for node in xml.getElementsByTagName('mfuser'):
			
			# Only bind the default user. Though, there should only ever be one. #
			if node.getAttribute('default').lower() == 'true':
				
				# Bind user, save user context. #
				config.SetValue('bound', 'True')
				bx.log_message('Bound: ' + config.GetValue('bound'))
				
				config.SetValue('user_context', bx.clean_string(node.getAttribute('accountName')))
				bx.log_message('Context: ' + config.GetValue('user_context'))
				
				# check if user has sources
				if len(get_content_sources(config.GetValue('user_context')))>0:
					config.SetValue('hasmcode', 'True')
				
			else:
				bound = False
	else:
		bound = False
		
	if not bound:
		# If binding failed for any reason, reset local vars, #
		config.SetValue('bound', 'False')
		config.Reset('user_context')



# Unbind Boxee user from MF account. (logout) #
def unbind_user():
	
	# Get MF username to unbind. #
	if user_is_bound():
		user = config.GetValue('user_context')
	else:
		user = mc.ShowDialogKeyboard("Enter Username", "", False)
	
	# Build API URL #
	url = '%sMediafly.Authentication.UnbindMFUser?app_id=%s&token=%s&accountName=%s' % (apiURL, appID, token, user)
	
	xml = _get_api_url(url, 'unbind_user()')
	
	if xml:
		mc.ShowDialogNotification('Unbound user: ' + user)
		
		# Set local config with binding info #
		config.SetValue('bound', 'False')
		config.Reset('user_context')
		config.Reset('hasmcode')
		
		return
		
	# If we get a failed response from the API, show user. #
	else:
		mc.ShowDialogNotification('Failed unbinding user: %s' % errMsg)
		return


# Check local config to see if a user is currently bound. #
def user_is_bound():
	
	# If the value of 'bound' is anything other than 'True', return false. #
	if config.GetValue('bound') != 'True':
		return False
	else:
		return True


# Play item with either Boxee's action menu, our MF's. #
def play_item(item, useActionMenu = False):
	
	# Play in thread so as not to halt app. #
	pt = _play_in_thread(item, useActionMenu)
	pt.start()



def requires_binding():
	
	bound = False

	if user_is_bound():
		bound = True
		
	else:
		response = mc.ShowDialogConfirm("Mediafly", "You have not logged in.  Would you like to login?", "No", "Yes")
		if response:
			if bind_user():
				bound = True

	return bound



	
'''
These are all helper methods should not be called outside of mediafly.py
'''
def _get_api_url(url, callMethod, isSSL = False, retryIfInvalidToken = True, writeXML = False):
	# Print API call for debugging.. #
	if not isSSL:
		bx.log_message('API URL: %s' % url)
	else:
		bx.log_message('SSL API call, URL not logged.')
	
	try:
		# Get API XML from Mediafly #
		xml = bx.get_xml(url)
		
		# I/O overhead from writing XML to disk kills performance. #
		if writeXML:
			bx.log_message('Temp XML: ' + tempXML)
			urllib.urlretrieve(url, tempXML)
		
		# Parse XML, if response is 'ok' #
		response = xml.getElementsByTagName('response')[0].getAttribute('status')
		if response == 'ok':
			return xml

		# If we get a failed response from the API, log it. #
		else:
			errCode = xml.getElementsByTagName('err')[0].getAttribute('code')
			errMsg = xml.getElementsByTagName('err')[0].getAttribute('message')
			
			if (errCode=="20" or errCode=="21") and retryIfInvalidToken:
				oldToken = token
				get_token()
				return _get_api_url(url.replace(oldToken, token, 1), callMethod, isSSL, False, writeXML)
			else:
				bx.log_message('%s failed MF response: %s' % (callMethod, errMsg), True)
				return False
			
	except Exception, e:
		bx.log_message('Exception when attempting to resolve API URL: %s (Calling method: %s)' % (e, callMethod), True)
		return False


class _play_in_thread(Thread):
	
	# Define class vars. #
	def __init__ (self, item, useActionMenu):
		Thread.__init__(self)
		self.item = item
		self.player = mc.GetPlayer()
		self.position = 0
		self.length = 0
		self.slug = item.GetProperty('slug')
		self.useActionMenu = useActionMenu
		
	# Run() method required for Thread. #
	def run(self):
		bx.log_message('Starting Play Thread.')

		# Play our item. #
		if self.useActionMenu:
			# This is still jacked-up, as playWithActionMenu does not return true/false.
			self.player.Stop()
			self.player.PlayWithActionMenu(self.item)
		else:
			mc.ShowDialogWait()
			# Stop anything that is currently playing, wait for it to stop. #
			while self.player.IsPlaying():
				bx.log_message('Found playing media, stopping it.')
				self.player.Stop()
				time.sleep(1)
			# Now start playing. #
			self.player.Play(self.item)
			mc.HideDialogWait()
			bx.log_message("Playing: %s (directly playing)" % self.item.GetTitle())

		#TODO HACK fix me if boxee ever makes PlayWithActionMenu return true/false
		# Boxee does not return wether the use plays or cancels the play menu
		# so this waits for 30 seconds to detect if media starts playing.  If
		# not the thread is aborted.
		abort=0
		while not self.player.IsPlaying():
			abort += 1
			time.sleep(1)
			bx.log_message('Abort in %s' % (30-abort))
			if self.useActionMenu and abort>30:
				bx.log_message("Aborting _play_in_thread.  Assuming user did not play from dialog")
				return

		# post the play action
		post_action(self.item, "play", 0)
		
		# Boxee does not switch to the play screen for audio, on its own. #
		if self.player.IsPlayingAudio():
			mc.ActivateWindow(12006)

		# Get the total length of the media, for reporting back to MF. #
		self.length = int(self.player.GetTotalTime())
			
		# Loop the player until the media is stopped. Update the time played. #
		lastupdate=0
		while self.player.IsPlaying():
			self.position = int(self.player.GetTime())
			if math.fabs(self.position-lastupdate>60): #only update boxee every 60 second difference
				post_action(self.item, "playing", self.position)
				lastupdate=self.position
			time.sleep(1)
			
		# Post back the MF how log we played the media for. #
		bx.log_message("Item with the slug: %s was played for: %s seconds"  % (self.slug, self.position))
		post_action(self.item, "stop", self.position)

def _check_token():
	
	# If the value of 'haveToken' is anything other than 'True', return false. #
	if config.GetValue('haveToken') != 'True':
		return False
	
	bx.log_message('Token found, checking if it has expired.')	
	
	# Convert string from XML into manageable format. #
	tokenTime = time.strptime(config.GetValue('expiry').split('.')[0], "%Y-%m-%dT%H:%M:%S")
	
	# Convert current UTC information into manageable format. #
	#currentTime =  time.strptime(datetime.datetime.utcnow().isoformat().split('.')[0], "%Y-%m-%dT%H:%M:%S")
	currentTime =  time.strptime(datetime.datetime.now().isoformat().split('.')[0], "%Y-%m-%dT%H:%M:%S")
	
	# Create variables that can be compared. #
	texpire = datetime.datetime(tokenTime.tm_year, tokenTime.tm_mon, tokenTime.tm_mday, tokenTime.tm_hour, tokenTime.tm_min, tokenTime.tm_sec)
	tnow = datetime.datetime(currentTime.tm_year, currentTime.tm_mon, currentTime.tm_mday, currentTime.tm_hour, currentTime.tm_min, currentTime.tm_sec)
	
	# Token time to current time, return accordingly. #
	if texpire < tnow:
		bx.log_message('Token has expired, request new token.')
		return False
	else:
		bx.log_message('Token is valid until: ' + str(texpire))	
		return True

def _document_to_listitem(document, userContext):

	item = False
	
	bx.log_message('=========================START MF DOCUMENT========================')
	docType = bx.clean_string(document.getAttribute('docType').lower())
	if docType=="html":
		title = bx.clean_string(document.getAttribute('title'))
		path = bx.clean_string(document.getAttribute('url'))
		description = bx.clean_string(document.getAttribute('description'))
		image = bx.clean_string(document.getAttribute('imageUrl'))
		slug = bx.clean_string(document.getAttribute('slug'))
		webSiteUrl = bx.clean_string(document.getAttribute('webSiteUrl'))
		date = bx.clean_string(document.getAttribute('published'))

		# media type
		bx.log_message('reported content type: ' + docType)
		item = mc.ListItem( mc.ListItem.MEDIA_VIDEO_OTHER )
		item.SetProperty('html', 'True')
		item.SetProperty('type',docType)

		bx.log_message('title: ' + title)
		item.SetLabel(title)
		item.SetTitle(title)
		item.SetContentType("text/html")

		bx.log_message('path: ' + path)
		item.SetPath(path)

		bx.log_message('description: ' + description)
		item.SetDescription(description)

		bx.log_message('image: ' + image)
		item.SetThumbnail(image)
		item.SetIcon(image)

		bx.log_message('slug: ' + slug)
		item.SetProperty('slug', slug)

		if (date):
			bx.log_message('date: ' + date)
			item.SetProperty('date', date)

		# These items are consistant. #
		bx.log_message('user context: ' + userContext)
		item.SetProperty('userContext', userContext)

		item.SetProperty('itemType', docType)
		item.SetProperty('isDocument', 'True')
		item.SetReportToServer(True)
		item.SetAddToHistory(True)
		item.SetProviderSource("Mediafly")

	else:
		bx.log_message("document type: %s.  Skipping." % docType)

	bx.log_message('=========================END MF DOCUMENT========================')
		
	return item

def _nodes_to_listitems(nodes, userContext):
	
	itemList = mc.ListItems()

	if len(nodes)>0:
		#loop through all nodes. creating items for episodes and documents
		for node in nodes:
			item=False
			if node.localName == 'document':
				item = _document_to_listitem(node, userContext)
			elif node.localName =='episode':
				item = _episode_to_listitem(node, userContext)
			elif node.localName == 'channel':
				#intentionally skipping channel nodes
				item = False
			else:
				bx.log_message("Skipping unknown node: %s." % node.localName)
			if(item): itemList.append(item)
	return itemList

def _episode_to_listitem(episode, userContext):
	
	bx.log_message('=========================START MF EPISODE=========================')
	mediaType = bx.clean_string(episode.getAttribute('mediaType').lower())
	title = bx.clean_string(episode.getAttribute('title'))
	path = bx.clean_string(episode.getAttribute('url'))
	description = bx.clean_string(episode.getAttribute('description'))
	image = bx.clean_string(episode.getAttribute('imageUrl'))
	slug = bx.clean_string(episode.getAttribute('slug'))
	showSlug = bx.clean_string(episode.getAttribute('showSlug'))
	showTitle = bx.clean_string(episode.getAttribute('showTitle'))
	webSiteUrl = bx.clean_string(episode.getAttribute('webSiteUrl'))
	duration = bx.clean_string(episode.getAttribute('duration'))
	date = bx.clean_string(episode.getAttribute('published'))
	averageRating = bx.clean_string(episode.getAttribute('averageRating'))
	userRating = bx.clean_string(episode.getAttribute('userRating'))
	favoriteType = bx.clean_string(episode.getAttribute('favoriteType'))
	subscriptionType = bx.clean_string(episode.getAttribute('subscriptionType'))
	#check for show information as a child of episode
	showNode = None
	if len(episode.getElementsByTagName("show"))>0:
		showNode = episode.getElementsByTagName("show")[0]
	elif episode.parentNode.localName == "show":
		showNode = episode.parentNode

	showRating=""
	userShowRating=""
	if showNode != None:
		if showNode.hasAttribute("averageRating"): showRating = bx.clean_string(showNode.getAttribute("averageRating"))
		if showNode.hasAttribute("userRating"): userShowRating = bx.clean_string(showNode.getAttribute("userRating"))

	bx.log_message('reported content type: ' + mediaType)

	if mediaType == 'video':
		bx.log_message('setting type: video')
		item = mc.ListItem( mc.ListItem.MEDIA_VIDEO_OTHER )
		exItem = mc.ListItem( mc.ListItem.MEDIA_VIDEO_OTHER )
		item.SetProperty('video', 'True')
		item.SetProperty('type','video')
	elif mediaType == 'audio':
		bx.log_message('setting content type: audio')
		item = mc.ListItem( mc.ListItem.MEDIA_AUDIO_OTHER )
		exItem = mc.ListItem( mc.ListItem.MEDIA_AUDIO_OTHER )
		item.SetProperty('audio', 'True')
		item.SetProperty('type', 'audio')
	else:
		bx.log_message('setting content type: unknown')
		item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
		exItem = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )


	bx.log_message('title: ' + title)
	item.SetLabel(title)
	exItem.SetLabel(title)
	item.SetTitle(title)
	exItem.SetTitle(title)

	bx.log_message('path: ' + path)
	item.SetPath(path)
	exItem.SetPath(webSiteUrl)

	bx.log_message('description: ' + description)
	item.SetDescription(description)
	exItem.SetDescription(description)

	bx.log_message('image: ' + image)
	item.SetThumbnail(image)
	exItem.SetThumbnail(image)
	item.SetIcon(image)
	exItem.SetIcon(image)

	bx.log_message('slug: ' + slug)
	item.SetProperty('slug', slug)

	bx.log_message('show slug: ' + showSlug)
	item.SetProperty('showSlug', showSlug)

	bx.log_message('show title: ' + showTitle)
	item.SetProperty('showTitle', showTitle)

	if (duration):
		bx.log_message('duration: ' + duration)
		item.SetDuration(int(duration))
		exItem.SetDuration(int(duration))
		item.SetProperty('formattedDuration', str(datetime.timedelta(seconds=int(duration))))

	if (date):
		bx.log_message('date: ' + date)
		item.SetProperty('date', date)

	if (averageRating and averageRating!="0"):
		bx.log_message('rating: ' + averageRating)
		item.SetProperty('averageRating', averageRating[:3]) # limit to 1 decimal

	if (userRating and userRating!="0"):
		bx.log_message('user rating: ' + userRating)
		item.SetProperty('userRating', userRating)

	if (showRating and showRating!="0"):
		bx.log_message('show rating: ' + showRating)
		item.SetProperty('showRating', showRating[:3]) # limit to 1 decimal

	if(userShowRating and userShowRating!="0"):
		bx.log_message('user show rating: '+ userShowRating)
		item.SetProperty('userShowRating', userShowRating)

	if (favoriteType):
		if "Episode" in favoriteType:
			item.SetProperty('isEpisodeFavorite', 'true')
		if "Show" in favoriteType:
			item.SetProperty('isShowFavorite','true')
		bx.log_message('favorite type: ' + favoriteType)
		item.SetProperty('favoriteType', favoriteType)

	if (subscriptionType):
		if "Episode" in subscriptionType:
			item.SetProperty('isEpisodeSubscription','true')
		if 'Show' in subscriptionType:
			item.SetProperty('isShowSubscription','true')
		bx.log_message('subscription type: ' + subscriptionType)
		item.SetProperty('subscriptionType', subscriptionType)

	# These items are consistant. #
	bx.log_message('user context: ' + userContext)
	item.SetProperty('userContext', userContext)

	item.SetProperty('itemType', 'episode')
	item.SetProperty('isEpisode', 'True')
	item.SetReportToServer(True)
	item.SetAddToHistory(True)
	item.SetProviderSource("Mediafly")
	exItem.SetProviderSource("Mediafly")

	#always report webSiteUrl
	item.SetExternalItem(exItem)

	bx.log_message('=========================END MF EPISODE=========================')

	return item


def _shows_to_listitems(shows, userContext):

	# ListItem to store show list. #
	itemList = mc.ListItems()
	
	if len(shows) > 0:
		
		# Add each show to a new instance of ListItem. #
		for show in shows:
			bx.log_message('=========================START MF SHOW=========================')
			title = bx.clean_string(show.getAttribute('title'))
			image = bx.clean_string(show.getAttribute('imageUrl'))
			slug = bx.clean_string(show.getAttribute('slug'))
			description = bx.clean_string(show.getAttribute('description'))
			mediaType = bx.clean_string(show.getAttribute('mediaType'))
			
			item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
			
			bx.log_message('title: ' + title)
			item.SetLabel(title)
			item.SetTitle(title)
			
			bx.log_message('image: ' + image)
			item.SetThumbnail(image)
			item.SetIcon(image)
			
			bx.log_message('slug: ' + slug)
			item.SetProperty('slug', slug)
			
			bx.log_message('description: ' + description)
			item.SetDescription(description)
			
			bx.log_message('media type: ' + mediaType)
			item.SetProperty('mediaType', mediaType)
			
			bx.log_message('user context: ' + userContext)
			item.SetProperty('userContext', userContext)
			
			item.SetProperty('itemType', 'show')
			item.SetProperty('isShow','True')
			itemList.append(item)
			
			bx.log_message('=========================END MF SHOW=========================')
	
	
	# Always return item list, even if it is empty. Otherwise, Boxee will freeze. #	
	return itemList


def _channels_to_listitems(channels, userContext):
	
	# ListItem to store show list. #
	itemList = mc.ListItems()
	
	if len(channels) > 0:
		
		# Add each channel to a new instance of ListItem. #
		for channel in channels:
			bx.log_message('=========================START MF CHANNEL=========================')
			title = bx.clean_string(channel.getAttribute('name'))
			image = bx.clean_string(channel.getAttribute('imageUrl'))
			slug = bx.clean_string(channel.getAttribute('slug'))
			parentSlug = bx.clean_string(channel.getAttribute('parentChannelSlug'))
			versionHash = bx.clean_string(channel.getAttribute('versionHash'))
			episodeCount = bx.clean_string(channel.getAttribute('episodeCount'))
			channelCount = bx.clean_string(channel.getAttribute('channelCount'))
			totalEpisodes = bx.clean_string(channel.getAttribute('totalEpisodes'))


			item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
			
			bx.log_message('title: ' + title)
			item.SetLabel(title)
			item.SetTitle(title)
			
			bx.log_message('image: ' + image)
			item.SetThumbnail(image)
			item.SetIcon(image)
			
			bx.log_message('slug: ' + slug)
			item.SetProperty('slug', slug)
			
			bx.log_message('parent slug: ' + parentSlug)
			item.SetProperty('parentSlug', parentSlug)
			
			bx.log_message('version hash: ' + versionHash)
			item.SetProperty('versionHash', versionHash)
			
			if (episodeCount):
				bx.log_message('episode count: ' + episodeCount)
				item.SetProperty('episodeCount', episodeCount)
				
			if (channelCount):
				bx.log_message('channel count: ' + channelCount)
				item.SetProperty('channelCount', channelCount)
			
			if (totalEpisodes):
				bx.log_message('total episodes: ' + totalEpisodes)
				item.SetProperty('totalEpisodes', totalEpisodes)
			
			bx.log_message('user context: ' + userContext)
			item.SetProperty('userContext', userContext)
			
			item.SetProperty('itemType', 'channel')
			item.SetProperty('isChannel','True')
			# Do not add root channel.  Not even sure why it gets returned. #
			if not slug == "__root__":
				itemList.append(item)
			
			bx.log_message('=========================END MF CHANNEL=========================')
	
	
	# Always return item list, even if it is empty. Otherwise, Boxee will freeze. #
	return itemList
		


def _content_sources_to_listitems(sources, userContext):
	
	# ListItem to store show list. #
	itemList = mc.ListItems()
	
	if len(sources) > 0:
		
		# Add each source to a new instance of ListItem. #
		for source in sources:
			bx.log_message('=========================START MF CONTENT SOURCE=========================')
			title = bx.clean_string(source.getAttribute('title'))
			image = bx.clean_string(source.getAttribute('imageUrl'))
			imageAlt1 = bx.clean_string(source.getAttribute('imageUrlAlt1'))
			imageAlt2 = bx.clean_string(source.getAttribute('imageUrlAlt2'))
			description = bx.clean_string(source.getAttribute('description'))
			provider = bx.clean_string(source.getAttribute('provider'))
			slug = bx.clean_string(source.getAttribute('slug'))
			mcode = bx.clean_string(source.getAttribute('mcode'))
			bindingMethod = bx.clean_string(source.getElementsByTagName('bindingMethod')[0].getAttribute('type'))
			
			createAccountUrl = bx.clean_string(source.getAttribute('createAccountUrl'))
			linkAccountUrl = bx.clean_string(source.getAttribute('linkAccountUrl'))
			requiresAuthentication = bx.clean_string(source.getAttribute('requiresAuthentication'))
			allowsUnboundUsers = bx.clean_string(source.getAttribute('allowsUnboundUsers'))
			supportsUserBindings = bx.clean_string(source.getAttribute('supportsUserBindings'))
			usernameRequired = bx.clean_string(source.getAttribute('usernameRequired'))
			passwordRequired = bx.clean_string(source.getAttribute('passwordRequired'))
			passwordEncryptionRequired = bx.clean_string(source.getAttribute('passwordEncryptionRequired'))
			encryptionType = bx.clean_string(source.getAttribute('encryptionType'))
			encryptionKey = bx.clean_string(source.getAttribute('encryptionKey'))
			isUserRemovable = bx.clean_string(source.getAttribute('isUserRemovable'))
			supportsRatings = bx.clean_string(source.getAttribute('supportsRatings'))
			supportsFavorites = bx.clean_string(source.getAttribute('supportsFavorites'))
			supportsSubscriptions = bx.clean_string(source.getAttribute('supportsSubscriptions'))
			contentCachingAllowed = bx.clean_string(source.getAttribute('contentCachingAllowed'))
			supportsExperiences = bx.clean_string(source.getAttribute('supportsExperiences'))
			isSearchable = bx.clean_string(source.getAttribute('isSearchable'))

			
			item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
			
			bx.log_message('title: ' + title)
			item.SetLabel(title)
			item.SetTitle(title)
			
			bx.log_message('image: ' + image)
			item.SetThumbnail(image)
			item.SetIcon(image)
			
			if (imageAlt1):
				bx.log_message('imageAlt1: ' + imageAlt1)
				item.SetProperty('imageAlt1', imageAlt1)
				
			if (imageAlt2):
				bx.log_message('imageAlt2: ' + imageAlt2)
				item.SetProperty('imageAlt2', imageAlt2)
			
			bx.log_message('description: ' + description)
			item.SetDescription(description)
			
			bx.log_message('provider: ' + provider)
			item.SetProviderSource(provider)
			
			bx.log_message('slug: ' + slug)
			item.SetProperty('slug', slug)
			
			bx.log_message('mcode: ' + mcode)
			item.SetProperty('mcode', mcode)
			
			bx.log_message('bindingMethod: ' + bindingMethod)
			item.SetProperty('bindingMethod', bindingMethod)
			
			if (createAccountUrl):
				bx.log_message('createAccountUrl: ' + createAccountUrl)
				item.SetProperty('createAccountUrl', createAccountUrl)
			
			if (linkAccountUrl):
				bx.log_message('linkAccountUrl: ' + linkAccountUrl)
				item.SetProperty('linkAccountUrl', linkAccountUrl)
				
			if (requiresAuthentication):
				bx.log_message('requiresAuthentication: ' + requiresAuthentication)
				item.SetProperty('requiresAuthentication', requiresAuthentication)
			
			if (allowsUnboundUsers):
				bx.log_message('allowsUnboundUsers: ' + allowsUnboundUsers)
				item.SetProperty('allowsUnboundUsers', allowsUnboundUsers)
				
			if (supportsUserBindings):
				bx.log_message('supportsUserBindings: ' + supportsUserBindings)
				item.SetProperty('supportsUserBindings', supportsUserBindings)
				
			if (usernameRequired):
				bx.log_message('usernameRequired: ' + usernameRequired)
				item.SetProperty('usernameRequired', usernameRequired)

			if (passwordRequired):
				bx.log_message('passwordRequired: ' + passwordRequired)
				item.SetProperty('passwordRequired', passwordRequired)

			if (passwordEncryptionRequired):
				bx.log_message('passwordEncryptionRequired: ' + passwordEncryptionRequired)
				item.SetProperty('passwordEncryptionRequired', passwordEncryptionRequired)

			if (encryptionType):
				bx.log_message('encryptionType: ' + encryptionType)
				item.SetProperty('encryptionType', encryptionType)

			if (encryptionKey):
				bx.log_message('encryptionKey: ' + encryptionKey)
				item.SetProperty('encryptionKey', encryptionKey)

			if (isUserRemovable):
				bx.log_message('isUserRemovable: ' + isUserRemovable)
				item.SetProperty('isUserRemovable', isUserRemovable)

			if (supportsRatings):
				bx.log_message('supportsRatings: ' + supportsRatings)
				item.SetProperty('supportsRatings', supportsRatings)

			if (supportsFavorites):
				bx.log_message('supportsFavorites: ' + supportsFavorites)
				item.SetProperty('supportsFavorites', supportsFavorites)

			if (supportsSubscriptions):
				bx.log_message('supportsSubscriptions: ' + supportsSubscriptions)
				item.SetProperty('supportsSubscriptions', supportsSubscriptions)

			if (contentCachingAllowed):
				bx.log_message('contentCachingAllowed: ' + contentCachingAllowed)
				item.SetProperty('contentCachingAllowed', contentCachingAllowed)

			if (supportsExperiences):
				bx.log_message('supportsExperiences: ' + supportsExperiences)
				item.SetProperty('supportsExperiences', supportsExperiences)

			if (isSearchable):
				bx.log_message('isSearchable: ' + isSearchable)
				item.SetProperty('isSearchable', isSearchable)
			
			bx.log_message('user context: ' + userContext)
			item.SetProperty('userContext', userContext)
			
			item.SetProperty('itemType', 'source')
			item.SetProperty('isSource', 'True')
			itemList.append(item)
			
			bx.log_message('=========================END MF CONTENT SOURCE=========================')
	
	
	# Always return item list, even if it is empty. Otherwise, Boxee will freeze. #
	return itemList