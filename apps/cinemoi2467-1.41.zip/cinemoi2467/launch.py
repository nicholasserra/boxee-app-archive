import mc
import bxutils as bx
import mediafly as mf
import mfConfig
import os
from xml.dom import minidom

mc.ShowDialogWait()
bx.log_message('Initialiazing Mediafly app.')
config = mc.GetApp().GetLocalConfig()

# Reset variables to be set
config.Reset('isderivativeapp')
config.Reset('hidegearmenu')
config.Reset('usePostImpressions')

# Set token for each instance #
if not mf.get_token():
	mc.ShowDialogNotification("Failed to get token from Mediafly, try restarting Boxee.")
else:
	bx.check_version(mfConfig.title)
	descriptor = '%s%s%s' % (mc.GetApp().GetAppDir(), os.sep, 'descriptor.xml')
	description = str(minidom.parse(descriptor).getElementsByTagName('description')[0].firstChild.nodeValue)
	config.SetValue('description', description)
	if hasattr(mfConfig, 'hideGearMenu'):
		if mfConfig.hideGearMenu: config.SetValue('hidegearmenu', 'True')

	# Used for testing.
	#mf.unbind_user()
	
	if mfConfig.isDerivativeApp:
		config.SetValue('isderivativeapp', 'True')
		slug = mf.add_source(mfConfig.mCode)
		config.SetValue('slug', slug)
		if(slug == False):
			mc.ShowDialogNotification("Error showing %s" % mfConfig.title)
		else:
			bx.launch_window(14001, 'source', {'slug':slug, 'title':mfConfig.title})
			
	else:
		mf.get_bound_users()
		config.SetValue('slug', '__mediafly__')
		config.SetValue('usePostImpressions', "True")
		if mf.user_is_bound():
			bx.log_message('Found bound user, setting content page.')
			bx.launch_window(14001, 'mine', {'title':'My Channels'})
		else:
			bx.log_message('No bound user')
			bx.launch_window(14001, 'popular', {'title':'Popular Channels'})

if config.GetValue('usePostImpressions')=="True":
	slug = config.GetValue('slug')
	bgUrl = "http://csassets.mediafly.com/%s/background-1280x720.png" % config.GetValue('slug')
	# send PostImpression for the bg image
	mf.post_impression(slug, slug, bgUrl)
mc.HideDialogWait()
