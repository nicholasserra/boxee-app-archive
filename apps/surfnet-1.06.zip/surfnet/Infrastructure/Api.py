
import xml.dom.minidom
#import urllib2
import Domain.Entities
import mc

class AuthenticationApi(object):
	def __init__(self):
		self._authenticationUrl = "http://api.nodplatform.com/boxee/auth.xml?username=%(uid)s&password=%(pwd)s&token=F7CCA699389E350AE2E6D0ED531A06349EFDC1861D6BCAF62D97DAB26099ECB3"
		
	def SignIn(self, username, password):
		
		#authenticationReader = urllib2.urlopen(self._authenticationUrl % {'uid': username, 'pwd': password})
		#authenticationResponse = authenticationReader.read()
		#authenticationReader.close()
		
		http = mc.Http()
		authenticationResponse = http.Get(self._authenticationUrl %{'uid':username,'pwd':password})
		
		authenticationXmlResponse = xml.dom.minidom.parseString(authenticationResponse)

		serviceReply = AuthenticationServiceReply()
	
		if self.GetText(authenticationXmlResponse, "login_status").startswith("200:"):
			serviceReply.Successful = True
			serviceReply.Customer.Id = self.GetText(authenticationXmlResponse, "cust_id")
			serviceReply.Customer.FirstName = self.GetText(authenticationXmlResponse, "firstname")
			serviceReply.Customer.LastName = self.GetText(authenticationXmlResponse, "lastname")
			serviceReply.Customer.FeedId = self.GetText(authenticationXmlResponse, "feed_id")
		else:
			serviceReply.Successful = False
			
		return serviceReply
	
	def GetText(self, xmlDom, nodeName):
		node = xmlDom.getElementsByTagName(nodeName)[0]
		return node.firstChild.nodeValue

class AuthenticationServiceReply(object):
	def __init__(self):
		self.Successful = False
		self.Customer = Domain.Entities.Customer()

