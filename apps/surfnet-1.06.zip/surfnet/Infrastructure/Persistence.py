import mc
import Domain.Entities

class LocalCustomerStorage:
	def __init__(self):
		self._storageKey = "surfnetwork.customer"
		
	def HasCustomer(self):
		
		return bool(mc.GetApp().GetLocalConfig().GetValue(self._storageKey))

	def Save(self, customer):
		config = mc.GetApp().GetLocalConfig()
		config.SetValue(self._storageKey, str(customer.Id))
		config.PushBackValue(self._storageKey, str(customer.FirstName))
		config.PushBackValue(self._storageKey, str(customer.LastName))
		config.PushBackValue(self._storageKey, str(customer.FeedId))
		
	def Get(self):
		customer = Domain.Entities.Customer()
		
		config = mc.GetApp().GetLocalConfig()
		customer.Id = config.GetValue(self._storageKey + "{0}")
		customer.FirstName = config.GetValue(self._storageKey + "{1}")
		customer.LastName = config.GetValue(self._storageKey + "{2}")
		customer.FeedId = config.GetValue(self._storageKey + "{3}")
		
		return customer
	
	def Clear(self):
		config = mc.GetApp().GetLocalConfig()
		config.ResetAll()