import Domain.Services
import Infrastructure.Persistence
import Infrastructure.Api

def CreateSession():

	persistence = Infrastructure.Persistence.LocalCustomerStorage()
	api = Infrastructure.Api.AuthenticationApi()

	return Domain.Services.Session(api, persistence)