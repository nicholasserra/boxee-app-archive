
class Customer(object):
	def __init__(self):
		self._id = ""
		self._firstName = ""
		self._lastName = ""
		self._feedId = ""

	def Id():
		def fget(self):
			return self._id
		def fset(self, value):
			self._id = value
		return locals()
	Id = property(**Id())

	def FirstName():
		def fget(self):
			return self._firstName
		def fset(self, value):
			self._firstName = value
		return locals()
	FirstName = property(**FirstName())

	def LastName():
		def fget(self):
			return self._lastName
		def fset(self, value):
			self._lastName = value
		return locals()
	LastName = property(**LastName())

	def FeedId():
		def fget(self):
			return self._feedId
		def fset(self, value):
			self._feedId = value
		return locals()
	FeedId = property(**FeedId())