
class HomePresenter():
	def __init__(self, view, session):
		self._view = view
		self._session = session
		
	def Show(self):
		
		if self._session.IsLoggedIn():
			self._view.ShowFeedView()
		else:
			self._view.ShowLoginView()