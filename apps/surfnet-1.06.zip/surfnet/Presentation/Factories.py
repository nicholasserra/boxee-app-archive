import Presentation.Presenters
import Domain.Factories

def CreateHomePresenter():

	session = Domain.Factories.CreateSession()
	return Presentation.Presenters.HomePresenter(session)