import mc

class Video(object):
	
	def Play(self, listItem):
	
		player = mc.GetPlayer()
		
		if player.IsPlaying():
			player.Stop()
		
		player.Play(listItem)

class Window(object):
	def __init__(self, windowId):
		self.__windowId_ = windowId
		self.__boxeeWindow_ = None

	def _GetWindow(self):

		if self.__boxeeWindow_ == None:
			self.__boxeeWindow_ = mc.GetWindow(self.__windowId_)

		return self.__boxeeWindow_

	def Show(self):
		#self._GetWindow().ClearStateStack(True)
		mc.ActivateWindow(self.__windowId_)

	def ShowWithParameters(self, params):
		mc.GetApp().ActivateWindow(self.__windowId_, params)
		
	def SaveState(self):
		self._GetWindow().ClearStateStack()
		#self._GetWindow().PushState()

class HomeWindow(Window):
	def __init__(self):
		Window.__init__(self, 14000)

	def SignInBox(self):
		return self._GetWindow().GetControl(100)

	def VideoList(self):
		return self._GetWindow().GetList(200)
	
	def EmailAddress(self):
		return self._GetWindow().GetEdit(101)
	
	def Password(self):
		return self._GetWindow().GetEdit(102)

	def SignOutButton(self):
		return self._GetWindow().GetButton(300)
	
	def SetSignedInState(self, isSignedIn):
		#self._GetWindow().ClearStateStack(False)
		
		self.SignInBox().SetVisible(not isSignedIn)
		self.SignOutButton().SetVisible(isSignedIn)
		self.VideoList().SetVisible(isSignedIn)
		self.ViewNavigation().SetVisible(isSignedIn)
		self.ViewNavigationSelections().SetVisible(isSignedIn)
		
	def ViewAllSelectedImage(self):
		return self._GetWindow().GetImage(411)

	def ViewFavouritesSelectedImage(self):
		return self._GetWindow().GetImage(412)
	
	def ViewRecentlyWatchedSelectedImage(self):
		return self._GetWindow().GetImage(413)
	
	def ViewNavigation(self):
		return self._GetWindow().GetControl(400)
		
	def ViewNavigationSelections(self):
		return self._GetWindow().GetControl(410)
	
	def HasVideosListed(self):
		return bool(len(self.VideoList().GetItems()) > 0)
		
		
class VideoDetailWindow(Window):
	def __init__(self):
		Window.__init__(self, 14005)

def Home():
	return HomeWindow()

def VideoDetail():
	return VideoDetailWindow()

