project = "khanacademy"
director = "Khan Academy"
publisher = "Khan Academy"
channel = "boxee"