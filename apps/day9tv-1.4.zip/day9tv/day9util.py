import mc
import re
from xml.sax.saxutils import unescape

# Setting variablols
http = mc.Http()
http.SetUserAgent('Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
items = mc.ListItems()
config = mc.GetApp().GetLocalConfig()
episodebatch = 20 #number of episodes -aka http requests- the app loads with every 'batch' for performance reasons
		
def GET_ARCHIVE():
	archive_html = http.Get("http://blip.tv/day9tv/rss")
	archive_results = re.compile('<blip:embedLookup>(.+?)</blip:embedLookup>').findall(archive_html)
	archive_thumbnails = re.compile('<blip:thumbnail_src>(.+?)</blip:thumbnail_src>').findall(archive_html)
	print "###############################################RETRIEVED THE ARCHIVE LIST"

	#Deleting items in case boxee was never closed, to prevent duplicates in 'items'
	del items[:]

	#Check if there is a new show, if not get from cache, or else get from the web 
	try: 
		if archive_results[0] == config.GetValue("cache_latestshow"):
			print "###############################################READING FROM CACHE"
			GET_FROMCACHE()
			print "###############################################CACHE SUCCESFUL"
		else:
			print "###############################################MAKING NEW LIST FROM THE INTERWEBS"
			config.ResetAll()		
			
			for i, episode_number in enumerate(archive_results):
				if i == episodebatch:
					break #stuff
				else:
					GET_NEWEPISODES("http://blip.tv/players/episode/" + episode_number + "?skin=api", archive_thumbnails[i]) 

			config.SetValue("nextbatch", "2")
			config.SetValue("cache_latestshow", archive_results[0])
			print "###############################################WEB RETRIEVAL SUCCESFUL"
	except IndexError:
		mc.ShowDialogNotification("Can't retrieve archive list. Please try again later.")
	
	#Create the list with all the acquired shows in 'items' & Reveal the "More" button
	mc.GetWindow(14000).GetList(201).SetItems(items)
	mc.GetWindow(14000).GetControl(300).SetVisible(True) 

def GET_FROMCACHE():
	#For some reason I couldn't loop through config.GetValue("value{" + str(i) + "}", so I'll make it into a normal array first
	cache_label_str = config.Implode('<!>', "cache_label")
	cache_label_array = cache_label_str.split('<!>')
	cache_url_str = config.Implode('<!>', "cache_url")
	cache_url_array = cache_url_str.split('<!>')
	cache_desc_str = config.Implode('<!>', "cache_desc")
	cache_desc_array = cache_desc_str.split('<!>')
	cache_thumb_str = config.Implode('<!>', "cache_thumb")
	cache_thumb_array = cache_thumb_str.split('<!>')

	for i in range(len(cache_label_array)):
		item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
		item.SetLabel(cache_label_array[i])
		item.SetPath(cache_url_array[i])
		item.SetDescription(cache_desc_array[i])
		item.SetThumbnail(cache_thumb_array[i])
		item.SetProviderSource("blip.tv")
		item.SetAuthor("Sean 'Day[9]' Plott")
		items.append(item)
		

def GET_NEWEPISODES(link, thumbs):
	print "Opening... " + link
	episode_html = http.Get(link)
	ep_name = re.compile('<title>(.+?)</title>').findall(episode_html)
	ep_url = re.compile('<link type="video/x-m4v" href="(.+?)" />').findall(episode_html)
	ep_url_alternative = re.compile('<link type="video/x-flv" href="(.+?)" />').findall(episode_html)
	ep_desc = re.compile('<description mode="escaped" type="text/html">(.+?)</description>').findall(episode_html)
	ep_thumb = thumbs
	
	#Build new item 
	item = mc.ListItem( mc.ListItem.MEDIA_UNKNOWN )
	try:
		item.SetLabel(unescape(ep_name[0], {"&apos;": "'", "&quot;": '"', "&amp;lt;": "<"}))
		config.PushBackValue("cache_label", unescape(ep_name[0], {"&apos;": "'", "&quot;": '"', "&amp;lt;": "<"}))
	except IndexError:
		item.SetLabel("No title")
		config.PushBackValue("cache_label", "No Title")

	#Because his encoding is not really consistent I first try to get the HD stream if HD/SD is available. Otherwise pick the only m4v which is HD normally, or the source FLV... 
	try:
		item.SetPath(ep_url[1])
		config.PushBackValue("cache_url", ep_url[1])
		print "###FOUND ep_url[1]: " + ep_url[1] + " ###"
	except IndexError:
		try: 
			item.SetPath(ep_url[0])
			config.PushBackValue("cache_url", ep_url[0])
			print "###FOUND ep_url[0]: " + ep_url[0] + " ###"
		except IndexError:
			try: 
				item.SetPath(ep_url_alternative[0])
				config.PushBackValue("cache_url", ep_url_alternative[0])
				print "###FOUND ep_url_alternative[0]: " + ep_url_alternative[0] + " ###"
			except IndexError:
				mc.ShowDialogNotification("Error loading one or more videos")
				print "#######CANT LOAD CONTENT FOR: " + link
				config.PushBackValue("cache_url", "empty")

	try:
		item.SetDescription(unescape(ep_desc[0], {"&apos;": "'", "&quot;": '"', "&amp;lt;": "<"}))
		config.PushBackValue("cache_desc", unescape(ep_desc[0], {"&apos;": "'", "&quot;": '"', "&amp;lt;": "<"}))
	except IndexError:
		item.SetDescription("No description available")
		config.PushBackValue("cache_desc", "No description available")
	
	try:
		item.SetThumbnail("http://a.images.blip.tv/" + ep_thumb)
		config.PushBackValue("cache_thumb", "http://a.images.blip.tv/" + ep_thumb)
	except IndexError:
		item.SetThumbnail("http://a.blip.tv/skin/blipnew/placeholder_video.gif")
		config.PushBackValue("cache_thumb", "http://a.blip.tv/skin/blipnew/placeholder_video.gif")
	
	item.SetProviderSource("blip.tv")
	item.SetAuthor("Sean 'Day[9]' Plott")
	items.append(item)
		
def GET_MOREEPISODES():
	#Load more episodes from the day9tv archives
	mc.ShowDialogWait()

	nextbatch = config.GetValue("nextbatch")
	more_html = http.Get("http://blip.tv/day9tv/rss")
	enoughepisodes = 1
	
	more_results = re.compile('<blip:embedLookup>(.+?)</blip:embedLookup>').findall(more_html)
	more_results_thumbs = re.compile('<blip:thumbnail_src>(.+?)</blip:thumbnail_src>').findall(more_html)
	print "###############################################RETRIEVED RSS ... AGAIN (LOADING MORE EPISODES)!"

	try:
		if (int(nextbatch) - 1) * episodebatch >= len(more_results):
			enoughepisodes = 0
			mc.ShowDialogNotification("No more episodes available.")
		else:
			for i, more_episode_numbers in enumerate(more_results):
				if i < (int(nextbatch) - 1) * episodebatch:
					#skip episodes we already indexed
					pass 
				elif i == int(nextbatch) * episodebatch:
					#stop when we hit the next batch
					break
				else:
					GET_NEWEPISODES("http://blip.tv/players/episode/" + more_episode_numbers + "?skin=api", more_results_thumbs[i]) 
	except IndexError:
			mc.ShowDialogNotification("Can't retrieve archive list. Please try again later.")
	
	if enoughepisodes == 1:
		mc.GetWindow(14000).GetList(201).SetItems(items)
		mc.GetWindow(14000).GetControl(201).SetFocus()
		mc.GetWindow(14000).GetList(201).SetFocusedItem(episodebatch * int(nextbatch) - episodebatch)
		
		nextnextbatch = int(nextbatch) + 1
		config.SetValue("nextbatch", str(nextnextbatch))
		
		print "###############################################MORE EPISODES ARE LOADED SUCCESFULLY"

	mc.HideDialogWait()
	
def GET_LIVESTREAM():
	# Check if the Day9's Channel is Online or Offline
	live_html = http.Get("http://api.justin.tv/api/stream/list.json?channel=day9tv")
	current_viewers = re.compile('"channel_count"\:(.+?),"').findall(live_html)
	live_button = mc.GetWindow(14000).GetButton(103)

	try:
		live_button.SetLabel("Channel online! Click here to tune in [CR]with " + str(current_viewers[0]) + " other viewers!")
		mc.GetWindow(14000).GetControl(105).SetVisible(True)
		print "###############################################CHANNEL IS ONLINE"
	except IndexError:
		live_button.SetLabel("Day[9] Daily is offline. Live on [CR]7pm PST Sunday through Thursday")
		mc.GetWindow(14000).GetControl(105).SetVisible(False)
		print "###############################################CHANNEL IS OFFLINE"		