# Gametrailers Boxee Script
import mc

# Globals
default_image  = 'special://home/apps/gametrailers/skin/Boxee Skin NG/media/gt_logo_w.png'
config = mc.GetApp().GetLocalConfig()
buttons = range(9001,9015)
refresh = True

feeds = (
	'rss://www.gametrailers.com/gtbonusround_podcast.xml',
	'rss://www.gametrailers.com/gtiw_podcast.xml',
	'rss://www.gametrailers.com/gtpa_podcast.xml',
	'rss://www.gametrailers.com/gtrev_podcast.xml',
	'rss://www.gametrailers.com/gtprev_podcast.xml',
	'rss://www.gametrailers.com/gtint_podcast.xml',
	'rss://feeds.gametrailers.com/rssgenerate.php?s1=&favplats[xb360]=xb360&favplats[ps3]=ps3&favplats[pc]=pc&type[feature]=on&quality[hd]=on&orderby=newest&limit=20',
	'rss://www.gametrailers.com/gtps3_podcast.xml',
	'rss://www.gametrailers.com/gtwii_podcast.xml',
	'rss://www.gametrailers.com/gt360_podcast.xml',
	'rss://feeds.gametrailers.com/rss_ipod_gen.php?source=psp',
	'rss://feeds.gametrailers.com/rss_ipod_gen.php?source=ds',
	'rss://feeds.gametrailers.com/rssgenerate.php?game1id=6426&quality[hd]=on&orderby=newest&limit=20',
	'rss://www.gametrailers.com/rssgenerate.php?game1id=10944&vidformat[flv]=on&embed=on&quality[either]=on&orderby=newest&limit=20'
	)

# I could do a search function...
# http://feeds.gametrailers.com/rssgenerate.php?s1=halovidformat[flv]=on&vidformat[mov]=on&vidformat[wmv]=on&orderby=newest&limit=5
# Maybe I can parse out the pages with videos...
# This page has the index
# http://www.gametrailers.com/show/gametrailers-tv
# and points to pages like this...
# http://www.gametrailers.com/episode/gametrailers-tv/108

# Start the Gametrailers App
def start():
	# global refresh
	global refresh
	refresh = True
	current_id = int_or_zero(config.GetValue('current_id'))
	mc.LogInfo('DFROST: start: current_id [%s]' % (current_id))
	if current_id in buttons:
		switch_to(current_id)
	else:
		switch_to(buttons[0])

# Switch to a RSS feed(button_id,reload): Switch to the rss_feed of the button.
# If reload is False, only reload if the rss_feed is diffrent than current feed.
def switch_to(button_id):
	global refresh
	current_id = int_or_zero(config.GetValue('current_id'))		
	mc.LogInfo('DFROST: switch from [%s] to [%s]' % (current_id, button_id))
	
	if (refresh or (button_id != current_id)):
		mc.ShowDialogWait()
		highlight(button_id)
		mc.GetWindow(14000).GetList(100).SetContentURL(feeds[buttons.index(button_id)])
		
	# For some shows replace the default thumbnail (not yet working)
	# if button_id == 9014:
	#	set_thumb('http://a1.phobos.apple.com/us/r30/Podcasts/f0/31/a1/ps.ldmekqjq.170x170-75.jpg')
		
	config.SetValue('current_id', '%s' % button_id)
	mc.HideDialogWait()	
	refresh = False

# Highlight one of the feeds
def highlight(button_id):
	mc.LogInfo('DFROST: highlight: %s' % button_id)
	for hl_button in buttons:
		if hl_button == button_id:
			mc.GetWindow(14000).GetControl(button_id).SetFocus()
			mc.GetWindow(14000).GetControl(hl_button + 100).SetVisible(True)
		else:
			mc.GetWindow(14000).GetControl(hl_button + 100).SetVisible(False)

# Convert to integer but return zero on exception
def int_or_zero(s):
	try:
		i = int(s)
		return i
	except:
		return 0

# Replace the thubmnail of an RSS feed video clip
# This function does not work. Thumb just don't update
# and the items returned seem to be cached. I can do a
# Refresh() and that seems to fix the list but that also
# seems to hang the Boxee interface for too long to be right.
def set_thumb(image):
	mc.LogInfo('DFROST: SET EPIC THUMB %s' % image)
	list  = mc.GetWindow(14000).GetList(100)
	items = list.GetItems()
	for item in items:
		label = item.GetLabel()
		mc.LogInfo('DFROST: GOT LABEL %s' % label)
		item.SetThumbnail(image)
		newthumb = item.GetThumbnail()
		mc.LogInfo('DFROST: GOT THUMB %s' % newthumb)
	