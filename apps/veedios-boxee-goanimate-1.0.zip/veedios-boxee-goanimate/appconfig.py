project = "goanimate"
director = "Go!Animate"
publisher = "Go!Animate"
channel = "boxee"