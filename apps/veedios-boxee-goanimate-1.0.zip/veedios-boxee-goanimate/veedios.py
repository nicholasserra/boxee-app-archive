"""veedios.py: Used to communicate with the Brilaps veedios.com web service."""

__author__ = "Brilaps, LLC"
__email__ = "code@brilaps.com"
__copyright__ = "Copyright 2011, Brilaps, LLC"


import mc
import urllib2
import urllib
import simplejson
from datetime import datetime, timedelta
from time import strptime, time
import unicodedata
import appconfig
from uuid import uuid1

class Fetcher:

    def __init__(self):        
        self.app_base_url = "http://apps.veedios.com/app/"
        self.pageSize = 10
        self.maintenanceWindowId = 14099
        self.pages = [] #array of pagination dict
        self.config = mc.GetApp().GetLocalConfig()
        self.fetch_categories()
        self.anonymous_identifier = self.get_anonymous_identifier()      
        
    def get_anonymous_identifier(self):
        uid = self.config.GetValue("anonynmous_unique_identifier")
        if uid is None or len(uid) == 0:
            uid = uuid1().__str__()
            self.config.SetValue("anonynmous_unique_identifier", uid)
        return uid
    
    
    def call_server(self, url):
        try:
            json = urllib2.urlopen(url)   
            resp = simplejson.load(json)
            self.check_status(resp)
            return resp
        except urllib2.URLError, e:
            if "code" in e:
                mc.LogInfo("@@@@@@@ Veedios: Call Server Error: %d" % e.code)
            self.push_maintenance_page("")
        except:  
            self.push_maintenance_page("")         
    
    def push_maintenance_page(self, message):
        params = mc.Parameters()
        params["message"] = message
        mc.GetApp().ActivateWindow(self.maintenanceWindowId, params)
        
    def check_status(self, serverResponse):
        if "status" in serverResponse:
            status = serverResponse["status"]
        
            #Verify system and app are available (system overrides app)
            if (status["system"]["code"] != 0):
                message = status["system"]["message"]
                self.push_maintenance_page(message)
            elif ("app" in status and status["app"]["code"] != 0):
                message = status["app"]["message"]
                self.push_maintenance_page(message)
            else:
                return True

    def fetch_categories(self):
        try:
            updatedelta = timedelta(minutes=1440)
            #get cache string  {'last_cached': someepoc, 'cache': '.....'}
            cachedCategoryJSON = self.config.GetValue("categoriesJSON")
            if cachedCategoryJSON is not None and len(cachedCategoryJSON) > 0:
                cacheobj = simplejson.loads(cachedCategoryJSON)
                #convert the cacheobe[lastcached] to datetime
                if 'last_cached' in cacheobj and timedelta(seconds=time() - cacheobj['last_cached']) < updatedelta:
                    return cacheobj['response']
                            
            resp = self.call_server(self.app_base_url + appconfig.project + "/categories/")
            cacheobj = {}
            cacheobj['last_cached'] = time()
            cacheobj['response'] = resp
            self.config.SetValue("categoriesJSON", simplejson.dumps(cacheobj)) #Cache the category response
            mc.LogError(simplejson.dumps(cacheobj))
            return cacheobj['response']
        except Exception, e:
            self.config.SetValue("categoriesJSON", "")
            self.push_maintenance_page("")

    def fetch_tags(self):
        resp = self.call_server(self.app_base_url + appconfig.project + "/tags/")

        return resp["tags"]

    def fetch_feeditems(self, feedKey, start, pageSize=None):
        if (pageSize == None):
            pageSize = self.pageSize

        try:
            params = urllib.urlencode({'key': feedKey, 'start': str(start), 'pagesize': str(pageSize)})
            resp = self.call_server(self.app_base_url + appconfig.project + "/?%s" % params)

            pagination = {}
            pagination = resp['pagination']
            self.pages.append(pagination)
            self.resp = {}
            self.resp = resp["entries"]

            return resp
        except:
            return False

    def fetch_search_results(self, searchString, start, pageSize=None):
        if (pageSize == None):
            pageSize = self.pageSize

        try:
            params = urllib.urlencode({'s': searchString, 'start': str(start), 'pagesize': str(pageSize)})
            resp = self.call_server(self.app_base_url + appconfig.project + "/search/?%s" % params)

            pagination = {}
            pagination = resp['results']['feedentryresultspagination']
            self.pages.append(pagination)
            self.resp = {}
            self.resp = resp['results']

            return resp['results']
        except:
            return False

    def feed_entries_to_listitems(self, entries, isSearch=False):
        if len(entries) > 0:
            listitems = mc.ListItems()

            for entry in entries:
                if isSearch == False:
                    entryExtras = entry["extras"]
                else:
                    entryJSON = simplejson.loads(entry["feedentry"])
                    entryExtras = entryJSON["extras"]

                item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_CLIP)

                if 'title' in entryExtras:
                    item.SetLabel(str(self.strip_accents(entryExtras['title'])))

                if 'summary' in entryExtras:
                    item.SetDescription(str(self.strip_accents(entryExtras['summary'])))

                if 'thumbnail' in entryExtras:
                    item.SetThumbnail(str(entryExtras['thumbnail']))

                if 'media_path_alt' in entryExtras and len(entryExtras['media_path_alt']) > 0:
                    item.SetPath(str(entryExtras['media_path_alt']))
                elif 'media_path' in entryExtras:
                    item.SetPath(str(entryExtras['media_path']))

                if 'updated' in entryExtras:
                    parsedDate = datetime(*strptime(str(entryExtras['updated'][0:19]), "%Y-%m-%dT%H:%M:%S")[0:5])
                    y = int(parsedDate.strftime("%Y"))
                    m = int(parsedDate.strftime("%m"))
                    d = int(parsedDate.strftime("%d"))
                    item.SetDate(y, m, d)

                item.SetDirector(appconfig.director)
                item.SetProviderSource(appconfig.publisher)

                if 'key' in entryExtras:
                    item.SetProperty("feedentrykey", str(entryExtras['key']))

                listitems.append(item)

            return listitems
        else:
            #Push back to the main screen with notification
            params = mc.Parameters()
            mc.GetApp().ActivateWindow(14000, params)
            mc.ShowDialogNotification("No results found!")

    def get_feed_keyinfo(self, categoryTitle, feedTitle=None):
        categoriesJSON = self.fetch_categories()
        
        if feedTitle == None:
            keys = categoriesJSON["categories"][categoryTitle]["feeds"].keys()
            if len(keys) > 0:
                return (keys[0], categoriesJSON["categories"][categoryTitle]["feeds"][keys[0]]["key"])
            else:
                return ('', '') #Prob will not reach here anyway
        else:
            return (feedTitle, categoriesJSON["categories"][categoryTitle]["feeds"][feedTitle]["key"])

    def get_response(self):
        return self.resp

    def get_pagination(self):
        temp = {}
        
        if len(self.pages) > 0:
            temp = self.pages[-1]
        else:
            temp
            
        return temp

    def next(self, key, isSearch=False):
        pagination = self.pages[-1]
        if isSearch == True:
            return self.fetch_search_results(key, pagination['nextstart'])
        else:
            return self.fetch_feeditems(key, pagination['nextstart'])

    def prev(self, key, isSearch=False):
        self.pages.pop() #pop the last
        pagination = self.pages.pop()
        if isSearch == True:
            return self.fetch_search_results(key, pagination['start'])
        else:
            return self.fetch_feeditems(key, pagination['start'])

    def fetch_category_listitems(self):
        itemList = mc.ListItems()
        categories = self.fetch_categories()['categories']

        for category in categories:
            item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
            item.SetLabel(str(category))
            itemList.append(item)

        return itemList

    def fetch_tag_listitems(self):
        itemList = mc.ListItems()
        tags = self.fetch_tags()

        for tag in tags:
            item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
            item.SetLabel(str(tag["tag"]))
            itemList.append(item)

        return itemList
             
    def get_feeds_for_category(self, category):
        categoriesJSON = self.fetch_categories()

        return categoriesJSON["categories"][category]

    def fetch_feed_listitems_for_category(self, category):
        itemList = mc.ListItems()
        feedsObject = self.get_feeds_for_category(category)
        feeds = sorted(feedsObject["feeds"])
        
        for feed in feeds:
            item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
            item.SetLabel(str(feed.replace("&amp;", "&")))
            itemList.append(item)
        
        return itemList

    def get_feed_url(self, categoryTitle, feedTitle):
        categoriesJSON = self.fetch_categories()
        feedKey = categoriesJSON["categories"][categoryTitle]["feeds"][feedTitle]["key"]

        if feedKey:
            try:
                resp = self.call_server(self.app_base_url + appconfig.project + "/?key=" + feedKey)
                
                return resp["feed"]["link"]
            except:
                return False

    def cache_window_params(self, windowKey, cacheObject):
        self.config.SetValue(windowKey, simplejson.dumps(cacheObject))
        
    def get_cached_window_params(self, windowKey):
        cachedParamStr = self.config.GetValue(str(windowKey))
        
        mc.LogError(cachedParamStr)
        
        if cachedParamStr is not None and len(cachedParamStr) > 0:
            try:
                cachedObject = simplejson.loads(cachedParamStr)
                return cachedObject
            except:
                return False
        else:
            return False
                
    def track(self, item):
        
        values = {'channel' : appconfig.channel,
                  'identifier' : self.anonymous_identifier,
                  'feedentrykey' :  item.GetProperty('feedentrykey')
                  }
    
        data = urllib.urlencode(values)
        req = urllib2.Request("%strack/" % self.app_base_url, data)
        response = urllib2.urlopen(req)
        rsp = response.read()
        # we don't need to no anything with the return

    def clear_window_params_cache(self, windowKey):
        self.config.Reset(str(windowKey))

    def strip_accents(self, string):
        return unicodedata.normalize('NFKD', unicode(string)).encode('ASCII', 'ignore')
        

