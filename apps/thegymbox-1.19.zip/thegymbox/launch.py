import mc
import time
from xml.dom import minidom
import threading
import xbmc
import urllib

########################################################################################################
################ Start control functions - used to keep xml files free of too much python ##############
########################################################################################################

################# Control 210 - List - Contains Top Categories ########################
def loader(fl=[]):
    if getConfig("resume"):
        if getConfig("list210"):
            setFocusedItem(210, getConfig("list210"))
        if getConfig("list320"):
            mc.GetActiveWindow().GetList(330).SetItems(fl[int(getConfig("list320"))-1])
            setFocusedItem(320, getConfig("list320"))
            if getConfig("list330"):
                setFocusedItem(330, getConfig("list330"))
        mc.GetActiveWindow().ClearStateStack(False)
    else:
        hideIt(330)
        hideIt(320)
        seeIt(325)
        moveFocus(210)
        
def click210():
    hideIt(330)
    hideIt(320)
    #mc.ShowDialogOk("Debug", "Click210()")
    mc.ShowDialogWait()
    mc.GetActiveWindow().ClearStateStack(False)
    fl=listInit()
    if len(fl)>0:
        hideIt(350)
        hideIt(325)
        seeIt(330)
        hideIt(500)
        seeIt(320)
        seeIt(310)
        setConfig("resume", "1")
        moveFocus(330)
    mc.HideDialogWait()
    return fl

#############Called when filter bar buttons 312 or 313 are clicked on onleft or right in list 330#########    
def filterLeft(flists):
    changeFilter(flists, 330, 320, -1)
    
def filterRight(flists):
    changeFilter(flists, 330, 320, 1)

#################Not currently used --- Called when buttons 211 or 212 are clicked in the main navigation panels#####################
def clickNav(direction=1):
    catList=mc.GetActiveWindow().GetList(210)
    listLength=catList.GetItems()
    listLength=(len(listLength)-1)
    
    itemNumber = catList.GetFocusedItem()
    nextItem=itemNumber+direction
    if nextItem < 0:
        catList.SetFocusedItem(listLength)
    elif nextItem > listLength:
        catList.SetFocusedItem(0)
    else:
        catList.SetFocusedItem(nextItem)

################# Control 350 - Button - displays/hides when you reach the top of list 330 with remote/up arrow ########################    
def up350():
    moveFocus(210)
    hideIt(350)
    seeIt(330)
    seeIt(320)
    seeIt(310)
    resetConfig("list320")
    resetConfig("list330")
    
        
def down350():
    hideIt(350)
    seeIt(330)
    seeIt(320)
    seeIt(310)
    moveFocus(330)

################# Control 330 - List - Contains filtered classes ########################    
def up330():
    hideIt(330)
    hideIt(320)
    hideIt(310)
    seeIt(350)
    moveFocus(350) 
       
################# Control 640 - Button - Cancel button in subscribe/link dialog######################## 
def click640():
    response=mc.ShowDialogConfirm("Cancel Registration", "Clicking cancel will stop the registration process.[CR][CR]Are you sure you want to cancel registration?", "No", "Yes")
    if response:
        hideIt(600)
        moveFocus(510)
        return True
    else: return False

def up510():
    moveFocus(210)
    hideIt(500)

######################################################################################################
###################App initialization Functions#######################################################
#####################################################################################################
def initialize(appVersion):
    player=mc.GetPlayer()
    player.Stop()
    mc.GetWindow(14001).ClearStateStack(False)
    resetConfig("session")
    resetConfig("resume")
    boxeeID = getConfig("id")
    setConfig("session", str(createSession(boxeeID)))
    if getConfig("session")=="default": resetConfig("id")
    resetConfig("list210")
    resetConfig("list320")
    resetConfig("list330")
    resetConfig("focused")

def createSession(id):
    http = mc.Http()
    data=http.Get("http://www.thegymbox.com/boxee_dev/xml/checkAuth.php?id=%s" % (id))
    response = http.GetHttpResponseCode()
    if response >= 400:
        mc.ShowDialogOk("Could Not Connect: " + str(response), "Could not connect to server.  Please check your Internet connection and try again?[CR][CR]Need help - support@discountworkouts.com.")
        #Should probably send a message to the server that an intializtion failed and handle any connection problems on the server end
        mc.GetActiveWindow().ClearStateStack(False)
        mc.CloseWindow()
        exit()    
    else:
        xmldoc = minidom.parseString(data)
        print "creating session - result:"
        print xmldoc
        results=readResult(xmldoc)
            
        if len(results["messages"]):
           handleMessages(results["messages"])
        
        if results["status"]=="error":
            retry=mc.ShowDialogConfirm("Error Launching App", "There was an error launching the app. Do you want to try again?", "Exit", "Retry")
            if retry:
                initialize()
            else:
                #Should probably send a message to the server that an intializtion failed and handle any connection problems on the server end
                mc.GetApp().Close()
        
        return results["session"]        

def readResult(doc):
    root=doc.firstChild
    elements = root.childNodes
    d={}
    messages=[]
    for node in elements:
        if node.nodeName=="messages":
            for n in node.childNodes:
                
                if n.nodeValue == None:
                    messages.append(getText(n))
        else:
            d[node.nodeName]=getText(node)
        d["messages"]=messages
    return d

def handleMessages(messages):
    for message in messages:
        mc.ShowDialogOk("Notice: ", str(message))    
###############################################################################################################################
############################ Main Application Functions #######################################################################
###############################################################################################################################

def regCode(method):
    if method != "newCode":
        message="Link Boxee to your Gymbox account.[CR]Login to your account at [CR][B]http:www.thegymbox.com[/B][CR]and enter the following code:"
        if method == "subscribe":
            message="To subscribe, visit[CR][B]http:www.thegymbox.com/boxee[/B][CR]and enter the following code:"
        mc.GetActiveWindow().GetLabel(610).SetLabel(str(message))
    
    URL="http://www.thegymbox.com/boxee_dev/xml/getRegCode.php?partner=%s" % "boxee"
    http = mc.Http()
    data=http.Get(URL)
    response = http.GetHttpResponseCode()
    if response < 400:
        xmldoc = minidom.parseString(data)
        results = xmldoc.getElementsByTagName('status')
        result = getText(results[0])
        
        if result=="success":
            regCode=getRegCode(xmldoc)
            boxeeID=getID(xmldoc)
            mc.GetActiveWindow().GetLabel(620).SetLabel(str(regCode))
            ##This is where we'll activate a dialog once Boxee tells us how.  For now, it just sets a hidden control as visible
            seeIt(600)
            moveFocus(640)
            return boxeeID
         ##############Need to handle errors in case RegCode is not returned
    else:
        mc.ShowDialogOk("Could Not Connect: " + str(response), "Could not connect to server.  Please check your Internet connection and try again?[CR][CR]Need help - support@discountworkouts.com.")
        return False
    
            
def checkStatus(boxeeID):
    mc.ShowDialogNotification("Checking code status...the dialog will close automatically when registration is complete.")
    http = mc.Http()
    data=http.Get("http://www.thegymbox.com/boxee_dev/xml/getRegResult.php?deviceID=%s" % (str(boxeeID)))
    response = http.GetHttpResponseCode()
    if response < 400:
        xmldoc = minidom.parseString(data)
        results = xmldoc.getElementsByTagName('status')
        result = getText(results[0])
        if result=="success":
            mc.GetApp().GetLocalConfig().SetValue("id", str(boxeeID))
            hideIt(600);
            hideIt(500);
            mc.ShowDialogOk("Congratulations!", "You have successfully registered this device.  The app will now restart.")
            return True
        else: return False
    else:
        mc.ShowDialogOk("Could Not Connect: " + str(response), "There was an error connecting to the server.  Check your internet connection and try again.")
        return True    

def restartApp():
    mc.CloseWindow()
    mc.ActivateWindow(14000)
    
def cancelReg():
    hideIt(600)
    mc.ShowDialogOk("Time is up!", "The maximum time for registration has passed.  Click 'subscribe' or 'link' to try again.")       
    moveFocus(510)
    
def listInit(focusedFilter=1):
    newReleases=0 #time.time()-(2*7*24*60*60) #now - 2 weeks
    
    mainList=mc.GetActiveWindow().GetList(210)
    itemNumber = mainList.GetFocusedItem()
    item = mainList.GetItem(itemNumber)
    filteredClassLists=[]
    boxeeID=mc.GetApp().GetLocalConfig().GetValue("id")
    sessionID=mc.GetApp().GetLocalConfig().GetValue("session")
    hideIt(330)
    hideIt(320)
    if item.GetPath() != "":
        url=item.GetPath()+"&boxeeID="+boxeeID+"&sessionID="+sessionID
        numItems=countItems(url)
        if numItems<1:
            mc.ShowDialogOk("Sorry!", "This class categories is currently empty. Please try a different category")
            return
        else:
            mc.GetActiveWindow().GetList(330).SetContentURL(url)
            classItems=[]
            i=0
            while len(classItems)<numItems:
                classItems=mc.GetActiveWindow().GetList(330).GetItems()
                i+=1
    if item.GetLabel()=="access":
        showDialogSubscribe()
    elif item.GetLabel()=="account":
        pass
    else:
        URL="http://www.thegymbox.com/boxee_dev/xml/categoriesauth.php?id=%s&session=%s" % (boxeeID, sessionID)
        http = mc.Http()
        data=http.Get(URL)
        response = http.GetHttpResponseCode()
        xmldoc = minidom.parseString(data)
        items = xmldoc.getElementsByTagName('item')
        filters = items[itemNumber].getElementsByTagName('filter')
        items = mc.ListItems()
        
        sort = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        sort.SetLabel('Sort By:')
        sort.SetPath('')
        items.append(sort)
        
        empty = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
        empty.SetLabel('')
        empty.SetPath('')
        
        if filters.length==0:
            mc.ShowDialogOk("Error: ", "This category has no classes")
            items = mc.ListItems()
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel("No Classes Available")
            item.SetPath("")
            items.append(item)
            items.append(empty)
        else:
            for f in filters:
                item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
                item.SetLabel(str(f.getAttribute("name")))
                item.SetPath("")
                
                tempClassList=mc.ListItems()
                if f.getAttribute("params")=="all":
                    filteredClassLists.append(classItems)
                    items.append(item)
                if f.getAttribute("params")=="new":
                    for classItem in classItems:
                        rd=int(classItem.GetProperty("release"))
                        if rd>newReleases:
                            tempClassList.append(classItem)
                    if len(tempClassList)>0:
                        filteredClassLists.append(tempClassList)
                        items.append(item)
                        if checkConfig("resume", 0): focusedFilter=len(items)-1
                else:
                    for classItem in classItems:
                        if item.GetLabel()==classItem.GetProperty("level") or item.GetLabel()==classItem.GetProperty("instructor"):
                            tempClassList.append(classItem)
                    if len(tempClassList)>0:
                        filteredClassLists.append(tempClassList)
                        items.append(item)
        setConfig("resume", "1")
        setConfig("list210", str(itemNumber))
        setConfig("list320", str(focusedFilter))
        items.append(empty)
        mc.GetActiveWindow().ClearStateStack()
        mc.GetActiveWindow().GetList(320).SetItems(items)
        mc.GetActiveWindow().GetList(320).SetFocusedItem(focusedFilter)
        mc.GetActiveWindow().GetList(330).SetItems(filteredClassLists[focusedFilter-1])
        
        seeIt(330)
        seeIt(320)
    return filteredClassLists

def changeFilter(fl, activeControl, targetControl, direction):
    mainList=mc.GetActiveWindow().GetList(targetControl)
    listLength=mc.GetActiveWindow().GetList(targetControl).GetItems()
    listLength=len(listLength)
    
    itemNumber = mainList.GetFocusedItem()
    nextItem=itemNumber+direction
    if nextItem != 0 and nextItem != listLength-1:
        try:
            mainList.SetFocusedItem(nextItem)
            setConfig("list320", str(nextItem))
            activeList=mc.GetActiveWindow().GetList(activeControl)
            activeList.SetItems(fl[nextItem-1])
            
        except Exception, e:
            mc.ShowDialogOk("Exception:", str(e))
            mainList.SetFocusedItem(0)
    else:
        return 0
 
#######################################################################################################################
################################# Utilities & Code to make Boxee Behave ##############################################
######################################################################################################################                        
def getText(node):
    text=" ".join(t.nodeValue for t in node.childNodes if t.nodeType == t.TEXT_NODE)
    return text

def getRegCode(doc):
    node=doc.getElementsByTagName('regCode')
    regCode=getText(node[0])
    return regCode

def getID(doc):
    node=doc.getElementsByTagName('boxeeID')
    ID=getText(node[0])
    return ID
    
def getNode(doc, tag):
    node=doc.getElementsByTagName(tag)
    return node              

def isInt(string):
    try:
        num = int(string)
        return num
    except ValueError:
        mc.ShowDialogOk("Not an int", "sorry")
        num=0
        return num

def countItems(feed):
    count=0
    if "http" in feed:
        http = mc.Http()
        data=http.Get(feed)
        response = http.GetHttpResponseCode()
        xmldoc = minidom.parseString(data)
        items = xmldoc.getElementsByTagName('item')
        count=len(items)
    return count

def setConfig(key, val):
    config = mc.GetApp().GetLocalConfig()
    config.SetValue(str(key), str(val))

def resetConfig(key):
    config = mc.GetApp().GetLocalConfig()
    config.Reset(str(key))
  
def getConfig(key):
    config = mc.GetApp().GetLocalConfig()
    val=config.GetValue(str(key))
    return val

def checkConfig(key, val):
    result=False
    config = mc.GetApp().GetLocalConfig()
    if config.GetValue(str(key))==str(val): result=True
    return result
        
def getFocused(control):
    focused=mc.GetActiveWindow().GetList(control).GetFocusedItem()
    return focused

def setFocusedItem(control, position):
    mc.GetActiveWindow().GetList(control).SetFocusedItem(int(position))
    
def getFocusedItem(control, number):
    item=mc.GetActiveWindow().GetList(control).GetItem(number)
    return item

def moveFocus(targetControl):
    mc.GetActiveWindow().GetControl(targetControl).SetFocus()

def seeIt(targetControl):
    target = mc.GetActiveWindow().GetControl(targetControl).SetVisible(True)
    
def hideIt(targetControl):
    target = mc.GetActiveWindow().GetControl(targetControl).SetVisible(False)
    
def controlIsVisible(control):
    cont=mc.GetActiveWindow().GetControl(control)
    return cont.IsVisible()

def showDialogSubscribe():
    seeIt(500)
    moveFocus(510)

def connectionError(response = 0):
    mc.ShowDialogOk("Could Not Connect: " + str(response), "Could not connect to server.  Check your internet connection and try again.")
    return False
           
def play_preview(item):
    if item.GetLabel() != "Press Up to Change Categories":
        setConfig("list330", str(getFocused(330)))
        pt = _play_in_thread(item)
        pt.start()

class _play_in_thread(threading.Thread):
# Define class vars. #
    def __init__ (self, item):
        threading.Thread.__init__(self)
        self.item = item
        self.player = mc.GetPlayer()
    	
    # Run() method required for Thread. #
    def run(self):
    	# Stop anything that is currently playing, wait for it to stop. #
        while self.player.IsPlaying():
            self.player.Stop()
    	
        # Now start playing. #
        self.player.Play(self.item)
        
        while not self.player.IsPlaying():
            time.sleep(1)

        if self.item.GetProperty("preview")=="1":
            mc.ShowDialogNotification("Playing 2 minute preview.  Click \"full access\" to view the entire class")	
       	    while self.player.IsPlaying():
                if int(self.player.GetTime()) > 120:
                    self.player.Stop()
                else:
                    time.sleep(1)
                    
class BackgroundTimer(threading.Thread):
    def __init__ (self, boxeeID):
        super(BackgroundTimer, self).__init__()
        self._stop = threading.Event()
        self.boxeeID = boxeeID
        self.retry = 1
        
    def stop (self):
        self._stop.set()

    def stopped (self):
        return self._stop.isSet()   
    
    def run(self):
      while not self._stop.isSet():
        # Keeps screen from going to sleep. #
        xbmc.executehttpapi("SendKey(61728)")
        if self.retry>120:
            self.stop()
            cancelReg()
        self.retry +=1
        time.sleep(15)
        finished = checkStatus(self.boxeeID)
        if finished: self.stop()
      restartApp()
        