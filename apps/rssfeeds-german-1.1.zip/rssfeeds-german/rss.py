# coding: UTF-8
import mc, sys, os, cgi, urllib, urllib2, time, re

# GET
def _get(id):
	config = mc.GetApp().GetLocalConfig()
	return config.GetValue(id)

# SET
def _set(id, val):
	config = mc.GetApp().GetLocalConfig()
	
	if val == False:
		config.Reset(id)
	else:
		config.SetValue(id, str(val))
	
def launch(id, params):
	p = mc.Parameters()
	
	if (params != False):
		for i in params: 
			p[i] = params[i]
			
	mc.GetApp().ActivateWindow(id, p)
	
# Post / Get
def call(url, params):
	mc.ShowDialogWait()
	enc = urllib.urlencode(params)
	rsp = mc.Http().Get(url + '?' + enc)
	mc.HideDialogWait()
	return rsp

def quickLaunch(id):
	mc.GetApp().ActivateWindow(id, mc.Parameters())
	
def subscribe_btn_click():
	params = mc.GetApp().GetLaunchedWindowParameters()
	btn = mc.GetActiveWindow().GetToggleButton(8002)
	
	if not _get('feed_subscribed'):
		subscribe_toggle(params['path'], True)
		btn.SetSelected(True)
		mc.ShowDialogNotification("Favorit hinzugefügt", "icons/icon_star.png")
	else:
		subscribe_toggle(params['path'], False)
		btn.SetSelected(False)
		mc.ShowDialogNotification("Favorit entfernt", "icons/icon_star.png")
		
	
def subscribe_toggle(url, subscribe):
	if subscribe == True:
		s = '1'
		_set('feed_subscribed', 1)
	else:
		s = '0'
		_set('feed_subscribed', False)
		
	_set('last_feed_refresh', False)
	
	return call('http://www.boxee.tv/rssapi/subscribe', { 'url': url, 'subscribe': s })
	
def directory_search():
	search = mc.ShowDialogKeyboard("Suche nach Videocasts", "", False)
	_set('dir_cur_label', 'DLinkSearch')
	_set('dir_search', search)
	directory_paginate()
	_set('searching', search)
	_set('category', False)
	
def directory_click():
	win  = mc.GetActiveWindow()
	list = win.GetList(2000)
	
	for i in list.GetItems():
		i.SetProperty('selected', '')
		
	item = list.GetItem(list.GetFocusedItem())
	item.SetProperty('selected', 'true')
	_set('dir_cur_label', item.GetLabel())
	_set('category', item.GetLabel())
	_set('dir_search', '')
	show_directory(item)
	
def directory_feed_click():
	_set('searching', False)
	list = mc.GetActiveWindow().GetList(2001)
	item = list.GetItem(list.GetFocusedItem())
	go_to_page('feed', item)
	
def show_directory(item):
	_set('searching', False)
	list = mc.GetActiveWindow().GetList(2001)
	list.SetContentURL(item.GetPath())
	list.SetFocus()
	
def directory_paginate():
	if not _get('loading'):
		list = mc.GetActiveWindow().GetList(2001)
		items = mc.ListItems()
			
		params = {
			'type': _get('dir_cur_label'),
			'search': _get('dir_search')
		}
	
		_set('loading', True)
		result = call('http://boxee.dlink.de/php/rss_xml.php', params)
	
		rss_items = re.compile("<item>((.|\s)*?)<\/item>").findall(result)

		for i in rss_items:
			title = re.compile("<title><!\[CDATA\[(.*?)\]\]><\/title>").findall(i[0])[0]
			desc  = re.compile("<description><!\[CDATA\[(.*?)\]\]><\/description>").findall(i[0])[0]
			thumb = re.compile("<boxee:image>(.*?)<\/boxee:image>").findall(i[0])[0]
		
			item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
			item.SetLabel(title)
			item.SetThumbnail(desc)
			item.SetPath(thumb)
		
			items.append(item)
		
		list.SetItems(items)
		list.SetFocus()
		
		_set('loading', False)
	
def on_directory_load():
	items = mc.ListItems()
	
	directory = ['Alle', 'Aktiv leben', 'Auto und Verkehr', 'Blogs', 'Comedy', 'Ernährung', 'Erziehung', 'Familie', 'Filme und Fernsehen', 'Gesundheit', 'Internationales', 'Kinder', 'Kultur', 'Kunst und Design', 'Lernstoff', 'Linux und freie Software', 'Lokales', 'Mac', 'Musik', 'Nachrichten', 'Öffentliche Sendeanstalten', 'Politik', 'Regierung', 'Reisen', 'Religion und Spirituelles', 'Sexualität', 'Sport', 'Technologie', 'Tiersendungen', 'Umwelt', 'Videospiele', 'Wirtschaft', 'Wissenschaft', 'Zeichentrick und Animation']
	
	for i in directory:
		item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
		item.SetLabel(i)
		item.SetPath("rss://boxee.dlink.de/php/rss_xml.php?type=%s" % urllib.quote(i))
			
		items.append(item)
		
	list = mc.GetActiveWindow().GetList(2000)
	list.SetItems(items)
	list.SetFocusedItem(0)
	
	directory_click()
	
	
def feed_list_click():
	win  = mc.GetActiveWindow()
	list = win.GetList(2000)
	
	item = list.GetItem(list.GetFocusedItem())
	item.SetProperty('subscribed', '1')
	
	go_to_page('feed', item)

def on_feed_load(params):
	list = mc.GetActiveWindow().GetList(2000)
	
	mc.ShowDialogWait()
	items = mc.GetDirectory(params['path'])
	list.SetItems(items)
	mc.HideDialogWait()

	if len(items) == 0:
		response = mc.ShowDialogConfirm(params['title'] + " verursachte einen Fehler", "Es scheint ein Problem mit dem " + params['title'] + " RSS feed zu geben. Wieder zum Gesamtverzeichnis?", "No", "Yes")
		if response:
			mc.CloseWindow()

	btn = mc.GetActiveWindow().GetToggleButton(8002)
	
	if params['subscribed'] == '1':	
		_set('feed_subscribed', 1)
		btn.SetSelected(True)
	else:
		_set('feed_subscribed', False)
		btn.SetSelected(False)
	
def go_to_page(page, args):
	_set('ui_page_' + _get('cur_page'), False)
	_set('searching', False)
	
	if page == 'feed':
		_set('cur_page', 'feed')

		params = {
			"title":		args.GetLabel(),
			"thumbnail":	args.GetThumbnail(),
			"path":			args.GetPath(),
			"date":			args.GetDate(),
			"subscribed":   args.GetProperty('subscribed')
		}
			
		# on_feed_load
		launch(14001, params)
		
	else:
		_set('cur_page', 'browse')
		
		
	_set('ui_page_' + _get('cur_page'), True)

_set('disclaimer', 0)	
quickLaunch(14000)
