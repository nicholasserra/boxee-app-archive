boxee.apiMinVersion=7.0;
boxee.reloadOnPageChange = true;
boxee.setMode(boxee.KEYBOARD_MODE);
boxee.browserWidth = 960;
boxee.browserHeight = 540;

boxee.onPlay = function() {
	browser.keyPress(71);
}

boxee.onPause  = function() {
	browser.keyPress(74);
}


var BoxeeApi = {};

BoxeeApi.onUserInput = function(inputText, confirmed) {
    if (confirmed)
	    alert("user entered: "+inputText);
	  else
	    alert("user cancelled...");
}

BoxeeApi.getUserInput = function(inputText) {
    boxee.getTextInput(inputText, "BoxeeApi.onUserInput");
}