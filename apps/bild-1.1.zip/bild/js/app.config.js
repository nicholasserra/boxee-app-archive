var 
	CONFIG_LOADED = true,
	
	//set JSON_WRAPPER_BASEURL as an empty string
	//for disable json padding
	//JSON_WRAPPER_BASEURL = 'http://dev.meta-morph.de/bild11/json.php?feed=';
	JSON_WRAPPER_BASEURL = '';