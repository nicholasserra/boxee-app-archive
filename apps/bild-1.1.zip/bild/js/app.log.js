//little log helper
var LOG_ON_SCREEN = true;
var LOG = function() {
	//output to browser log
	var outputConsole = function(args) {
		for(var i = 0; i < args.length; i++) {
			console.log(args[i]);
		}
	};
	
	//output to div container
	var outputDiv = function(args) {
		$div.show();
		for(var i = 0; i < args.length; i++) {
			$span = $('<span></span>')
				.html('&gt; '+args[i])
				.css({
					display: 'block',
					padding: '5px 0'
				});
			$div.append($span);
		}
	};
	//prepare the div container.
	var $div = $('#console');
	$div.css({
		position: 'absolute',
		left: 50,
		bottom: 50,
		zIndex: 200,
		background: 'white',
		opacity: 0.8,
		color: 'black',
		padding: '10px',
		fontFamily: 'Courier New',
		fontSize: '12px',
		width: '350px',
		display: 'none',
		zIndex: 100
	});
	
	
	if(LOG_ON_SCREEN) {
		outputDiv(LOG.arguments);
	}
	else {
		outputConsole(LOG.arguments);
	}
};

LOG.clear = function() {
	$('#console').html('');
}