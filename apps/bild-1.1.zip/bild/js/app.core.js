mdb = false;
/*
 *	Small Helper Methods.
 *	Javascript isnt perfect
 */

var DEVICE_UNKNOWN = 0;
var DEVICE_BROWSER = 1;
var DEVICE_SAMSUNG = 2;

var SUB_DEVICE_UNKNOWN = 0;
var SUB_DEVICE_TV = 1;
var SUB_DEVICE_BD = 2;
var SUB_DEVICE_HT = 3;

String.prototype.ucfirst = function () {
    return this.substr(0,1).toUpperCase() + this.substr(1,this.length);
};

String.prototype.toClassName = function() {
	return this.toLowerCase().replace(/ /g, '_');
};

function strip_tags (input, allowed) {
    allowed = (((allowed || "") + "").toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join(''); // making sure the allowed arg is a string containing only tags in lowercase (<a><b><c>)
    var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,
        commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;
    return input.replace(commentsAndPhpTags, '').replace(tags, function ($0, $1) {
        return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';
    });
}

Array.prototype.drop = function(position) {
	for (var x = 0; x < this.length; ++x) {
		if (x >= position) {
			this[x] = this[x + 1];
		}
	} 
	this.pop();
};


/**
 *	The Core Application
 */
var App = {
	args: {},
	$b: {},
	focusObj: null,
	focusObjects: [],
	hijackKeyDownEvent: false,
	afterKeyDownEvent: false,
	globalReturnEvent: false,
	nDeviceType: DEVICE_UNKNOWN,
	nDeviceSubType: SUB_DEVICE_UNKNOWN,
	
	init: function(arguments) {
		var defaults = {selector: 'body', focusElementClass: 'canHaveFocus'};
		this.args = $.extend(defaults, arguments);
		this.args.focusElementSelector = '.'+this.args.focusElementClass;
		this.$b = $(this.args.selector);
		return this;
	},
	
	hasFocus: function(i) {
		this.focusObj = i;
	},
	
	getFocusObject: function() {
		return this.focusObjects[this.focusObj];
	},
	
	get: function() {
		return this.$b;
	},
	
	addPart: function(part) {
		var uid = this.focusObjects.length;
		part.args.uid = uid;
		this.focusObjects.push(part);
		return uid;
	},
	
	handleKeyDown: function(e) {
		this.clearAllTimeouts();
		if(typeof this.hijackKeyDownEvent == 'function') {
			var callback = this.hijackKeyDownEvent;
			this.hijackKeyDownEvent = false;
			callback(this, e);
		}
		else {			
			switch(e.keyCode) {
				case KEY_LEFT:
					this.left(true);
					break;
				case KEY_RIGHT:
					this.right(true);
					break;
				case KEY_UP:
					this.up(true);
					break;
				case KEY_DOWN:
					this.down(true);
					break;
				case KEY_ENTER:
					this.enter(true);
					break;
			}
		}
		if(typeof this.afterKeyDownEvent == 'function') {
			var callback2 = this.afterKeyDownEvent;
			this.afterKeyDownEvent = false;
			callback2(this, e);
		}
	},
	
	left: function(fromRemote) {
		if(typeof this.getFocusObject().handleLeft == 'function') {
			this.getFocusObject().handleLeft(fromRemote);
		}
		else {
			this.getFocusObject().trigger('beforeLeft', fromRemote);
			if(this.getFocusObject().args.hasSelectableItems) {
				item = this.getFocusObject().getFocusItem();
				if(item) {
					var previtem = this.getFocusObject().getPrevItem(item.uid());
					if(previtem) {
						previtem.focus();
						item.blur();
					}
				}
			}
			this.getFocusObject().trigger('afterLeft', fromRemote);
		}
	},
	
	right: function(fromRemote) {
		if(typeof this.getFocusObject().handleRight == 'function') {
			this.getFocusObject().handleRight(fromRemote);
		}
		else {
			this.getFocusObject().trigger('beforeRight', fromRemote);
			if(this.getFocusObject().args.hasSelectableItems) {
				item = this.getFocusObject().getFocusItem();
				if(item) {
					var nextitem = this.getFocusObject().getNextItem(item.uid());
					if(nextitem) {
						nextitem.focus();
						item.blur();
					}
				}
			}
			this.getFocusObject().trigger('afterRight', fromRemote);
		}
	},
	
	up: function(fromRemote) {
		if(typeof this.getFocusObject().handleUp == 'function') {
			this.getFocusObject().handleUp(fromRemote);
		}
		else {
			this.getFocusObject().blur();
			this.getFocusObject().trigger('up', fromRemote);
			this.getPrevFocusObject().focus();
		}
	},
	
	down: function(fromRemote) {
		if(typeof this.getFocusObject().handleDown == 'function') {
			this.getFocusObject().handleDown();
		}
		else {
			this.getFocusObject().blur();
			this.getFocusObject().trigger('down', fromRemote);
			this.getNextFocusObject().focus();
		}
	},
	
	enter: function(fromRemote) {
		if(typeof this.getFocusObject().handleEnter == 'function') {
			this.getFocusObject().handleEnter();
		}
		else {
			this.getFocusObject().trigger('enter', fromRemote);
		}
	},
	
	getNextFocusObject: function(key) {
		var fo, i;
		if(typeof key != 'undefined') {
			i = key;
		}
		else {
			i = this.getFocusObject().uid+1;	
		}
		if(i < this.focusObjects.length) {
			fo = this.focusObjects[i];
		}
		else {
			fo = this.focusObjects[0];
			i = 0;
		}
		if(i > 20) {
			return false;
		}
		if(this.isValidFocusObject(fo)) {
			return fo;
		}
		else {
			return this.getNextFocusObject(i+1);
		}
	},
	
	getPrevFocusObject: function(key) {
		var fo, i;
		if(typeof key != 'undefined') {
			i = key;	
		}
		else {
			i = this.getFocusObject().uid-1;
		}
		if(i < 0) {
			i = this.focusObjects.length-1;			
		}
		fo = this.focusObjects[i];
		if(this.isValidFocusObject(fo)) {
			return fo;
		}
		else {
			return this.getPrevFocusObject(i-1);
		}
	},
	
	isValidFocusObject: function(focusObject) {
		var $obj = focusObject.get();
		if(!$obj.hasClass(this.args.focusElementClass)) {
			return false;	
		}
		if($obj.css('display') == 'none') {
			return false;
		}
		return true;
	},
	
	setWrapClass: function(classname) {
		this.$b.addClass(classname);
	},
	removeWrapClass: function(classname) {
		this.$b.removeClass(classname);
	},
	
	getDateRegEx: function() {
		return /^([0-9]{4})-([0-9]{2})-([0-9]{2})[A-Z]{1}([0-9]{2}):([0-9]{2}):([0-9]{2})$/;
	},
	getDateObject: function(strtime) {
		var reg = this.getDateRegEx();
		var parts = reg.exec(strtime);
		//var date = new Date(parts[1]+'-'+parts[2]+'-'+parts[3]+' '+parts[4]+':'+parts[5]+':'+parts[6]);
		var date = new Date();
		date.setDate(parts[3]);
		date.setMonth(parts[2]-1);
		date.setYear(parts[1]);
		date.setHours(parts[4]);
		date.setMinutes(parts[5]);
		date.setSeconds(parts[6]);
		return date;
	},
	getDateNice: function(strtime) {
		var date = this.getDateObject(strtime);
		var Wochentag = new Array("Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag");
		var Monat = new Array("Januar", "Februar", "M&auml;rz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember");
		var d = date.getDate();
		var t = Wochentag[date.getDay()];
		var m = Monat[date.getMonth()];
		var y = date.getYear();
		if (y < 999) y += 1900;
		return t+', '+d+'. '+m+' '+y;
	},
	getTimeNice: function(strtime) {
		var date = this.getDateObject(strtime);
		var t = date.getHours();
		if(t < 10) {
			t = '0'+t;
		}
		var m = date.getMinutes();
		if(m < 10) {
			m = '0'+m;
		}
		return t+':'+m;
	},	
	clearAllTimeouts: function() {
		if(this.focusObjects.length >= 0) {
			for(var i = 0; i < this.focusObjects.length; i++) {
				this.focusObjects[i].clearAllTimeouts();
			}
		}
	},
	identify: function() {
	  if (typeof TEST_DEVICE != 'undefined') {		
		this.nDeviceType = TEST_DEVICE; 
	  }
		  
	  if (this.nDeviceType == DEVICE_UNKNOWN) {
		//SAMSUNG
		var location 	= window.location.search;
		var product 	= /^.*product=(\d).*$/;
		//
			
		if ( product.test(location) ) {
			//
			switch(location.replace(product, "$1")) {
				case '0' : 	this.nDeviceType = DEVICE_SAMSUNG; this.nDeviceSubType = SUB_DEVICE_TV; break;
				case '2' : 	this.nDeviceType = DEVICE_SAMSUNG; this.nDeviceSubType = SUB_DEVICE_BD; break;
				default  :	this.nDeviceType = DEVICE_SAMSUNG; this.nDeviceSubType = SUB_DEVICE_HT; break;				}
			//
		}
		else {
			this.nDeviceType = DEVICE_BROWSER;
		}
	  }
	  return this.nDeviceType;
	},			
	setHTML: function(elem, strHTML) {
	  switch (App.identify()) {
	  	case DEVICE_SAMSUNG:
	   	  widgetAPI.putInnerHTML(elem.get(0), strHTML);  		    		  
	      break;
	    default:
	      elem.html(strHTML);
	      break;
	  }
	}		
};

/*********** end of AppCore ***********/

/*
 *	Skeleton of an default Part
 */
//constructor
var AppPart = function(arguments) {
	var defaults = {
		//the unique identifier of this app part in an app
		uid: null,
		//name of the object
		name: 'Skeleton',
		//the parent app - used for focus
		App: {},
		//the html selector
		selector: '',
		//has the part selectable items
		hasSelectableItems: true,
		//the items
		items: [],
		//the selector referencing to the items inside the part
		itemContainerSelector: '.items',
		//function to create an item from the array this.args.items
		itemCreator: function(item) {},
		//the item getting the focus when part is getting focus
		itemOnFocusIndex: function() { return 0; },
		//holds the created items
		itemObjects: [],
		//is it possible for the part to get the focus
		canHaveFocus: true,
		//catch all other key events until this part is closed
		modal: false
	};
	this.timeouts = [];
	this.errors = [];
	this.data = {};
	this.itemObjects = [];
	this.args = $.extend(defaults, arguments);
	this.delayedEvent = false;
	return this;
};

//helper - 	call a callback if available
//			or call a callback in delay milliseconds
AppPart.prototype.trigger = function(action, delay) {
	if(typeof delay == 'number') {
		this.setTimeout(action, delay);
	}
	else {
		var callbackname = 'on'+action.ucfirst();
		if(typeof this.args[callbackname] == 'function') {
			this.args[callbackname](this, delay);
		}
	}
	return this;
};
//helper - log some information, related to this obj
AppPart.prototype.log = function() {
	LOG('['+this.args.name+']');
	for(var i = 0; i < arguments.length; i++) {
		LOG(arguments[i]);
	}
	LOG(' ');
	return this;
};
//helper - throw an error
AppPart.prototype.error = function(msg) {
	this.errors.push(msg);
	this.log('ERROR', msg);
	this.trigger('error');
	return this;
};
//helper - all about timeouts
AppPart.prototype.setTimeout = function(event, delay) {
	var that = this;
	//search for existing timeouts
	if(!this.hasTimeout(event)) {
		//if(this.args.name == 'Menu' && event == 'refresh') {
		//	console.log('ATTENTION ATTENTION: Set refresh timeout in ', delay);
		//}
		var timeout = setTimeout(function() {
			that.clearTimeout(event);
			that.trigger(event);
		}, delay);
		this.timeouts.push({
			event: event,
			delay: delay,
			timeout: timeout
		});
		//console.log(this.args.name, 'trigger', event, 'after', delay);
	}
	else {
		//console.log(this.args.name+' has already a timeout for '+event);
	}
	return this;
};
AppPart.prototype.hasTimeout = function(event) {
	var timeout_id = this.getTimeout(event);
	return (timeout_id >= 0);
};
AppPart.prototype.getTimeout = function(event) {
	if(this.timeouts.length > 0) {
		for(var i = 0; i < this.timeouts.length; i++) {
			if(this.timeouts[i].event == event) {
				return i;
			}
		}
	}
	return -1;
};
AppPart.prototype.clearTimeout = function(param) {
	//console.log(this.args.name, 'clearTimeout', param);
	var timeout_id = typeof param == 'string' ? this.getTimeout(param) : param;
	if(timeout_id >= 0) {
		clearTimeout(this.timeouts[timeout_id].timeout);
		this.timeouts.drop(timeout_id);
		return true;
	}
	return false;
};
AppPart.prototype.clearAllTimeouts = function() {
	//console.log(this.args.name, 'clear all timeouts');
	if(this.timeouts.length > 0) {
		for(var i = 0; i < this.timeouts.length; i++) {
			this.clearTimeout(i);
		}
	}
	this.trigger('clearAllTimeouts');
};

//bind the part to an app
AppPart.prototype.bind = function(App) {
	this.App = App;
	this.uid = this.App.addPart(this, false);
	this.trigger('bind');
	return this;
};

//Set Data used in this app
AppPart.prototype.setData = function(key, value) {
	this.data[key] = value;
	return this;
};

//create the html from items and set variables
AppPart.prototype.create = function(items) {
	this.$obj = $(this.args.selector);
	if(!this.$obj) {
		this.error('No Object with the Selector '+this.args.selector+' found.');
		return false;
	}
	if(!this.App) {
		this.error('This Part is not binded to an App.');
		return false;	
	}
	this.$items = $(this.args.itemContainerSelector);
	if(items && items.length > 0) {
		this.args.items = items;
		this.$items.html('');
	}
	this.trigger('beforeCreate');
	if(this.args.items.length > 0) {
		var part, itemarray = [], part_id;
		for(var i = 0; i < this.args.items.length; i++) {
			part = new AppPartItem({
				uid: i,
				id: 'part_'+this.uid+'_item_'+i,
				data: this.args.items[i],
				hasFocus: false,
				part: this
			});

			content = this.args.itemCreator(this.args.items[i], this);
			if (content) {
			  part.create(content);
			  this.$items.append(part.get());
			  itemarray.push(part);				
			}
		}
		this.itemObjects = itemarray;
	}
	this.$obj.data('obj', this);
	if(this.args.canHaveFocus) {
		this.$obj.addClass('canHaveFocus');
	}
	this.trigger('afterCreate');
	return this;	
};

//get the jquery object
AppPart.prototype.get = function() {
	return this.$obj;
};

//show the part in the view
AppPart.prototype.show = function(zIndex) {
	this.visible = true;
	this.$obj
		.css('z-index', zIndex)
		.show();
	this.trigger('show');
	return this;
};

//hide the part
AppPart.prototype.hide = function() {
	this.visible = false;
	if(!this.$obj) {
		//this.error('Part was not created.');
		return false;
	}
	this.$obj.hide();
	this.trigger('hide');
	return this;
};

AppPart.prototype.isVisible = function() {
	return this.visible;
};

//set the focus, maybe select an item and inform the app
AppPart.prototype.focus = function(itemnumber) {
	this.trigger('focus');
	if(!this.$obj) {
		this.error('Part was not created.');
		return false;
	}
	var i = itemnumber || this.args.itemOnFocusIndex(this);
	if(this.args.canHaveFocus) {
		this.$obj.addClass('focus');
	}
	if(this.args.hasSelectableItems && this.itemObjects.length > i) {
		this.itemObjects[i].focus();
	}
	this.App.hasFocus(this.uid);
	this.App.setWrapClass(this.args.name.toLowerCase());
	this.trigger('afterFocus');
	return this;
};

AppPart.prototype.blur = function() {
	this.trigger('beforeBlur');
	this.$obj.removeClass('focus');
	if(this.args.hasSelectableItems && this.getFocusItem()) {
		this.getFocusItem().blur().addBlur();
	}
	this.App.removeWrapClass(this.args.name.toLowerCase());
	this.trigger('blur');
	return this;
};

AppPart.prototype.getFocusItem = function() {
	for(var i = 0; i < this.itemObjects.length; i++) {
		if(this.itemObjects[i].hasFocus()) {
			return this.itemObjects[i];	
		}
	}
	return false;	
};

AppPart.prototype.getBlurItem = function() {
	for(var i = 0; i < this.itemObjects.length; i++) {
		if(this.itemObjects[i].hasBlur()) {
			return this.itemObjects[i];	
		}
	}
	return false;	
};

AppPart.prototype.getNextItem = function(i) {
	i+= 1;
	if(i >= this.itemObjects.length) {
		i = 0;
	}
	return this.itemObjects[i];
};

AppPart.prototype.getPrevItem = function(i) {
	i-= 1;
	if(i < 0) {
		i = this.itemObjects.length - 1;
	}
	return this.itemObjects[i];
};

/*********** end of AppPart ***********/

var AppPartItem = function(arguments) {
	var defaults = {
		part: {},
		uid: null,
		id: '',	
		data: {},
		$obj: {},
		hasFocus: false,
		blur: false
	};
	this.args = $.extend(defaults, arguments);
	return this;
};
AppPartItem.prototype.create = function(html) {
	this.args.$obj = $('<div></div>');
	//NO: this.args.$obj.replaceWith(html);
	this.args.$obj.html(html);
	//else this.args.$obj = $(html);
	this.args.$obj.attr('id', this.args.id);	
};
AppPartItem.prototype.uid = function() {
	return this.args.uid;	
};
AppPartItem.prototype.get = function() {
	return this.args.$obj;	
};
AppPartItem.prototype.focus = function() {
	this.args.hasFocus = true;
	this.get().find('>*').addClass('focus');
	var blurPart = this.args.part.getBlurItem();
	if(blurPart) {
		blurPart.unBlur();
	}
	return this;
};
AppPartItem.prototype.blur = function() {
	this.args.hasFocus = false;
	this.get().find('>*').removeClass('focus');
	return this;
};
AppPartItem.prototype.addBlur = function() {
	this.args.blur = true;
	this.get().find('>*').addClass('blur');
	return this;
}
AppPartItem.prototype.unBlur = function() {
	this.args.blur = false;
	this.get().find('>*').removeClass('blur');
	return this;
};
AppPartItem.prototype.hasFocus = function() {
	return this.args.hasFocus;	
};
AppPartItem.prototype.hasBlur = function() {
	return this.args.blur;	
};


/*********** end of AppPartItem ***********/