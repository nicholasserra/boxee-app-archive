var DataFeedManager = {
}
DataFeedManager.create = function(elemContent) {
  this.arrFeeds = new Array();
      
  var self = this;
      
  this.objDataFeed = new DataFeed({elemContent:elemContent});
  elemContent.bind('DataFeed:loaded', function (evt, param) {self.dfLoaded(evt, param)});
  elemContent.bind('DataFeed:timedout', function (evt, param) {self.dfTimedOut(evt, param)});
}

DataFeedManager.dropFeeds = function() {
  var nFeeds = this.arrFeeds.length;
  for (var nFeed=0; nFeed < nFeeds; nFeed++) {
	this.arrFeeds.pop();
  }  
}

DataFeedManager.loadFeed = function(elemFeed, strURL, bJSON) {	
  var objFeedData = new Object();
  objFeedData.elemFeed = elemFeed;
  objFeedData.strURL = strURL;
  objFeedData.bJSON = bJSON;      
  this.arrFeeds.push(objFeedData);    	  

  // load now
  if (this.arrFeeds.length == 1) {
	this.objDataFeed.load(objFeedData.elemFeed, objFeedData.strURL, objFeedData.bJSON);  
  }	  	  
}	

DataFeedManager.dumpFeeds = function() {
  var objFeedData = new Object();
	
  for (var nFeed=0; nFeed < this.arrFeeds.length; nFeed++) {
	objFeedData = this.arrFeeds[nFeed];
//	debug('feed '+nFeed+' : '+objFeedData.elemFeed.attr('class'));
  }
}

DataFeedManager.dfLoaded = function(evt, param) {
//  debug('dfLoaded:'+param.elemFeed.attr('class'));

  // remove curr feed
  this.arrFeeds.shift();
//  this.dumpFeeds();
  	  
  // do we have more feeds to load?
  if (this.arrFeeds.length) {
    var objFeedData = new Object();
	objFeedData = this.arrFeeds[0];
	this.objDataFeed.load(objFeedData.elemFeed, objFeedData.strURL, objFeedData.bJSON);  
  }	  
  // fire event
  param.elemFeed.trigger('DataFeedManager:loaded', { elemFeed:param.elemFeed, data:param.data });	  
}

DataFeedManager.dfTimedOut = function(evt, param) {
  // fire event
  param.elemFeed.trigger('DataFeedManager:timedout', { elemFeed:param.elemFeed });	  
}
