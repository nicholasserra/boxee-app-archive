/*jslint devel: true, browser: true, sloppy: true, maxerr: 50, indent: 4 */
if(typeof CONFIG_LOADED == 'undefined') {
	alert('CONFIGURATION WAS NOT LOADED NOR CREATED!');
}

/*
 *	FEHLERCODES
 *
 *	404 = Ajax Feed kann nicht geladen werden
 *	408	= Der Ladescreen hat sein Timeout erreicht
 *	A01 = MenÃ¼feed hat keine EintrÃ¤ge
 *	A02 = Der Newsticker hat keinen Inhalt
 *	A03	= Videofeed ist leer
 */

//
// !VARIABLES
////////////////////////////////////////////
var 
	BildApp,
	active_part = false,
	
	GLOBAL_AUTOPLAY_TIMEOUT = 30000,
	//GLOBAL_REFRESH = (1000*60*10)/2,
	//GLOBAL_REFRESH_RETRY = 5000,
	global_refresh_counter = 0,
	//GLOBAL_REFRESH = 3000,
	
	SLIDESHOW_INTERVAL = 5000,
	SINGLEIMAGE_INTERVAL = 30000,
	
	IMAGEGALLERY_FULLSCREEN_TIMEOUT = 5000,
	IMAGEGALLERY_NEXTIMAGE_TIMEOUT = 15000,

	VIDEOGALLERY_FULLSCREEN_TIMEOUT = 5000,
	VIDEOGALLERY_SLIDER_ENTERTIMEOUT = 2000,
	
	AFTER_FULLSCREEN_NEXT_SLIDE = 2000,
	ATEASER_HIDE_OVERLAYS = 5000,
	
	LOADING_FADEOUT = 500,
	LOADING_FADEOUT_OFFSET = 50,
	
	LOADING_TIMEOUT = 60000,
	
	ARTICLE_ALLOWED_HTML_TAGS = '<b><strong><p><br>',
		
	g_overlayBundesliga
;


//
// !URL/AJAX HELPER
////////////////////////////////////////////
var URL = {
	base: JSON_WRAPPER_BASEURL+'http://json.bild.de/servlet/kiosk/tv',
	frontpage: null,
	frontpageteaser: null,
	
	load: function(url, arg1, arg2) {	
		var url, callback, additional_settings = {};
		if(typeof arg1 == 'function') {
			callback = arg1;
		}
		if(typeof arg1 == 'object') {
			callback = arg2;
			additional_settings = arg1;
		}
		if(typeof this[url] == 'string') {
			url = this[url];
		}
		else {
			if(JSON_WRAPPER_BASEURL.length > 0 && url.indexOf('.bild.de') != -1) {
				url = JSON_WRAPPER_BASEURL+url;
			}
		}
				
	  	var self = this;
	  	switch (App.identify()) {
	  	  case DEVICE_SAMSUNG:
	  		Loading.start(url);
	  		
	      	if (this.XHRObj != null) this.XHRObj.destroy();
	    	
	    	this.XHRObj = new XMLHttpRequest(); 
	    	if (this.XHRObj) { 
	    	  this.XHRObj.onreadystatechange = function () { 
	    	    if (self.XHRObj.readyState == 4) { 
	    	      recieveData(); 
	    	    } 
	    	  }; 
	    	  this.XHRObj.open("GET", url, true); 
	    	  this.XHRObj.send(null); 
	    	} 

	    	recieveData = function () {
	    	  Loading.stop(url);
	    	  callback(jQuery.parseJSON(self.XHRObj.responseText));    		    		
	    	}
	  		break;
	  		
	  	  default:
	  		var defaults = {
	  			url: url,
	  			dataType: JSON_WRAPPER_BASEURL.length > 0 ? 'jsonp' : 'json',
	  			jsonp: 'jsonp_callback',
	  			beforeSend: function() {
	  				Loading.start(url);
	  			},
	  			error: function() {
	  				Error.show('Es ist ein Fehler aufgetreten (404)');
	  			},
	  			success: function(response) {
	  				callback(response);
	  			},
	  			complete: function() {
	  				Loading.stop(url);
	  			}
	  		};
	  		var args = $.extend(defaults, additional_settings);
	  		$.ajax(args);
	  		break;
	  	}
	}
};


//
// !WEBTREKK
////////////////////////////////////////////
var TRACK = {};
TRACK.domain = 'springer02.webtrekk.net';
TRACK.id = '707476814322924';
TRACK.version = 300;
TRACK.ceid = 'usr'+new Date().getTime();
TRACK.prepareDocpath = function(docpath) {
	if(docpath.substr(0, 6).toLowerCase() == '/bild/') {
		docpath = docpath.substr(6, docpath.length);
	}
	return docpath;
};
TRACK.getCategory = function(docpath) {
	docpath = TRACK.prepareDocpath(docpath);
	return docpath.substr(0, docpath.indexOf('/'));
};
TRACK.PageView = function(contentPosition, doctype, docpath) {
	var params = {
		contentId: encodeURIComponent(contentPosition)+'%2F'+encodeURIComponent(TRACK.prepareDocpath(docpath)),
		javascript: 1,
		screensize: SCREEN_WIDTH+'x'+SCREEN_HEIGHT,
		colors: 0,
		cookies: 0,
		timestamp: new Date().getTime(),
		referrer: 0,
		windowsize: SCREEN_WIDTH+'x'+SCREEN_HEIGHT,
		java: 0,
		devicename: DEVICE_NAME,
		pageURL: 0,
		doctype: encodeURIComponent(doctype),
		category: encodeURIComponent(TRACK.getCategory(docpath))
	};
	//var url = 'http://'+params.domain+'/'+params.id+'/wt?p='+params.version+','+params.contentId+','+params.javascript+','+params.screensize+','+params.colors+','+params.cookies+','+params.timestamp+','+params.referrer+','+params.windowsize+','+params.java+'&ceid='+params.ceid+'&cs1='+params.devicename+'&cp1='+params.pageURL+'&cp2='+params.doctype+'&cg1='+params.category;

	//console.log('TRACK PAGEVIEW', params);
	TRACK.send({
		p: TRACK.version+','+params.contentId+','+params.javascript+','+params.screensize+','+params.colors+','+params.cookies+','+params.timestamp+','+params.referrer+','+params.windowsize+','+params.java,
		cs1: DEVICE_NAME,
		cp1: encodeURIComponent(PAGE_URL),
		cp2: params.doctype,
		cg1: params.category,
		ceid: TRACK.ceid
	});
};
TRACK.Click = function(clicktype, doctype, docpath) {
	var params = {
		contentId: encodeURIComponent(clicktype)+'%2F'+encodeURIComponent(docpath),
		doctype: doctype,
		docpath: docpath
	};
	//var url = 'http://'+params.domain+'/'+params.id+'/wt?p='+params.version+'&ceid='+params.ceid+'&ct='+params.contentId;

	TRACK.send({
		p: TRACK.version,
		ct: params.contentId,
		ceid: TRACK.ceid
	});
};
TRACK.Video = function(action, videourl, videotitle, videosubtitle, videolength, videosize, videoautoplay, preroll, videoAdsString, firstpublicationdate, doctype, docpath) {
	var params = {
		mediaid: encodeURIComponent(DEVICE_NAME+'/'+docpath),
		action: action,
		videourl: videourl,
		videotitle: encodeURIComponent(videotitle),
		videosubtitle: encodeURIComponent(videosubtitle),
		videoposition: 0,
		videolength: videolength,
		videosize: videosize,
		videoAdsString: videoAdsString,
		sessionid: 0,
		timestamp: new Date().getTime(),
		withPreroll: preroll,
		firstpublicationdate: firstpublicationdate,
		videoautoplay: videoautoplay ? 'auto' : 'nutzer'
	};
	/*var url = 'http://'+params.domain+'/'+params.id+'/wt?p='+params.version
			+','+params.mediaid+'&mk='+params.action+'&mt1='+params.videoposition
			+'&mt2='+params.videolength+'&csid='+params.sessionid+'&x='+params.timestamp
			+'&ck1='+params.withPreroll+'&ck2='+params.videosize+'&ck3='+params.videourl
			+'&ck4='+params.videotitle+'&ck5='+params.videoAdsString+'&ck6='+params.firstpublicationdate
			+'&ck7='+params.videoautoplay+'&mg1='+params.videosubtitle;*/
	//console.log('TRACK VIDEO', params);
	TRACK.send({
		p: TRACK.version+',st',
		mi: params.mediaid,
		mk: params.action,
		mt1: params.videoposition,
		mt2: params.videolength,
		csid: TRACK.ceid,
		ceid: TRACK.ceid,
		x: params.timestamp,
		ck1: params.withPreroll,
		ck2: params.videosize,
		//ck3: params.firstpublicationdate,
		ck4: params.videotitle,
		//ck5: 0,
		//ck6: 0,
		ck7: params.videoautoplay,
		mg1: params.videosubtitle
	});
};
TRACK.send = function(params) {
	var url = 'http://'+TRACK.domain+'/'+TRACK.id+'/wt?';
	var x = -1;
	for(var key in params) {
		x++;
		value = params[key];
		if(value) {
			//value = 0;
			url = url+( x > 0 ? '&' : '' )+key+'='+value;
		}
	}
	//console.log(params, url);
	TRACK.get(url);
};
TRACK.get = function(url) {
	$('#track').html('<img src="'+url+'" width="1px" height="1px">');
};

//
// !LOADING
////////////////////////////////////////////
var Loading = new AppPart({
	name: 'Loading',
	selector: '#loading',
	hasSelectableItems: false,
	canHaveFocus: false,
	onBeforeCreate: function(that) {
		that.tasks = [];
		that.blockedNav = false;
		that.setData('styles', {
			width: SCREEN_WIDTH,
			height: SCREEN_HEIGHT,
			left: 0,
			top: 0
		});
	},
	onShow: function(that) {
		that.$obj.css(that.data.styles);
		that.$obj.find('#spinner').css({
			left: that.data.styles.width / 2,
			top: that.data.styles.height / 2
		});
		that.clearAllTimeouts();
		that.trigger('error', LOADING_TIMEOUT);
	},
	onHide: function(that) {
		that.clearAllTimeouts();
		that.trigger('unblockNavigation');
	/*	that.trigger('test', 2000);
	},
	onTest: function(that) {
		alert('Start Test');
		Main.checkNetworkCable();*/
	},
	onError: function(that) {
		that.clearAllTimeouts();
		that.tasks = [];
		Error.show('Leider ist ein Fehler aufgetreten (408)');
		Error.focus();
	},
	onBlockNavigation: function(that) {
		App.hijackKeyDownEvent = function(thatApp, event) {
			that.trigger('blockNavigation');
		}
	},
	onUnblockNavigation: function(that) {
		App.hijackKeyDownEvent = false;
	}
});
Loading.start = function(ident) {
	if(typeof ident == 'object') {
		//its an video, baby
		Video = ident;
		ident = Video.args.videourl;
		this.setData('styles', {
			width: Video.args.width,
			height: Video.args.height,
			left: Video.args.left,
			top: Video.args.top
		});
	}
	else {
		//default size is the hole screen
		this.setData('styles', {
			width: SCREEN_WIDTH,
			height: SCREEN_HEIGHT,
			left: 0,
			top: 0
		});
		this.trigger('blockNavigation');
		//App.globalReturnEvent = false;
	}
	if(this.getTask(ident) === false) {
		this.addTask(ident);
		this.show();
	}
},
Loading.stop = function(ident, bForceHide) {
	if(typeof ident == 'object') {
		//the video is loaded!
		Video = ident;
		ident = Video.args.videourl;
	}
	this.removeTask(ident);
	// mla 04.01.12 - allow force drop otherwise loader sometimes stays on with videos! 
	if (bForceHide) {
	  this.tasks.splice(0, this.tasks.length);
	}
	
	if(this.tasks.length == 0) {
		this.hide();
	}
},
Loading.getTask = function(ident) {
	if(this.tasks.length > 0) {
		for(var i = 0; i < this.tasks.length; i++) {
			if(this.tasks[i].ident == ident) {
				return i;
			}
		}
	}
	return false;
},
Loading.addTask = function(ident) {
	this.tasks.push({ident: ident});
},
Loading.removeTask = function(ident) {
	var taskid = this.getTask(ident);
	if(taskid >= 0) {
		this.tasks.drop(taskid);
		return true;
	}
	return false;
},
Loading.hide = function() {
	var that = this;
	if(that.isVisible()) {
		that.visible = false;
		setTimeout(function() {
			that.$obj.hide();
		}, LOADING_FADEOUT_OFFSET);
	}
	that.trigger('hide');
};


//
// !ERROR
////////////////////////////////////////////
var Error = new AppPart({
	name: 'Error',
	selector: '#error',
	hasSelectableItems: true,
	modal: true,
	itemContainerSelector: '#erroritems',
	itemCreator: function(item) {
		return '<span class="msg">'+item.msg+'</span>';
	},
	onClose: function(that) {
		that.hide();
		Menu.itemObjects[0].focus();
		Menu.trigger('enter');
	}
});
Error.handleUp = function() {
};
Error.handleDown = function() {
};
Error.handleLeft = function() {
};
Error.handleRight = function() {
};
Error.handleEnter = function() {
	this.trigger('close');
};
Error.show = function(msg) {
	this.visible = true;
	if(typeof active_part == 'object') {
		active_part.blur();
	}
	Error.bind(BildApp).create([{msg: msg}]).focus();
	Error.get().show();
	BildApp.clearAllTimeouts();
	BildApp.hijackKeyDownEvent = function() {
		Error.trigger('close');
	}
};

//send the user back to frontpage
//assign this function to App.globalReturnEvent
var backToFrontpage = function() {
	Menu.focus();
	// blur any selected menus
	for (var nMenu=0; nMenu < Menu.itemObjects.length; nMenu++) {
		Menu.itemObjects[nMenu].blur();			
	}	
	Menu.itemObjects[0].focus();
	Menu.trigger('enter');
};

//
// !MENU
////////////////////////////////////////////
var Menu = new AppPart({
	name: 'Menu',
	selector: '#menu',
	hasSelectableItems: true,
	itemContainerSelector: '#menuitems',
	itemCreator: function(item) {
		return '<span rel="'+item.url+'" type="'+item.type+'" class="item '+item.title.toClassName()+'">'+item.title+'</span>';
	},
	itemOnFocusIndex: function(that) {
		var blurItem = that.getBlurItem();
		if(blurItem) {
			return blurItem.args.uid;
		}
		else {
			return 0;
		}
	},
	onBeforeCreate: function(that) {
		that.active_item = {};
		//used for menuscrolling
		that.itemWidth = MENU_ITEMWIDTH;
		that.visibleMenuItems = 8;
		that.menuOffset = MENU_OFFSET_LEFT;
		that.menuInitOffset = that.menuOffset;
		that.menuStartOffset = that.menuInitOffset;
	},
	onAfterCreate: function(that) {
		that.menuScrollMax = that.itemObjects.length;
		that.menuMaxOffset = that.menuOffset - (that.itemWidth * (that.itemObjects.length - that.visibleMenuItems));
		//that.trigger('refresh', GLOBAL_REFRESH);
	},
	onBind: function(that) {
		URL.load('base', function(feed) {
			//parse the frontpage informations
			if(feed.__childNodes__[0] && feed.__childNodes__[0].__childNodes__ && feed.__childNodes__[0].__childNodes__.length > 0) {
				for(var i = 0; i < feed.__childNodes__[0].__childNodes__.length; i++) {
					var frontpart = feed.__childNodes__[0].__childNodes__[i];
					URL[frontpart.name.toClassName()] = frontpart;
				}
				//console.log(URL);
			}
			else {
				that.error('No Frontpage Informations found.');
			}

			//create the menu
			var menu = feed.__childNodes__[1].__childNodes__;
			//push static frontpage
			that.args.items.push({
				title: 'Start',
				url: '',
				type: 'frontpage',
				doctype: URL['start-screen']['doctype']
			});
			if(menu.length > 0) {
				for(var i = 0; i < menu.length; i++) {
					that.args.items.push({
						title: menu[i].name,
						url: menu[i].navigationURL,
						type: menu[i].targetContentType,
						doctype: menu[i].doctype,
						docpath: menu[i].docpath
					});
				}
				//only create and show if menu data is arrived
				that.create().show();
				//and show the frontpage
				active_part = Frontpage.show().focus();
				that.active_item = that.itemObjects[0];
				Menu.blur();
			}
			else {
				Error.show('Leider ist ein Fehler aufgetreten. (A01)');
			}
		});
	},
	onEnter: function(that) {
		App.get().attr('class', '');
		that.active_item = that.getFocusItem();
		if(typeof active_part == 'object') {
			active_part
				.blur()
				.hide()
				.trigger('close');
			Slider.trigger('close');
		}
		TRACK.PageView('übersicht', that.active_item.args.data.doctype, that.active_item.args.data.title);
		switch(that.active_item.args.data.type) {
			case 'frontpage':
				active_part = Frontpage;
				break;
			case 'bilder':
				active_part = Images
					.setData('remote', true)
					.setData('url', that.getFocusItem().args.data.url);
				break;
			case 'newsticker':
				active_part = Newsticker
					.setData('url', that.getFocusItem().args.data.url);
				break;
			case 'videos':
				active_part = Videos
					.setData('url', that.getFocusItem().args.data.url);
				break;
			case 'mix':
				// mla testing
				// **
//				if (that.getFocusItem().args.data.title == "Bundesliga") {
//				  that.getFocusItem().args.data.url = JSON_WRAPPER_BASEURL + "http://www.eggontop.com/staging/meta.morph/test_bundesliga.json";
// 				}
				// **			
				active_part = Mix
					.setData('url', that.getFocusItem().args.data.url);
				break;
			case 'text':
				active_part = Article
					.setData('gotoFrontpage', true)
					.setData('url', that.getFocusItem().args.data.url);				
				break;
			default:
				that.log('Type <b>'+that.getFocusItem().args.data.type+'</b> is not implemented.');		
		}
		if(that.active_item.args.data.type == 'frontpage') {
			App.globalReturnEvent = false; //remove global return event for exiting the app
		}
		else {
			App.globalReturnEvent = backToFrontpage;
		}
		active_part.focus().show();
		App.setWrapClass(that.active_item.args.data.title.toClassName());
		that.menuStartOffset = that.menuOffset;
		that.blur();
		that.$items.find('.red').removeClass('red');
	},
	onFocus: function(that) {
		that.menuStartOffset = parseFloat(that.$items.css('left'));
		//hide the slider if the video gallery is active
		if(Videos.isVisible()) {
			Slider.hide();
		}
	},
	onAfterFocus: function(that) {
		that.getFocusItem().get().addClass('red');
	},
	onBeforeRight: function(that) {
		var focusItem = that.getFocusItem();
		that.__prevFOID = focusItem.args.uid;
	},
	onAfterRight: function(that) {
		var focusItem = that.getFocusItem();
		if(focusItem.args.uid != that.__prevFOID && focusItem.args.uid >= that.visibleMenuItems) {
			that.menuOffset-= focusItem.get().find('>*').width()+25;
			if(that.menuOffset >= that.menuMaxOffset) {
				that.$items.css('left', that.menuOffset);
			}
		}
	},
	onAfterLeft: function(that) {
		var focusItem = that.getFocusItem();
		if(focusItem && focusItem.args.uid >= that.visibleMenuItems) {
			that.menuOffset+= focusItem.get().find('>*').width()+25;
		}
		else {
			that.menuOffset = that.menuInitOffset;
		}
		if(that.menuOffset >= that.menuMaxOffset) {
			that.$items.css('left', that.menuOffset);
		}
	},
	onCheckPosition: function(that) {
		var focusItem = that.getBlurItem();
		var l = 0;
		if(focusItem.args.uid < that.visibleMenuItems) {
			l = that.menuInitOffset;
		}
		else if(that.menuOffset < that.menuMaxOffset) {
			l = that.menuMaxOffset;
		}
		else {
			l = that.menuStartOffset;
		}
		that.$items.css('left', l);
		that.menuOffset = l;
	},
	onBlur: function(that) {
		that.active_item.addBlur();
		that.trigger('checkPosition');
		//show the slider if the video gallery is active
		if(Videos.isVisible()) {
			Slider.show();
		}
	},
	onRefresh: function(that) {
		//LOG('now refresh the feed');
		that.focus().trigger('enter');
		
		/*var video1IsPlaying = typeof Videos.video == 'object' ? Videos.video.isPlaying() : false;
		var video2IsPlaying = typeof ATeaser.video == 'object' ? ATeaser.video.isPlaying() : false;
		if((!video1IsPlaying && !video2IsPlaying && !Loading.isVisible()) || global_refresh_counter > 20) {
			LOG('refresh the feed');
			global_refresh_counter = 0;
			that.focus().trigger('enter');
			that.trigger('refresh', GLOBAL_REFRESH);
		}
		else {
			LOG('try to refresh in a view sec... '+global_refresh_counter);
			global_refresh_counter++;
			that.trigger('refresh', GLOBAL_REFRESH_RETRY);
		}*/
	}
});
Menu.blur = function() {
	this.trigger('beforeBlur');
	this.$obj.removeClass('focus');
	if(this.args.hasSelectableItems && this.getFocusItem()) {
		this.getFocusItem().blur();
	}
	this.App.removeWrapClass(this.args.name.toLowerCase());
	this.trigger('blur');
	return this;
};
//dont scroll infinte through
Menu.getNextItem = function(i) {
	i+= 1;
	if(i >= this.itemObjects.length) {
		return false;
	}
	return this.itemObjects[i];
};
Menu.getPrevItem = function(i) {
	i-= 1;
	if(i < 0) {
		return false;
	}
	return this.itemObjects[i];
};


//
// !NEWSTICKER
////////////////////////////////////////////
var Newsticker = new AppPart({
	name: 'Newsticker',
	selector: '#newsticker',
	hasSelectableItems: true,
	itemContainerSelector: '#newstickeritems',
	itemCreator: function(item, that) {
		var d = App.getTimeNice(item.date);
		var h = '<span class="date">'+d+' Uhr</span>';
		h+= '<span class="tickertitle">'+item.tickerText+'</span>';
		return '<div class="item">'+h+'</div>';
	},
	onFocus: function(that) {
		if(that.args.items.length == 0) {
			URL.load(that.data.url, function(feed) {
				if(feed.__nodeType__ == 'telegramm') {
					if(!feed.__childNodes__) {
						Error.show('Leider ist ein Fehler aufgetreten (A02)');
						return false;
					}
					if(!feed.__childNodes__[0].date) {
						that.error('First Newsticker entry has no date field');
						return false;
					}
					var d = App.getDateNice(feed.__childNodes__[0].date);
					$('#newstickerhead').html('<span class="date">'+d+'</span>');
					//$('#newstickerhead').html('<span class="date">'+'Tag, ??. Monat Jahr'+'</span>');
					if(feed.__childNodes__.length > 0) {
						//for(var i = 0; i < feed.__childNodes__.length; i++) {
						for(var i = 0; i < 10; i++) {
							that.args.items.push(feed.__childNodes__[i]);
						}
						that
							.create()
							.show()
							.itemObjects[0].focus();
						that.trigger('enter');
					}
					else {
						that.error('Newsticker Feed is empty');
					}
				}
				else {
					that.error('Newsticker Feed type is not telegramm');
				}
			});
		}
		Slider.hide();
	},
	onEnter: function(that) {
		var item = that.getFocusItem().args.data;
		var d = App.getTimeNice(item.date);
		var h = '<span class="title">'+d+' Uhr</span>';
		h+= '<span class="headline">'+item.header+'</span>';
		h+= '<div class="teaserText">'+item.text+'</div>';
		$('#newstickerdisplay').html('<div class="newstickerwrap">'+h+'</div>');
		TRACK.Click('ticker', '', 'Newsticker');
	},
	onClose: function(that) {
		that.hide().blur();
		that.args.items = [];
		that.$items.html('');
	}
});
Newsticker.handleDown = function() {
	var item = this.getFocusItem();
	var next = item.args.uid + 1;
	if(next >= this.itemObjects.length) {
		this.blur();
		Menu.focus();
	}
	else {
		item.blur();
		this.itemObjects[next].focus();
		this.trigger('enter');
	}
};
Newsticker.handleUp = function() {
	var item = this.getFocusItem();
	var prev = item.args.uid - 1;
	if(prev < 0) {
		this.blur();
		Menu.focus();
	}
	else {
		item.blur();
		this.itemObjects[prev].focus();
		this.trigger('enter');
	}
};
 

//
// !SLIDER
////////////////////////////////////////////
var Slider = new AppPart({
	name: 'Slider',
	selector: '#slider',
	hasSelectableItems: true,
	itemContainerSelector: '#slideritems',
	itemCreator: function(slide, that) {
		var h = '';
		if(typeof that.data.itemCreator == 'function') {
			h = that.data.itemCreator(slide);
		}
		else {
			h = '<img src="'+slide.imageURL+'" />';
		}
		if (h) {
		  return '<div class="slide"><div class="shadow">'+h+'</div></div>';	
		}
		else {
		  return null;
		}
	},
	itemOnFocusIndex: function(that) {
		var i = that.itemObjects.length / 2;		
		//return Math.ceil(i);
		return i;
	},
	onBeforeCreate: function(that) {
		//after 20 items the cehtml version crashs. 
		that.args.items = that.args.items.slice(0, 20);
		that.args.itemslength = that.args.items.length;
		//that.args.items = that.args.items.slice(0, 3); //!HERE!
		
		that.clones = 2;
		that.args.items = that.args.items.concat(that.args.items);
		that.callbackTimeout = -1;
		while(that.args.items.length < 16) {
			that.clones+= 2;
			that.args.items = that.args.items.concat(that.args.items);
		}
		
		//change order if there was no clone
		/*if(that.clones == 0) {
			half = that.args.items.length/2;
			part1 = that.args.items.slice(0, half);
			part2 = that.args.items.slice(half, that.args.items.length);
			that.args.items = [];
			that.args.items = part2.concat(part1);
			LOG('order changed');
		}*/
	},
	onAfterCreate: function(that) {
		var itemwidth = that.data.itemwidth;
		itemwidth = itemwidth + 14; //add the padding
		var width = that.itemObjects.length * itemwidth;
		var offset = Math.floor(-(width/2) + (SCREEN_WIDTH/2) - (itemwidth/2));
		if(that.data.isFrontpage) {
			offset = offset - ((FRONTPAGE_SLIDER_ITEMWIDTH_BIG - itemwidth) / 2);
		}
		/*if(that.args.items.length%2 > 0) {
			offset-= itemwidth/2;	
		}*/
		$('#slideritems')
			.width(width+400)
			.css('left', offset)
			.find('.slide').css('width', itemwidth);
	},
	onClose: function(that) {
		//reset used data
		that.data.itemCreator = false;
		that.data.itemwidth = false;
		that.data.isFrontpage = false;
		that.data.callbackDelay = false;
		that.data.isGallery = false;
		that.$items.html('');
		clearTimeout(that.callbackDelay);
	},
	onEnter: function(that, fromRemote) {
		if(that.data.callbackDelay && !that.hasTimeout('enterNow')) {
			that.trigger('enterNow', that.data.callbackDelay);
		}
		else {
			that.trigger('enterNow', fromRemote);
		}
	},
	onEnterNow: function(that, fromRemote) {
		if(typeof that.data.callback == 'function') {
			var slide = that.getFocusItem();
			that.data.callback(slide.args.data);
			if(fromRemote) {
				global_refresh_counter = 0;
				//TRACK.PageView((that.data.isGallery ? 'projektor%2Fbg' : 'teaser'), slide.args.data.doctype, slide.args.data.docpath);
				if(that.data.isGallery) {
					TRACK.PageView('galerie', 'galerie', slide.args.data.docpath);
				}
				else {
					TRACK.PageView('teaser', slide.args.data.doctype, slide.args.data.docpath);
				}
			}
		}
		else {
			that.error('Callback is not definied.');
		}
		that.clearTimeout('enter');
		that.clearTimeout('focusAndEnter');
		that.clearTimeout('enterNow');
	},
	onBeforeLeft: function(that, fromRemote) {
		var last = that.itemObjects.pop();
		last.get().remove();
		that.$items.prepend(last.get());
		that.itemObjects.unshift(last);
	},
	onBeforeRight: function(that, fromRemote) {
		var first = that.itemObjects.shift();
		first.get().remove();
		that.$items.append(first.get());
		that.itemObjects = that.itemObjects.concat(first);
	},
	onAfterLeft: function(that, fromRemote) {
		// mla 04.01.12 - added to always show overlays
		Slider.show();
		Menu.show();
		
		that.clearTimeout('enterNow');
		that.trigger('enter', fromRemote);
		if(fromRemote) {
			TRACK.Click('teaserswipe', '', Menu.getBlurItem().args.data.title);
		}
	},
	onAfterRight: function(that, fromRemote) {
		// mla 04.01.12 - added to always show overlays
		Slider.show();
		Menu.show();

		that.clearTimeout('enterNow');
		that.trigger('enter', fromRemote);
		if(fromRemote) {
			TRACK.Click('teaserswipe', '', Menu.getBlurItem().args.data.title);
		}
	},
	onNext: function(that) {
		if(BildApp.getFocusObject().args.name == 'Slider') {
			global_refresh_counter++;
			if(global_refresh_counter >= that.args.itemslength) {
				global_refresh_counter = 0;
				Menu.trigger('refresh');
			}
			else {
				BildApp.right();
				that.trigger('enterNow');
			}
		}
	},
	onShow: function(that) {
		//dont show a slider with one slide
		if((that.itemObjects.length/2) <= 1) {
			that.blur().hide();
		}
	},
	onClearAllTimeouts: function(that) {
		//start the slider again
		that.trigger('startAutomatic', GLOBAL_AUTOPLAY_TIMEOUT);
	},
	onStartAutomatic: function(that) {
		//LOG('### START AUTOMATIC');
		var fo = App.getFocusObject();
		var video1IsPlaying = typeof Videos.video == 'object' ? Videos.video.isPlaying() : false;
		var video2IsPlaying = typeof ATeaser.video == 'object' ? ATeaser.video.isPlaying() : false;
		if(that.isVisible() && !video1IsPlaying && !video2IsPlaying && !ATeaser.fullscreen && !Article.isVisible() && !BundesligaArticle.isVisible() && !Error.isVisible()) {
			fo.blur();
			that.focus();
			that.trigger('enter');
		}
		//Menu.trigger('refresh', GLOBAL_REFRESH);
	}
});
Slider.getPrevItem = function(i) {
	var x = this.args.itemOnFocusIndex(this);
	return this.itemObjects[x];
}
Slider.getNextItem = function(i) {
	var x = this.args.itemOnFocusIndex(this);
	return this.itemObjects[x];
}


//
// !IMAGES
////////////////////////////////////////////
var Images = new AppPart({
	name: 'Bildergallerie',
	selector: '#images',
	hasSelectableItems: false,
	canHaveFocus: false,
	itemContainerSelector: '#imagesitems',
	itemCreator: function(item, that) {
		var title, kicker;
		if(that.data.globalkicker) {
			kicker = that.data.globalkicker;
		}
		else {
			kicker = 'Aus aller Welt';
		}
		if(that.data.globaltitle) {
			title = that.data.globaltitle;
		}
		else {
			title = 'Der Tag in Bildern';
		}
		$('#imageimage').attr('src', '').hide().attr('src', item.imageURL3);
		$('#imagetextkicker').text(kicker);
		$('#imagetextheadline').text(title);
		$('#imagetextteaser').text(item.imageCaption);
		$('#imagetext').show();
		return '';
	},
	onBeforeCreate: function(that) {
		that.setData('images', []);
	},
	onAfterCreate: function(that) {
		if(that.itemObjects.length > 0) {
			that.active_item = 0;
			that.itemObjects[that.active_item].focus();
			for(var i = 1; i < that.itemObjects.length; i++) {
				that.itemObjects[i].blur();
			}
		}
		$('#imageimage').fadeIn();
	},
	onFocus: function(that) {
		that.show();
		if(that.data.remote) {
			URL.load(that.data.url, function(feed) {
				if(feed.__nodeType__ == 'imageGallery') {
					that
						.setData('images', feed.__childNodes__)
						.trigger('createSlider');
				}
				else {
					that.error('Images called, but JSON Feed has not the right type');
				}
			});
		}
	},
	onCreateSlider: function(that) {
		that.images_count = that.data.images.length;
		Slider
			.setData('isGallery', true)
			.setData('itemwidth', IMAGE_SLIDER_ITEMWIDTH)
			.setData('callback', function(slide) {
				that.create([slide]);
				if(that.images_count > 1) {
					that.trigger('nextImage', IMAGEGALLERY_NEXTIMAGE_TIMEOUT);
				}
			})
			.create(that.data.images)
			.show()
			.focus()
			.trigger('enter');
		if(that.images_count > 1) {
			that.trigger('fullscreen', IMAGEGALLERY_FULLSCREEN_TIMEOUT);
		}
	},
	onFullscreen: function(that) {
		Slider.hide();
		BildApp.hijackKeyDownEvent = function(thatapp) {
			Slider.show();
		};
	},
	onNextImage: function(that) {
		Menu.blur();
		Slider
			.focus()
			.trigger('next')
			.trigger('enter');
	},
	onClearAllTimeouts: function(that) {
		if(that.isVisible() && that.itemObjects.length == 1 && that.data.ctype == 'gallery') {
			that
				.trigger('nextImage', IMAGEGALLERY_NEXTIMAGE_TIMEOUT)
				.trigger('fullscreen', IMAGEGALLERY_FULLSCREEN_TIMEOUT);
		}
	},
	onBlur: function(that) {
		Slider.blur().hide();
		that.clearAllTimeouts();
	},
	onClose: function(that) {
		$('#imageimage').attr('src', '').hide();
		that.itemObjects = [];
		that
			.setData('images', [])
			.setData('remote', true)
			.setData('globalkicker', false)
			.setData('globaltitle', false)
			.hide()
			.clearAllTimeouts();
		that.hide();		
	}
});


//
// !FRONTPAGE
////////////////////////////////////////////
var Frontpage = new AppPart({
	name: 'Frontpage',
	selector: '#frontpage',
	hasSelectableItems: false,
	canHaveFocus: false,
	onFocus: function(that) {
		that.show();
		Menu.show();
		//load the a teasers
		URL.load(URL['a-teaser-rotation'].navigationURL, function(feed) {
			if(feed.__childNodes__.length > 0) {
				Slider
					.setData('itemwidth', FRONTPAGE_SLIDER_ITEMWIDTH)
					.setData('isFrontpage', true)
					.setData('itemCreator', function(slide) {
						var h = '<img class="small" src="'+slide.teaserImageURL+'" height="'+FRONTPAGE_SLIDER_ITEMHEIGHT+'px" width="'+FRONTPAGE_SLIDER_ITEMWIDTH+'px" />';
						h+= '<img class="big" src="'+slide.teaserImageURL2+'" height="'+FRONTPAGE_SLIDER_ITEMHEIGHT_BIG+'px" width="'+FRONTPAGE_SLIDER_ITEMHEIGHT_BIG+'px" />';
						return h;
					})
					.setData('callback', function(slide) {
						var content = $.extend({ctype: 'content'}, slide);
						var media = $.extend({ctype: 'media'}, slide);
						ATeaser
							.setData('itemwidth', IMAGE_SLIDER_ITEMWIDTH)
							.setData('itemCreator', function(item) {
								if(item.ctype == 'content') {
									var h = '<span class="title">'+item.kicker+'</span>';
									h+= '<span class="headline">'+item.title+'</span>';
									//h+= '<span class="date">'+item.date+'</span>';
									h+= '<span class="teaserText">'+item.text+'</span>';
									return '<div class="content item"><div class="contentwrap">'+h+'</div></div>';
								}
								if(item.ctype == 'media') {
									//var m = '<img src="'+item.teaserImageURL2+'" width="600px" height="338px">';
									var m = '';
									return '<div class="media item">'+m+'</div>';
								}
							})
							.create([content, media])
							.show()
							.trigger('play');
					})
					.create(feed.__childNodes__)
					.show()
					.focus()
					.trigger('enter');
			}
			else {
				that.error('ATeaser Feed is empty');
			}
		});
		//Small workaround - could be the problem of everything
		//window.setTimeout(function() { Menu.focus(); }, 100);
	},
	onAfterFocus: function(that) {
		Menu.focus();
	},
	onClose: function(that) {
		ATeaser.trigger('close').hide();
		Slider.trigger('close').hide();
		that.blur();
	}	
});


//
// !VIDEOS
////////////////////////////////////////////
var Videos = new AppPart({
	name: 'Videogallerie',
	selector: '#videos',
	hasSelectableItems: false,
	canHaveFocus: false,
	itemContainerSelector: '#videoitems',
	onBeforeCreate: function(that) {
		that.video = false;
	},
	onFocus: function(that) {
		that.show();
		URL.load(that.data.url, function(feed) {
			if(typeof feed.__childNodes__ != 'undefined') {
				if(feed.__childNodes__.length > 0) {					
					Slider
						.setData('itemwidth', VIDEO_SLIDER_ITEMWIDTH)
						.setData('itemCreator', function(item) {
							// only support videos served with http
							if(item.video.substr(0,4) == 'http') {
								var h = '<img src="'+item.imageURL+'" />';
								h+= '<span class="slidertitlewrap">';
								h+= '<span class="sliderkicker">'+item.title+'</span>';
								h+= '<span class="slidertitle">'+item.headline+'</span>';
								h+= '</span>';
								return h;
							}
							else {
								return null;
							}
						})
						.setData('callbackDelay', VIDEOGALLERY_SLIDER_ENTERTIMEOUT)
						.setData('callback', function(slide) {
							that
								.trigger('stop')
								.trigger('play');
						})
						.create(feed.__childNodes__)
						.show()
						.focus()
						.trigger('enterNow');
				}
				else {
					that.error('No Videos found in the feed');
				}
			}
			else {
				//that.error('The Video feed is empty');
				Error.show('Leider ist ein Fehler aufgetreten (A03)');
			}
		});
	},
	onPlay: function(that) {
		var videodata = Slider.getFocusItem().args.data;
		that.video = new Videoplayer({
			target: '#videofullscreen',
			videourl: videodata.video,
			imageurl: videodata.imageURL,
			background: '#wrapbg, #wrapbgkachel',
			left: 0,
			top: 0,
			width: SCREEN_WIDTH,
			height: SCREEN_HEIGHT,
			onStop: function() {
				Slider.trigger('next');
			},
			onCanNotPlayVideo: function() {
				Slider.trigger('next', IMAGEGALLERY_NEXTIMAGE_TIMEOUT);
			},
			data: videodata,
			fullscreen: true
		});
		that.trigger('fullscreen', VIDEOGALLERY_FULLSCREEN_TIMEOUT);
		Loading.hide(); // <- notwendig?
	},
	onFullscreen: function(that) {
		Slider.hide();
		Menu.hide();
		BildApp.hijackKeyDownEvent = function(thatapp) {
			Slider.show();
			Menu.show();
			that.trigger('fullscreen', VIDEOGALLERY_FULLSCREEN_TIMEOUT);
			App.globalReturnEvent = backToFrontpage;
		};
		App.globalReturnEvent = function() {
			BildApp.hijackKeyDownEvent();
		};
	},
	onStop: function(that) {
		if(that.video) {
			that.video.destroy('Videogalerie onStop');
			that.video = false;
		}
	},
	onHide: function(that) {
		that.clearAllTimeouts();
		that.trigger('stop');
	},
	onClearAllTimeouts: function(that) {
		if(typeof that.video == 'object' && that.video.isPlaying() && that.isVisible()) {
			that.trigger('fullscreen', VIDEOGALLERY_FULLSCREEN_TIMEOUT);
		}
	}
});


//
// !ATEASER
////////////////////////////////////////////
var ATeaser = new AppPart({
	name: 'A Teaser',
	selector: '#ateaser',
	hasSelectableItems: true,
	itemContainerSelector: '#ateaseritems',
	itemOnFocusIndex: function(that) {
		return 1;
	},
	itemCreator: function(item, that) {
		if(typeof that.data.itemCreator == 'function') {
			return that.data.itemCreator(item);
		}
		else {
			if(item.type == 'content') {
				var h = '<span class="title">'+item.title+'</span>';
				h+= '<span class="headline">'+item.headline+'</span>';
				//h+= '<span class="date">'+item.date+'</span>';
				h+= '<span class="teaserText">'+item.teaserText+'</span>';
				return '<div class="content item"><div class="contentwrap">'+h+'</div></div>';
			}
			if(item.type == 'media') {
				var m = '<img src="'+item.imageURL+'" />';
				return '<div class="media item">'+m+'</div>';
			}
		}
	},
	onBeforeCreate: function(that) {
		if(that.fullscreen) {
			that.trigger('closeFullscreen');
		}
		$('#ateaseroverlaymedia span').text('Vollbild');
		that.fullscreen = false;
	},
	onAfterFocus: function(that) {
		$('.ateaseroverlay').hide();
		switch (that.mediatype) {
		  case 'bundesligaOverlay':
			// override default to show focus over full content
			$('#ateaseroverlayfull').show();
			break;
		  default:
			$('#ateaseroverlay'+that.getFocusItem().args.data.ctype).show();
			break;
		}
	},
	onAfterLeft: function(that) {
		that.trigger('afterFocus');	
	},
	onAfterRight: function(that) {
		that.trigger('afterFocus');	
	},
	onAfterCreate: function(that) {
		that.data.itemCreator = false;
		//Menu.trigger('refresh', GLOBAL_REFRESH);
	},
	onBlur: function(that) {
		$('.ateaseroverlay').hide();
	},
	onEnter: function(that, manual) {
		that.clearAllTimeouts();
		var item = that.getFocusItem();
		
		switch (that.mediatype) {
		  case 'bundesligaOverlay':
			//display content
			BundesligaArticle
				.setData('')
				.show()
				.focus();
			that.blur();
			App.globalReturnEvent = function() {
				BundesligaArticle.trigger('close');
			};
			break;
			
		  default:
			if(item.args.data.ctype == 'content') {
				//display article content
				Article
					.setData('url', item.args.data.linkURL)
					.show()
					.focus();
				that.blur();
				App.globalReturnEvent = function() {
					Article.trigger('close');
				};
				TRACK.PageView('artikel', item.args.data.doctype, item.args.data.docpath);
			}
			else {
				if(!Loading.isVisible()) {
					that.trigger('fullscreen');
				}
			}
		  	break;
		}
	},
	onPlay: function(that) {
		if(that.video) {
			that.video.destroy('ATeaser onPlay');	
			that.video = false;
		}
		if(that.itemObjects.length > 0) {
			var item = that.itemObjects[0];
			var media = item.args.data.__childNodes__[0];
			$('#ateaseritems .media').hide();
			switch(media.__nodeType__) {
				case 'imageGallery':
					that.mediatype = 'gallery';
					that.gallery = {
						activeslide: -1,
						slides: media.__childNodes__
					};
					that.trigger('nextSlide');
					break;
				case 'image':
					that.mediatype = 'image';
					that.gallery = {
						activeslide: 0,
						slides: [media]
					};
					that
						.trigger('showSlide')
						.trigger('ended', SINGLEIMAGE_INTERVAL);
					break;
				case 'video':
					that.mediatype = 'video';	
					that.videodata = {
						url: media.video,
						image: media.imageURL,
						data: item.args.data
					};
					that.trigger('playVideo');
					break;
					// mla removed - 21.12.11					
					
				case 'bundesligaOverlay':
					that.mediatype = 'bundesligaOverlay';
					that.gallery = {
						activeslide: -1,
						slides: media.__childNodes__
					};
					that.trigger('nextSlide');
					break;
					
				default:
					that.error('Mediatype is not implemented '+media.__nodeType__);
			}
		}
		else {
			LOG('ATeaser triggerd play without content');
		}
	},
	onNextSlide: function(that) {
		that.gallery.activeslide++;
		$('#ateaseritems .media').hide();
		if(that.gallery.activeslide < that.gallery.slides.length) {
			that
				.trigger('showSlide')
				.trigger('nextSlide', SLIDESHOW_INTERVAL);
		}
		else {
			//last slide is visible...
			that.gallery.activeslide = 0;
			that.trigger('ended');
		}
	},
	onShowSlide: function(that) {
		if(typeof that.gallery == 'object') {
			var slide = that.gallery.slides[that.gallery.activeslide];
			$('#ateaseritems .media').html('<img src="'+slide.imageURL3+'" />').fadeIn();
		}
	},
	onPlayVideo: function(that) {
		if(that.mediatype == 'gallery') {
			LOG('mediatype was gallery');
			//App.clearTimeout(that.gallery.timeout);
		}
		that.video = new Videoplayer({
			//target: '#ateaseritems .media', 
			videourl: that.videodata.url,
			imageurl: that.videodata.image,
			background: '#ateaserbgkachel, #wrapbgkachel',
			width: ATEASER_MEDIA_WIDTH,
			height: ATEASER_MEDIA_HEIGHT,
			left: ATEASER_MEDIA_LEFT,
			top: ATEASER_MEDIA_TOP,
			onStop: function() {
				that.trigger('ended');
			},
			onCanNotPlayVideo: function() {
				that.trigger('ended', IMAGEGALLERY_NEXTIMAGE_TIMEOUT);
			},
			data: that.videodata.data
		});
		//BildApp.clearAllTimeouts();
		//that.clearAllTimeouts();
	},
	onFullscreen: function(that) {
		var item = that.getFocusItem();
		that.blur();
		Slider.focus();
		that.fullscreen = true;
		that.clearAllTimeouts();
		switch(that.mediatype) {
			case 'gallery':
			case 'image':
				active_part.trigger('close');
				if(that.mediatype == 'gallery') {
					Slider
						.setData('isFrontpage', false)
						.setData('itemwidth', 133)
						.setData('itemCreator', function(slide) {
							var h = '<img src="'+slide.imageURL+'" />';
							return h;
						});
				}
				//var images = [that.gallery.slides[0], that.gallery.slides[1]];
				var images = that.gallery.slides;
				active_part = Images
					.setData('remote', false)
					.setData('globalkicker', that.itemObjects[0].args.data.kicker)
					.setData('globaltitle', that.itemObjects[0].args.data.title)
					.setData('images', images)
					.setData('ctype', that.mediatype)
					.show();
				if(images.length == 1) {
					that.mediatype = 'image';
					Images.create(images);
				}
				if(that.mediatype == 'gallery') {
					Images
						.trigger('createSlider')
						.trigger('nextImage', IMAGEGALLERY_NEXTIMAGE_TIMEOUT)
						.focus();
					Slider.focus();
				}
				else {
					Slider.hide().blur();
					Menu.focus();
				}
				TRACK.PageView('galerie', item.args.data.doctype, item.args.data.docpath);
				break;
			case 'video':
				that.trigger('hideOverlays');
				that.video.setFullscreen('#wrapbg, #wrapbgkachel');
				break;
				// mla removed - 21.12.11				
			case 'bundesligaOverlay':
				break;
			default:
				LOG('mediatype '+that.mediatype+' has no fullscreen view');
		}
		App.globalReturnEvent = function() {
			Menu.focus().trigger('enter');
		}
	},
	onCloseFullscreen: function(that) {
		if(that.video) {
			that.video.destroy('ATeaser onCloseFullscreen');
			that.video = false;
		}
		that.fullscreen = false;
		that.trigger('showOverlays');
		ATeaser.show();
		Images.hide().blur();
		Images.clearTimeout('fullscreen');
		BildApp.hijackKeyDownEvent = false;
		that.clearTimeout('hideOverlays');
		that.clearTimeout('nextSlide');
		Slider.show().focus(); //.trigger('next', AFTER_FULLSCREEN_NEXT_SLIDE);
	},
	onShowOverlays: function(that) {
		Menu.show();
		Slider.show();
	},
	onHideOverlays: function(that) {
		ATeaser.hide();
		Menu.hide();
		Slider.hide();
		BildApp.hijackKeyDownEvent = function(theapp) {
			that
				.trigger('showOverlays')
				.trigger('hideOverlays', ATEASER_HIDE_OVERLAYS);
		};
	},
	onEnded: function(that) {
		if(that.video) {
			that.video.destroy('ATeaser onEnded');
			that.video = false;
		}
		Slider.trigger('next');
	},
	onClearAllTimeouts: function(that) {
		if(that.fullscreen && that.video) {
			that.trigger('hideOverlays', ATEASER_HIDE_OVERLAYS);
		}
	},
	onClose: function(that) {
		if(that.video) {
			that.video.destroy('ATeaser onClose');
			that.video = false;
			if(that.fullscreen) {
				that.trigger('closeFullscreen');
				ATeaser.hide();
			}			
		}
		that.clearAllTimeouts();
		Images.trigger('close');
	}
});


//
// !ARTICLE
////////////////////////////////////////////
var Article = new AppPart({
	name: 'Article',
	selector: '#article',
	hasSelectableItems: false,
	modal: true,
	itemContainerSelector: '#articleitems',
	itemCreator: function(item, that) {
		var h = '';
		if(item.kicker) {
			h+= '<span class="title">'+item.kicker+'</span>';
		}
		if(item.headline) {
			h+= '<span class="headline">'+item.headline+'</span>';
		}
		if(item.title) {
			h+= '<span class="headline">'+item.title+'</span>';
		}
		h+= '<div class="teaserText">'+strip_tags(item.text, ARTICLE_ALLOWED_HTML_TAGS)+'</span>';
		return h;
	},
	onBeforeCreate: function(that) {
		that.offsetTop = 0;
		that.move = 20;
		that.articleHeight = 1000;
	},
	onAfterCreate: function(that) {
		that.articleHeight = parseFloat(that.$items.height()) - ARTICLE_OFFSET_BOTTOM;
	},
	onShow: function(that) {
		if(that.data.url) {
			URL.load(that.data.url, function(feed) {
				that.args.items = [feed];
				that
					.create()
					.focus()
					.trigger('setPosition');
			}); 
		}
	},
	onFocus: function(that) {
		BildApp.clearAllTimeouts();
	},
	onEnter: function(that) {
		that.hide();
		ATeaser.focus();
	},
	onSetPosition: function(that) {
		if(that.articleHeight > 0) {
			$('#articlescrollbar').show();
			that.$items.css('top', that.offsetTop);
			//calc percent position from text
			var p = ((that.offsetTop*-1)*100)/that.articleHeight;
			if(p > 100) { p = 100; }
			//calc pixel offset for scrollbar
			var o = (Math.round((ARTICLE_SCROLLBAR_HEIGHT*p)/100)+ARTICLE_SCROLLBAR_OFFSET);
			$('#articlescrollbarhandler').css('top', o);
		}
		else {
			$('#articlescrollbar').hide();
		}		
	},
	onHide: function(that) {
		$('#articleitems').removeClass('focus').html('');
		$('#articleback').removeClass('focus');
	},
	onClose: function(that) {
		that.hide().blur();
		if(that.data.gotoFrontpage) {
			that.setData('gotoFrontpage', false);
			Menu.itemObjects[0].focus();
			Menu.focus().trigger('enter');
		}
		else {		
			Slider.focus();
			if(active_part.args.name == 'Frontpage') {
				App.globalReturnEvent = false;
			}
			else {
				App.globalReturnEvent = backToFrontpage;
			}
		}
	}
});
Article.handleUp = function() {
	if(this.offsetTop < 0) {
		this.offsetTop+= this.move;
		this.trigger('setPosition');
	}
};
Article.handleDown = function() {
	if(this.offsetTop + this.articleHeight > 0) {
		this.offsetTop-= this.move;
	}
	this.trigger('setPosition');
};
Article.handleLeft = function() {
};
Article.handleRight = function() {
};
Article.handleEnter = function() {
	this.trigger('close');
};

//
//!BundesligaArticle
////////////////////////////////////////////
var BundesligaArticle = new AppPart({
	name: 'BundesligaArticle',
	selector: '#bl_article',
	hasSelectableItems: false,
	modal: true,
	itemContainerSelector: '#bl_articleitems',
	itemCreator: function(item, that) {
		var h = '';
		if(item.kicker) {
			h+= '<span class="title">'+item.kicker+'</span>';
		}
		if(item.headline) {
			h+= '<span class="headline">'+item.headline+'</span>';
		}
		if(item.title) {
			h+= '<span class="headline">'+item.title+'</span>';
		}
		h+= '<div class="teaserText">'+strip_tags(item.text, ARTICLE_ALLOWED_HTML_TAGS)+'</span>';
		return h;
	},
	onBeforeCreate: function(that) {
		that.offsetTop = 0;
		that.move = 20;
		that.articleHeight = 1000;
	},
	onAfterCreate: function(that) {
		that.articleHeight = parseFloat(that.$items.height()) - ARTICLE_OFFSET_BOTTOM;
	},
	onShow: function(that) {
	  Loading.start('bl_article');
	  // update content
	  g_overlayBundesliga.update(12, function() {
		  Loading.stop('bl_article');
		  that
			.create()
			.focus();
	  });						
	},
	onFocus: function(that) {
		BildApp.clearAllTimeouts();
	},
	onEnter: function(that) {
		that.hide();
		ATeaser.focus();
	},
	onSetPosition: function(that) {
		if(that.articleHeight > 0) {
			$('#bl_articlescrollbar').show();
			that.$items.css('top', that.offsetTop);
			//calc percent position from text
			var p = ((that.offsetTop*-1)*100)/that.articleHeight;
			if(p > 100) { p = 100; }
			//calc pixel offset for scrollbar
			var o = (Math.round((ARTICLE_SCROLLBAR_HEIGHT*p)/100)+ARTICLE_SCROLLBAR_OFFSET);
			$('#bl_articlescrollbarhandler').css('top', o);
		}
		else {
			$('#bl_articlescrollbar').hide();
		}		
	},
	onHide: function(that) {
		$('#bl_articleitems').removeClass('focus').html('');
		$('#bl_articleback').removeClass('focus');
	},
	onClose: function(that) {
		that.hide().blur();
		if(that.data.gotoFrontpage) {
			that.setData('gotoFrontpage', false);
			Menu.itemObjects[0].focus();
			Menu.focus().trigger('enter');
		}
		else {		
			Slider.focus();
			if(active_part.args.name == 'Frontpage') {
				App.globalReturnEvent = false;
			}
			else {
				App.globalReturnEvent = backToFrontpage;
			}
		}
	}
});
BundesligaArticle.handleUp = function() {
	g_overlayBundesliga.scrollUp();
};
BundesligaArticle.handleDown = function() {
	g_overlayBundesliga.scrollDown();
};
BundesligaArticle.handleLeft = function() {
};
BundesligaArticle.handleRight = function() {
};
BundesligaArticle.handleEnter = function() {
	this.trigger('close');
};

//
// !MIX GALLERY
////////////////////////////////////////////
var Mix = new AppPart({
	name: 'Mix',
	selector: '#mix',
	hasSelectableItems: false,
	canHaveFocus: false,
	onFocus: function(that) {
		URL.load(that.data.url, function(feed) {
			Slider
				.setData('itemwidth', MIX_SLIDER_ITEMWIDTH)
				.setData('itemCreator', function(item) {
					// only support videos served with http
					var bValid = true;
					if (item.__childNodes__[0].video) {
						// only support videos served with http
						if(item.__childNodes__[0].video.substr(0,4) != 'http') {							
							bValid = false;
						}												
					}

					var h = '<img src="'+item.teaserImageURL+'" />';
					h+= '<span class="slidertitlewrap">';
					h+= '<span class="sliderkicker">'+item.kicker+'</span>';
					h+= '<span class="slidertitle">'+item.title+'</span>';
					h+= '</span>';
					if (bValid) {
						return h;
					}
					else {
						return null;
					}
				})
				.setData('callback', function(slide) {
					var content = $.extend({ctype: 'content'}, slide);
					var media = $.extend({ctype: 'media'}, slide);
					ATeaser
						.setData('itemwidth', MIX_SLIDER_ITEMWIDTH)
						.setData('itemCreator', function(item) {
							if(item.ctype == 'content') {
								var h = '<span class="title">'+item.kicker+'</span>';
								h+= '<span class="headline">'+item.title+'</span>';
								//h+= '<span class="date">'+item.date+'</span>';
								h+= '<span class="teaserText">'+item.text+'</span>';
								return '<div class="content item"><div class="contentwrap">'+h+'</div></div>';
							}
							if(item.ctype == 'media') {
								var m = '<img src="'+item.teaserImageURL2+'" width="600px" height="338px" />';
								return '<div class="media item">'+m+'</div>';
							}
						})
						.create([content, media])
						.show()
						.trigger('play');
				})
				.create(feed.__childNodes__)
				.show()
				.focus()
				.trigger('enter');
		});
	},
	onHide: function() {
		//ATeaser.hide();
		//Slider.hide();
	},
	onClose: function(that) {
		ATeaser.trigger('close').hide();
		Slider.trigger('close').hide();
		that.blur();
	}
});



/*
 * When the DOM is ready
 */
jQuery(function() {
	
	$('body').focus();
	
	//create the great app
	BildApp = App.init({
		selector: '#wrap'
	});
	
	//loading
	if(typeof Loading == 'object') {
		Loading.bind(BildApp).create().show();
	}
	
	//test video application
	/*var video = new Videoplayer({
		target: '#videofullscreen',
		videourl: 'http://jsonvideos.bild.de/BILD/20/23/15/04/20231504,property=Video.mp4',
		data: {
			kicker: 'test'
		}
	});*/
	
	
	//menü
	if(typeof Menu == 'object') {
		Menu.bind(BildApp); //load menu in onBind callback and show + frontpage show
	}
	
	//ateaser
	if(typeof ATeaser == 'object') {
		ATeaser.bind(BildApp).create().hide();
	}

	//images
	if(typeof Images == 'object') {
		Images.bind(BildApp).create().hide();
	}
	
	//videos
	if(typeof Videos == 'object') {
		Videos.bind(BildApp).create().hide();
	}
	
	//mix
	if(typeof Mix == 'object') {
		Mix.bind(BildApp).create().hide();
	}
	
	//slider
	if(typeof Slider == 'object') {
		Slider.bind(BildApp);
	}
	
	//frontpage
	if(typeof Frontpage == 'object') {
		Frontpage.bind(BildApp).create().hide();
	}
	
	//newsticker
	if(typeof Newsticker == 'object') {
		Newsticker.bind(BildApp).create().hide();
	}
	
	//article
	if(typeof Article == 'object') {
		Article.bind(BildApp).create().hide();
	}
	
	//bundesligaarticle
	DataFeedManager.create($('#wrap'));
    g_overlayBundesliga = new OverlayBundesliga({elemContent:$('#bl_article')});
	if(typeof BundesligaArticle == 'object') {
		BundesligaArticle.bind(BildApp).create().hide();
	}

});