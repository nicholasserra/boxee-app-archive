/*
 *  Developed by Jonas Neumann for Smartclip
 *  v0.3
 */
/*
 * represents an AdCall
 * url of the adProvider
 * adPosition can be preRoll or postRoll
 * json is relevant for Philips Devices, which can not receive HTMLRequests, default is false
 * 
 * 22.12.01 mla - added states to prevent ajax timer and ajax jsonp function both bring called.  This was causing a problem on Samsung devices. 
 */

var STATE_INIT = 0;
var STATE_WAITING = 1;
var STATE_READY = 2;

var AdRequest = function(url, adPosition, json, midRollStartTime, overlayID, overlayStartTime, overlayDuration) {
	this.url = url;
	this.adPosition = adPosition;
	this.loaded = false;
	this.json = json;
    this.overlayID = overlayID;
    this.overlayStartTime = overlayStartTime;
    this.overlayDuration = overlayDuration;
    this.midRollStartTime = midRollStartTime;
}
/*
 * handles the AdCalls
 */
var AdController = function(){//appName) {
	var that = this;

	this.activeStreamIndex = 0;
	this.currentStreamIndex = 0;
	this.videoURL = "";
	this.playlist = new Array();
	this.requestsSequence = new Array();
	this.currentLoadedRequest = 0;
	this.postRollLoaded = false
	this.duration = 0;

	this.preRollSequenceIndex = 0;
	this.midRollSequenceIndex = 0;
	this.postRollSequenceIndex = 0;

	this.midRollsPlayed = 0;
	this.midRollStartTimes = new Array();
	this.midRollsAreLoading = false;
	this.currentMidRollLoadTime = 0;

	this.midRollCallback = null;

	this.adModel = new AdModel();//appName);
	this.trackingController = new TrackingController();

	// defines the URL for the actually video
	this.setVideoURL = function(url) {
		this.videoURL = url;
		//Util.log("AdController.setVideoUrl " + this.videoURL);
	};
	/*
	 * defines the url for the AdCall
	 * adPosition can be preRoll or postRoll
	 * json is relevant for Philips Devices, which can not receive HTMLRequests, default is false
	 * count defines the number of calls in sequence
	 * midRollStartTime defines the start time for a mid roll ad (format is millisec )
	 */
	this.setAdRequest = function(url, adPosition, json, count, midRollStartTime, overlayID, overlayStartTime, overlayDuration) {
		Util.log("AdController.setAdRequest " + url + " " + json + " "  + count);
		var requestUrl = url;
		if (!count || count < 1) {
			var count = 1;
		}
		for (var i = 0; i < count; i++) {
				switch (adPosition) {
					case 'preRoll' :
						requestUrl = url + ";count=" + (++this.preRollSequenceIndex);
						break;
					case 'midRoll' :
						requestUrl = url + ";count=" + (++this.midRollSequenceIndex);
						break;
					case 'postRoll' :
						requestUrl = url + ";count=" + (++this.postRollSequenceIndex);
						break;
					default :
						requestUrl = url + ";count=0";
						break;
				}
            
			this.requestsSequence.push(new AdRequest(requestUrl, adPosition, json, midRollStartTime*1000, overlayID, overlayStartTime, overlayDuration));
		}
		Util.log("AdController.setAdRequest " + this.requestsSequence.length);
	};
	// starts the adCalls
	this.startAdLoading = function(callback) {
		this.adCallback = callback;
		this.loadNextAdRequest("preRoll");
	};
	this.loadNextAdRequest = function(adType) {
		var that = this;
		try{
			Util.log("loadNextAdRequest " + adType + " " + this.currentLoadedRequest);
			if(this.requestsSequence[this.currentLoadedRequest].loaded == false && (this.requestsSequence[this.currentLoadedRequest].adPosition == adType || this.requestsSequence[this.currentLoadedRequest].adPosition == "overlay")){
				var loadingAllowed = true;
				if(this.requestsSequence[this.currentLoadedRequest].adPosition == "overlay" && this.adModel.getOverlays().length > 0 ){
					loadingAllowed = false;
				}
				else if(this.requestsSequence[this.currentLoadedRequest].adPosition == "midRoll" && this.requestsSequence[this.currentLoadedRequest].midRollStartTime > this.currentMidRollLoadTime){
					loadingAllowed = false;
				}
				Util.log("loadingAllowed " + loadingAllowed + " " + this.requestsSequence[this.currentLoadedRequest].adPosition + " " + this.adModel.getOverlays().length + " " + this.requestsSequence[this.currentLoadedRequest].midRollStartTime + " > " + this.currentMidRollLoadTime);
				if(loadingAllowed == true){
					this.requestsSequence[this.currentLoadedRequest].loaded = true;
					this.loadAdData(this.requestsSequence[this.currentLoadedRequest], function() {
						that.currentLoadedRequest++;
						Util.log("AdController.loadNextAdRequest 1 " + that.currentLoadedRequest + " == " + (that.requestsSequence.length));
						if (that.currentLoadedRequest >= (that.requestsSequence.length)) {
							that.createPlaylist(adType);
							that.adCallback();
						} else {
							that.loadNextAdRequest(adType);
						}
					});
				}
				else{
					that.createPlaylist(adType);
					that.adCallback();
				}
			}
			else{
				this.currentLoadedRequest++;
				Util.log("AdController.loadNextAdRequest 2 " + that.currentLoadedRequest + " == " + (that.requestsSequence.length));
				if (this.currentLoadedRequest >= (this.requestsSequence.length)) {
					that.createPlaylist(adType);
					this.adCallback();
				} else {
					this.loadNextAdRequest(adType);
				}
			}
		}
		catch(e){
			Util.log("error on loadnextrequest " + e);
			that.createPlaylist(adType);
			this.adCallback();
		}
	};
	this.loadAdData = function(adRequest, callback) {
		Util.log("AdController.loadAdData");
		this.loadCallback = callback;
		this.addLoading = true;
		this.adModel.getAdData(adRequest, this.currentLoadedRequest, function(linearAdItem) {
			that.addLoading = false;
			that.loadCallback();
		});
	};
	this.onJSONPResponse = function(xmlResponse){
        this.adModel.onJSONPResponse(xmlResponse, this.requestsSequence[this.currentLoadedRequest]);
    };
	// function should be called from the JSONPResponse function
	this.parseData = function(xmlResponse) {
		//this.adModel.parseData(xmlResponse, new AdRequest(null, null, null, adPosition, true));
		this.adModel.parseData(xmlResponse, this.requestsSequence[this.currentLoadedRequest]);
	};
	// creates the list of clips and orders the files dependent on pre- or postRoll
	this.createPlaylist = function(adType) {
		var linearAdItems = this.adModel.getLinearAdItems();
		var streamIndexCount = this.playlist.length;
		Util.log("AdController.createPlaylist " + linearAdItems.length);
		// PREROLLS
		if(adType == "preRoll"){
			for (var i = 0; i < linearAdItems.length; i++) {
				if (linearAdItems[i].adPosition == "preRoll") {
					linearAdItems[i].streamIndex = streamIndexCount;
					streamIndexCount++;
					this.playlist.push(linearAdItems[i]);
				}
			}
			//if(this.playlist.length > 0){
			// FIRST VIDEO OCCURENCE
			var videoItem = new VideoAd([{
				bitrate: 0,
				url: this.videoURL
			}], "", "video", 0);
			videoItem.streamIndex = streamIndexCount;
			this.playlist.push(videoItem);
			streamIndexCount++;
		}
		// MIDROLLS
		else if(adType == "midRoll"){
			var midRollStartTimesCount = 0;
			for (var k = 0; k < linearAdItems.length; k++) {
				if (linearAdItems[k].adPosition == "midRoll") {
					//Util.log("............ linearAdItems[k].midRollStartTime " + linearAdItems[k].midRollStartTime);
					this.midRollStartTimes.push(linearAdItems[k].midRollStartTime);
					linearAdItems[k].streamIndex = streamIndexCount;
					streamIndexCount++;
					this.playlist.push(linearAdItems[k]);
					// when midRoll is found and this midRoll is not the last in a sequence of midRolls with same start time
					// or it is the last midRoll of all, then insert video to playlist again
					Util.log("************ " + (midRollStartTimesCount+1) + " >= " + this.midRollStartTimes.length + " || " + this.midRollStartTimes[midRollStartTimesCount] + " != " + this.midRollStartTimes[midRollStartTimesCount+1] + " ****************");
					if (midRollStartTimesCount+1 >= this.midRollStartTimes.length || this.midRollStartTimes[midRollStartTimesCount] != this.midRollStartTimes[midRollStartTimesCount+1]) {
						var videoItem = new VideoAd([{
							bitrate: 0,
							url: this.videoURL
						}], "", "video", this.midRollStartTimes[midRollStartTimesCount]);
						videoItem.streamIndex = streamIndexCount;
						this.playlist.push(videoItem);
						streamIndexCount++;
					}
					midRollStartTimesCount++;
				}
			}
		}
		else if(adType == "postRoll"){
		// POSTROLLS
			for (var j = 0; j < linearAdItems.length; j++) {
				if (linearAdItems[j].adPosition == "postRoll") {
					linearAdItems[j].streamIndex = streamIndexCount;
					streamIndexCount++;
					this.playlist.push(linearAdItems[j]);
				}
			}
		}
        //}
	};
	// returns the index of the current playing video
	this.getActiveStreamIndex = function() {
		return this.activeStreamIndex;
	};
	// returns a video of a streamIndex with a maximum defined bitrate
	this.getMediaFileWithMaxBitrate = function(streamIndex, maxBitrate) {
		var streamItem = this.playlist[streamIndex];
		var urls = streamItem.urls;
		var resultBitrate = urls[0].bitrate;
		var resultUrl = urls[0].url;
		for (var i = 0; i < urls.length; i++) {
			//Util.log(i+ " " + urls[i].bitrate + " >= " + resultBitrate);
			if (urls[i].bitrate <= maxBitrate && urls[i].bitrate >= resultBitrate) {
				resultUrl = urls[i].url;
				resultBitrate = urls[i].bitrate;
				//Util.log(">> " + urls[i].bitrate + " " + urls[i].url);
			}
		}
		Util.log("AdController.getMediaFileWithMaxBitrate " + maxBitrate + " " + resultBitrate + " " + resultUrl);
		return resultUrl;
	};
	this.getClickThrough = function(streamIndex){
		var targetUrl = "";
		try{
			targetUrl = this.playlist[streamIndex].urls[0].targetUrl;
		}
		catch(e){}
		Util.log("AdController.getClickThrough " + targetUrl);
		return targetUrl;
	}
	// is the playing video an ad?
	this.isAd = function(streamIndex) {
		var streamItem = this.playlist[streamIndex];
		if (streamItem.adPosition == "preRoll" || streamItem.adPosition == "midRoll" || streamItem.adPosition == "postRoll") {
			//Util.log("Adcontroller.isAd true");
			return true;
		} else {
			//Util.log("Adcontroller.isAd false");
			return false;
		}
	};
	// returns the streamItem of the next ad or video in the playlist and fires the ImpressionTracker
	this.getNextStream = function() {
		var that = this;
		Util.log("AdController.getNextStream " + this.currentStreamIndex + " < " + this.playlist.length);
		if (this.currentStreamIndex < this.playlist.length) {
			this.activeStreamIndex = this.currentStreamIndex;
			var streamItem = this.playlist[this.activeStreamIndex];
			streamItem.played = true;
			this.initTracking();
			this.showCompanionAds();
			this.trackingController.fireImpressions();
			this.currentStreamIndex++;
			return streamItem;
		}
		else if (this.currentStreamIndex == this.playlist.length && this.postRollLoaded == false) {
			this.postRollLoaded = true;
			/*this.adCallback = function(){
				alert("+++++++++++ adCallback after PostRoll++++++++++++++");
				return that.getNextStream();
			};*/
			this.currentLoadedRequest = 0;
			this.loadNextAdRequest("postRoll");
		}
		else{
			return null;
		}
	};
	this.showCompanionAds = function(){
		var companionsArray = this.adModel.getCompanionAds(this.activeStreamIndex);
        Util.log("showCompanionAds " + companionsArray);
        if(companionsArray){
            for(var i=0; i<companionsArray.length; i++){
                Util.log(companionsArray[i].id + " " + companionsArray[i].url);
                $("#"+companionsArray[i].id).attr("src", companionsArray[i].url);
            }
        }
	}
	this.getOverlay = function(adPosition) {
        this.initOverlayTracking(adPosition);
        Util.log("--------------- getOverlay " +this.adModel.getOverlay(adPosition).urls[0].url);
        if(this.adModel.getOverlay(adPosition).urls){
            return this.adModel.getOverlay(adPosition).urls[0].url;
        }
        return "";
	};
    this.initOverlayTracking = function(adPosition){
        Util.log("initOverlayTracking "+  adPosition);
        this.trackingController.setJSONP(this.adModel.isOverlayJSONP(adPosition));
		this.trackingController.setTrackingPoints(this.adModel.getOverlayTrackingPoints(adPosition));
		this.trackingController.setImpressions(this.adModel.getOverlayImpressions(adPosition));
		this.trackingController.setClickThroughTrackingPoints(this.adModel.getOverlayClickThroughTrackingPoints(adPosition));
		this.trackingController.fireImpressions();
        this.trackingController.setDuration(1);
        this.trackingController.fireTimeTrackingPoints(0);
    }
	this.initTracking = function() {
		this.trackingController.setJSONP(this.adModel.isJSONP(this.activeStreamIndex));
		this.trackingController.setTrackingPoints(this.adModel.getTrackingPoints(this.activeStreamIndex));
		this.trackingController.setImpressions(this.adModel.getImpressions(this.activeStreamIndex));
		this.trackingController.setClickThroughTrackingPoints(this.adModel.getClickThroughTrackingPoints(this.activeStreamIndex));
	};
	this.setDuration = function(duration) {
		this.duration = duration;
		this.trackingController.setDuration(duration);
	};
	// requests to call the tracking points based on an event like firstQuartile, midpoint, thirdQuartile, complete, mute, pause or close
	this.fireEventTrackingPoints = function(eventLabel) {
		this.trackingController.fireEventTrackingPoints(eventLabel);
	};
	// requests to call the tracking points for an ClickThrough
	this.fireClickThroughTrackingPoints = function() {
		Util.log("fireClickThroughTrackingPoints");
		this.trackingController.fireClickThroughTrackingPoints();
	};
	// should be called on the end of a video for exact call of the tracking points
	this.onRenderingComplete = function() {
		this.onUpdatePlayTime(this.duration);
		if (this.playlist[this.activeStreamIndex].adPosition == "midRoll") {
			this.midRollsPlayed++;
		}
		/*
		if (this.currentStreamIndex == this.playlist.length && this.postRollLoaded == false) {
			this.postRollLoaded = true;
			//this.adCallback = function(){
				//alert("+++++++++++ adCallback after PostRoll++++++++++++++");
			//};
			this.currentLoadedRequest = 0;
			this.loadNextAdRequest("postRoll");
		}*/
	};
	// should be called every second or shorter for firing the tracking points
	this.onUpdatePlayTime = function(time) {
		if (this.playlist[this.activeStreamIndex].adPosition == "postRoll" || this.playlist[this.activeStreamIndex].adPosition == "midRoll" || this.playlist[this.activeStreamIndex].adPosition == "preRoll") {
			Util.log("AdController.onUpdatePlayTime " + this.playlist[this.activeStreamIndex].adPosition + " " + time + " " + this.activeStreamIndex);
			this.trackingController.fireTimeTrackingPoints(time);
		} else if (!this.isAd(this.activeStreamIndex)) {
            Util.log("midRolls " + this.midRollsPlayed + " " + this.midRollStartTimes.length + " " + this.midRollsAreLoading + " " + time);
			if (this.midRollsPlayed < this.midRollStartTimes.length && this.midRollStartTimes[this.midRollsPlayed] <= time) {
				this.midRollCallback();
			}
            //Util.log("getOverlays " + this.adModel.getOverlays().length);
            for(var i=0; i< this.adModel.getOverlays().length; i++){
                var tempOverlay = this.adModel.getOverlays()[i]; 
                if(tempOverlay.urls[0].url && tempOverlay.played == false){
                    Util.log("tempOverlay.startTime " + tempOverlay.adPosition + " " + tempOverlay.urls[0].url + " " + tempOverlay.played + " " + tempOverlay.startTime + " " + tempOverlay.duration + " " + time/1000);
                    if(time/1000 >= tempOverlay.startTime  && (time/1000) < (tempOverlay.startTime+tempOverlay.duration) ){
                        if(tempOverlay.showed == false){
                            $("#"+tempOverlay.adPosition).attr("src", tempOverlay.urls[0].url);
                            $("#"+tempOverlay.adPosition).show();
                            this.initOverlayTracking(tempOverlay.adPosition);
                            tempOverlay.showed = true;
                        }
                    }
                    else if( (time/1000) > (tempOverlay.startTime+tempOverlay.duration) ){
                        //Util.log("overlay played " + (time/1000) + " > " + (tempOverlay.startTime+tempOverlay.duration) );
                        $("#"+tempOverlay.adPosition).hide();
                        tempOverlay.played = true;
                    }
                }
            }
			if(this.midRollsAreLoading == false){
				var that = this;
				for(var j=0; j<this.requestsSequence.length; j++){
					Util.log("requestsSequence " + this.requestsSequence[j].adPosition + " == midRoll && " + this.requestsSequence[j].midRollStartTime + " <= " + time + " && " + this.requestsSequence[j].loaded + " == false");
					if(this.requestsSequence[j].adPosition == "midRoll" && this.requestsSequence[j].midRollStartTime <= time && this.requestsSequence[j].loaded == false){
						this.currentLoadedRequest = 0;
						this.currentMidRollLoadTime = time;
						this.adCallback = function(){
							Util.log("MidRoll adCallback " + that.midRollsAreLoading);
							that.midRollsAreLoading = false;
						};
						this.midRollsAreLoading = true;
						this.loadNextAdRequest("midRoll");
						break;
					}
				}
			}
            
		}
	};
	// should be called every second or shorter for firing the tracking points
	this.setMidRollCallback = function(midRollCallback) {
		this.midRollCallback = midRollCallback;
	};
	// requests to call the impression tracking points on start of an ad
	this.fireImpressions = function() {
		this.trackingController.fireImpressions();
	};
	this.cancelAds = function() {
		this.adModel.cancelAll();
	}	
	// should be called before a new noncommercial video is started and a new AdCall is requested
	this.resetAds = function() {
		this.activeStreamIndex = 0;
		this.currentStreamIndex = 0;
		this.playlist = new Array();

		this.requestsSequence = new Array();
		this.currentLoadedRequest = 0;

		this.preRollSequenceIndex = 0;
		this.midRollSequenceIndex = 0;
		this.postRollSequenceIndex = 0;

		this.midRollsPlayed = 0;
		this.midRollStartTimes = new Array();
		this.midRollsAreLoading = false;
		this.currentMidRollLoadTime = 0;

		this.adModel.resetAll();
		this.trackingController.resetAll();
	};
}
/*
 * urlValue => Array of url and bitrate of video clips
 * [{ bitrate : bitrate, url : url }]
 * detail => some Title of the clip
 * adPosition => preRoll, postRoll or other
 */
var VideoAd = function (urlValues, detail, adPosition, startTime, midRollStartTime) {
	this.urls = urlValues;
	this.detail = detail;
	this.streamIndex = -1;
	this.adPosition = adPosition;
    this.jsonp = false;
	this.trackingPoints = [];
	this.impressions = [];
	this.clickThroughTrackingPoints = [];
	this.played = false;
	this.startTime = startTime ? startTime : 0;
    this.midRollStartTime = midRollStartTime;
	this.companionAdsItems = [];
}
var OverlayAd = function (urlValues, detail, adPosition, startTime, duration) {
	this.urls = urlValues;
	this.detail = detail;
	this.adPosition = adPosition;
	this.trackingPoints = [];
	this.impressions = [];
	this.clickThroughTrackingPoints = [];
	//this.jsonp = jsonp;
	this.played = false;
	this.startTime = startTime ? startTime : 0;
	this.duration = duration ? duration : 5;
	this.showed = false;
}
var AdModel = function (){//appName) {
	var xhrToolKitObj = null;
	this.adModelCallback = null;
	this.linearAdItems = [];
	this.wrapperAdItems = [];
	this.overlayAdItems = [];
    this.overlayWrapperAdItems = [];
	this.companionAdItems = [];
	this.isWrapperRequest = false;
	//this.cookieHandler = new CookieHandler(appName);
	this.nState = STATE_INIT;
	this.adCallTimeout = null;
	this.ajaxCall = null;
	
	// parsing data, save to model, and execute callback function
	this.onReceiveData = function (bSuccess, adRequest) {
		Util.log("AdModel.onReceiveData("+bSuccess+") " + adRequest.json);

		if (bSuccess) {
			var responseXML = xhrToolKitObj.getResponseXML();
			var responseDoc = responseXML.documentElement;
			var xmlString = xhrToolKitObj.getXHRObj().responseText;
			Util.log("-------------- AdModel responseXML " + xmlString);

			/*var header = xhrToolKitObj.getResponseHeader();
			if(header) {
				var cookieString = header.substring(header.indexOf("Cookie:")+8, header.length);
				var cookie = cookieString.substring(0, cookieString.indexOf(";"));
				this.cookieHandler.writeCookie(cookie, adRequest.marketer);
			}*/
			adRequest.loaded = true;
			this.parseData(responseDoc, adRequest);
		} else if(adRequest.json == false) {
			//this.adModelCallback();
		}
		//Util.log("AdModel.onReceiveData() End");
	};
	
	// send XHR request
	this.getAdData = function (adRequest, currentLoadedRequest, callback) {
		this.adModelCallback = callback;
		this.adRequest = adRequest;
		if(this.currentLoadedRequest != currentLoadedRequest) {
			this.wrapperAdItems = new Array();
			this.isWrapperRequest = true;
		} else {
			this.isWrapperRequest = false;
		}
		this.currentLoadedRequest = currentLoadedRequest;
		linearAdItem = null;
		//var adUrl = url.replace(/\[timestamp\]/g, (new Date()).getTime());
		var adUrl = adRequest.url;

		this.nState = STATE_WAITING;

		Util.log("AdModel.getAdData " +adUrl);
		if (this.adCallTimeout) {
		  clearTimeout(this.adCallTimeout);
	    }
		this.adCallTimeout = setTimeout('jsonp_callback_timeout()', '2000');
		
		var that = this;
		if(adRequest.json == true) {
			if (this.ajaxCall) {
			  this.ajaxCall.abort();
			}
			this.ajaxCall = $.ajax({
				dataType: 'jsonp',
				jsonp: false,
				jsonpCallback: 'jsonp_callback',				
				//cache: true,
				url: adUrl,
				crossDomain: true,
				success: function (j) {					
//					Util.log("******************* success " + j);
				},
			});
		} else {
			xhrToolKitObj = new XHRToolKit( function (result) {
				that.onReceiveData(result, that.adRequest);
			});
			//xhrToolKitObj.createXHRObject(adUrl, this.cookieHandler.readCookie(this.adRequest.marketer));
            xhrToolKitObj.createXHRObject(adUrl);
			xhrToolKitObj.send();
		}
	};
	this.onJSONPResponse = function(jsonpResponse, adRequest){
		if (this.nState != STATE_WAITING) {
		  return;			
		}
		this.nState = STATE_READY;
		
		var result;
		if(typeof(jsonpResponse) == "object"){
			result = jsonpResponse.contents;
		}else{
			result = '<?xml version="1.0"?> <VAST version="2.0"> <Ad id="EWAD"> <InLine> <AdSystem>EW</AdSystem> <AdTitle>SAMPLE</AdTitle> <Creatives> <Creative> </Creative> </Creatives> <Impression id="SMARTCLIP"><![CDATA[http://stats.smartclip.net/stats/beacon?709;11040;400x320;1184521;2529199;0;1662365331]]></Impression></InLine> </Ad> </VAST>';
		}
		Util.log(result);
		var responseDoc = new DOMParser().parseFromString(result, 'text/xml');
		Util.log(responseDoc.firstChild);
		this.parseData(responseDoc.firstChild, adRequest);

	}
	// parses the XMLResponse
	this.parseData = function(responseDoc, adRequest) {
		if (this.adCallTimeout) {
		  clearTimeout(this.adCallTimeout);	
		}		

		var linearAdItem = null;

		if (responseDoc) {
			//Util.log("responseDoc.nodeName " + responseDoc.nodeName);
			if(responseDoc.nodeName == "content") {
				this.parseSmartclipData(responseDoc, adRequest);
			} else {
				this.parseVASTData(responseDoc, adRequest);
			}
		}

		//this.adModelCallback(linearAdItem);
	}
	// creates a VideoAd Object
	this.createAdItem = function(adUrl, adDetails, adPosition, midRollStartTime) {
		if(adUrl) {
			Util.log("createAdItem AdModel adUrl " + adUrl + " " + adPosition);
			var linearAdItem = new VideoAd(adUrl, adDetails, adPosition, 0, midRollStartTime);
			return linearAdItem;
		}
	}
	// creates an Overlay Object
	this.createOverlayAdItem = function(adUrl, adDetails, adPosition, startTime, duration) {
		if(adUrl) {
			Util.log("createOverlayAdItem AdModel adUrl " + adUrl + " " + adPosition + " " + startTime + " " + duration);
			var overlayAdItem = new OverlayAd(adUrl, adDetails, adPosition, startTime, duration);
			return overlayAdItem;
		}
	}
	// initialize a VideoAd Object and ads it to a array with the clips
	this.initOverlayAdItem = function(adUrl, adDetails, adPosition, trackingPoints, impressions, clickThroughTrackingPoints, jsonp, isWrapper, startTime, duration) {
		Util.log("<<<<<< initOverlayAdItem AdModel adUrl " + adUrl + " "  + adPosition +" " + trackingPoints.length + " " + startTime + " " + duration);
		var overlayAdItem = this.createOverlayAdItem(adUrl, adDetails, adPosition, startTime, duration);
		overlayAdItem.trackingPoints = trackingPoints;
		overlayAdItem.impressions = impressions;
		overlayAdItem.clickThroughTrackingPoints = clickThroughTrackingPoints;
		overlayAdItem.jsonp = jsonp;
		/*if(isWrapper == true) {
			Util.log("isWrapper");
			this.wrapperOverlayAdItems.push(overlayAdItem);
		} else {
			Util.log("noWrapper " + this.wrapperAdItems.length);
			if(this.wrapperAdItems.length > 0) {
				this.mergeOverlayAdItems(overlayAdItem);
			}
			this.overlayAdItems.push(overlayAdItem);
		}*/
        this.overlayAdItems.push(overlayAdItem);
	}
	// initialize a VideoAd Object and ads it to a array with the clips
	this.initAdItem = function(adUrl, adDetails, adPosition, trackingPoints, impressions, clickThroughTrackingPoints, jsonp, companionAdsItems, isWrapper, midRollStartTime) {
		Util.log("<<<<<< initAdItem AdModel adUrl " + adUrl + " "  + adPosition +" " + trackingPoints.length + " " + companionAdsItems.length);
		var linearAdItem = this.createAdItem(adUrl, adDetails, adPosition, midRollStartTime);
		linearAdItem.trackingPoints = trackingPoints;
		linearAdItem.impressions = impressions;
		linearAdItem.clickThroughTrackingPoints = clickThroughTrackingPoints;
		linearAdItem.jsonp = jsonp;
		linearAdItem.companionAdsItems = companionAdsItems;
		if(isWrapper == true) {
			Util.log("isWrapper");
			this.wrapperAdItems.push(linearAdItem);
		} else {
			Util.log("noWrapper " + this.wrapperAdItems.length);
			if(this.wrapperAdItems.length > 0) {
				this.mergeVast2AdItems(linearAdItem);
			}
			this.linearAdItems.push(linearAdItem);

		}
	}
	this.mergeVast2AdItems = function(linearAdItem) {
		//var wrapperTrackingPoints = new Array();
		//var wrapperImpressions = new Array();
		Util.log("mergeVast2AdItems " + this.wrapperAdItems.length);
		for(var i = 0; i < this.wrapperAdItems.length; i++) {
			var tempWrapperAdItem = this.wrapperAdItems[i];
			for(var j=0; j<tempWrapperAdItem.trackingPoints.length; j++) {
				Util.log(tempWrapperAdItem.trackingPoints[j]);
				linearAdItem.trackingPoints.push(tempWrapperAdItem.trackingPoints[j]);
			}
			for(var k = 0; k<tempWrapperAdItem.impressions.length; k++) {
				linearAdItem.impressions.push(tempWrapperAdItem.impressions[k]);
			}
			for(var k = 0; k<tempWrapperAdItem.clickThroughTrackingPoints.length; k++) {
				linearAdItem.impressions.push(tempWrapperAdItem.clickThroughTrackingPoints[k]);
			}
			for(var k = 0; k<tempWrapperAdItem.companionAdsItems.length; k++) {
				linearAdItem.companionAdsItems.push(tempWrapperAdItem.companionAdsItems[k]);
			}
		}
		this.wrapperAdItems = new Array();
	}
	this.parseSmartclipData = function(responseDoc, adRequest) {
		Util.log("parseSmartclipData " + adRequest.adPosition);

		var companionAds = responseDoc.getElementsByTagName("Companion");
		var companionAdsItems = this.parseCompanionAds(companionAds);
		var adDetails = responseDoc.getElementsByTagName("ad_details");
		for(var i=0; i<adDetails.length; i++) {
			this.parseSmartclipAdDetail(adDetails[i], companionAdsItems, adRequest);
		}
		this.adModelCallback();
	}
	this.parseSmartclipAdDetail = function(adDetails, companionAdsItems, adRequest) {
		var trackingPoints = new Array();
		var impressions = new Array();
		var clickThroughTrackingPoints = new Array();
		var adUrl = {
			bitrate : 0,
			url : adDetails.getAttribute("imageUrl"),
			targetUrl : adDetails.getAttribute("targetUrl")
		};
		Util.log("adUrl " + adUrl.url);
		if(adUrl.url != "") {
			var itemElements = adDetails.getElementsByTagName("agencyTracker");
			if(itemElements) {
				Util.log("itemElements " + itemElements.length);
				for( i=0;  i < itemElements.length; i++) {
					var agencyTrackerUrl = encodeURI(itemElements[i].getAttribute("url"));
					var trackerProgress = itemElements[i].getAttribute("progress");
					Util.log(trackerProgress + " " + agencyTrackerUrl);
					trackingPoints.push({
						trackingType: "percent",
						trackingValue: trackerProgress,
						url: agencyTrackerUrl,
						isHit: false
					});
				}
			}
			if(adDetails.getAttribute("type") == "overlay") {
				this.initOverlayAdItem([adUrl], adDetails, adRequest.overlayID, trackingPoints, impressions, clickThroughTrackingPoints, adRequest.json, false, adRequest.overlayStartTime, adRequest.overlayDuration);
			} else {
				this.initAdItem([adUrl], adDetails, adRequest.adPosition, trackingPoints, impressions, clickThroughTrackingPoints, adRequest.json, companionAdsItems, false, adRequest.midRollStartTime);
			}
		}
	}
	this.parseCompanionAds = function(companionItems) {
        Util.log("parseCompanionAds " + companionItems);
		//var companionItems = companionAd.getElementsByTagName("Companion");
		var companions = new Array();
		for( i=0;  i < companionItems.length; i++) {
			var companionID = companionItems[i].getAttribute("id");
			var companionUrl = encodeURI(companionItems[i].getElementsByTagName("StaticResource")[0].firstChild.data);
            Util.log("companionID " + companionID + " " +companionUrl);
			companions.push({
				id: companionID,
				url: companionUrl
			});
		}
		return companions;
	}
    this.parseVastCompanionAds = function(companionItems, vastVersion) {
        Util.log("parseVastCompanionAds " + companionItems);
		//var companionItems = companionAd.getElementsByTagName("Companion");
		var companions = new Array();
		for( i=0;  i < companionItems.length; i++) {
			var companionID = companionItems[i].getAttribute("id");
			var companionUrl = encodeURI(companionItems[i].getElementsByTagName("StaticResource")[0].getElementsByTagName("URL")[0].firstChild.data);
            Util.log("companionID " + companionID + " " +companionUrl);
			companions.push({
				id: companionID,
				url: companionUrl
			});
		}
		return companions;
	}
	this.parseVASTData = function(responseDoc, adRequest) {
		Util.log("----------- parseVASTData " + responseDoc.nodeName);
		var adItems = responseDoc.getElementsByTagName("Ad");
		for(var i=0; i<adItems.length; i++) {
			if(responseDoc.nodeName == "VAST") {
				Util.log("parse Vast2");
				this.parseAd_Vast2(adItems[i], adRequest);
			} else {
				Util.log("parse Vast1");
				this.parseAd_Vast1(adItems[i], adRequest);
			}
		}
	}
	this.parseAd_Vast1 = function(ad, adRequest) {
		if(ad.hasChildNodes() == true) {
			if (ad.getElementsByTagName("Wrapper").length > 0) {
				this.parseWrapperAd_Vast1(ad, adRequest);
			} else {
				//this.parseLinearAd_Vast1(ad, adPosition, false);
				var impressions = this.parseImpressions(ad.getElementsByTagName("Impression")[0].getElementsByTagName("URL"));
				var clickThroughTrackingPoints = new Array();
				try{
					clickThroughTrackingPoints = this.parseClickThrough(ad.getElementsByTagName("ClickTracking")[0].getElementsByTagName("URL"));
				}
				catch(e){}				
				this.createAds_Vast(ad.getElementsByTagName("Video"), ad.getElementsByTagName("Video"), ad.getElementsByTagName("Companion"), adRequest, impressions, clickThroughTrackingPoints, 1, false);
				this.adModelCallback();
			}
		}

	}
	this.parseWrapperAd_Vast1 = function(ad, adRequest) {
		Util.log("parseWrapperAd_Vast1 " + ad.getElementsByTagName("VASTAdTagURL")[0].getElementsByTagName("URL")[0].firstChild.data);
		try {
			var wrapperAdUrl = ad.getElementsByTagName("VASTAdTagURL")[0].getElementsByTagName("URL")[0].firstChild.data;
		} catch(e) {
			Util.log("Error on get VASTAdTagURL");
		}
		//this.parseLinearAd_Vast1(ad, adPosition, true);
		var impressions = this.parseImpressions(ad.getElementsByTagName("Impression")[0].getElementsByTagName("URL"));
		var clickThroughTrackingPoints = new Array();
		try{
			clickThroughTrackingPoints = this.parseClickThrough(ad.getElementsByTagName("ClickTracking")[0].getElementsByTagName("URL"));
		}
		catch(e){}
		var trackingPoints = this.parseTracking_VAST1(ad.getElementsByTagName("Tracking"));
		this.initAdItem([], "", adRequest.adPosition, trackingPoints, impressions, clickThroughTrackingPoints, adRequest.json, null, true);
		if(wrapperAdUrl != null) {
			var wrapperAdRequest = new AdRequest(wrapperAdUrl, adRequest.adPosition, adRequest.json)
			this.getAdData(wrapperAdRequest, this.currentLoadedRequest, this.adModelCallback);
		}
	}
	this.parseAd_Vast2 = function(ad, adRequest) {
		Util.log("parseAd_Vast2 " + ad.getElementsByTagName("InLine").length);
		if (ad.getElementsByTagName("Wrapper").length > 0) {
			this.parseWrapperAd_Vast2(ad, adRequest);
		} else {
			this.parseLinearAd_Vast2(ad, adRequest);
			//this.parseNonLinearAd_Vast2(ad, adRequest);
			this.adModelCallback(linearAdItem);

		}
	}
	this.parseWrapperAd_Vast2 = function(ad, adRequest) {
		Util.log("parseWrapperAd_Vast2 " + ad.getElementsByTagName("VASTAdTagURI")[0].firstChild.data);
		try {
			var wrapperAdUrl = ad.getElementsByTagName("VASTAdTagURI")[0].firstChild.data;
		} catch(e) {
			Util.log("Error on get VASTAdTagURI");
		}
		this.parseLinearAd_Vast2(ad, adRequest, true);
		//this.parseNonLinearAd_Vast2(ad, adRequest, true);
		if(wrapperAdUrl != null) {
			var wrapperAdRequest = new AdRequest(wrapperAdUrl, adRequest.adPosition, adRequest.json)
			this.getAdData(wrapperAdRequest, this.currentLoadedRequest, this.adModelCallback);
		}
	}
	this.parseLinearAd_Vast2 = function(ad, adRequest, isWrapper) {
		var impressions = this.parseImpressions(ad.getElementsByTagName("Impression"));
		var clickThroughTrackingPoints = this.parseClickThrough(ad.getElementsByTagName("ClickTracking"));
		var creativesList = ad.getElementsByTagName("Creatives");
		Util.log("parseLinearAd_Vast2 " +  creativesList.length);
        this.createAds_Vast( ad.getElementsByTagName("Linear"),  ad.getElementsByTagName("NonLinear"),  ad.getElementsByTagName("Companion"), adRequest, impressions, clickThroughTrackingPoints, 2, isWrapper);

	}
	this.parseImpressions = function(impressionList) {
		//Util.log("parseImpressions");
		var result = new Array();
		//var impressionList = ad.getElementsByTagName("Impression");
		if(impressionList) {
			//Util.log("impressionList " + impressionList.length);
			for(var i=0; i<impressionList.length; i++) {
				var impressionElement = impressionList[i];
				//Util.log("Impression " + impressionElement.getAttribute("id") + " " +  impressionElement.firstChild.data);
				result.push({
					trackingType: "impression",
					trackingValue: impressionElement.getAttribute("id"),
					url: impressionElement.firstChild.data,
					isHit: false
				});
			}
		}
		return result;
	}
	this.parseClickThrough = function(clickThroughList) {
		Util.log("parseClickThrough " + clickThroughList);
		var result = new Array();
		if(clickThroughList) {
			for(var i=0; i<clickThroughList.length; i++) {
				var clickThroughElement = clickThroughList[i];
				result.push({
					trackingType: "clickThrough",
					trackingValue: clickThroughElement.getAttribute("id"),
					url: clickThroughElement.firstChild.data,
					isHit: false
				});
			}
		}
		Util.log("parseClickThrough " + result.length);
		return result;
	}
	this.createAds_Vast = function(linearAds, nonLinearAds, companionAds, adRequest, impressions, clickThroughTrackingPoints, vastVersion, isWrapper) {
		Util.log("createAds_Vast " + linearAds.length);
		var companionAdsItems = [];
		if(vastVersion == 2){
            companionAdsItems = this.parseCompanionAds(companionAds);
		}
        else{
            companionAdsItems = this.parseVastCompanionAds(companionAds);
        }
        Util.log("bong " +linearAds.length );
		if(linearAds.length > 0) {
			for(var i=0; i< linearAds.length; i++) {
				var linearVideoAd = linearAds[i];
				var urls = new Array();
				var mediaFiles = linearVideoAd.getElementsByTagName("MediaFile");
				var clickThrough = linearVideoAd.getElementsByTagName("ClickThrough")[0];
				if(mediaFiles) {
					for(var j = 0; j < mediaFiles.length; j++) {
						var mediaFile = mediaFiles[j];
						if(vastVersion == 2) {
							urls.push(this.parseMediaFile_VAST2(mediaFile, clickThrough));
						} else if(mediaFile.getAttribute("delivery") != "static"){
							urls.push(this.parseMediaFile_VAST1(mediaFile, clickThrough));
						}
					}
					//Util.log(mediaFiles.length + " mediaFiles");
				}
				var trackingEvents = linearVideoAd.getElementsByTagName("Tracking");
				if(vastVersion == 2) {
					var trackingPoints = this.parseTracking_VAST2(trackingEvents);//new Array();
				} else {
					var trackingPoints = this.parseTracking_VAST1(trackingEvents);
				}
                Util.log("------------------ Bing ---------------");
				this.initAdItem(urls, "", adRequest.adPosition, trackingPoints, impressions, clickThroughTrackingPoints, adRequest.json, companionAdsItems, isWrapper, adRequest.midRollStartTime);
			}
		}
		if(nonLinearAds.length > 0) {
			for(var i=0; i< nonLinearAds.length; i++) {
            	var nonLinearVideoAd = nonLinearAds[i];
				var adUrl = "";
				if(vastVersion == 1) {
					var mediaFiles = linearVideoAd.getElementsByTagName("MediaFile");
                    //Util.log("mediaFiles " + mediaFiles);
					if(mediaFiles) {
						for(var j = 0; j < mediaFiles.length; j++) {
							var mediaFile = mediaFiles[j];
                            //Util.log("mediaFile " + mediaFile + " " + mediaFile.getAttribute("delivery"));
							if(mediaFile.getAttribute("delivery") == "static") {
                                Util.log("url "  + mediaFile.getElementsByTagName("URL")[0].firstChild.data);
								adUrl = {
                                    url : mediaFile.getElementsByTagName("URL")[0].firstChild.data
                                 };
							}
						}
					}
				} else {
					adUrl = {
                        url : nonLinearAds[i].getElementsByTagName("StaticResource")[0].firstChild.data
                    };
				}
                try{
                    var trackingEvents = nonLinearVideoAd.getElementsByTagName("Tracking");
                }
                catch(e){
                    var trackingEvents = [];
                }
				if(vastVersion == 2) {
					var trackingPoints = this.parseTracking_VAST2(trackingEvents);//new Array();
				} else {
					var trackingPoints = this.parseTracking_VAST1(trackingEvents);
				}
				this.initOverlayAdItem([adUrl], "", adRequest.overlayID, trackingPoints, impressions, clickThroughTrackingPoints, adRequest.json, false, adRequest.overlayStartTime, adRequest.overlayDuration);
			}
		}
	}
	this.parseMediaFile_VAST2 = function(mediaFile, clickThrough) {
		Util.log("parseMediaFile_VAST2 " + parseInt(mediaFile.getAttribute("bitrate")) + " " + mediaFile.firstChild.data + " " + clickThrough.firstChild.data);
		return {
			bitrate : parseInt(mediaFile.getAttribute("bitrate")),
			url : mediaFile.firstChild.data,
			targetUrl: clickThrough.firstChild.data
		};
	}
	this.parseMediaFile_VAST1 = function(mediaFile, clickThrough) {
		Util.log("parseMediaFile_VAST1 " + parseInt(mediaFile.getAttribute("bitrate")) + " " +mediaFile.getElementsByTagName("URL")[0].firstChild.data) + " " + clickThrough.getElementsByTagName("URL")[0].firstChild.data;
		return {
			bitrate : parseInt(mediaFile.getAttribute("bitrate")),
			url : mediaFile.getElementsByTagName("URL")[0].firstChild.data,
			targetUrl: clickThrough.getElementsByTagName("URL")[0].firstChild.data
		};
	}
	this.parseTracking_VAST2 = function(trackingEvents) {
		var result = new Array();
		if(trackingEvents) {
			for(var j = 0; j < trackingEvents.length; j++) {
				var trackingEvent = trackingEvents[j];
				// only use if there is a url
				if (trackingEvent.firstChild.nodeValue) {				
					Util.log("trackingEvent.firstChild.nodeValue " + trackingEvent.getAttribute("event") + " " + trackingEvent.firstChild.nodeValue);
					result.push({
						trackingType: trackingEvent.getAttribute("event"),
						trackingValue: trackingEvent.getAttribute("event"),
						url: trackingEvent.firstChild.nodeValue,
						isHit: false
					});				
				}
			}
		}
		return result;
	}
	this.parseTracking_VAST1 = function(trackingEvents) {
		var result = new Array();
		if(trackingEvents) {
			for(var j = 0; j < trackingEvents.length; j++) {
				var trackingEvent = trackingEvents[j];
				var eventType = trackingEvent.getAttribute("event");
				var urls = trackingEvent.getElementsByTagName("URL");
				for(var i=0; i<urls.length; i++) {
					//Util.log("trackingEvent " + eventType + " " + urls[0].firstChild.data);
					result.push({
						trackingType: eventType,
						trackingValue: eventType,
						url: urls[0].firstChild.data,
						isHit: false
					});
				}
			}
		}
		return result;
	}
	this.getMediaFile = function(activeStreamIndex) {
		for(var i=0; i< this.linearAdItems.length; i++) {
			if(this.linearAdItems[i].streamIndex == activeStreamIndex) {
				return this.linearAdItems[i].urls[0].url;
			}
		}
		return null;
	}
	this.getCompanionAds = function(activeStreamIndex) {
		for(var i=0; i< this.linearAdItems.length; i++) {
			if(this.linearAdItems[i].streamIndex == activeStreamIndex) {
				return this.linearAdItems[i].companionAdsItems;
			}
		}
		return null;
	}
	this.isJSONP = function(activeStreamIndex) {
		for(var i=0; i< this.linearAdItems.length; i++) {
			//Util.log(this.linearAdItems[i].streamIndex);
			if(this.linearAdItems[i].streamIndex == activeStreamIndex) {
				return this.linearAdItems[i].jsonp;
			}
		}
		return false;
	}
	this.isOverlayJSONP = function(adPosition) {
		for(var i=0; i< this.overlayAdItems.length; i++) {
			if(this.overlayAdItems[i].adPosition == adPosition) {
				return this.overlayAdItems[i].jsonp;
			}
		}
		return false;
	}
	this.getTrackingPoints = function(activeStreamIndex) {
		Util.log("AdModel.getTrackingPoints " + activeStreamIndex + " " + this.linearAdItems.length);
		for(var i=0; i< this.linearAdItems.length; i++) {
			Util.log(this.linearAdItems[i].streamIndex + " " + activeStreamIndex);
			if(this.linearAdItems[i].streamIndex == activeStreamIndex) {
				return this.linearAdItems[i].trackingPoints;
			}
		}
		return new Array();
	}
	this.getImpressions = function(activeStreamIndex) {
		for(var i=0; i< this.linearAdItems.length; i++) {
			if(this.linearAdItems[i].streamIndex == activeStreamIndex) {
				return this.linearAdItems[i].impressions;
			}
		}
		return new Array();
	}
	this.getOverlayTrackingPoints = function(adPosition) {
		Util.log("AdModel.getOverlayTrackingPoints " + adPosition + " " + this.overlayAdItems.length);
		for(var i=0; i< this.overlayAdItems.length; i++) {
			Util.log(this.overlayAdItems[i].adPosition);
			if(this.overlayAdItems[i].adPosition == adPosition) {
				Util.log(this.overlayAdItems[i].trackingPoints + " " + this.overlayAdItems[i].trackingPoints.length);
				return this.overlayAdItems[i].trackingPoints;
			}
		}
		return new Array();
	}
	this.getOverlayImpressions = function(adPosition) {
		for(var i=0; i< this.overlayAdItems.length; i++) {
			if(this.overlayAdItems[i].adPosition == adPosition) {
				return this.overlayAdItems[i].impressions;
			}
		}
		return new Array();
	}
	this.getClickThroughTrackingPoints = function(activeStreamIndex) {
		Util.log("getClickThroughTrackingPoints");
		for(var i=0; i< this.linearAdItems.length; i++) {
			if(this.linearAdItems[i].streamIndex == activeStreamIndex) {
				Util.log("getClickThroughTrackingPoints 2 " + this.linearAdItems[i].clickThroughTrackingPoints);
				return this.linearAdItems[i].clickThroughTrackingPoints;
			}
		}
		return new Array();
	}
	this.getOverlayClickThroughTrackingPoints = function(adPosition) {
		for(var i=0; i< this.overlayAdItems.length; i++) {
			if(this.overlayAdItems[i].adPosition == adPosition) {
				return this.overlayAdItems[i].clickThroughTrackingPoints;
			}
		}
		return new Array();
	}
	this.getLinearAdItems = function() {
		return this.linearAdItems;
	}
	this.getOverlay = function(adPosition) {
		for(var i=0; i< this.overlayAdItems.length; i++) {
			if(this.overlayAdItems[i].adPosition == adPosition) {
				return this.overlayAdItems[i];
			}
		}
		return new Array();
	}
	this.getOverlays = function() {
		if(this.overlayAdItems.length > 0) {
			return this.overlayAdItems;
		}
		return new Array();
	}
	this.cancelAll = function() {
		this.nState = STATE_INIT;
	}
	this.resetAll = function() {
		this.nState = STATE_INIT;
		
		this.linearAdItems = new Array();
		this.wrapperAdItems = new Array();
	}
}
var TrackingController = function () {

    this.trackingModel = new TrackingModel();
    this.duration = 0;
	this.jsonp = false;

	this.setJSONP = function(jsonp){
		this.jsonp = jsonp;
	}
    this.setTrackingPoints = function(trackingPoints){
        Util.log("setTrackingPoints " + trackingPoints + " " + trackingPoints.length);
        this.trackingModel.setTrackingPoints(trackingPoints);
    }
    this.setImpressions = function(impressions){
        this.trackingModel.setImpressions(impressions);
    }
    this.setClickThroughTrackingPoints = function(clickThroughTrackingPoints){
        this.trackingModel.setClickThroughTrackingPoints(clickThroughTrackingPoints);
    }
    this.setDuration = function(duration){
        this.duration = duration;
    }
    // fire impression tracking points on start of an ad
    this.fireImpressions = function(){
        this.impressions = this.trackingModel.getImpressions();
		Util.log("fireImpressions " + this.impressions.length);
        for(var i=0; i< this.impressions.length; i++){
            Util.log("fireImpression " + this.impressions[i].url);
			if (this.jsonp == true) {
				$.ajax({
					dataType: 'jsonp',
					jsonp: false,
					crossDomain: true,
					url: encodeURI(this.impressions[i].url),
					async: true,
					success: function(j){
					//Util.log("success " + j);
					},
				});
			}
			else {
            	var xhrToolKitObj = new XHRToolKit(function (result) {});
            	xhrToolKitObj.sendXHRRequest(encodeURI(this.impressions[i].url));
			}
            
        }
    }
	// fire tracking points based on the played time
    this.fireTimeTrackingPoints = function(time){
        var percentProgress = Math.round((100/this.duration)*time);
        var trackingPoints = this.trackingModel.getActiveTrackingPoints(percentProgress);
        //Util.log(this.duration + " " +  time/1000 + " " + percentProgress + " %" + " " + trackingPoints.length);
        for(i=0; i<trackingPoints.length; i++){
            Util.log("fireTimeTrackingPoints " + trackingPoints[i].url);
            if (this.jsonp == true) {
				$.ajax({
					dataType: 'jsonp',
					jsonp: false,
					crossDomain: true,
					url: encodeURI(trackingPoints[i].url),
					async: true,
					success: function(j){
					//Util.log("success " + j);
					},
				});
			}
			else {
	            var xhrToolKitObj = new XHRToolKit(function (result) {});
	            xhrToolKitObj.sendXHRRequest(encodeURI(trackingPoints[i].url));
			}
        }
    }
	// fire tracking points based on a event like firstQuartile, midpoint, thirdQuartile, complete, mute, pause or close
    this.fireEventTrackingPoints = function(eventLabel){
        var trackingPoints = this.trackingModel.getEventTrackingPoints(eventLabel);
        //Util.log(eventLabel +" " + trackingPoints.length);
        for(i=0; i<trackingPoints.length; i++){
            Util.log("fireEventTrackingPoints " + trackingPoints[i].url);
            if (this.jsonp == true) {
				$.ajax({
					dataType: 'jsonp',
					jsonp: false,
					crossDomain: true,
					url: encodeURI(trackingPoints[i].url),
					async: true,
					success: function(j){
					//Util.log("success " + j);
					},
				});
			}
			else {
				var xhrToolKitObj = new XHRToolKit(function(result){});
				xhrToolKitObj.sendXHRRequest(encodeURI(trackingPoints[i].url));
			}
        }
    }
    // fire relevant Tracking Points for an ClickThrough
    this.fireClickThroughTrackingPoints = function(){
        var clickThroughTrackingPoints = this.trackingModel.getClickThroughTrackingPoints();
        Util.log("fireClickThroughTrackingPoints " + clickThroughTrackingPoints.length);
        for(i=0; i<clickThroughTrackingPoints.length; i++){
            Util.log("fireClickThroughTrackingPoints " + clickThroughTrackingPoints[i].url);
            if (this.jsonp == true) {
				$.ajax({
					dataType: 'jsonp',
					jsonp: false,
					crossDomain: true,
					url: encodeURI(clickThroughTrackingPoints[i].url),
					async: true,
					success: function(j){
					//Util.log("success " + j);
					},
				});
			}
			else {
				var xhrToolKitObj = new XHRToolKit(function(result){});
				xhrToolKitObj.sendXHRRequest(encodeURI(clickThroughTrackingPoints[i].url));
			}
        }
    }
    this.resetAll = function(){
        this.duration = 0;
        this.trackingModel.resetAll();
    }
}
var TrackingModel = function () {

    this.impressions = new Array();
    this.trackingPoints = new Array();

    this.setImpressions = function(impressions){
        this.impressions = impressions;
    }
    this.getImpressions = function(){
        return this.impressions;
    }
	
    this.setClickThroughTrackingPoints = function(clickThroughTrackingPoints){
        this.clickThroughTrackingPoints = clickThroughTrackingPoints;
    }
    this.getClickThroughTrackingPoints = function(){
        return this.clickThroughTrackingPoints;
    }
    
    this.setTrackingPoints = function (trackingPoints) {
        this.trackingPoints = trackingPoints;
    
    }
    this.resetAll = function () {
        this.impressions = new Array();
        this.trackingPoints = new Array();
    }
	// returns the tracking points for the events like firstQuartile, midpoint, thirdQuartile, complete, mute, pause or close
    this.getEventTrackingPoints = function(eventLabel){
        var result = [];
        //Util.log("getActiveTrackingPoints " + trackingValue);
        for(i=0; i<this.trackingPoints.length; i++){
            if(this.trackingPoints[i].isHit == false){
                    if(this.trackingPoints[i].trackingType == eventLabel){
                        result.push(this.trackingPoints[i]);
                    }
            }
        }
        return result;
    }
	// returns all tracking points based on a time
    this.getActiveTrackingPoints = function (trackingValue) {
        var result = [];
        //Util.log("getActiveTrackingPoints " + trackingValue);
        for(i=0; i<this.trackingPoints.length; i++){
            //Util.log(this.trackingPoints[i].isHit  + " " + this.trackingPoints[i].trackingType + " " + this.trackingPoints[i].trackingValue);
            if(this.trackingPoints[i].isHit == false){
                //if(trackingType == this.trackingPoints[i].trackingType){
                    switch(this.trackingPoints[i].trackingType){
                        case "percent":
                            if(this.trackingPoints[i].trackingValue <= trackingValue){
                                this.trackingPoints[i].isHit = true;
                                result.push(this.trackingPoints[i]);
                            }
                            break;
                        case "start":
                            this.trackingPoints[i].isHit = true;
                            result.push(this.trackingPoints[i]);
                            break;
                        case "firstQuartile":
                            if(trackingValue >= (100/4)){
                                this.trackingPoints[i].isHit = true;
                                result.push(this.trackingPoints[i]);
                            }
                            break;
                        case "midpoint":
                            if(trackingValue >= (100/2)){
                                this.trackingPoints[i].isHit = true;
                                result.push(this.trackingPoints[i]);
                            }
                            break;
                        case "thirdQuartile":
                            if(trackingValue >= (100/4*3)){
                                this.trackingPoints[i].isHit = true;
                                result.push(this.trackingPoints[i]);
                            }
                            break;
                        case "complete":
                             if(trackingValue >= this.duration && trackingValue > 0){
                                this.trackingPoints[i].isHit = true;
                                result.push(this.trackingPoints[i]);
                             }
                            break;
                        default:
                            break;
                   }
                //}
            }
        }
        return result;
    }

}
// UTIL OBJECT
var Util = {};

Util.log = function(msg) {	
	try{
		document.getElementById("outputMessage").innerHTML = msg;
	}
	catch(e){}
	if (typeof(console) !== 'undefined' && console != null) {
//		console.log(msg);
	}
    else{
        //alert(msg);
    }
};
var XHRToolKit = function (pSendResultFunc) {
    var that = this;
    this.URL = "";
    this.sendResultFunc = pSendResultFunc;
    this.XHRObj = null;
    
    this.createXHRObject= function(pURL){//, cookie) {
		that.URL = pURL;
         if (that.XHRObj) {
		 	that.XHRObj.destroy();
		 }
        that.XHRObj = new XMLHttpRequest();
        
        if (that.XHRObj) {
            that.XHRObj.onreadystatechange = function () {
                //Util.log("that.XHRObj.onreadystatechange " + that.XHRObj.readyState + " " + URL);
                if (that.XHRObj.readyState == 4) {
                    //Util.log("Set-Cookie " + that.XHRObj.getResponseHeader("Set-Cookie"));
                    that.receiveXHRResponse();
                }
            };
            that.XHRObj.open("GET", that.URL, true);
	        /*if(cookie){
	            that.XHRObj.setRequestHeader("Cookie", cookie);
	        }*/
        }
        else 	{
            Util.log("XHR Object is NULL");
        }
    }
    this.send = function() {
        if (this.XHRObj) {
            //Util.log("XHRToolKit.send " + URL);
            this.XHRObj.send(null);
        }
        else 	{
            Util.log("XHR Object is NULL");
        }
    }
    this.sendXHRRequest = function(url) {
        this.createXHRObject(url);
        this.send();
    }

    this.receiveXHRResponse = function(){
        if (this.XHRObj.status == 200) {
            Util.log("Good XHR response");
            this.sendResultFunc(true);
        }
        else {
            Util.log("Bad XHR response.");
            this.sendResultFunc(false);
        }
    }
    
    this.getResponseXML = function () {
        return this.XHRObj.responseXML;
    }
	this.getResponseHeader = function() {
        return this.XHRObj.getResponseHeader("Set-Cookie");
	}
	this.getXHRObj = function () {
		return this.XHRObj;
	}
    
    this.abortXHRObj = function () {
        if (this.XHRObj) {
            this.XHRObj.abort();
        }
    }
}

function jsonp_callback(j){
  AdController.onJSONPResponse(j);  
}

function jsonp_callback_timeout(j){
  AdController.onJSONPResponse(j);  
}