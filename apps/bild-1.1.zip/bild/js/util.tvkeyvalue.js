/* DEPRECATED */
var TVKeyValue = {
    KEY_RETURN : 0,
    KEY_ENTER : 13,
    KEY_UP : 38,
    KEY_DOWN : 40,
    KEY_LEFT : 37,
    KEY_RIGHT : 39,
    
    KEY_ENTER_SAMSUNG: 29443,
    KEY_UP_SAMSUNG: 29460,
    KEY_DOWN_SAMSUNG: 29461,
	KEY_LEFT_SAMSUNG: 4,
	KEY_RIGHT_SAMSUNG: 5,
	KEY_RETURN_SAMSUNG: 88,
	
    KEY_UP_PHILIPS : 130,
    KEY_DOWN_PHILIPS : 131,
    KEY_LEFT_PHILIPS : 132,
    KEY_RIGHT_PHILIPS : 133,
	
    KEY_PAUSE : 74,
    KEY_PAUSE_LG : 19,
    KEY_PLAY : 71,
    KEY_PLAY_PHILIPS : 415,
    KEY_STOP : 70,
    KEY_STOP_LG : 413,
    KEY_1 : 101,
    KEY_2 : 98,
    KEY_3 : 6,
    KEY_4 : 8,
    KEY_5 : 9,
    KEY_6 : 10,
    KEY_7 : 12,
    KEY_8 : 13,
    KEY_9 : 14,
    KEY_0 : 17,
    KEY_EMPTY : 0,
    
    KEY_PANEL_CH_UP : 105,
    KEY_PANEL_CH_DOWN : 106,
    KEY_PANEL_VOL_UP : 203,
    KEY_PANEL_VOL_DOWN : 204,
    KEY_PANEL_ENTER : 309,
    KEY_PANEL_SOURCE : 612,
    KEY_PANEL_MENU : 613,
    KEY_PANEL_POWER : 614,
	
	KEY_POWER : 76,
	KEY_TV : 77,
	KEY_VOL_UP : 7,
	KEY_VOL_DOWN : 11,
	KEY_CH_UP : 68,
	KEY_CH_DOWN : 65,
	
	KEY_BLUE : 406,
};

if(typeof VK_LEFT == 'undefined') { VK_LEFT = -1; }
if(typeof VK_RIGHT == 'undefined') { VK_RIGHT = -1; }
if(typeof VK_UP == 'undefined') { VK_UP = -1; }
if(typeof VK_DOWN == 'undefined') { VK_DOWN = -1; }
if(typeof VK_ENTER == 'undefined') { VK_ENTER = -1; }
if(typeof VK_PLAY == 'undefined') { VK_PLAY = -1; }