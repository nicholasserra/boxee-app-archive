var UIScrollPanel = $.inherit(
  // base

  // props
  {
    __constructor: function(options) {
	  this.options = options;
	  
	  this.bShowScroller = false;
	  this.nScrollPage = 0;
	  this.nScrollPages = 1;
	  
	  this.effectScrollList = null;
	  this.effectScrollBead = null;

	  this.elemScrollContent = $('.scrollcontent:eq(0)', this.options.elemContent);
	  this.elemScrollItems = $('.items:eq(0)', this.options.elemContent); 
	  this.elemBead = $('.scrollbead:eq(0)', this.options.elemContent); 
	  this.elemScroller = $('.scrollbar:eq(0)', this.options.elemContent); 
	  this.elemScrollerBack = $('.scrollback:eq(0)', this.options.elemContent); 
	  
	  this.nScrollAmount = 0;	
	},	

  	getCurrSel: function() {
  	  return this.nCurrSelItem;
  	},
  	
  	setScrollAmount: function(nScrollAmount) {
      this.nScrollAmount = nScrollAmount;  
  	},
  	
  	getContent: function() {
  	  return $('.items:eq(0)', this.options.elemContent);
  	},
  	
  	setContent: function(strHTML) {
  	  this.bShowScroller = false;
  	    	    	    	  
	  this.nContentHeight = this.elemScrollItems.height();
	  App.setHTML(this.elemScrollItems, strHTML);		
	  this.nContentHeight = this.elemScrollItems.height();
	  
      // reset
	  this.bShowScroller = false;
	  this.nScrollPage = 0;      
	  this.nScrollPages = 1;
	  this.elemScrollItems.css({top: "0px"});		
	  this.elemBead.css({top: "0px"});		
  	  // stop any existing animation
  	  this.elemScrollItems.stop(true);
  	  this.elemBead.stop(true);
  	  
	  if (this.nContentHeight > this.nScrollAmount) {		  
		this.nItemsPerPage = 1;
		
		this.nScrollPages = Math.ceil(this.nContentHeight / this.nScrollAmount);
				
		this.nBeadHeight = this.elemScrollerBack.height() / this.nScrollPages;
		this.elemBead.css({height: Math.round(this.nBeadHeight) + "px"});
		
		this.bShowScroller = true;
	  }      
  	},
  	
  	show: function() {
  	  this.elemScrollItems.css({visibility: "visible"});
  	  if (this.bShowScroller) {
  		if (this.elemScroller.css('visibility') == 'hidden') {
  		  this.elemScroller.css({visibility: "visible"});	
  		}  		  		
  	  }
  	  else {
   		if (this.elemScroller.css('visibility') == 'visible') {
   		  this.elemScroller.css({visibility: "hidden"});
   		}
  	  }
  	},

  	hide: function() {
  	  this.elemScrollItems.css({visibility: "hidden"});
      this.elemScroller.css({visibility: "hidden"});  			  		  
  	},
  	
    focus: function(bFocus) {
      if (bFocus) {
    	this.elemBead.addClass('focus');
      }
      else {
      	this.elemBead.removeClass('focus');    	  
      }
	},
	
    nextItem: function() {
      if (this.nScrollPage >= this.nScrollPages-1) {
    	return;
      }

      this.nScrollPage++;
      this.updateScroll();
    },

    previousItem: function() {
	  if (this.nScrollPage == 0) {	  
	    return false;
	  }

	  this.nScrollPage--;  	  
	  this.updateScroll();
	  
	  return true;
    },
    
	updateScroll: function() {
	  var nScrollPos = this.nScrollPage * this.nScrollAmount;
	  this.elemScrollItems.animate({top: -nScrollPos + "px"}, 1000, "swing");		
			
	  var nScrollBeadPos = this.nBeadHeight * this.nScrollPage;
	  this.elemBead.animate({top: nScrollBeadPos + "px"}, 1000, "swing");		
	}
	
  },
  // static props
  {    
  }
);