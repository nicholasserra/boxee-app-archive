/**
 *	Big Helper for Videoplayback
 */
//alle brauchen werbung
var AdController = new AdController('framework');
//function will be called from a loaded JSON-Request and starts the parsing of the xml-Response
function jsonp_callback(j) {
	AdController.onJSONPResponse(j);
}
 
var Videoplayer = function(arguments) {
	var defaults = {
		target: '#videofullscreen',
		videourl: false,
		imageurl: false,
		onAfterCreate: function(that) {
			//that.play();
			if(that.args.use == 'video') {
				Loading.start(that);
			}
		},
		onCanPlay: function(that) {
			Loading.stop(that);
		},
		onStreamEnd: function(that) {
			if(AdController.currentStreamIndex < AdController.playlist.length) {
				//that.stop();
				that.play();
			}
			else {
				that.trigger('stop');
			}
		},
		use: 'video',
		autoplay: true,
		preroll: true,
		adString: 0,
		firstpublicationdate: 0
	};
	this.progressTimer = null;	
	this.playing = false;
	this.args = $.extend(defaults, arguments);
	this.args.$target = $(this.args.target);
	if(this.testVideourl()) {
		var that = this;
		that.createVideo();
		
		//ads
		AdController.resetAds();
		AdController.setVideoURL(this.args.videourl);
		var strURL = SMARTCLIP_URL.replace("\[RANDOM\]", 10000000 + Math.floor(Math.random()*10000000));
		AdController.setAdRequest(strURL, 'preRoll', true);
		AdController.startAdLoading(function() {
			AdController.createPlaylist();
			that.play();
		});
		
		//AdController.adCallback(); // <- fail
		
	}
	else {
		this.createImage();
	}
	TRACK.Video('init', this.args.videourl, this.args.data.kicker, this.args.data.title, 
				100, this.args.width+'x'+this.args.height, this.args.autoplay, this.args.preroll, 
				this.args.adString, this.args.firstpublicationdate, this.args.data.doctype, this.args.data.docpath);

};
Videoplayer.prototype.trigger = function(action) {
	var callbackname = 'on'+action.ucfirst();
	if(typeof this.args[callbackname] == 'function') {
		this.args[callbackname](this);
	}
};
Videoplayer.prototype.testVideourl = function() {
	if(this.args.videourl.substr(0,4) != 'http') {
		//console.log('RTMP VIDEO!!!');
		this.args.use = 'image';
		return false;
	}
	return true;
};
Videoplayer.prototype.createImage = function() {
	this.trigger('createImage');
	this.args.$video = $('<img>')
		.attr('width', this.args.width)
		.attr('height', this.args.height)
		.attr('src', this.args.imageurl);
	this.args.$target
		.html('')
		.css({
			width: this.args.width,
			height: this.args.height,
			left: this.args.left,
			top: this.args.top
		})
		.append(this.args.$video)
		.show();
	this.trigger('canNotPlayVideo');
};
Videoplayer.prototype.createVideo = function() {
	var that = this;
	this.trigger('createVideo');
	this.args.$video = $('<video>')
		.attr('type', 'video/mp4')
		.attr('width', '100%')
		.attr('height', '100%');
	this.args.video = this.args.$video.get(0);

	this.args.$target
		.html('')
		.css({
			width: this.args.width,
			height: this.args.height,
			left: this.args.left,
			top: this.args.top
		})
		.append(this.args.$video)
		.show();
	this.trigger('afterCreate');
};
Videoplayer.prototype.play = function() {
	if(this.args.use == 'video') {
		var that = this;
		
		this.args.video.pause();
		var streamItem = AdController.getNextStream();
		if(streamItem) {
			// we must create again here as setting src on boxee does not work!
			this.args.$video = $('<video>')
				.attr('type', 'video/mp4')
				.attr('width', '100%')
				.attr('height', '100%')
				.attr('src', streamItem.urls[0].url);
			this.args.video = this.args.$video.get(0);
			this.args.video.addEventListener('ended', function() {
				that.playing = false;
				that.trigger('streamEnd');
			});
			this.args.video.addEventListener('canplay', function() {
				that.trigger('canPlay');
			});
			this.args.video.addEventListener('play', function() {
				that.playing = true;
				that.trigger('play');
			});
			this.args.$target
				.html('')
				.css({
					width: this.args.width,
					height: this.args.height,
					left: this.args.left,
					top: this.args.top
				})
				.append(this.args.$video)
				.show();			
			
			this.args.video.load();
			this.args.video.play();
			
			// setup timer
			if (this.progressTimer) {
			  clearTimeout(this.progressTimer);
			}
			// call now
			onVideoProgress();
			this.progressTimer = setInterval(function(){ onVideoProgress(); }, 1000); 	    
			function onVideoProgress() {
				AdController.setDuration(that.args.video.duration);
				AdController.onUpdatePlayTime(that.args.video.currentTime);				
			}
			// handle ad/non ad
			this.checkAd();
		}
	}
	else {
		this.trigger('canNotPlayVideo');	
	}
};

Videoplayer.prototype.checkAd = function() {
	if(AdController.isAd(AdController.getActiveStreamIndex())) {
		if(this.args.fullscreen || this.fullscreen) {
			$('#videofullscreenoverlay').show();
			$('#videooverlay').hide();
		}
		else {
			$('#videooverlay').show();			
			$('#videofullscreenoverlay').hide();
		}
	}
	else {
		if(this.args.fullscreen || this.fullscreen) {
			$('#videofullscreenoverlay').hide();					
			//one keydown event for starting all the nice timeouts again
//			App.handleKeyDown({keyCode: -1});
		}
		else {
			$('#videooverlay').hide();
		}
	}
};

Videoplayer.prototype.setFullscreen = function() {
	this.fullscreen = true;
	this.args.$target.css({
		width: SCREEN_WIDTH,
		height: SCREEN_HEIGHT,
		left: 0,
		top: 0
	});
	// handle ad/non ad
	this.checkAd();
};
Videoplayer.prototype.pause = function() {
	this.args.video.pause();
	this.playing = false;
};
Videoplayer.prototype.isPlaying = function() {
	return this.playing;
};
Videoplayer.prototype.getPosition = function() {
	return this.args.video.currentTime;
};
Videoplayer.prototype.setPosition = function(position) {
	this.args.video.currentTime = position;
};
Videoplayer.prototype.destroy = function(from) {
	if (this.progressTimer) {
	  clearTimeout(this.progressTimer);
	}	
	// cancel any pending ad
	AdController.cancelAds();	
	
	if(this.args.use == 'video') {
		this.args.video.pause();
	}
	this.args.$video.remove().hide();
	Loading.stop(this);
	// force ad text to hide
	$('#videooverlay').hide();	
	$('#videofullscreenoverlay').hide();
};