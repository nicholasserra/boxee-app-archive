var OverlayBundesliga = $.inherit(
  // base

  // props
  {
    __constructor: function(options) {
	  this.options = options;

	  this.callback = null;
	  this.nNumFeeds = 3;
	  this.nFeedLoaded = 0;
	  this.nCompetitionID = 0;
      this.nCurrSeasonID = 0;
      this.nCurrMatchDay = 0;
	  	  
	  var self = this;
	  this.options.elemContent.bind('DataFeedManager:loaded', function (evt, param) {self.dfLoaded(evt, param)});

	  this.elemSpieltag = $('.spieltag', this.options.elemContent);
	  this.elemSpieltag.bind('DataFeedManager:loaded', function (evt, param) {self.dfLoaded(evt, param)});
	  this.elemSpieltagContent = $('.items:eq(0)', this.elemSpieltag);
	  
	  this.elemTabelle = $('.tabelle', this.options.elemContent);
	  this.elemTabelle.bind('DataFeedManager:loaded', function (evt, param) {self.dfLoaded(evt, param)});
	        
	  // scroll panel
	  this.scrollPanel = new UIScrollPanel({elemContent:$('.tabelle:eq(0)', this.options.elemContent)});	  
	},	

	update: function(nCompetitionID, callback) {
	  this.nCompetitionID = nCompetitionID;
	  this.callback = callback; 

	  this.nFeedLoaded = 0;
	  // hide content
	  this.elemSpieltagContent.hide();
	  this.scrollPanel.hide();
	  
      DataFeedManager.dropFeeds();
	        
  	  this.scrollPanel.setContent('');  	
	  
	  var strURL = "http://sport-json.bild.de/gs_competition-info/co"+nCompetitionID;
	  DataFeedManager.loadFeed(this.options.elemContent, strURL, true);		
	},
	
	scrollUp: function() {
	  this.scrollPanel.previousItem();
	},
	
	scrollDown: function() {
	  this.scrollPanel.nextItem();
	},
	
	dfLoaded: function(evt, param) {
	  evt.stopPropagation();
	  
	  if (!param.data) {
		return;
	  }
	  
	  this.nFeedLoaded++;
	  
	  var self = this;
	  switch (param.elemFeed.attr('id')) {
	    case 'bl_article':	    	
	      // load views	    	
	  	  $.each(param.data.globalsports.sport.competition, function(key,data) {
	  		switch (key) {
	  		  case '@current_season_id':
	  			self.nCurrSeasonID = data;	  			  
	  			break;
	  		  case '@current_matchday':
	  			self.nCurrMatchDay = data;
	  		    break;
	  		}
	  	  });	  	 
	      // update title
	  	  var elemHeadline = $('.headline:eq(0)', this.elemSpieltag);	  	  
	      App.setHTML(elemHeadline, self.nCurrMatchDay + ". Spieltag");
	      
	  	  // load spieltag
	  	  var strURL = "http://sport-json.bild.de/matches-by-matchday/se"+this.nCurrSeasonID+"/md"+this.nCurrMatchDay;
		  DataFeedManager.loadFeed(this.elemSpieltag, strURL, true);			  	  
	  	  // load tabelle
		  var strURL = "http://sport-json.bild.de/standing/co"+this.nCompetitionID;
		  DataFeedManager.loadFeed(this.elemTabelle, strURL, true);		
		  break;  

	    case 'bl_spieltag':
	  	  var items = [];	  
		  // add teams
		  $.each(param.data[0].matches, function(nMatch,match) {
	  	    items.push('<div class="item"><div class="col1"><div class="datum">'+match.date.substr(8, 2)+'.'+match.date.substr(5, 2)+'.'+match.date.substr(2, 2)+'</div></div><div class="col2"><div class="home"><div class="icon"><img src="http://bilder.bild.de/sportdaten/static/global/gfx/emblem/27x27/'+match.home_id+'.png"/></div><div class="name">'+match.home_name+'</div></div><div class="div"> : </div><div class="away"><div class="icon"><img src="http://bilder.bild.de/sportdaten/static/global/gfx/emblem/27x27/'+match.away_id+'.png"/></div><div class="name">'+match.away_name+'</div></div></div><div class="col3"><span class="lastcol"><div class="score">'+match.full.replace(':', ' : ')+'</div></span></div></div>');  	
		  });
	  	  
	  	  App.setHTML(this.elemSpieltagContent, items.join(''));
	      break;
	      
	    case 'bl_tabelle':
	      // set scroll amount
	      var elemScrollView = $('.scrollview:eq(0)', this.elemTabelle);
		  this.scrollPanel.setScrollAmount(elemScrollView.height());  	  	  	    	
	        
	      // check it's the data we're expecting
	  	  var items = [];	  
		  // add teams
		  $.each(param.data.ranking, function(nRanking,ranking) {
	        items.push('<div class="item"><div class="col1"><div class="pos">'+ranking.rank+'</div><div class="icon"><img src="http://bilder.bild.de/sportdaten/static/global/gfx/emblem/27x27/'+ranking.team_id+'.png"/></div></div><div class="col2">'+ranking.team+'</div><div class="col3">'+ranking.matches+'</div><div class="col4">'+ranking.difference+'</div><div class="col5"><div class="punkte">'+ranking.points+'</div></div></div>');
		  });
	  	  this.scrollPanel.setContent(items.join(''));  	  	  
	      break;
	  }
	  
	  if (this.nFeedLoaded == this.nNumFeeds) {
	  	// show
		this.elemSpieltagContent.show();
		this.scrollPanel.show();
	  	// callback
	  	this.callback();	  	  	  		  
	  }
	}
	
  },
  // static props
  {    
  }
);