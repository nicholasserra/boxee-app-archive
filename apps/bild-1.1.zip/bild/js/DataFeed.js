var DataFeed = $.inherit(
  // base
	
  // props
  {
	__constructor: function(options) {
      this.options = options;

  	  this.XHRObj = null;
  	  this.elemFeed = null;
  	  this.bJSON = true;
  	  this.xmlHttpTimeout = null;
	},
	
  	load: function(elemFeed, strURL, bJSON) {
  	  this.elemFeed = elemFeed;
  	  this.bJSON = bJSON;
  	  
  	  var self = this;
  	  if (this.xmlHttpTimeout) {
  		clearTimeout(this.xmlHttpTimeout);  
  	  }  	  
  	  this.xmlHttpTimeout = setTimeout(function(){ self.ajaxTimeout(); }, 20000);
	  switch (App.identify()) {
	  	case DEVICE_SAMSUNG:
  	      if (this.XHRObj != null) this.XHRObj.destroy();
  	    	
  	      this.XHRObj = new XMLHttpRequest(); 
  	      if (this.XHRObj) { 
  	        this.XHRObj.onreadystatechange = function () { 
  	          if (self.XHRObj.readyState == 4) { 
  	            recieveData(); 
  	          } 
  	        }; 
  	        this.XHRObj.open("GET", strURL, true); 
  	        this.XHRObj.send(null); 
  	      } 

  	      recieveData = function () {
  	      	if (bJSON) {
  	      	  self.loaded(jQuery.parseJSON(self.XHRObj.responseText));    		    		
  	        }
  	        else {
  	      	  self.loaded(self.XHRObj.responseText);
  	        }    		
  	      }
  	      break;
  	      
  	    default:
  	      if (bJSON) {
  			if(JSON_WRAPPER_BASEURL.length > 0) {
			  strURL = JSON_WRAPPER_BASEURL+strURL;
			}
			
			$.ajax({
			  url: strURL,
			  dataType: JSON_WRAPPER_BASEURL.length > 0 ? 'jsonp' : 'json',
			  jsonp: 'jsonp_callback',
			  success: function(data) {
	    	    self.loaded(data);
	    	  },
			  error: function() {
				Error.show('Es ist ein Fehler aufgetreten (404)');
			  },
			});
  	      }
  	      else {
  	   	    $.ajax({
  	      	  type: "GET",
  	          url: strURL,
  	          dataType: "html",
  	          success: function(data) {
  	       	    self.loaded(data);
  	          }
  	        });    	  
  	      }
  	      break;
  	  }
  	},
  	
  	ajaxTimeout: function() {  		
      // fire event
      $(this.options.elemContent).trigger('DataFeed:timedout', { elemFeed:this.elemFeed });		             	   
   	},
  	
   	loaded: function(data) {   		
  	  if (data) {
    	clearTimeout(this.xmlHttpTimeout); 
        // fire event
        $(this.options.elemContent).trigger('DataFeed:loaded', { elemFeed:this.elemFeed, data:data });		          
  	  }
  	}
  	
  },
  // static props
  {	    
  }
);