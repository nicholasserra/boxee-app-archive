from default import *

import api
import xbmc
from threading import Thread
import traceback

window = mc.GetWindow(14000)
config = mc.GetApp().GetLocalConfig()

class init:
    def __init__(self):
        """Init main Application"""
        self.tuner   = False
        self.menu = {
            'REFRESH LIST':'refresh',
            'SETUP N7 TUNER':'find',
            'SELECT CHANNEL':'select',
        }
        mc.ShowDialogWait()

        #Initialize N7 setup
        self.setup()
        #get channel list
        self.fetch_channels()
        #render the left menu
        self.render_menu()

        #disable splash screen
        window.GetControl(300).SetVisible(False)

        #DISABLED FOR NOW : for 1.0 NO EPG!
        #self.epg = _EPG()
        #self.epg.start()
        
        mc.HideDialogWait()

    def setup(self, force=False):
        """Setup N7 Tuner"""
        n7 = config.GetValue("N7")
        warning = config.GetValue("warning")

        #Give warning for first time use
        if warning != 'done':
            info = mc.ShowDialogConfirm("Njoy N7 TV APP", "To use this app and watch live television, you need an Anysee N7 TV Tuner. Do you have this tuner and is it setup correctly?", "Exit", "Continue")
            if info:
                config.SetValue("warning", "done")
            else:
                window.ClearStateStack(False)
                mc.CloseWindow()

        #check n7 ip in cache
        if n7 and not force:
            if api.request(n7, api.DISCOVER, True):
                self.tuner = n7
                print "%s - N7 tuner ip loaded from cache: %s" % (APPID, n7, )
                return
            else:
                mc.ShowDialogOk("Error", "Tuner not found at ip %s" % (n7, ))

        #Automatic scan
        if mc.ShowDialogConfirm("Please Choose", "Scan for a N7 network TV tuner or enter it's IP/hostname manually.", "Manually", "Scan"):
            scanner = api.scan()
            if scanner.run():
                if len(scanner.n7) > 1:
                    n7 = mc.ShowDialogSelect("Multiple Tuners Found, Please Choose", scanner.n7)
                else:
                    n7 = scanner.n7[0]
                    mc.ShowDialogNotification("N7 Tuner found at %s" % n7)
                config.SetValue("N7", n7)
                self.tuner = n7
                print "%s - N7 tuner selected: %s" % (APPID, n7, )
                del scanner
                return
            else:
                mc.ShowDialogNotification("No N7 tuner found during the scan.")

        #Manual IP
        n7 = mc.ShowDialogKeyboard("Enter IP number of N7 netwerktuner", "", False)
        if api.request(n7, api.DISCOVER, True):
            config.SetValue("N7", n7)
            mc.ShowDialogNotification("N7 Tuner found at %s" % n7)
            self.tuner = n7
            print "%s - N7 tuner manually entered: %s" % (APPID, n7, )
        else:
            mc.ShowDialogOk("Error", "Tuner not found at ip %s" % (n7, ))
            mc.ShowDialogNotification("Closing application in 3 seconds")
            config.SetValue("N7", "")
            xbmc.sleep(3000)
            window.ClearStateStack(False)
            mc.CloseWindow()

    def fetch_channels(self):
        """get channel list"""
        if self.tuner:
            items = api.channel_list(self.tuner)
            if items:
                window.GetList(120).SetItems(items)
            else:
                mc.ShowDialogOk("Error", "Could not get Channel List, try to setup the tuner again")

    def render_menu(self):
        """render left menu"""
        items = mc.ListItems()
        for (k, v) in self.menu.items():
            item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
            item.SetLabel(k)
            item.SetProperty('action', v)
            if self.tuner:
                item.SetProperty('tuner', self.tuner)
            items.append(item)
        window.GetList(110).SetItems( items )

    def process_menu(self):
        """left menu actions"""
        list   = window.GetList(110)
        focus  = list.GetFocusedItem()
        action = list.GetItem(focus).GetProperty("action")
        
        if action == 'find':
            mc.ShowDialogWait()
            self.setup(True)
            self.fetch_channels()
            mc.HideDialogWait()

        elif action == 'refresh':
            mc.ShowDialogWait()
            self.fetch_channels()
            window.GetControl(120).SetFocus()
            self.render_menu()
            mc.HideDialogWait()

        elif action == 'select':
            import xbmcgui
            dialog = xbmcgui.Dialog()
            focus = dialog.numeric(0, 'Input Channel Number')
            if focus:
                list   = window.GetList(120)
                window.GetControl(120).SetFocus()
                list.SetFocusedItem( int(focus) -1 )

class _EPG(Thread):
    """init epg class"""
    def __init__ (self):
        Thread.__init__(self)
        self.active = True

    def run(self):
        """main epg poller, checks every 2 seconds if focus has changed."""
        last = ''
        count = 0
        while self.active:
            try:
                list    = window.GetList(120)
                focus   = list.GetFocusedItem()
                thumb   = list.GetItem(focus).GetThumbnail()
                current = thumb.rsplit('/', 1)[1].replace('.png', '').replace('.jpg', '').replace('_', '%20')
                if last != current:
                    self.reset_epg()
                    count = 0
                else:
                    if count == 4:
                        data = api.get_internet_epg( current )
                        self.push_epg(data)
                    count += 1
                last = current
                xbmc.sleep(500)
            except:
                #if DEBUG:
                #    traceback.print_exc()
                pass

    
    def push_epg(self, data):
        """set epg data to gui"""
        window.GetLabel(200).SetLabel( data['current'].encode('utf-8') )
        window.GetLabel(201).SetLabel( data['next'].encode('utf-8') )

    def reset_epg(self):
        """reset epg data in gui"""
        window.GetLabel(200).SetLabel('')
        window.GetLabel(201).SetLabel('')

    def stop(self):
        """stop epg polling thread"""
        self.active = False
