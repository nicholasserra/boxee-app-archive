import mc
import os
import sys

VERSION = "1.00"
CWD     = os.getcwd().replace(";","")
APPID   = mc.GetApp().GetId()
DEBUG   = True

sys.path.append(os.path.join(CWD, 'libs'))
sys.path.append(os.path.join(CWD, 'external'))

if ( __name__ == "__main__" ):
    mc.ActivateWindow(14000)

    import app
    MAIN = app.init()

