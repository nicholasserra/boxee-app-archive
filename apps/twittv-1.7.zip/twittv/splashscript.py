AppVersion = "1.7"
AppDate = "08/09/2012"