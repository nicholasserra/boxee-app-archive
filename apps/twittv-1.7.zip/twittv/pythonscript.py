import mc
import splashscript
from urllib import quote_plus, urlencode
config = mc.GetApp().GetLocalConfig()
window = mc.GetWindow(14001)

if config.GetValue("settingsversion") == "":
	config.SetValue("settingsversion", "1.7")
	if config.GetValue("lastlivestream") == "121":
		config.SetValue("lastlivestream", "2201")
	if config.GetValue("lastlivestream") == "122":
		config.SetValue("lastlivestream", "2202")
	if config.GetValue("lastlivestream") == "123":
		config.SetValue("lastlivestream", "2204")
	if config.GetValue("lastlivestream") == "124":
		config.SetValue("lastlivestream", "2203")
	if config.GetValue("lastlivestream") == "125":
		config.SetValue("lastlivestream", "2205")
	if config.GetValue("lastlivestream") == "126":
		config.SetValue("lastlivestream", "2209")

DefaultTab = config.GetValue("defaultwindow")
LastActiveTab = config.GetValue("lastactivewindow")
LastLiveStream = config.GetValue("lastlivestream")
ShowsRSS = config.GetValue("showsrss")
SettingsVersion = config.GetValue("settingsversion")
ShowList_SD_High = "rss://breedingbits.com/twit/boxee/ShowList_SD_High.xml"
ShowList_SD_Low = "rss://breedingbits.com/twit/boxee/ShowList_SD_Low.xml"
ShowList_Audio = "rss://breedingbits.com/twit/boxee/ShowList_Audio.xml"
ShowList_HD = "rss://breedingbits.com/twit/boxee/ShowList_HD.xml"
RecentList_Audio = "http://pipes.yahoo.com/pipes/pipe.run?_id=f313a71c58d6fbec2422b3f516738528&_render=rss"
RecentList_SD_Low = "http://pipes.yahoo.com/pipes/pipe.run?_id=2ed081fa986cfc8e8c669216047c983b&_render=rss"
RecentList_SD_High = "http://pipes.yahoo.com/pipes/pipe.run?_id=b738200ec23a915938f2a606188f7dc3&_render=rss"
RecentList_HD = "rss://pipes.yahoo.com/pipes/pipe.run?_id=17e0b1688f7053b4873e033dd0f3bf07&_render=rss"
RecentRSS = config.GetValue("recentrss")

def Window_OnLoad():
	if config.GetValue("showsrss") == "":
		config.SetValue("showsrss", ShowList_SD_High)
		config.SetValue("showsquality", "SD High")
	if config.GetValue("recentrss") == "":
		config.SetValue("recentrss", RecentList_SD_High)
	if not window.GetControl(2100).IsVisible() and not window.GetControl(2200).IsVisible() and not window.GetControl(2300).IsVisible() and not window.GetControl(2400).IsVisible():
		if DefaultTab == "":
			config.SetValue("defaultwindow", "lastactivewindow")
			mc.GetWindow(14001).GetControl(2200).SetVisible(True)
			if LastLiveStream == "":
				mc.GetWindow(14001).GetControl(2204).SetFocus()
			else:
				mc.GetWindow(14001).GetControl(int(LastLiveStream)).SetFocus()
		elif DefaultTab == "watchlive":
			mc.GetWindow(14001).GetControl(2200).SetVisible(True)
			if LastLiveStream == "":
				mc.GetWindow(14001).GetControl(2204).SetFocus()
			else:
				mc.GetWindow(14001).GetControl(int(LastLiveStream)).SetFocus()
		elif DefaultTab == "shows":
			mc.GetWindow(14001).GetControl(2300).SetVisible(True)
			mc.GetWindow(14001).GetControl(2302).SetFocus()
		elif DefaultTab == "recent":
			mc.GetWindow(14001).GetControl(2400).SetVisible(True)
			mc.GetWindow(14001).GetControl(2400).SetFocus()
		elif DefaultTab == "lastactivewindow":
			if LastActiveTab == "watchlive":
				mc.GetWindow(14001).GetControl(2200).SetVisible(True)
				if LastLiveStream == "":
					mc.GetWindow(14001).GetControl(2204).SetFocus()
				else:
					mc.GetWindow(14001).GetControl(int(LastLiveStream)).SetFocus()
			elif LastActiveTab == "shows":
				mc.GetWindow(14001).GetControl(2300).SetVisible(True)
				mc.GetWindow(14001).GetControl(2302).SetFocus()
			elif LastActiveTab == "recent":
				mc.GetWindow(14001).GetControl(2400).SetVisible(True)
				mc.GetWindow(14001).GetControl(2400).SetFocus()
			else:
				mc.GetWindow(14001).GetControl(2200).SetVisible(True)
				if LastLiveStream == "":
					mc.GetWindow(14001).GetControl(2204).SetFocus()
				else:
					mc.GetWindow(14001).GetControl(int(LastLiveStream)).SetFocus()
		else:
			mc.GetWindow(14001).GetControl(2400).SetVisible(True)
			mc.GetWindow(14001).GetControl(2400).SetFocus()
		mc.GetActiveWindow().GetLabel(2142).SetLabel("App Version: " + splashscript.AppVersion)
		mc.GetActiveWindow().GetLabel(2143).SetLabel("Release Date: " + splashscript.AppDate)
		mc.GetActiveWindow().GetLabel(2304).SetLabel(config.GetValue("showsquality"))
		mc.GetActiveWindow().GetList(2302).SetContentURL(config.GetValue("showsrss"))
		mc.GetActiveWindow().GetList(2401).SetContentURL(config.GetValue("recentrss"))
			
def MenuButton_OnClick(ButtonID):
	if ButtonID == "1101":
		mc.GetWindow(14001).GetControl(2200).SetVisible(False)
		mc.GetWindow(14001).GetControl(2300).SetVisible(False)
		mc.GetWindow(14001).GetControl(2400).SetVisible(False)
		mc.GetWindow(14001).GetControl(2100).SetVisible(True)
		mc.GetWindow(14001).GetControl(2100).SetFocus()
		if config.GetValue("defaultwindow") == "lastactivewindow":
			window.GetToggleButton(2111).SetSelected(True)
		elif config.GetValue("defaultwindow") == "watchlive":
			window.GetToggleButton(2112).SetSelected(True)
		elif config.GetValue("defaultwindow") == "shows":
			window.GetToggleButton(2113).SetSelected(True)
		elif config.GetValue("defaultwindow") == "recent":
			window.GetToggleButton(2114).SetSelected(True)
		else:
			config.SetValue("defaultwindow", "lastactivewindow")
			window.GetToggleButton(2111).SetSelected(True)
		if config.GetValue("showsquality") == "Audio Only":
			window.GetToggleButton(2121).SetSelected(True)
		elif config.GetValue("showsquality") == "SD Low":
			window.GetToggleButton(2122).SetSelected(True)
		elif config.GetValue("showsquality") == "SD High":
			window.GetToggleButton(2123).SetSelected(True)
		elif config.GetValue("showsquality") == "HD":
			window.GetToggleButton(2124).SetSelected(True)
		else:
			config.SetValue("showsquality", "SD High")
			config.SetValue("showsrss", ShowList_SD_High)
			window.GetToggleButton(2123).SetSelected(True)
	if ButtonID == "1102":
		mc.GetWindow(14001).GetControl(2100).SetVisible(False)
		mc.GetWindow(14001).GetControl(2300).SetVisible(False)
		mc.GetWindow(14001).GetControl(2400).SetVisible(False)
		config.SetValue("lastactivewindow", "watchlive")
		mc.GetWindow(14001).GetControl(2200).SetVisible(True)
		mc.GetWindow(14001).GetControl(2200).SetFocus()
	if ButtonID == "1103":
		mc.GetWindow(14001).GetControl(2100).SetVisible(False)
		mc.GetWindow(14001).GetControl(2200).SetVisible(False)
		mc.GetWindow(14001).GetControl(2400).SetVisible(False)
		config.SetValue("lastactivewindow", "shows")
		if window.GetControl(2310).IsVisible():
			mc.GetWindow(14001).GetControl(2310).SetFocus()
		else:
			mc.GetWindow(14001).GetControl(2302).SetFocus()
		mc.GetWindow(14001).GetControl(2300).SetVisible(True)
	if ButtonID == "1104":
		mc.GetWindow(14001).GetControl(2100).SetVisible(False)
		mc.GetWindow(14001).GetControl(2200).SetVisible(False)
		mc.GetWindow(14001).GetControl(2300).SetVisible(False)
		config.SetValue("lastactivewindow", "recent")
		mc.GetWindow(14001).GetControl(2400).SetVisible(True)
		mc.GetWindow(14001).GetControl(2400).SetFocus()
		
def MenuButton_OnDown():
	if window.GetControl(2100).IsVisible():
	   window.GetControl(2100).SetFocus()
	if window.GetControl(2200).IsVisible():
	   window.GetControl(2200).SetFocus()
	if window.GetControl(2300).IsVisible():
	   window.GetControl(2300).SetFocus()
	if window.GetControl(2400).IsVisible():
	   window.GetControl(2400).SetFocus()
	   
def DefaultTabToggle_OnClick(ButtonID):
	window.GetToggleButton(2111).SetSelected(False)
	window.GetToggleButton(2112).SetSelected(False)
	window.GetToggleButton(2113).SetSelected(False)
	window.GetToggleButton(2114).SetSelected(False)
	if ButtonID == "2111":
		window.GetToggleButton(2111).SetSelected(True)
		config.SetValue("defaultwindow", "lastactivewindow")
	elif ButtonID == "2112":
		window.GetToggleButton(2112).SetSelected(True)
		config.SetValue("defaultwindow", "watchlive")
	elif ButtonID == "2113":
		window.GetToggleButton(2113).SetSelected(True)
		config.SetValue("defaultwindow", "shows")
	elif ButtonID == "2114":
		window.GetToggleButton(2114).SetSelected(True)
		config.SetValue("defaultwindow", "recent")
	else:
		window.GetToggleButton(2111).SetSelected(True)
		config.SetValue("defaultwindow", "lastactivewindow")
		
def DefaultTabToggle_AltClick(ButtonID):
	window.GetToggleButton(2111).SetSelected(False)
	window.GetToggleButton(2112).SetSelected(False)
	window.GetToggleButton(2113).SetSelected(False)
	window.GetToggleButton(2114).SetSelected(False)
	if ButtonID == "2111":
		window.GetToggleButton(2112).SetSelected(True)
		config.SetValue("defaultwindow", "watchlive")
	elif ButtonID == "2112":
		window.GetToggleButton(2111).SetSelected(True)
		config.SetValue("defaultwindow", "lastactivewindow")
	elif ButtonID == "2113":
		window.GetToggleButton(2111).SetSelected(True)
		config.SetValue("defaultwindow", "lastactivewindow")
	elif ButtonID == "2114":
		window.GetToggleButton(2111).SetSelected(True)
		config.SetValue("defaultwindow", "lastactivewindow")
	else:
		window.GetToggleButton(2111).SetSelected(True)
		config.SetValue("defaultwindow", "lastactivewindow")

def ShowQualityToggle_OnClick(ButtonID):
	window.GetToggleButton(2121).SetSelected(False)
	window.GetToggleButton(2122).SetSelected(False)
	window.GetToggleButton(2123).SetSelected(False)
	window.GetToggleButton(2124).SetSelected(False)
	if ButtonID == "2121":
		window.GetToggleButton(2121).SetSelected(True)
		config.SetValue("showsquality", "Audio Only")
		config.SetValue("showsrss", ShowList_Audio)
		config.SetValue("recentrss", RecentList_Audio)
	elif ButtonID == "2122":
		window.GetToggleButton(2122).SetSelected(True)
		config.SetValue("showsquality", "SD Low")
		config.SetValue("showsrss", ShowList_SD_Low)
		config.SetValue("recentrss", RecentList_SD_Low)
	elif ButtonID == "2123":
		window.GetToggleButton(2123).SetSelected(True)
		config.SetValue("showsquality", "SD High")
		config.SetValue("showsrss", ShowList_SD_High)
		config.SetValue("recentrss", RecentList_SD_High)
	elif ButtonID == "2124":
		window.GetToggleButton(2124).SetSelected(True)
		config.SetValue("showsquality", "HD")
		config.SetValue("showsrss", ShowList_HD)
		config.SetValue("recentrss", RecentList_HD)
	else:
		window.GetToggleButton(2123).SetSelected(True)
		config.SetValue("showsquality", "SD High")
		config.SetValue("showsrss", ShowList_SD_High)
		config.SetValue("recentrss", RecentList_SD_High)
	mc.GetActiveWindow().GetList(2302).SetContentURL(config.GetValue("showsrss"))
	mc.GetActiveWindow().GetLabel(2304).SetLabel(config.GetValue("showsquality"))
	mc.GetActiveWindow().GetList(2401).SetContentURL(config.GetValue("recentrss"))
		
def ShowQualityToggle_AltClick(ButtonID):
	window.GetToggleButton(2121).SetSelected(False)
	window.GetToggleButton(2122).SetSelected(False)
	window.GetToggleButton(2123).SetSelected(False)
	window.GetToggleButton(2124).SetSelected(False)
	if ButtonID == "2121":
		window.GetToggleButton(2123).SetSelected(True)
		config.SetValue("showsquality", "SD High")
		config.SetValue("showsrss", ShowList_SD_High)
		config.SetValue("recentrss", RecentList_SD_High)
	elif ButtonID == "2122":
		window.GetToggleButton(2123).SetSelected(True)
		config.SetValue("showsquality", "SD High")
		config.SetValue("showsrss", ShowList_SD_High)
		config.SetValue("recentrss", RecentList_SD_High)
	elif ButtonID == "2123":
		window.GetToggleButton(2122).SetSelected(True)
		config.SetValue("showsquality", "SD Low")
		config.SetValue("showsrss", ShowList_SD_Low)
		config.SetValue("recentrss", RecentList_SD_Low)
	elif ButtonID == "2124":
		window.GetToggleButton(2123).SetSelected(True)
		config.SetValue("showsquality", "SD High")
		config.SetValue("showsrss", ShowList_SD_High)
		config.SetValue("recentrss", RecentList_SD_High)
	else:
		window.GetToggleButton(2123).SetSelected(True)
		config.SetValue("showsquality", "SD High")
		config.SetValue("showsrss", ShowList_SD_High)
		config.SetValue("recentrss", RecentList_SD_High)
	mc.GetActiveWindow().GetList(2302).SetContentURL(config.GetValue("showsrss"))
	mc.GetActiveWindow().GetLabel(2304).SetLabel(config.GetValue("showsquality"))
	mc.GetActiveWindow().GetList(2401).SetLContentURL(config.GetValue("recentrss"))

def playHlsStream(stream):
   #set playlist stream bandwith, 0, 1, A (low, high, adaptive)
   params = { 'quality': stream['quality'] }
 
   #build stream url
   playlist_url = "playlist://%s?%s" % (quote_plus(stream['url']), urlencode(params))
 
   #build Boxee listitem and set properties
   item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_EPISODE)
   item.SetPath(playlist_url)
   item.SetLabel(stream['title'])
   item.SetContentType('application/vnd.apple.mpegurl')
 
   #initialize the Boxee player and pass our listitem
   mc.GetPlayer().Play(item)