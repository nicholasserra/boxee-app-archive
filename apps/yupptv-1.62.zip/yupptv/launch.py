import mc
def launch():
    params = mc.Parameters()
    app = mc.GetApp()
    app.RunScript('utils', params)
launch()
