import mc
import urllib
from urllib import quote_plus, urlencode
from xml.dom import minidom



player = None
uid = None
def prepareurl(x):
    urlstring=x;
    username_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_username")
    password_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_password")
    if ((username_string != "") and (username_string != False)):
        if ((password_string != "") and (password_string != False)):
            urlstring=urlstring+"&Loginid="+username_string.strip()+"&pwd="+password_string.strip()
        else:
            urlstring=urlstring+"&Loginid=&pwd="
    else:
        urlstring=urlstring+"&Loginid=&pwd="
    return urlstring
def get_packagesList():
    urlstring=prepareurl('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=2')
    dom = minidom.parse(urllib.urlopen(str(urlstring)))
    channelList = mc.ListItems()
    for node in dom.getElementsByTagName('Pack'):
        item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
	item.SetPath(str(node.getAttribute('Channels')))
	item.SetLabel(str(node.getAttribute('Desc')))
	item.SetThumbnail(str(node.getAttribute('Img')))
	item.SetProperty("Pakid", str(node.getAttribute('id')))
	channelList.append(item)
    return channelList
def get_ChannelsFree():
    urlstring=prepareurl('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=5')
    dom = minidom.parse(urllib.urlopen(str(urlstring)))
    channelList = mc.ListItems()
    for node in dom.getElementsByTagName('Channel'):
        item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
	item.SetPath(str(node.getAttribute('url')))
	item.SetLabel(str(node.getAttribute('Desc')))
	item.SetThumbnail(str(node.getAttribute('Img')))
	item.SetProperty("chid", str(node.getAttribute('id')))
	channelList.append(item)
    return channelList
def get_ChannelsList(z):
    urlstring=prepareurl('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=3&bxPkid='+z)
    dom = minidom.parse(urllib.urlopen(str(urlstring)))
    channelList = mc.ListItems()
    for node in dom.getElementsByTagName('Channel'):
        item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
        item.SetPath(str(node.getAttribute('Img')))
        item.SetLabel(str(node.getAttribute('Desc')))
	item.SetThumbnail(str(node.getAttribute('Img')))
	item.SetProperty("vodid", str(node.getAttribute('vodid')))
	item.SetProperty("chid", str(node.getAttribute('id')))
	channelList.append(item)
    return channelList
def get_VodDatesList():
    urlstring=prepareurl('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=6')
    dom = minidom.parse(urllib.urlopen(str(urlstring)))
    channelList = mc.ListItems()
    for node in dom.getElementsByTagName('Dt'):
        item = mc.ListItem(mc.ListItem.MEDIA_UNKNOWN)
	item.SetLabel(str(node.getAttribute('disp')))
	item.SetProperty("chid", str(node.getAttribute('chid')))
	item.SetProperty("vodDt", str(node.getAttribute('id')))
	channelList.append(item)
    return channelList
def get_VodList(x,y,z):
    urlstring=prepareurl('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=4&bxchannelid='+x+'&bxvoddt='+y)
    dom = minidom.parse(urllib.urlopen(str(urlstring)))
    channelList = mc.ListItems()
    for node in dom.getElementsByTagName('Channel'):
        item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_OTHER)
        item.SetPath(str(node.getAttribute('Img')))
	item.SetThumbnail(str(node.getAttribute('Img')))
	item.SetProperty("id", str(node.getAttribute('id')))
	item.SetProperty("chid", str(node.getAttribute('chid')))
	item.SetProperty("url", str(node.getAttribute('url')))
	item.SetLabel(str(z) + "     " + str(node.getAttribute('title')) + "     "+ str(node.getAttribute('Time')))
	channelList.append(item)
    return channelList
def launchChannels(z):
    params = {
            "id": z
    }
    p = mc.Parameters()
    if (params != False):
        for i in params:
            p[i] = params[i]
    mc.GetApp().ActivateWindow(14001,p)
def launchVods(z):
    params = {
            "vid": z
    }
    p = mc.Parameters()
    if (params != False):
        for i in params:
            p[i] = params[i]
    mc.GetApp().ActivateWindow(14002,p)
def playurl(x,y,z):
    playurl=""
    if (x==0):
        playurl="https://www.yupptv.com/forms/boxeeplayer.aspx?ChanId="+str(y)
    else:
        username_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_username")
        password_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_password")
        if (z==0):
            playurl="https://www.yupptv.com/forms/boxeeplayer.aspx?ChanId="+str(y)+"&Loginid="+username_string.strip()+"&pwd="+password_string.strip()+"&vod=0"
        else:
            playurl="https://www.yupptv.com/forms/boxeeplayer.aspx?ChanId="+str(y)+"&Loginid="+username_string.strip()+"&pwd="+password_string.strip()+"&vod=1"
    return playurl
def playurlLive(x,y,z):
    playurl=""
    if (x==0):
        playurl="https://www.yupptv.com/forms/boxeeplayerxml.aspx?ChanId="+str(y)
    else:
        username_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_username")
        password_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_password")
        playurl="https://www.yupptv.com/forms/boxeeplayerxml.aspx?ChanId="+str(y)+"&Loginid="+username_string.strip()+"&pwd="+password_string.strip()+"&vod=0"
    dom = minidom.parse(urllib.urlopen(playurl))
    for node in dom.getElementsByTagName('url'):
        playurl=node.getAttribute('stream')
    return str(playurl.strip())
def playHlsStream(stream,name):
    params = { 'live': '1' }
    playlist_url = "playlist://%s?%s" % (quote_plus(str(stream)), urlencode(params))
    item = mc.ListItem(mc.ListItem.MEDIA_VIDEO_EPISODE)
    item.SetPath(playlist_url)
    item.SetLabel(str(name))
    item.SetContentType('application/vnd.apple.mpegurl')
    mc.GetPlayer().Play(item)
def login_user(z):
    uid=""
    subscribe=""
    result="0"
    mc.ShowDialogWait()
    username_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_username")
    password_string = mc.GetApp().GetLocalConfig().GetValue("yupptv_password")
    if (username_string.strip() == ''):
        username_string=''
        password_string=''
        username_string = mc.ShowDialogKeyboard("Please enter your YUPPTV Username:", "", False)
        password_string = mc.ShowDialogKeyboard("Please enter your YUPPTV Password:", "", True)
        if ((username_string != "") and (username_string != False)):
                if ((password_string != "") and (password_string != False)):
                    dom = minidom.parse(urllib.urlopen('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=1&bxeid='+username_string.strip()+'&bxepass='+password_string.strip()+'&bxpackid='+z.strip()))
                    for node in dom.getElementsByTagName('status'):
                        uid = str(node.getAttribute('uid'))
                        subscribe=str(node.getAttribute('subscribed'))
                        if(uid.strip() == ''):
                            mc.GetWindow(14000).GetToggleButton(132).SetSelected(False)
                        else:
                            mc.GetApp().GetLocalConfig().SetValue("yupptv_username", username_string)
                            mc.GetApp().GetLocalConfig().SetValue("yupptv_password", password_string)
                            mc.GetWindow(14000).GetToggleButton(132).SetSelected(True)
    else:
        dom = minidom.parse(urllib.urlopen('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=1&bxeid='+username_string.strip()+'&bxepass='+password_string.strip()+'&bxpackid='+z.strip()))
        for node in dom.getElementsByTagName('status'):
            uid = str(node.getAttribute('uid'))
            subscribe=str(node.getAttribute('subscribed'))
    mc.HideDialogWait()
    if ((uid.strip()=='') and (subscribe.strip()=='')):
        result="0"
    elif ((uid.strip()!='') and (subscribe.strip()=='')):
        result="1"
    else:
        result="2"
    return result.strip()
def relogin_user():
    uid=""
    mc.ShowDialogWait()
    mc.GetApp().GetLocalConfig().SetValue("yupptv_username", '')
    mc.GetApp().GetLocalConfig().SetValue("yupptv_password", '')
    username_string = mc.ShowDialogKeyboard("Please enter your YUPPTV Username:", "", False)
    password_string = mc.ShowDialogKeyboard("Please enter your YUPPTV Password:", "", True)
    if ((username_string != "") and (username_string != False)):
        if ((password_string != "") and (password_string != False)):
            dom = minidom.parse(urllib.urlopen('https://www.yupptv.com/boxee/boxee.aspx?Bxefn=1&bxeid='+username_string.strip()+'&bxepass='+password_string.strip()))
            for node in dom.getElementsByTagName('status'):
                uid = str(node.getAttribute('uid'))
                if (uid.strip() == ''):
                    mc.GetWindow(14000).GetToggleButton(132).SetSelected(False)
                else:
                    mc.GetApp().GetLocalConfig().SetValue("yupptv_username", username_string)
                    mc.GetApp().GetLocalConfig().SetValue("yupptv_password", password_string)
                    mc.GetWindow(14000).GetToggleButton(132).SetSelected(True)
    mc.HideDialogWait()
    return uid.strip()
def Get_Player():
    global player
    player = mc.GetPlayer()
    return player
mc.ActivateWindow(14000)

