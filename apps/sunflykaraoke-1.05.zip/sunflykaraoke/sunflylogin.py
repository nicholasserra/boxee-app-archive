'''
TriceraSoft
'''

import mc

def login():
    try:
        username = mc.ShowDialogKeyboard('Sunfly: USERNAME', '', False)
        password = mc.ShowDialogKeyboard('Sunfly: PASSWORD', '', True)

        if not username or not password:
            raise Exception('Missing username or password!')

        keys = {'key1': username, 'key2': password}
        return keys
    except Exception, e:
        mc.ShowDialogOk('Sunfly Karaoke Login', 'Login Failure: ' + str(e))
        return False